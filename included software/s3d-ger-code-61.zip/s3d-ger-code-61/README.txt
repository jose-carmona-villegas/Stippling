TO COMPILE IN UNIX/LINUX:
   Type: make help

TO COMPILE IN WINDOWS:
   Add SYSTEM=mingw to compile with mingw in windows:
       $> make SYSTEM=mingw all

    /--------------------------------------------------------\
   |                      S3D-GER Library (S3D)               |
   |          Simple 3D Graphical Engine for Research         |
    \--------------------------------------------------------/



* To make the library try:
    make all
* To install the library (default) try:
    make install
* To uninstall the library (default) try:
    make uninstall
* To install or uninstall the library in a directory try:
    make install INSTALLPATH=/directory/
    make uninstall INSTALLPATH=/directory/

    WARNING: INSTALLPATH must be a full path without ~ 
             and it must finish with /
* To compile the documentation type:
    make documentation

* To clean (or hard clean) the files try:
    make clean   or    make mrpropper

PLEASE: Before commit any file to the repository use: make mrpropper
