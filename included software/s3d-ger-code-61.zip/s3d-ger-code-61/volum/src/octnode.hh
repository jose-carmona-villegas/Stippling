#ifndef __OCTNODE__
#define __OCTNODE__

#include <iostream>
#include <math.h>
#include <SDL/SDL_image.h>
#include <GL/glew.h>

#include "primitive3d.hh"
#include "dataset.hh"

/** @class   S3DOctNode octnode.hh
 *  @author  Germ�n Arroyo
 *  @date    2007
 *  @brief   This class is a node of an octree for volumetric data
 *
 *  @bug     No bugs detected yet, some things to do, double data not tested
 *  @warning May be issues with the double data (not tested yet)
 */

class S3DOctNode {
   public:

      /// Stop of subdivide the octree when there are a per cent empty
      static const unsigned int STOP_PERCENT         = 0x01;

      /// Stop of subdivide the octree when the size is equal or less
      static const unsigned int STOP_SIZE            = 0x02;

      /// Stop of subdivide the octree when reached the level of the tree
      static const unsigned int STOP_LEVEL           = 0x03;




      /** 
       * @post Constructor. Inizialite the empty node.
       */
      S3DOctNode(void);

      /** 
       * @pre data must be a valid data
       * @post Constructor. Inizialite a non empty node
       * @warning This object will not free data
       * @param[in] s The surface
       */
      S3DOctNode(S3DDataSet *data);

      /**
       * @post Constructor copy. It is unfinished (TODO).
       */
      S3DOctNode(S3DOctNode &node);
      
      /** @post Destructor. Memory is freed here.
       */
      ~S3DOctNode(void);

      /**
       * @pre  pos cannot be greater than 7
       * @post A child of this node, 0 if it does not exist
       * @param[in] pos The number of the children or the position as bits: ZYX
       */
      S3DOctNode *getChild (unsigned char pos);


      /**
       * @pre  
       * @post Prepare the data for render
       * @warnig You should call this method ONLY once or when the data change
       */
      void directPreRender (void);

      /**
       * @pre  directPreRender method must be called before
       * @post Render the data of this node with direct rendering,
               if it has no data, it do nothing
       */
      void directRender (unsigned int numslizes);

      /**
       * @post Render the data of this node as points, 
               if it has no data, it do nothing
       */
      void pointsRender(void);

      /**
       * @post Rotate the volume in the node
       */
      double rotate(double x, double y, double z);

      /**
       * @post The used memory by this node and its children
       */
      double usedMemory(void);

      /**
       * @post Draw the bounding box of this node
       * @param[in] solid If render only the wire or fill the face too
       */
      void bboxRender(bool solid);

      /**
       * @post Subdivide a node and make an octree from it
       * @param[in] criteria It is the criteria of when to stop
       * @param[in] value This values changes according to the criteria:
                    1. STOP_PERCENT: The percent of empty values
                    2. STOP_SIZE: The minimal size of a node
                    3. STOP_LEVEL: The maximal level of the tree
       */
      void subdivide(unsigned int criteria, double value);

      /**
       * @post Return the level of the octree
       */      
      unsigned int getLevel(void);

      /**
       * @post Set the polar coordinate of the node in the octree
       */      
      void setCoord(double x, double y, double z, 
		    double w, double h, double d);

      /**
       * @post Set the level of the octree
       * @warning It only changes de level value, not the true level in the
                  octree
       */      
      void setLevel(unsigned int l);

      
      /**
       * @post Set the palette in the GPU
       */      
      void setPalette(void);

      /**
       * @post Set the materials in the GPU
       */      
      void setMaterials(void);

   private:
      /// Children:
      S3DOctNode *child[8];
      /// ID of the texture 3D
      GLuint idtex3D;
      /// ID of the normal texture 3D
      GLuint idtexnormal3D;
      /// Angles of rotation of the camera
      GLfloat rotTexX, rotTexY, rotTexZ;
      /// Data of the volume
      S3DData *data;
      /// Data of the normals of the volume
      S3DData *normaldata;
      /// Palette of materials
      S3DData *palette;
      /// Shininess of materials
      S3DData *shininess;
      /// Level of the node in the octree
      unsigned int level;
      /// Minimal position in euclidean coordinates of the node in the octree
      double octx, octy, octz;
      /// Size of the node in the octree
      double octw, octh, octd;
      /// ID Palette
      GLuint idpal0;
      /// ID Shininess of the material
      GLuint idsh0;

};


#endif

