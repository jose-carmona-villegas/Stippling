#include "data.hh"


// --------------------------------------------------
S3DData::S3DData (void)
{
   this->data_width = this->data_height = this->data_depth = 0;
   this->data_ub = 0;
   this->data_d = 0;
   this->data_spc = 0;
   this->format = 0;
}


// --------------------------------------------------
S3DData::S3DData (unsigned int w, unsigned int h, unsigned int d,
		  unsigned int spc, unsigned int type)
{
   this->data_ub = 0;
   this->data_d = 0;

   switch (type)
   {
      case DATA_UNSIGNED_BYTE: {
	 this->data_ub = new unsigned char[w * h * d * spc];
	 memset (this->data_ub, 0, w * h * d * spc);
      } break;
      
      case DATA_DOUBLE: {
	 this->data_d = new double[w * h * d * spc * sizeof(double)];
	 memset (this->data_d, 0, w * h * d * spc * sizeof(double));
      } break;

      default: {
	 std::cerr << "WARNING: Uknown flag: " << type << "\n";
	 return;
      };
   }

   this->format = type;

   this->data_width = w;
   this->data_height = h;
   this->data_depth = d;
   this->data_spc = spc;
}


// --------------------------------------------------
S3DData::S3DData (void *rawdata, unsigned int flag, unsigned int spc, 
		  unsigned int w, unsigned int h, unsigned int d)
{
   this->data_width = w;
   this->data_height = h;
   this->data_depth = d;

   this->data_ub = 0;
   this->data_d = 0;

   switch (flag)
   {
      case DATA_UNSIGNED_BYTE: {
	 this->data_ub = (unsigned char *) rawdata;
      } break;

      case DATA_DOUBLE: {
	 this->data_d = (double *) rawdata;
      } break;
   }

   this->data_spc = spc;
   this->format = flag;
}


// --------------------------------------------------
S3DData::~S3DData (void)
{
   if (this->data_ub != 0)
      delete [] this->data_ub;

   if (this->data_d != 0)
      delete [] this->data_d;
}


// --------------------------------------------------
void S3DData::loadFromImages (bool scale, unsigned int w, unsigned int h, 
			      unsigned int d, unsigned int s, 
			      const char *filename, 
			      unsigned int from, bool convertTOrgba)
{
   char *fname; 
   char *prevname; 
   unsigned int i, j, k, n, z;
   S3DImage *img;
   unsigned long int pos;
   unsigned int pn;
   bool samefile = true;
   bool firsttime = true;
   bool err;

   
   if (filename == 0)
      return;
   
   fname = new char[strlen(filename) + 100];
   prevname = new char[strlen(filename) + 100];
   
   img = new S3DImage ();

   if (s < 1)
      s = 1;

   d = d / s;
  
   std::cerr << "Loading " << d << " images: [";

   // number of points in bar = 10
   pn = (unsigned int) d * 10 / 100;
   
   n = 0;
   while (n < d)
   {
      i = 0;
      j = 0;
      while (i < strlen (filename))
      {
	 if (filename[i] != '%')
	    fname[j] = filename[i];
	 else
	 {
	    samefile = false;
	    i ++;

	    fname[j] = '\0';
	    sprintf (fname + j, filename + i - 1, n * s + from);
	    j = strlen (fname);
	 }
	 
	 i ++;
	 j ++;
      }
      fname[j] = '\0';


      // Now, fname is the name of the file:
      if ( (firsttime) || (!samefile) )
      {
	 err = img->load (fname); 
	 img->flip(false, true);
      }
      
      if (err)
      {

	 if ( (firsttime) || (!samefile) )
	    if (convertTOrgba)
	       img->convert (4);

	 if (n == 0) // Initialize the volume:
	 {
	    if (!scale)
	    {
	       if (w == 0)
		  w = img->getWidth();
	       if (h == 0)
		  h = img->getHeight();
	    }

	    // Free the old data
	    if (this->data_ub != 0)
	       delete [] this->data_ub;
	    if (this->data_d != 0)
	       delete [] this->data_d;

	    this->data_ub = new unsigned char[img->getBPP() * w * h * d];
	    this->data_spc = img->getBPP();

	    if (this->data_ub == 0)
	    {
	       std::cerr << "\nNot enought memory to load the volume: " 
			 << w << ", " << h << ", " << d << std::endl;
	       exit (1);
	    }
	    else
	       memset (this->data_ub, 0, img->getBPP() * w * h * d);

	    std::cerr << "\nCreated a new volume: " 
		      << w << ", " << h << ", " << d << std::endl;

	    this->data_width = w;
	    this->data_height = h;
	    this->data_depth = d;
	 }

	 if ((firsttime) || (!samefile))
	 {
	    if (scale == true)
	       img->scale (w, h, S3DImage::QUALITY);
	    else
	       if ((img->getWidth() != w) || (img->getHeight() != h))
		  std::cerr << "Warning: the size of images are "
			 << "different in the volume." << std::endl;

	 if (img->getBPP() != this->data_spc)
	    std::cerr << "Warning: the BPP of the images are "
		      << "different in the volume." << std::endl;
	 }
	 
	 memcpy (this->data_ub + (w * h * n * img->getBPP()), 
		 img->getRaw(), w * h * img->getBPP());
      }

      if ((pn != 0) && (n % pn == 0))
	 std::cerr << ".";
      n ++;


      if (samefile)
	 firsttime = false;
   }

   if (samefile)
      delete img;

   this->format = this->format | this->DATA_UNSIGNED_BYTE;
   std::cerr << "] Ok." << std::endl;

   delete [] fname; 
   delete [] prevname;

   return;
}


// --------------------------------------------------
unsigned char *S3DData::getRawUB(void)
{
   return this->data_ub;
}


// --------------------------------------------------
double *S3DData::getRawD(void)
{
   return this->data_d;
}


// --------------------------------------------------
void S3DData::setData(void *data, unsigned int i, unsigned int j, 
		      unsigned int k)
{
   unsigned long long int pos;
   unsigned char *d_ub;
   double *d_d;
   unsigned int h;

   pos = i + j * this->data_width + k * this->data_width * this->data_height;
   pos *= this->data_spc;

   if (this->data_ub != 0)
   {
      d_ub = (unsigned char *) data;
      for (h = 0; h < this->data_spc; h ++)
	 this->data_ub[pos + h] = d_ub[h];
   }

   if (this->data_d != 0)
   {
      d_d = (double *) data;
      for (h = 0; h < this->data_spc; h++)
	 this->data_d[pos + h] = d_d[h];
   }
   
   return;
}


// --------------------------------------------------
void S3DData::convert(unsigned int spc, 
		      unsigned int w, unsigned int h, unsigned int d, 
		      bool scale)
{
   double *buffer_d, *d_d;
   unsigned char *buffer_ub, *d_ub;
   bool same_size = false;
   unsigned int i, j, k;
   float skip;
   unsigned long long int pos;
   unsigned int s;
   S3DImage *img;

   if ((this->data_width == w) && (this->data_height == h) && 
       (this->data_depth == d) )
      same_size = true;

   if ( (this->data_ub == 0) && (this->data_d == 0))
      return;

   if ((this->data_spc == spc) && (same_size == true))
      return;



   switch(this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 buffer_ub = new unsigned char[w * h * d * spc];
	 memset(buffer_ub, 0, w * h * d * spc);
      
      } break;

      case DATA_DOUBLE: {
	 buffer_d = new double[w * h * d * spc];
	 memset(buffer_d, 0, w * h * d * spc * sizeof(double));
      } break;
   }

   if (spc <= this->data_spc)
      s = spc;
   else
      s = this->data_spc;

   if ((scale == false) || (same_size == true))
   {
      for (k = 0; k < this->data_depth; k ++)
	 for (j = 0; j < this->data_height; j ++)
	    for (i = 0; i < this->data_width; i ++)
	    {
	       pos = (i + j * w + k * w * h) * spc;
	       switch(this->format)
	       {
		  case DATA_UNSIGNED_BYTE: {
		     d_ub = (unsigned char *) this->getData(i, j, k);
		     memcpy(buffer_ub + pos, d_ub, s); 
		  } break;

		  case DATA_DOUBLE: {
		     d_d = (double *) this->getData(i, j, k);
		     memcpy(buffer_d + pos, d_d, s); 
		  } break;
	       }
	    }
   }
   else
   {
      switch (this->format)
      {
	 
	 case DATA_UNSIGNED_BYTE: {
	    
	    skip = ((float) this->data_depth / (float) d);
	    
	    // If scale == true:
	    for (k = 0; k < d; k ++)
	    {
	       i = (unsigned int) (skip * (float) k);
	       
	       img = new S3DImage(this->data_width, this->data_height, 
				  this->data_spc, this->data_ub + 
				  i * this->data_width * this->data_height
				  * this->data_spc);

	       if (this->data_spc != spc)
		  img->convert(spc);

	       if ( (this->data_width != w) || (this->data_height != h) )
		  img->scale(w, h, S3DImage::QUALITY);

	       memcpy (buffer_ub + (w * h * k * spc), 
		       img->getRaw(), w * h * spc);
	       	       
	       delete img;
	    }
	 } break;
	    
	 case DATA_DOUBLE: {
	    std::cerr << "Not implemented yet :(, sorry!\n";
	    /// TODO
	    delete [] buffer_d; 
	    return;
	 } break;
      }

   }
   
   this->data_width = w;
   this->data_height = h;
   this->data_depth = d;
   this->data_spc = spc;

   // BUG here: we can not free the memory
   // Free the old data
   if (this->data_ub != 0)
      delete [] this->data_ub;
   if (this->data_d != 0)
      delete [] this->data_d;   

   switch(this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 this->data_ub = buffer_ub;
      } break;
	 
	 
      case DATA_DOUBLE: {
	 this->data_d = buffer_d;
      } break;
   }

   return;
}


// --------------------------------------------------
void *S3DData::getData(unsigned int i, unsigned int j, unsigned int k)
{
   unsigned long int pos;

   pos = i + j * this->data_width + k * this->data_width * this->data_height;

   if (this->data_ub != 0)
      return (void *) (this->data_ub + pos * this->data_spc);

   if (this->data_d != 0)
      return (void *) (this->data_d + pos * this->data_spc);

   return 0;
}


// --------------------------------------------------
unsigned int S3DData::getWidth(void)
{
   return this->data_width;
}


// --------------------------------------------------
unsigned int S3DData::getHeight(void)
{
   return this->data_height;
}


// --------------------------------------------------
unsigned int S3DData::getDepth(void)
{
   return this->data_depth;
}


// --------------------------------------------------
bool S3DData::formatsAvailable (void)
{
   return this->format;
}

// --------------------------------------------------
unsigned int S3DData::getSPC (void)
{
   return this->data_spc;
}

// --------------------------------------------------
double S3DData::usedMemory (void)
{
   float memory = 0;

   if (this->data_ub != 0)
      memory += (double) (this->data_width * this->data_height * 
			  this->data_depth * this->data_spc);
   if (this->data_d != 0)
      memory += (double) (this->data_width * this->data_height * 
			  this->data_depth * this->data_spc * sizeof (double));
   return memory;
}


// --------------------------------------------------
S3DData *S3DData::copy (unsigned int x, unsigned int y, unsigned int z, 
			unsigned int w, unsigned int h, unsigned int d)
{
   unsigned long int it, jt, kt, i, j, k;
   S3DData *newdata;
   unsigned char *buffer_ub = 0;
   double *buffer_d = 0;
   unsigned long int pos, pos2;
   unsigned char *cmp_ub = 0;
   double *cmp_d = 0;
   bool write = false;

   if ((w < 0) || (h < 0) || (d < 0))
      return 0;

   if (w == 0)
      w = this->data_width;

   if (h == 0)
      h = this->data_height;

   if (d == 0)
      d = this->data_depth;

   if (this->format & S3DData::DATA_UNSIGNED_BYTE)
   {
      buffer_ub = new unsigned char[w * h * d * this->data_spc];
      cmp_ub = new unsigned char[this->data_spc];

      for (i = 0; i < this->data_spc; i ++)
	 cmp_ub[i] = 0;
   }

   if (this->format & S3DData::DATA_DOUBLE)
   {
      buffer_d = new double[w * h * d * this->data_spc];
      cmp_d = new double[this->data_spc * sizeof(double)];

      for (i = 0; i < this->data_spc; i ++)
	 cmp_d[i] = 0.0;
   }

   for (k = 0; k < d; k ++)
      for (j = 0; j < h; j ++)
	 for (i = 0; i < w; i ++)
	 {
	    it = x + i;
	    jt = y + j;
	    kt = z + k;
	    
	    if ( (it >= 0) && (it < this->data_width) && 
		 (jt >= 0) && (jt < this->data_height) &&
		 (kt >= 0) && (kt < this->data_width) )
	    {
	       pos = (i + w * j + w * h * k) * this->data_spc;
	       pos2 = (it + this->data_width * jt + 
		       this->data_width * 
		       this->data_height * kt) * this->data_spc;

	       if (this->format & S3DData::DATA_UNSIGNED_BYTE)
		  memcpy (buffer_ub + pos, this->data_ub + pos2, 
			  this->data_spc);

	       if (this->format & S3DData::DATA_DOUBLE)
		  memcpy (buffer_d + pos, this->data_d + pos2, 
			  this->data_spc * sizeof(double));
	    }
	 }

   // if write is false then there is nothing in the volume
   if (this->format & S3DData::DATA_UNSIGNED_BYTE)
      newdata = new S3DData (buffer_ub, S3DData::DATA_UNSIGNED_BYTE, 
			     this->data_spc, w, h, d);
   else
      if (this->format & S3DData::DATA_DOUBLE)
	 newdata = new S3DData (buffer_d, S3DData::DATA_UNSIGNED_BYTE, 
				this->data_spc, w, h, d);

   return newdata;
}


// --------------------------------------------------
void S3DData::removeDirectRender (bool border, bool blackdata)
{
   unsigned int i, j, k;
   unsigned int pos, pos2;
   unsigned int m;
   

   for (k = 0; k < this->data_depth; k ++)
      for (j = 0; j < this->data_height; j ++)
	 for (i = 0; i < this->data_width; i ++)
	 {
	    pos = ((i + j * this->data_width + 
		    k * this->data_width * this->data_height) * 
		   this->data_spc);
	    
	    if ( (i <= 0) || (j <= 0) || (k <= 0) || 
		 (i >= this->data_width-1) || (j >= this->data_height-1) || 
		 (k >= this->data_depth-1))
	    {
	       // remove the border for direct rendering
	       if (border)
		  for (m = 0; m < this->data_spc; m++)
		  {
		     if (this->data_ub != 0)
			this->data_ub[pos + m] = 0;
		     if (this->data_d != 0)
			this->data_d[pos + m] = 0;
		  }
	    }
	    else
	    {
	       // remove black data
	       if ( (this->data_ub[pos] <= 0) && (blackdata) )
		  for (m = 0; m < this->data_spc; m++)
		  {
		     if (this->data_ub != 0)
			this->data_ub[pos + m] = 0;
		     if (this->data_d != 0)
			this->data_d[pos + m] = 0;
		  }
	    }
	 }
}


// --------------------------------------------------
S3DData *S3DData::computeNormal (void)
{
   S3DData *temp;
   S3DVector *normal, *n;
   unsigned long int p;
   long long int i, j, k, x, y, z;
   double m, sumx, sumy, sumz;
   double *newdatad;
   unsigned char *newdataub;
   double *datad;
   unsigned char *dataub;
   double sobelx[27] = {/*-1*/  -1, -3, -1,
			/*-1*/  -3, -6, -3,
			/*-1*/  -1, -3, -1,
			
			/* 0*/   0,  0,  0, 
			/* 0*/   0,  0,  0, 
			/* 0*/   0,  0,  0, 
			
			/*+1*/   1,  3,  1,
			/*+1*/   3,  6,  3,
			/*+1*/   1,  3,  1};
   
   double sobely[27] = {/*-1*/   1,  3,  1,
			/*-1*/   0,  0,  0,
			/*-1*/  -1, -3, -1,
			
			/* 0*/   3,  6,  3, 
			/* 0*/   0,  0,  0, 
			/* 0*/  -3, -6, -1, 
			
			/*+1*/   1,  3,  1,
			/*+1*/   0,  0,  0,
			/*+1*/  -1, -3, -1};
   
   double sobelz[27] = {/*-1*/  -1,  0,  1,
			/*-1*/  -3,  0,  3,
			/*-1*/  -1,  0,  1,
			
			/* 0*/  -3,  0,  3, 
			/* 0*/  -6,  0,  6, 
			/* 0*/  -3,  0,  3, 
			
			/*+1*/  -1,  0,  1,
			/*+1*/  -3,  0,  3,
			/*+1*/  -1,  0,  1};

   normal = new S3DVector (0.0, 0.0, 0.0);
   temp = 0;

   // Unsigned byte mode
   if (this->data_ub != 0)
   {
      newdataub = new unsigned char[(this->data_width * this->data_height * 
				     this->data_depth * 3)];

      for (k = 0; k < this->data_depth; k ++)
	 for (j = 0; j < this->data_height; j ++)
	    for (i = 0; i < this->data_width; i ++)
	    {
	       sumx = 0.0;
	       sumy = 0.0;
	       sumz = 0.0;
	       for (x = -1; x <= 1; x ++)
		  for (y = -1; y <= 1; y ++)
		     for (z = -1; z <= 1; z ++)
			if ( ((i + x) >= 0) && ((i + x) < this->data_width)  &&
			     ((j + y) >= 0) && ((j + y) < this->data_height) &&
			     ((k + z) >= 0) && ((k + z) < this->data_depth) )
			{
			   dataub = (unsigned char *) this->getData(i + x,
								    j + y,
								    k + z);
			   m = (double) (*dataub);
			   p = (x + 1) + 3 * (y + 1) + 9 * (z + 1);
			   sumx += (sobelx[p] * m);
			   sumy += (sobely[p] * m);
			   sumz += (sobelz[p] * m);
			}
			// else => do not add anything

	       
	       normal->set(sumx, sumy, sumz);

	       n = normal->normalize();

	       p = (i + j * this->data_width + 
		    k * this->data_width * this->data_height) * 3;
	       newdataub[p] = (unsigned char) (n->X() * 127) + 127;
	       newdataub[p + 1] = (unsigned char) (n->Y() * 127) + 127;
	       newdataub[p + 2] = (unsigned char) (n->Z() * 127) + 127;

	       delete n;
	    }

      temp = new S3DData (newdataub, S3DData::DATA_UNSIGNED_BYTE, 3, 
			  this->data_width, this->data_height, 
			  this->data_depth);
   }


   // Similar for doubles
   if (this->data_d != 0)
   {
      newdatad = new double[(this->data_width * this->data_height * 
			     this->data_depth * 3 * sizeof(double))];
      
      for (k = 0; k < this->data_depth; k ++)
	 for (j = 0; j < this->data_height; j ++)
	    for (i = 0; i < this->data_width; i ++)
	    {
	       sumx = 0.0;
	       sumy = 0.0;
	       sumz = 0.0;
	       for (x = -1; x <= 1; x ++)
		  for (y = -1; y <= 1; y ++)
		     for (z = -1; z <= 1; z ++)
			if ( ((i + x) >= 0) && ((i + x) < this->data_width)  &&
			     ((j + y) >= 0) && ((j + y) < this->data_height) &&
			     ((k + z) >= 0) && ((k + z) < this->data_depth) )
			{
			   datad = (double *) this->getData(i + x,
							    j + y,
							    k + z);
			   m = *datad;
			   p = (x + 1) + 3 * (y + 1) + 9 * (z + 1);
			   sumx += (sobelx[p] * m);
			   sumy += (sobely[p] * m);
			   sumz += (sobelz[p] * m);
			}
	       // else => do not add anything
	       
	       
	       normal->set(sumx, sumy, sumz);
	       
	       n = normal->normalize();
	       
	       p = (i + j * this->data_width + 
		    k * this->data_width * this->data_height) * 3;
	       newdatad[p] = n->X();
	       newdatad[p + 1] = n->Y();
	       newdatad[p + 2] = n->Z();

	       delete n;
	    }
      
      temp = new S3DData (newdatad, S3DData::DATA_DOUBLE, 3, 
			  this->data_width, this->data_height, 
			  this->data_depth);
   }

   delete normal;
   return temp;
}


// --------------------------------------------------
void S3DData::savePCOS (const char *fname)
{
   char *header;
   char *datatext;
   std::ofstream *fout;
   unsigned int i, j, k;
   unsigned long long int pos;
   unsigned long long int max;
   int s;


   fout = new std::ofstream(fname, std::ios::binary);

   std::cerr << "Saving file \"" << fname << "\": [";

   header = new char[1000];
   datatext = new char[3000];

   header[0] = '\0';
   sprintf (header, "<pacOS textbased volume>\n");
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Version = %i>\n", S3DData::PCOS_FILEVERSION);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Size = %i, %i, %i>\n", 
	    this->data_width, this->data_height, this->data_depth);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Format = %i>\n", this->format);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<SPC = %i>\n", this->data_spc);
   fout->write((char *)header, strlen(header));

   delete [] header;

   max = (this->data_width * this->data_height * this->data_depth);

   // Saving the data:
   for (k = 0; k < this->data_depth; k ++)
      for (j = 0; j < this->data_height; j ++)
	 for (i = 0; i < this->data_width; i ++)
	 {
	    datatext[0] = '\0';
	    sprintf(datatext, "<");
	    fout->write((char *)datatext, strlen(datatext));

	    pos = (i + j * this->data_width + 
		   k * this->data_width * this->data_height);
	    pos *= this->data_spc;
	    
	    if (pos % (max / 10) == 0)
	       std::cerr << ".";

	    for (s = 0; s < this->data_spc; s ++)
	    {
	       switch (this->format)
	       {
		  case DATA_UNSIGNED_BYTE: {
		     if (s < this->data_spc - 1)
			sprintf(datatext, "%i, ", this->data_ub[pos + s]);
		     else
			sprintf(datatext, "%i>\n", this->data_ub[pos + s]);
		  } break;

		  case DATA_DOUBLE: {
		     if (s < this->data_spc - 1)
			sprintf(datatext, "%g, ", this->data_d[pos + s]);
		     else
			sprintf(datatext, "%g>\n", this->data_d[pos + s]);
		  } break;

		  default: {};
	       }
	       fout->write((char *)datatext, strlen(datatext));
	    }
	 }
   
   delete [] datatext;
   fout->close();
   std::cerr << "] Ok." << std::endl;
   delete fout;
}


// --------------------------------------------------
bool S3DData::loadPCOS (const char *fname)
{
   char *header;
   char *datatext;
   char *values;
   unsigned char *d_ub;
   double *d_d;
   std::ifstream *fin;
   unsigned int version;
   unsigned int i, j, k;
   unsigned long long int size;
   unsigned long long int pos;
   unsigned long long int max;
   int s;

   // New data:
   if (this->data_ub != 0)
      delete [] this->data_ub;

   if (this->data_d != 0)
      delete [] this->data_d;

   this->data_ub = 0;
   this->data_d = 0;

   this->format = 0;
   this->data_width = this->data_height = this->data_depth = 0;
   this->data_spc = 0;

   fin = new std::ifstream(fname, std::ios::binary);

   std::cerr << "Loading file \"" << fname << "\": [";

   header = new char[1000];
   datatext = new char[3000];
   values = new char[3000];

   fin->getline((char *)header, 1000);
   if (strncmp("<pacOS textbased volume>", header, 24))
   {
      std::cerr << "\nError: it is not a valid pacOS file (" << header << ")\n";
      fin->close();
      delete fin;
      delete [] header;
      return false;
   }

   // Remove white spaces in all the file:
   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Version=%i>", &version);
   if (version != PCOS_FILEVERSION)
   {
      std::cerr << "\nWarning: file version is " << version 
		<< "whereas this program loader version is " 
		<< PCOS_FILEVERSION << "\n";
   }

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Size=%i,%i,%i>\n", 
	   &(this->data_width), &(this->data_height), &(this->data_depth));

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Format=%i>\n", &(this->format));

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<SPC=%i>\n", &(this->data_spc));
   delete [] header;


   // Load all the data:
   max = (this->data_width * this->data_height * this->data_depth);
   size = max * this->data_spc;
   switch(this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 this->data_ub = new unsigned char[size];
      } break;
      
      case DATA_DOUBLE: {
	 this->data_d = new double[size];
      } break;      
   }

   d_ub = new unsigned char[this->data_spc];
   d_d = new double[this->data_spc];


   for (k = 0; k < this->data_depth; k ++)
      for (j = 0; j < this->data_height; j ++)
	 for (i = 0; i < this->data_width; i ++)
	 {
	    fin->getline((char *)datatext, 1000);
	    this->removeWhiteSpaces(datatext);
	    datatext[0] = ' '; // Remove "<" and ">"
	    datatext[strlen(datatext) - 1] = ' ';

	    // Divide the string:
	    this->changeCharacters(datatext, ',', '\0');
	    s = 0;
	    header = datatext;

	    pos = (i + j * this->data_width + 
		   k * this->data_width * this->data_height);
 
	    if (pos % (max / 10) == 0)
	       std::cerr << ".";

	    while (s < this->data_spc)
	    {
	       switch(this->format)
	       {
		  case DATA_UNSIGNED_BYTE: {
		     d_ub[s] = atoi (header);
		  } break;
		  
		  case DATA_DOUBLE: {
		     d_d[s] = atof (header);
		  } break;      
	       }

	       header += strlen(header) + 1;
	       s++;
	    }

	    switch(this->format)
	    {
	       case DATA_UNSIGNED_BYTE: {
		  this->setData(d_ub, i, j, k);
	       } break;
	       
	       case DATA_DOUBLE: {
		  this->setData(d_d, i, j, k);
	       } break;      
	    }
	 }

   delete [] d_ub;
   delete [] d_d;

   delete [] datatext;

   fin->close();
   std::cerr << "] Ok. Size = (" << this->data_width << ", "
	     << this->data_height << ", " << this->data_depth 
	     << "); Format = " << (int) this->format 
	     << "; SPC = " << this->data_spc
	     << std::endl;
   delete fin;   

   return true;
}


// --------------------------------------------------
void S3DData::saveBCOS (const char *fname)
{
   char *header;
   char *datatext;
   std::ofstream *fout;
   unsigned int i, j, k;
   unsigned long long int pos;
   unsigned long long int max, size;
   int s;


   fout = new std::ofstream(fname, std::ios::binary);

   std::cerr << "Saving file \"" << fname << "\": [";

   header = new char[1000];
   datatext = new char[3000];

   header[0] = '\0';
   sprintf (header, "<pacOS binarybased volume>\n");
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Version = %i>\n", S3DData::PCOS_FILEVERSION);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Size = %i, %i, %i>\n", 
	    this->data_width, this->data_height, this->data_depth);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<Format = %i>\n", this->format);
   fout->write((char *)header, strlen(header));

   header[0] = '\0';
   sprintf (header, "<SPC = %i>\n", this->data_spc);
   fout->write((char *)header, strlen(header));

   delete [] header;

   max = (this->data_width * this->data_height * this->data_depth);
   size = max * this->data_spc;

   // Saving the data:
   switch (this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 fout->write((char *)this->data_ub, size);
      } break;

      case DATA_DOUBLE: {
	 fout->write((char *)this->data_d, size * sizeof(double));
      } break;

      default: {};
   }

   fout->close();
   std::cerr << "] Ok." << std::endl;
   delete fout;
}


// --------------------------------------------------
bool S3DData::loadBCOS (const char *fname)
{
   char *header;
   char *datatext;
   char *values;
   unsigned char *d_ub;
   double *d_d;
   std::ifstream *fin;
   unsigned int version;
   unsigned int i, j, k;
   unsigned long long int size;
   unsigned long long int pos;
   unsigned long long int max;
   int s;

   // New data:
   if (this->data_ub != 0)
      delete [] this->data_ub;

   if (this->data_d != 0)
      delete [] this->data_d;

   this->data_ub = 0;
   this->data_d = 0;

   this->format = 0;
   this->data_width = this->data_height = this->data_depth = 0;
   this->data_spc = 0;

   fin = new std::ifstream(fname, std::ios::binary);

   std::cerr << "Loading file \"" << fname << "\": [";

   header = new char[1000];
   datatext = new char[3000];
   values = new char[3000];

   fin->getline((char *)header, 1000);
   if (strncmp("<pacOS binarybased volume>", header, 24))
   {
      std::cerr << "\nError: it is not a valid pacOS file (" << header << ")\n";
      fin->close();
      delete fin;
      delete [] header;
      return false;
   }

   // Remove white spaces in all the file:
   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Version=%i>", &version);
   if (version != PCOS_FILEVERSION)
   {
      std::cerr << "\nWarning: file version is " << version 
		<< "whereas this program loader version is " 
		<< PCOS_FILEVERSION << "\n";
   }

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Size=%i,%i,%i>\n", 
	   &(this->data_width), &(this->data_height), &(this->data_depth));

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<Format=%i>\n", &(this->format));

   header[0] = '\0';
   fin->getline((char *)header, 1000);
   this->removeWhiteSpaces(header);
   sscanf (header, "<SPC=%i>\n", &(this->data_spc));
   delete [] header;


   // Load all the data:
   max = (this->data_width * this->data_height * this->data_depth);
   size = max * this->data_spc;
   switch(this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 this->data_ub = new unsigned char[size];
	 fin->read((char *) (this->data_ub), size);
      } break;
      
      case DATA_DOUBLE: {
	 this->data_d = new double[size];
	 fin->read((char *) (this->data_d), size);
      } break;      
   }

   fin->close();
   std::cerr << "] Ok. Size = (" << this->data_width << ", "
	     << this->data_height << ", " << this->data_depth 
	     << "); Format = " << (int) this->format 
	     << "; SPC = " << this->data_spc
	     << std::endl;
   delete fin;   

   return true;
}

// --------------------------------------------------
/* Transform this function in the future to const char * and 
   return the same type */
///DEBUG
void S3DData::removeWhiteSpaces(char *str)
{
   unsigned int i, j;

   i = 0;
   while (i < strlen(str))
   {
      if (isspace(str[i]) != 0)
      {
	 j = i;
	 while (j <= strlen(str))
	 {
	    str[j] = str[j+1];
	    j ++;
	 }
      }
      else
	 i ++;
   }   

   return;
}


// --------------------------------------------------
void S3DData::changeCharacters(char *str, char org, char dst)
{
   unsigned int i, j, len;

   i = 0;
   len = strlen(str);

   while (i < len)
   {
      if (str[i] == org)
	 str[i] = dst;

      i ++;
   }   

   return;
}


// --------------------------------------------------
bool S3DData::loadFromRaw (const char *fname, 
			   unsigned int w, unsigned int h, unsigned int d, 
			   unsigned int spc, unsigned char format)
{
   std::ifstream *fin;
   unsigned long long int size;
   
   
   fin = new std::ifstream(fname, std::ios::binary);   

   if (fin == 0)
   {
      std::cerr << "Error reading the file: " << fname << "\n";
      return false;
   }

   this->data_width = w;
   this->data_height = h;
   this->data_depth = d; 
   this->data_spc = spc;

   std::cerr << "Loading file \"" << fname << "\": [";


   size = w * h * d * spc;
   this->format = format;

   switch(this->format)
   {
      case DATA_UNSIGNED_BYTE: {
	 std::cerr << "...";
	 this->data_ub = new unsigned char[size];
	 fin->read((char *) (this->data_ub), size);
      } break;
      
      case DATA_DOUBLE: {
	 std::cerr << "...";
	 this->data_d = new double[size];
	 fin->read((char *) (this->data_d), size * sizeof(double));
      } break;      
   }

   fin->close();
   delete fin;

   std::cerr << "] OK.\n";


   return true;
}
