#ifndef __DATA__
#define __DATA__

#include <GL/glew.h>
#include <fstream>
#include "vector.hh"
#include "image.hh"

/** @class   S3DData data.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is the 3D data of a volume, it can contain colors, 
 *           normals, physic values, etc. in a space 3D. It can store the data
 *           as double or as unsigned char. Every cell of the grid can have 
 *           until 4 values.
 *
 *  @bug     A bug detected when you try to free the memory in the
 *           convert method
 */

class S3DData {
   public:

      // DO NOT CHANGE THIS VALUES BECAUSE IT WILL BE SAVE IN FILES:
      /// The data is as unsigned byte
      static const unsigned int DATA_UNSIGNED_BYTE        = 0x01;

      /// The data is as double
      static const unsigned int DATA_DOUBLE               = 0x02;
      // -----------------------------------------------------------

      /// The version of the .pcos files (CHANGE IT IF FORMAT IS CHANGED)
      static const unsigned int PCOS_FILEVERSION          = 1;


      /** 
       * @post Constructor. Inizialite the empty data.
       */
      S3DData(void);

      /** 
       * @param[in] w The width of the array
       * @param[in] h The height of the array
       * @param[in] d The depth of the array
       * @param[in] type One of these:
                    DATA_UNSIGNED_BYTE: data is stored as unsigned byte
                    DATA_DOUBLE: data is stored as double
       * @param[in] spc The number of samples per cell 
       *                (it is equivalent to bytes per cell 
       *                 if flag = DATA_UNSIGNED_BYTE)
       * @post Constructor. Inizialite the data with a default value of all 0.
       */
      S3DData (unsigned int w, unsigned int h, unsigned int d,
	       unsigned int spc, unsigned int type);

      /** 
       * @pre rawdata must be a valid pointer (not 0) and it must have the 
       *      right size
       * @param[in] rawdata The data as an array of size (w·h·d·spc), 
       * @param[in] flag One of these:
                    DATA_UNSIGNED_BYTE: data is stored as unsigned byte
                    DATA_DOUBLE: data is stored as double
       * @param[in] spc The number of samples per cell 
       *                (it is equivalent to bytes per cell 
       *                 if flag = DATA_UNSIGNED_BYTE)
       * @param[in] w The width of the array
       * @param[in] h The height of the array
       * @param[in] d The depth of the array
       * @post Constructor. Inizialite the empty data.
       */
      S3DData(void *rawdata, unsigned int flag, unsigned int spc, 
	      unsigned int w, unsigned int h, unsigned int d);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DData(void);


      /** 
       * @pre filenames must be a sprintf valid string.
       * @param[in] scale If the images will be scaled to w and h or not
       * @param[in] w The width of the image. If scale is false, it will take
       *              part of the size if w is less than the width of the image
       *              If it is 0, the width is detected from the first image
       * @param[in] h The height of the image. If scale is false, it will take
       *              part of the size if h is less than the height of
       *              the image
       *              If it is 0, the height is detected from the first image
       * @param[in] d The number of images to load
       * @param[in] s The number of images to skip
       * @param[in] filenames It is a string to load the set of images:
       *                      - It will load the same image during the loop:
       *                           "name.png" -> name.png,name.png,etc.
       *                      - It will load the next image during the loop:
       *                           "name%d.png" -> name1.png,name2.png,etc.
       *                      - It will load the next image during the loop:
       *                           "name%.2d.png" -> name01.png,name02.png,etc.
       *                      - It will load the next image during the loop:
       *                           "name%.3d.png" -> name001.png,...,etc.
       * @param[in] from The number of the first image
       * @param[in] convertTOrgba If it is true, it will take the images as a
       *                          set of gray scale images, it will transform
       *                          them to a RGBA data to view it
       * @post Import the data from a set of images
       */
      void loadFromImages (bool scale, unsigned int w, unsigned int h, 
			   unsigned int d, unsigned int s,
			   const char *filenames, unsigned int from,
			   bool convertTOrgba);

      /** 
       * @post The data as an array of unsigned byte, it does not convert data
       * @warning This is not a copy, so, do not free the array
       */
      unsigned char *getRawUB(void);

      /** 
       * @post The data as an array of doubles, it does not convert data
       * @warning This is not a copy, so, do not free the array
       */
      double *getRawD(void);

      /** 
       * @param[in] i, j and k must be lesser than the size of the volume
       * @param[in] i The x coordinate
       * @param[in] j The y coordinate
       * @param[in] k The z coordinate
       * @post The data of a position as an array of void
       * @warning This is not a copy, so do not free the array
       */
      void *getData(unsigned int i, unsigned int j, unsigned int k);

      /** 
       * @pre The data must be a valid double or unsigned char array
       *      i, j and k must be lesser than the size of the volume
       * @param[in] i The x coordinate
       * @param[in] j The y coordinate
       * @param[in] k The z coordinate
       * @param[in] data The array of values as a data
       * @post The data of a position as an array of void
       * @warning This is not a copy, so, do not free the array
       */
      void setData(void *data, unsigned int i, unsigned int j, unsigned int k);

      /** 
       * @post The width of the volume
       */
      unsigned int getWidth(void);

      /** 
       * @post The height of the volume
       */
      unsigned int getHeight(void);

      /** 
       * @post The depth of the volume
       */
      unsigned int getDepth(void);

      /** 
       * @post The number of samples per cell (equivalent to the BPP if this 
       *       volume is an array of byte)
       */
      unsigned int getSPC(void);

      /** 
       * @post The available formats of the volume 
       */
      bool formatsAvailable (void);

      /** 
       * @post The used memory in bytes
       */
      double usedMemory(void);

      /** 
       * @param[in] x The x position of the lesser corner
       * @param[in] y The y position of the lesser corner
       * @param[in] z The z position of the lesser corner
       * @param[in] w The width of the returned volume, 
       *              if it is 0, it will take the same of this volume
       * @param[in] h The height of the returned volume, 
       *              if it is 0, it will take the same of this volume
       * @param[in] d The depth of the returned volume, 
       *              if it is 0, it will take the same of this volume
       * @post A copy of the data
       */
      S3DData *copy(unsigned int x, unsigned int y, unsigned int z, 
		    unsigned int w, unsigned int h, unsigned int d);


      /** 
       * @pre border and blackdata should not be both false
       * @param[in] border If it is true, remove the border of the volume
       * @param[in] blackdata If it is true, remove the empty data of the 
       *                      volume
       * @post Remove the "empty" data of the volume and remove the border
       */
      void removeDirectRender (bool border, bool blackdata);

      /** 
       * @pre spc, w, h, and d must be valid values
       * @param[in] spc The new samples per cell
       * @param[in] w The new width
       * @param[in] h The new height
       * @param[in] d The new depth
       * @param[in] scale If it is true, the volume is scaled
       * @post Convert the type of volume in other 
       */
      void convert(unsigned int spc, 
		   unsigned int w, unsigned int h, unsigned int d, bool scale);

      /** 
       * @post A new volume with the normals of this volume. Only the first 
       *       sample is used to compute it
       * @note You can free the new volume because it is independent 
       * @warning In Unsigned byte mode, the values are between 0 and 254, 
       *          The way you must take the elements is: (x - 127), so, you 
       *          will get the range between -127 and 127
       */
      S3DData *computeNormal (void);

      /** 
       * @pre fname must be a valid filename with extension .pcos
       * @param[in] fname The name of the file
       * @post Save this in a file 
       * @note The format is a text based format:
       *       "<pacOS textbased volume>\n"
       *       "<Version = " <version> ">\n"
       *       "<Size = " <width> ", " <height> ", " <depth> ">\n"
       *       "<Format = " <type> ">\n"
       *       "<SPC = " <spc> ">\n"
       *       "<" <sample[0]> ", " <sample[...]> ", " <sample[spc-1]> ">\n"
       *               ....
       * @note The order to read the data is according to this formula: 
       *       [x][y][z] = x + y * width + z * width * height
       */
      void savePCOS(const char *fname);

      /** 
       * @pre fname must be a valid filename with extension .pcos
       * @param[in] fname The name of the file
       * @post Load the file, if it suceeds return true, false in other case
       * @note For more information see savePCOS
       */
      bool loadPCOS(const char *fname);

      /** 
       * @pre fname must be a valid filename with extension .bcos
       * @param[in] fname The name of the file
       * @post Save this in a file 
       * @note The format is a binary based format (header is textbased format):
       *       "<pacOS binarybased volume>\n"
       *       "<Version = " <version> ">\n"
       *       "<Size = " <width> ", " <height> ", " <depth> ">\n"
       *       "<Format = " <type> ">\n"
       *       "<SPC = " <spc> ">\n"
       *       binary_raw_data
       *               ....
       * @note The order to read the data is according to this formula: 
       *       [x][y][z] = x + y * width + z * width * height
       */
      void saveBCOS(const char *fname);

      /** 
       * @pre fname must be a valid filename with extension .bcos
       * @param[in] fname The name of the file
       * @post Load the file, if it suceeds return true, false in other case
       * @note For more information see saveBCOS
       */
      bool loadBCOS(const char *fname);

      /** 
       * @pre fname must be a valid filename, w, h, and d, must be valid values
       * @param[in] fname The name of the file
       * @param[in] w The width
       * @param[in] h The height
       * @param[in] d The depth
       * @post Load the file, if it suceeds return true, false in other case
       * @note For more information see savePCOS
       */
      bool loadFromRaw (const char *fname, 
			unsigned int w, unsigned int h, unsigned int d, 
			unsigned int spc, unsigned char format);

   protected:

      /** 
       * @pre str must be a valid string
       * @param[in] str The string
       * @post Change str to the same string without spaces 
       */
      void removeWhiteSpaces (char *str);

      /** 
       * @pre str must be a valid string
       * @param[in] str The string
       * @param[in] org The original character
       * @param[in] dst The destination character (it can be '\0')
       * @post Change all characters like org with others like dst in str
       */
      void changeCharacters(char *str, char org, char dst);

   private:
      /// Size of the volume
      unsigned int data_width, data_height, data_depth;
      /// The samples per cell
      unsigned int data_spc;
      /// The data
      unsigned char *data_ub;
      double *data_d;
      /// The format
      unsigned char format;
};


#endif
