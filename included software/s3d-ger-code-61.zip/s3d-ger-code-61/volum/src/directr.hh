#ifndef __DIRECTR__
#define __DIRECTR__

#include <iostream>
#include <math.h>
#include <SDL/SDL_image.h>
#include <GL/glew.h>

#include "framebuffer.hh"
#include "primitive3d.hh"
#include "shader.hh"
#include "dataset.hh"

/** @class   S3DDirectr directr.hh
 *  @author  Germ�n Arroyo
 *  @date    2007
 *  @brief   This class is block to direct render a volumetric data
 *
 *  @bug     No bugs detected yet, some things to do, double data not tested
 *  @warning This class does not support double data
 */

#define NAUXSHADERS  6

class S3DDirectr {
   public:

      /** 
       * @post Constructor. Inizialite the empty node.
       */
      S3DDirectr(void);

      /** 
       * @pre data must be a valid data
       * @post Constructor. Inizialite a non empty node
       * @warning This object will not free data
       * @param[in] s The surface
       */
      S3DDirectr(S3DDataSet *data);

      /**
       * @post Constructor copy. It is unfinished (TODO).
       */
      S3DDirectr(S3DDirectr &node);
      
      /** @post Destructor. Memory is freed here.
       */
      ~S3DDirectr(void);


      /**
       * @param[in] m If the volume is for moving or not
       * @post Change the mode to render the volume: optimized for moving or to
       *       be static, by default is not optimized for moving
       */
      void setMobile (bool m);

      /**
       * @post Prepare the data for render
       * @warnig You should call this method ONLY once or if the dataset
       *         have changed
       */
      void directPreRender (void);

      /**
       * @pre  directPreRender method must be called before
       * @post Render the data of this node with direct rendering,
               if it has no data, it do nothing
       */
      void directRender (unsigned int numslizes);

      /**
       * @param[in] numslizes Number of slices
       * @pre  directPreRender method must be called before
       * @post Render the data of this node with direct rendering,
               if it has no data, it do nothing
	       This method do not use any shaders to render anything
       */
      void directSimpleRender (unsigned int numslizes);

      /**
       * @param[in] numslizes Number of slices
       * @param[in] falseAlpha If it is true, the volume uses the red value
       *                       of a voxel as an alpha value. It is useful for
       *                       gray scale volumes without alpha values
       * @pre  directPreRender method must be called before
       * @post Render the data of this node with a simple raytracing,
       *       if it has no data, it do nothing
       *       This method uses a simple shader to render anything
       * @note This method uses slots 0 and 1 of shaders,
       *       and slots 0 and 1 of FBOs, when mobile flag is enabled
       */
      void directSimpleRayRender (unsigned int numslizes, bool falseAlpha=true);

      /**
       * @param[in] numslizes Number of slices
       * @param[in] falseAlpha If it is true, the volume uses the red value
       *                       of a voxel as an alpha value. It is useful for
       *                       gray scale volumes without alpha values
       * @pre  directPreRender method must be called before
       * @post Render the data of this node with a simple raytracing,
       *       if it has no data, it do nothing
       *       This method uses a simple shader to render anything
       * @note This method uses slots 2 and 3 of shaders,
       *       and slots 2 and 3 of FBOs, when mobile flag is enabled
       */
      void directRayRender (unsigned int numslizes, bool falseAlpha=true);

      /**
       * @param[in] numslizes Number of slices
       * @param[in] numslizes The slice to render
       * @pre  directPreRender method must be called before
       * @post Render one slice of the data
       */
      void directSimpleSlice (unsigned int numslizes, float slice);

      /**
       * @post Render the data of this node as points, 
               if it has no data, it do nothing
       */
      void pointsRender(void);

      /**
       * @param[in] x The x angle
       * @param[in] y The y angle
       * @param[in] z The z angle
       * @post Rotate the volume in the node
       * @note The rotation is the oposited to OpenGL geometry
       */
      void rotate(double x, double y, double z);

      /**
       * @param[in] x The x size
       * @param[in] y The y size
       * @param[in] z The z size
       * @post Scale the texture
       * @note The smaller number, the bigger volume
       */
      void scale(double x, double y, double z);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Move the texture
       * @note The movement is the oposited to OpenGL geometry
       */
      void move(double x, double y, double z);

      /**
       * @post The used memory by this node and its children
       */
      double usedMemory(void);

      /**
       * @post Draw the bounding box of this node
       * @param[in] solid If render only the wire or fill the face too
       */
      void bboxRender(bool solid);

      /**
       * @post Set the palette in the GPU
       */      
      void setPalette(void);

      /**
       * @post Set the materials in the GPU
       */      
      void setMaterials(void);

   private:
      GLuint idtex3D; /// ID of the texture 3D
      GLuint idtexnormal3D; /// ID of the normal texture 3D
      GLfloat rotTexX, rotTexY, rotTexZ; /// Angles of rotation of the camera
      GLfloat trTexX, trTexY, trTexZ; /// Position of the texture
      GLfloat scTexX, scTexY, scTexZ; /// Scale of the texture
      S3DData *data; /// Data of the volume
      S3DData *normaldata; /// Data of the normals of the volume
      S3DData *palette; /// Palette of materials
      S3DData *shininess; /// Shininess of materials
      GLuint idpal0; /// ID Palette
      GLuint idsh0;  /// ID Shininess of the material
      S3DShaderObj *auxshader[NAUXSHADERS]; /// Auxiliary shaders
      S3DFBO *auxfbo[NAUXSHADERS]; /// Auxiliary FBOs
      bool mobile; /** Flag to optimize the shaders and fbos for
		    *  moving the volume
		    */
};


#endif

