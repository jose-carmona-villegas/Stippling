#include "directr.hh"


// --------------------------------------------------
S3DDirectr::S3DDirectr (void)
{
   int i;

   this->rotTexX = this->rotTexX =  this->rotTexY = 0.0;
   
   this->data = 0;
   this->normaldata = 0;
   this->palette = 0;
   this->shininess = 0;

   this->idpal0 = 0;
   this->idtex3D = 0;
   this->idtexnormal3D = 0;
   this->idsh0 = 0;

   this->mobile = false;

   for (i = 0; i < NAUXSHADERS; i ++)
   {
      this->auxshader[i] = 0;
      this->auxfbo[i] = 0;
   }

   this->trTexX = this->trTexY = this->trTexZ = 0.0;
   this->rotTexX = this->rotTexY = this->rotTexZ = 0.0;
   this->scTexX = this->scTexY = this->scTexZ = 1.0;
}


// --------------------------------------------------
S3DDirectr::S3DDirectr (S3DDataSet *dst)
{
   int i;

   this->rotTexX = this->rotTexX = this->rotTexY = 0.0;

   this->data = dst->getData("gray_ub");
   if (this->data == 0)
   {
      this->data = dst->getData("rgba_ub");
      this->normaldata = 0;
      this->palette = 0;
      this->shininess = 0;
   }
   else
   {
      this->normaldata = dst->getData("normal_ub");
      this->palette = dst->getData("palette_ub");
      this->shininess = dst->getData("shininess_ub");
   }

   this->mobile = false;

   for (i = 0; i < NAUXSHADERS; i ++)
   {
      this->auxshader[i] = 0;
      this->auxfbo[i] = 0;
   }

   this->idpal0 = 0;
   this->idtex3D = 0;
   this->idtexnormal3D = 0;
   this->idsh0 = 0;

   this->trTexX = this->trTexY = this->trTexZ = 0.0;
   this->rotTexX = this->rotTexY = this->rotTexZ = 0.0;
   this->scTexX = this->scTexY = this->scTexZ = 1.0;
}


// --------------------------------------------------
S3DDirectr::S3DDirectr(S3DDirectr &node)
{
   // TODO
}


// --------------------------------------------------
S3DDirectr::~S3DDirectr (void)
{
   int i;

   // This object will not free the data
   if (this->idtex3D != 0)
      glDeleteTextures(1, &(this->idtex3D));

   if (this->idtexnormal3D != 0)
      glDeleteTextures(1, &(this->idtexnormal3D));       

   if (this->idpal0 != 0)
      glDeleteTextures(1, &(this->idpal0));
   
   if (this->idsh0 != 0)
      glDeleteTextures(1, &(this->idsh0));

   for (i = 0; i < NAUXSHADERS; i ++)
   {
      if (auxshader[i] != 0)
	 delete auxshader[i];
      if (this->auxfbo[i] != 0)
	 delete this->auxfbo[i];
   }
}


// --------------------------------------------------
void S3DDirectr::setMobile(bool m)
{
   int i;

   if ((this->mobile != m) && (m == false))
   {
      for (i = 0; i < NAUXSHADERS; i ++)
      {
	 if (this->auxshader[i] != 0)
	 {
	    delete this->auxshader[i];
	    this->auxshader[i] = 0;
	 }

	 if (this->auxfbo[i] != 0)
	 {
	    delete this->auxfbo[i];
	    this->auxfbo[i] = 0;
	 }
      }
   }

   this->mobile = m;
}


// --------------------------------------------------
void S3DDirectr::directPreRender(void)
{
   int i, j, k;
   unsigned int w, h, d;
   unsigned long int pos;
   unsigned char f;
   GLenum format;

   if (this->data == 0)
      return;

   if (f & S3DData::DATA_UNSIGNED_BYTE == 0)
   {
      std::cerr << "Warning: The type of the data must be unsigned byte to"
		<< " render it directly to the GPU" << std::endl;
      return;
   }

   w = this->data->getWidth();
   h = this->data->getHeight();
   d = this->data->getDepth();

   if ((this->normaldata != 0) || (this->palette != 0))
      glActiveTexture(GL_TEXTURE0); // Multitexture

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glEnable(GL_TEXTURE_3D);
   if (this->idtex3D != 0)
      glDeleteTextures(1, &(this->idtex3D));
   glGenTextures(1, &(this->idtex3D));

   glBindTexture(GL_TEXTURE_3D, this->idtex3D);

   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP);
   
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
//   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
//   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   switch (this->data->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   f = this->data->formatsAvailable();
   glTexImage3D(GL_TEXTURE_3D, 0, format, w, h, d, 0, format, 
		GL_UNSIGNED_BYTE, this->data->getRawUB());

   // Prerender normal too:
   if (this->normaldata == 0)
      return;

   glActiveTexture(GL_TEXTURE2); // Multitexture
   glEnable(GL_TEXTURE_3D);
   if (this->idtexnormal3D != 0)
      glDeleteTextures(1, &(this->idtexnormal3D));
   glGenTextures(1, &(this->idtexnormal3D));

   glBindTexture(GL_TEXTURE_3D, this->idtexnormal3D);
   
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP);
   
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
//   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB, w, h, d, 0, GL_RGB, 
		GL_UNSIGNED_BYTE, this->normaldata->getRawUB());
}


// --------------------------------------------------
void S3DDirectr::pointsRender(void)
{
   unsigned long int i, j, k;
   unsigned long int w, h, d;
   unsigned char *v;

   if (this->data == 0)
      return;

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_1D);
   glDisable(GL_BLEND);


   w = this->data->getWidth();
   h = this->data->getHeight();
   d = this->data->getDepth();
   
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      // a rotation just to make the picture more interesting 
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);
      
      glBegin(GL_POINTS);
      for (k = 0; k < d; k++)
	 for (j = 0; j < h; j++)
	    for (i = 0; i < w; i++)
	    {
	       v = (unsigned char *) this->data->getData(i, j, k);

	       switch (this->data->getSPC())
	       {
		  case 1: {
		     glColor3ub (*v, *v, *v);
		  } break;

		  case 3: {
		     glColor3ub (v[0], v[1], v[2]);
		  } break;

		  case 4: {
		     glEnable(GL_BLEND);
		     glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		     glColor4ub (v[0], v[1], v[2], v[3]);
		  } break;
	       }
	       glVertex3f(i / (float) w - 0.5, 
			  j / (float) h - 0.5, 
			  k / (float) d - 0.5);
	    }
      glEnd();

   }
   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();
   
}


// --------------------------------------------------
void S3DDirectr::bboxRender(bool solid)
{
   unsigned long int i, j, k;
   double x, y, z;
   unsigned char *v;
   double anglex, angley;
   

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_1D);
   glDisable(GL_BLEND);

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      // a rotation just to make the picture more interesting 
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);

      // center the box
      glTranslatef (-0.5, -0.5, -0.5);

      glDisable(GL_BLEND);
      S3DPrimitive3D::drawAxis(0.5, 0.5, 0.5, 0.5);

      glColor3f (0.0, 0.0, 0.8);
      S3DPrimitive3D::drawBox(GL_LINE_STRIP, 0, 0, 0, 1, 1, 1);
      
      if (solid)
      {
	 glEnable(GL_BLEND);
	 glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

	 glColor4f (0.0, 0.3, 0.6, 0.3);
	 S3DPrimitive3D::drawBox(GL_POLYGON, 0, 0, 0, 1, 1, 1);
      }
   }
   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();
}


// --------------------------------------------------
void S3DDirectr::setPalette(void)
{
   unsigned int format;

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glEnable(GL_TEXTURE_1D);

   if (this->idpal0 != 0)
      glDeleteTextures(1, &(this->idpal0));
   glGenTextures(1, &(this->idpal0));

   glBindTexture(GL_TEXTURE_1D, this->idpal0);
   
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP);

   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);   
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);


   switch (this->palette->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   glTexImage1D(GL_TEXTURE_1D, 0, format, 256, 0, format, 
		GL_UNSIGNED_BYTE, this->palette->getRawUB());

   glActiveTexture(GL_TEXTURE0); // Multitexture
}


// --------------------------------------------------
void S3DDirectr::setMaterials(void)
{
   unsigned int format;

   glActiveTexture(GL_TEXTURE3); // Multitexture
   glEnable(GL_TEXTURE_1D);

   if (this->idsh0 != 0)
      glDeleteTextures(1, &(this->idsh0));
   glGenTextures(1, &(this->idsh0));

   glBindTexture(GL_TEXTURE_1D, this->idsh0);
   
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP);

   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);   
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);


   switch (this->shininess->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   glTexImage1D(GL_TEXTURE_1D, 0, format, 256, 0, format, 
		GL_UNSIGNED_BYTE, this->shininess->getRawUB());

   glActiveTexture(GL_TEXTURE0); // Multitexture
}


// --------------------------------------------------
void S3DDirectr::directSimpleRayRender(unsigned int steps, bool falseAlpha)
{
   GLint loc;
   const char *vprogram0 = {
      "/* Parameters of the shader  */"
      "uniform vec3 position; /* The position of the box*/"
      "uniform vec3 size; /* The size of the box*/"
      ""
      "varying vec4 pos;"
      "void main()"
      "{"
      "   pos = gl_Vertex;"
      "   gl_Position = ftransform();"
      "}"
   };
   const char *fprogram0 = {
      "/* Parameters of the shader  */"
      "uniform vec3 position; /* The position of the box*/"
      "uniform vec3 size; /* The size of the box*/"
      ""
      "varying vec4 pos;"
      "void main()"
      "{"
      "   gl_FragColor = vec4(pos.rgb, 1.0);"
      "}"
   };
   const char *vprogram1 = {
      "/* Parameters of the shader  */"
      "uniform sampler3D tex; /* The texture*/"
      "uniform sampler2D tex1fbo, tex2fbo;"
      "uniform int maxsteps;"
      "uniform int falseAlpha;"
      ""
      ""
      "void main()"
      "{"
      "  vec4 pos;"
      " gl_TexCoord[0] = gl_Vertex;"
      " gl_Position = ftransform();"
      "}"
   };
   const char *fprogram1 = {
      "/* Parameters of the shader  */"
      "uniform sampler3D tex;"
      "uniform sampler2D tex1fbo, tex2fbo;"
      "uniform int maxsteps;"
      "uniform int falseAlpha;"
      ""
      ""
      "void main()"
      "{"
      " vec4 voxelcolor;" 
      " vec4 acc;" 
      " vec3 ray, incray;"
      " vec3 ray_direction, rayStart, rayEnd;"
      " int step;"
      " float inc, f, maxLength, alpha;"
      " "
      " acc = vec4(0.0);"
      " rayStart = texture2D(tex1fbo, gl_TexCoord[0].st).xyz;"
      " rayEnd = texture2D(tex2fbo, gl_TexCoord[0].st).xyz;"
      " "
      " alpha = texture2D(tex1fbo, gl_TexCoord[0].st).a;"
      " if (alpha <= 0)"
      "    discard;"
      " "
      " ray_direction = rayEnd - rayStart;"
      ""
      " if (ray_direction == vec3(0.0,0.0,0.0))"
      "    discard;"
      ""
      " maxLength = length(ray_direction);"
      " inc = float(maxLength) / float(maxsteps);"
      " incray = vec3(inc) * normalize(ray_direction);"
      " "
      " ray = vec3(0.0);"
      " for (step = 0; step < maxsteps; step ++)"
      " { " 
      ""
      "  if ( (acc.a >= 0.99) || (length(ray) >= maxLength) )"
      "  {"
      "    acc.a = 1.0;"
      "    break;"
      "  }"
      ""
      "  voxelcolor = texture3D(tex, ray + rayStart);"
      "  if (falseAlpha != 0)"
      "     voxelcolor.a = voxelcolor.r * 0.1; "
      ""
      "  acc.rgb += voxelcolor.rgb * voxelcolor.a * (1.0 - acc.a);"
      "  acc.a += voxelcolor.a * (1.0 - acc.a);"
      "  ray += incray;"
      " } "
      " "
      " gl_FragColor = acc;"
      "}"
   };
   S3DShaderObj *rayshader, *rayFBOshader;
   S3DFBO *ray1fbo, *ray2fbo;   
   GLint viewport[4];
   GLuint tex1fbo, tex2fbo;
   int w, h;

   glGetIntegerv(GL_VIEWPORT, viewport);
   w = viewport[2];
   h = viewport[3];

   // First Step in FBO:
   if (this->mobile == false)
   {
      ray1fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			   true, false);
   }
   else
   {
      if (this->auxfbo[0] == 0)
      {
	 ray1fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			      true, false);
	 this->auxfbo[0] = ray1fbo;
      }
      else
	 ray1fbo = this->auxfbo[0];
   }


   ray1fbo->renderFBO();

   glDisable(GL_BLEND);
   glClearColor(0, 0, 0, 0);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   if (this->mobile == false)
   {
      rayFBOshader = new S3DShaderObj();
      rayFBOshader->loadTextPrograms(vprogram0, fprogram0);
   }
   else
   {
      if (this->auxshader[0] == 0)
      {
	 rayFBOshader = new S3DShaderObj();
	 rayFBOshader->loadTextPrograms(vprogram0, fprogram0);
	 this->auxshader[0] = rayFBOshader;
      }
      else
	 rayFBOshader = this->auxshader[0];
   }

   rayFBOshader->useProgram();

   loc = rayFBOshader->locate("position");
   glUniform3f (loc, -0.5, -0.5, -0.5);

   loc = rayFBOshader->locate("size");
   glUniform3f (loc, 1, 1, 1);


   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);

      glTranslatef (-0.5, -0.5, -0.5);
      S3DPrimitive3D::drawBox(GL_POLYGON, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
   }
   glPopMatrix();
   // Obtain the textures:
   tex1fbo = ray1fbo->getTexture ();

   glMatrixMode(GL_MODELVIEW);
   ray1fbo->renderFramebuffer();


   // Second Step in FBO:
   if (this->mobile == false)
   {
      ray2fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			   true, false);
   }
   else
   {
      if (this->auxfbo[1] == 0)
      {
	 ray2fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			      true, false);
	 this->auxfbo[1] = ray2fbo;
      }
      else
	 ray2fbo = this->auxfbo[1];
   }

   ray2fbo->renderFBO();
   glDisable(GL_BLEND);
   glClearColor(0, 0, 0, 0);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glEnable(GL_CULL_FACE);
   glCullFace(GL_FRONT);

   glMatrixMode(GL_MODELVIEW);

   glPushMatrix();
   {
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);

      glTranslatef (-0.5, -0.5, -0.5);
      S3DPrimitive3D::drawBox(GL_POLYGON, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
   }
   glPopMatrix();
   rayFBOshader->doNotUseProgram();

   // Obtain the textures:
   tex2fbo = ray2fbo->getTexture ();

   glMatrixMode(GL_MODELVIEW);
   ray2fbo->renderFramebuffer();


   // Third Step in framebuffer:

   glEnable(GL_BLEND);
   glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   if (this->mobile == false)
   {
      rayshader = new S3DShaderObj();
      rayshader->loadTextPrograms(vprogram1, fprogram1);
   }
   else
   {
      if (this->auxshader[1] == 0)
      {
	 rayshader = new S3DShaderObj();
	 rayshader->loadTextPrograms(vprogram1, fprogram1);
	 this->auxshader[1] = rayshader;
      }
      else
	 rayshader = this->auxshader[1];
   }

   rayshader->useProgram();

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glEnable(GL_TEXTURE_3D);

   glActiveTexture(GL_TEXTURE0); // Multitexture
   glBindTexture(GL_TEXTURE_3D, this->idtex3D);

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glBindTexture(GL_TEXTURE_2D, tex1fbo);

   glActiveTexture(GL_TEXTURE2); // Multitexture
   glBindTexture(GL_TEXTURE_2D, tex2fbo);

   glActiveTexture(GL_TEXTURE0); // Multitexture   
   glDisable(GL_LIGHTING);
   glColor4f(0, 0, 1, 1);


   loc = rayshader->locate("tex");
   glUniform1i (loc, 0);

   loc = rayshader->locate("tex1fbo");
   glUniform1i (loc, 1);

   loc = rayshader->locate("tex2fbo");
   glUniform1i (loc, 2);

   loc = rayshader->locate("maxsteps");
   glUniform1i (loc, steps);

   loc = rayshader->locate("falseAlpha");
   glUniform1i (loc, falseAlpha);

   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);

   glMatrixMode(GL_TEXTURE);
   glPushMatrix();
   glLoadIdentity();

   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   glOrtho(0.0, 1.0, 0.0, 1.0, -10, 10);
   
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glLoadIdentity();
      S3DPrimitive3D::drawPlane(GL_POLYGON, 0, 0, 0, 1, 1);
   }
   glPopMatrix();
   rayshader->doNotUseProgram();

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();

   glMatrixMode(GL_TEXTURE);
   glPopMatrix();
   
   glMatrixMode(GL_MODELVIEW);

   if (this->mobile == false)
   {
      delete ray1fbo;
      delete ray2fbo;
      delete rayshader;
      delete rayFBOshader;
   }


   return;
}


// --------------------------------------------------
void S3DDirectr::directRayRender(unsigned int steps, bool falseAlpha)
{
   GLint loc;
   const char *vprogram0 = {
      "/* Parameters of the shader  */"
      "uniform vec3 position; /* The position of the box*/"
      "uniform vec3 size; /* The size of the box*/"
      ""
      "varying vec4 pos;"
      "void main()"
      "{"
      "   pos = gl_Vertex;"
      "   gl_Position = ftransform();"
      "}"
   };
   const char *fprogram0 = {
      "/* Parameters of the shader  */"
      "uniform vec3 position; /* The position of the box*/"
      "uniform vec3 size; /* The size of the box*/"
      ""
      "varying vec4 pos;"
      "void main()"
      "{"
      "   gl_FragColor = vec4(pos.rgb, 1.0);"
      "}"
   };
   const char *vprogram1 = {
      "/* Parameters of the shader  */"
      "uniform sampler3D tex; /* The texture*/"
      "uniform sampler2D tex1fbo, tex2fbo;"
      "uniform sampler3D normaltex;"
      "uniform sampler1D indextex; /* The transfer function */" 
      "uniform sampler1D shtex;"
      "uniform int maxsteps;"
      ""
      "varying vec3 lightDir;"
      "varying vec3 lightHV;"
      ""
      "void main()"
      "{"
      "  vec4 pos;"
      " gl_TexCoord[0] = gl_Vertex;"
      " lightDir = normalize(vec3(gl_LightSource[0].position));"
      " lightDir = gl_LightSource[0].halfVector.xyz;"
      " gl_Position = ftransform();"
      "}"
   };
   const char *fprogram1 = {
      "/* Parameters of the shader  */"
      "uniform sampler3D tex;"
      "uniform sampler2D tex1fbo, tex2fbo;"
      "uniform sampler3D normaltex;"
      "uniform sampler1D indextex; /* The transfer function */" 
      "uniform sampler1D shtex;"
      "uniform int maxsteps;"
      ""
      "varying vec3 lightDir;"
      "varying vec3 lightHV;"
      ""
      "void main()"
      "{"
      " vec4 voxelcolor, vox;" 
      " vec4 acc;" 
      " vec3 normal;"
      " float NdotL, NdotHL;"
      " float sh;"
      " vec3 ray, incray;"
      " vec3 ray_direction, rayStart, rayEnd;"
      " int step;"
      " float inc, f, maxLength, alpha;"
      " "
      " acc = vec4(0.0);"
      " rayStart = texture2D(tex1fbo, gl_TexCoord[0].st).xyz;"
      " rayEnd = texture2D(tex2fbo, gl_TexCoord[0].st).xyz;"
      " "
      " alpha = texture2D(tex1fbo, gl_TexCoord[0].st).a;"
      " if (alpha <= 0)"
      "    discard;"
      " "
      " ray_direction = rayEnd - rayStart;"
      ""
      " if (ray_direction == vec3(0.0,0.0,0.0))"
      "    discard;"
      ""
      " maxLength = length(ray_direction);"
      " inc = float(maxLength) / float(maxsteps);"
      " incray = vec3(inc) * normalize(ray_direction);"
      " "
      " ray = vec3(0.0);"
      " for (step = 0; step < maxsteps; step ++)"
      " { " 
      ""
      "  if ( (acc.a >= 0.99) || (length(ray) >= maxLength) )"
      "  {"
      "    acc.a = 1.0;"
      "    break;"
      "  }"
      ""
      "  voxelcolor = texture1D(indextex, texture3D(tex, ray + rayStart).s);"
      ""
      "  normal = texture3D(normaltex, ray + rayStart).xyz - vec3(-0.5);" 
      "  NdotL = max(dot(normal, lightDir), 0.0);"
      "  NdotHL = max(dot(normal, lightHV), 0.0);"
      "  "
      "  sh = texture1D(shtex, texture3D(tex, ray + rayStart).s);"
//      "  vox = vec4(voxelcolor.rgb * NdotL + vec3(pow(NdotHL, sh)),"
      "  vox = vec4(voxelcolor.rgb * NdotL,"
      "             voxelcolor.a);"
      "  acc.rgb += vox.rgb * vox.a * (1.0 - acc.a);"
      "  acc.a += vox.a * (1.0 - acc.a);"
      "  ray += incray;"
      " } "
      " "
      " gl_FragColor = acc;"
      "}"
   };
   S3DShaderObj *rayshader, *rayFBOshader;
   S3DFBO *ray1fbo, *ray2fbo;   
   GLint viewport[4];
   GLuint tex1fbo, tex2fbo;
   int w, h;

   glGetIntegerv(GL_VIEWPORT, viewport);
   w = viewport[2];
   h = viewport[3];

   // First Step in FBO:
   if (this->mobile == false)
   {
      ray1fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			   true, false);
   }
   else
   {
      if (this->auxfbo[2] == 0)
      {
	 ray1fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			      true, false);
	 this->auxfbo[2] = ray1fbo;
      }
      else
	 ray1fbo = this->auxfbo[2];
   }

   ray1fbo->renderFBO();

   glDisable(GL_BLEND);
   glClearColor(0, 0, 0, 0);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   if (this->mobile == false)
   {
      rayFBOshader = new S3DShaderObj();
      rayFBOshader->loadTextPrograms(vprogram0, fprogram0);
   }
   else
   {
      if (this->auxshader[2] == 0)
      {
	 rayFBOshader = new S3DShaderObj();
	 rayFBOshader->loadTextPrograms(vprogram0, fprogram0);
	 this->auxshader[2] = rayFBOshader;
      }
      else
	 rayFBOshader = this->auxshader[2];
   }

   rayFBOshader->useProgram();

   loc = rayFBOshader->locate("position");
   glUniform3f (loc, -0.5, -0.5, -0.5);

   loc = rayFBOshader->locate("size");
   glUniform3f (loc, 1, 1, 1);


   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);

      glTranslatef (-0.5, -0.5, -0.5);
      S3DPrimitive3D::drawBox(GL_POLYGON, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
   }
   glPopMatrix();
   // Obtain the textures:
   tex1fbo = ray1fbo->getTexture ();

   glMatrixMode(GL_MODELVIEW);
   ray1fbo->renderFramebuffer();


   // Second Step in FBO:
   if (this->mobile == false)
   {
      ray2fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			   true, false);
   }
   else
   {
      if (this->auxfbo[3] == 0)
      {
	 ray2fbo = new S3DFBO(w, h, GL_RGBA, GL_RGBA, GL_FLOAT, GL_NEAREST, 
			      true, false);
	 this->auxfbo[3] = ray2fbo;
      }
      else
	 ray2fbo = this->auxfbo[3];
   }

   ray2fbo->renderFBO();
   glDisable(GL_BLEND);
   glClearColor(0, 0, 0, 0);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glEnable(GL_CULL_FACE);
   glCullFace(GL_FRONT);

   glMatrixMode(GL_MODELVIEW);

   glPushMatrix();
   {
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);

      glTranslatef (-0.5, -0.5, -0.5);
      S3DPrimitive3D::drawBox(GL_POLYGON, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
   }
   glPopMatrix();
   rayFBOshader->doNotUseProgram();

   // Obtain the textures:
   tex2fbo = ray2fbo->getTexture ();

   glMatrixMode(GL_MODELVIEW);
   ray2fbo->renderFramebuffer();


   // Third Step in framebuffer:

   glEnable(GL_BLEND);
   glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   if (this->mobile == false)
   {
      rayshader = new S3DShaderObj();
      rayshader->loadTextPrograms(vprogram1, fprogram1);
   }
   else
   {
      if (this->auxshader[3] == 0)
      {
	 rayshader = new S3DShaderObj();
	 rayshader->loadTextPrograms(vprogram1, fprogram1);
	 this->auxshader[3] = rayshader;
      }
      else
	 rayshader = this->auxshader[3];
   }

   rayshader->useProgram();

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glEnable(GL_TEXTURE_3D);

   glActiveTexture(GL_TEXTURE0); // Multitexture
   glBindTexture(GL_TEXTURE_3D, this->idtex3D);

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glBindTexture(GL_TEXTURE_2D, tex1fbo);

   glActiveTexture(GL_TEXTURE2); // Multitexture
   glBindTexture(GL_TEXTURE_2D, tex2fbo);


   glActiveTexture(GL_TEXTURE3); // Multitexture
   glBindTexture(GL_TEXTURE_3D, this->idtexnormal3D);

   glActiveTexture(GL_TEXTURE4); // Multitexture
   glBindTexture(GL_TEXTURE_1D, this->idpal0);

   glActiveTexture(GL_TEXTURE5); // Multitexture
   glBindTexture(GL_TEXTURE_1D, this->idsh0);

   glActiveTexture(GL_TEXTURE0); // Multitexture   
   glEnable(GL_LIGHT0);
   glColor4f(0, 0, 1, 1);


   loc = rayshader->locate("tex");
   glUniform1i (loc, 0);

   loc = rayshader->locate("tex1fbo");
   glUniform1i (loc, 1);

   loc = rayshader->locate("tex2fbo");
   glUniform1i (loc, 2);

   loc = rayshader->locate("normaltex");
   glUniform1i (loc, 3);

   loc = rayshader->locate("indextex");
   glUniform1i (loc, 4);

   loc = rayshader->locate("shtex");
   glUniform1i (loc, 5);

   loc = rayshader->locate("maxsteps");
   glUniform1i (loc, steps);


   glEnable(GL_CULL_FACE);
   glCullFace(GL_BACK);

   glMatrixMode(GL_TEXTURE);
   glPushMatrix();
   glLoadIdentity();

   glMatrixMode(GL_PROJECTION);
   glPushMatrix();
   glLoadIdentity();
   glOrtho(0.0, 1.0, 0.0, 1.0, -10, 10);
   
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glLoadIdentity();
      S3DPrimitive3D::drawPlane(GL_POLYGON, 0, 0, 0, 1, 1);
   }
   glPopMatrix();
   rayshader->doNotUseProgram();

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();

   glMatrixMode(GL_TEXTURE);
   glPopMatrix();
   
   glMatrixMode(GL_MODELVIEW);

   if (this->mobile == false)
   {
      delete ray1fbo;
      delete ray2fbo;
      delete rayshader;
      delete rayFBOshader;
   }


   return;
}


// --------------------------------------------------
void S3DDirectr::directRender(unsigned int numslices)
{
   double r, dr, z, dz;
   unsigned int i;
   float material_diffuse[4] = {1.0, 1.0, 1.0, 1.0};

   if (this->data == 0)
      return;

   glEnable (GL_LIGHTING) ;

   glActiveTexture(GL_TEXTURE0); // Multitexture

   glDisable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
//   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);


   glEnable(GL_TEXTURE_1D);
   glEnable(GL_TEXTURE_3D);
   glBindTexture(GL_TEXTURE_3D, this->idtex3D);
//   glDisable(GL_TEXTURE_3D);


   glActiveTexture(GL_TEXTURE2); // Multitexture
   glBindTexture(GL_TEXTURE_3D, this->idtexnormal3D);
   glEnable(GL_BLEND);

//   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glEnable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_1D);
   glBindTexture(GL_TEXTURE_1D, this->idpal0);

   glActiveTexture(GL_TEXTURE3); // Multitexture
   glEnable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_1D);
   glBindTexture(GL_TEXTURE_1D, this->idsh0);

   glActiveTexture(GL_TEXTURE0); // Multitexture

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glMatrixMode(GL_TEXTURE);
      glPushMatrix();
      glLoadIdentity();
   
      // scale the texture
      glScalef(this->scTexX, this->scTexY, this->scTexZ);

      // center the texture coords around the [0,1] cube 
      glTranslatef(0.5 + this->trTexX, 0.5 + this->trTexY, 0.5 + this->trTexZ);
  
      // a rotation just to make the picture more interesting 
      glRotatef(-this->rotTexZ, 0.0, 0.0, 1.0);
      glRotatef(-this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(-this->rotTexX, 1.0, 0.0, 0.0);


      r = -0.87;
      dr = 1.74 / (float) numslices;
//      z = -0.5;
      z = -1.0;
      dz = 1.00 / (float) numslices;

      material_diffuse[4] = (float) i / (float) (numslices);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
      glColor4f (1, 1, 1, (float) i / (float) (1000 * numslices));
//	    glColor4f (1, 1, 1, 1);



      glMatrixMode(GL_MODELVIEW);
      for (i = 0; i < numslices; i++) 
      {

	 glBegin(GL_QUADS);
	 {
	    glMultiTexCoord3f(GL_TEXTURE0, -0.87, -0.87, r);
	    glVertex3f(-1.0, -1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, 0.87, -0.87, r);
	    glVertex3f(1.0,-1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, 0.87,  0.87, r);
	    glVertex3f(1.0, 1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, -0.87, 0.87, r);
	    glVertex3f(-1.0, 1.0, z);
	 }
	 glEnd();
	 r += dr;
	 z += dz;
      }

      glMatrixMode(GL_TEXTURE);
      glPopMatrix();

   }
   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_1D);
}


// --------------------------------------------------
void S3DDirectr::directSimpleRender(unsigned int numslices)
{
   double r, dr, z, dz;
   unsigned int i;

   if ( (this->data == 0) || (this->idtex3D == 0) )
      return;

//   glActiveTexture(GL_TEXTURE0); // Multitexture

   glEnable(GL_BLEND);
//   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//   glBlendFunc(GL_ONE, GL_ONE);
   glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);


//   glDisable(GL_TEXTURE_1D);
//   glDisable(GL_TEXTURE_2D);
   glEnable(GL_TEXTURE_3D);


   glBindTexture(GL_TEXTURE_3D, this->idtex3D);
/*
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
*/


   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glMatrixMode(GL_TEXTURE);
      glPushMatrix();

      glLoadIdentity();

      // scale the texture
      glScalef(this->scTexX, this->scTexY, this->scTexZ);

      // center the texture coords around the [0,1] cube 
      glTranslatef(0.5 + this->trTexX, 0.5 + this->trTexY, 0.5 + this->trTexZ);
  
      // a rotation just to make the picture more interesting 
      glRotatef(-this->rotTexZ, 0.0, 0.0, 1.0);
      glRotatef(-this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(-this->rotTexX, 1.0, 0.0, 0.0);

      r = -0.87;
      dr = 1.74 / (float) numslices;
//      z = -0.5;
      z = -1.0;
      dz = 1.00 / (float) numslices;

//      glColor4f (1, 1, 1, (float) i / (float) (1000 * numslices));
      glColor4f (1, 1, 1, 1);



      glMatrixMode(GL_MODELVIEW);
      for (i = 0; i < numslices; i++) 
      {

	 glBegin(GL_QUADS);
	 {
	    glTexCoord3f(-0.87, -0.87, r);
	    glVertex3f(-1.0, -1.0, z); 
	    glTexCoord3f(0.87, -0.87, r);
	    glVertex3f(1.0,-1.0, z); 
	    glTexCoord3f(0.87,  0.87, r);
	    glVertex3f(1.0, 1.0, z); 
	    glTexCoord3f(-0.87, 0.87, r);
	    glVertex3f(-1.0, 1.0, z);
	 }
	 glEnd();
	 r += dr;
	 z += dz;
      }

      glMatrixMode(GL_TEXTURE);
      glPopMatrix();

   }
   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glDisable(GL_TEXTURE_3D);
}


// --------------------------------------------------
void S3DDirectr::directSimpleSlice(unsigned int numslices, float slice)
{
   double r, dr, z, dz;

   if ( (this->data == 0) || (this->idtex3D == 0) )
      return;

//   glActiveTexture(GL_TEXTURE0); // Multitexture

//   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//   glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glEnable(GL_TEXTURE_3D);

   numslices = numslices - 1; // To compute the loop

   glBindTexture(GL_TEXTURE_3D, this->idtex3D);
/*
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
*/
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glMatrixMode(GL_TEXTURE);
      glPushMatrix();

      glLoadIdentity();

      // center the texture coords around the [0,1] cube 
      glTranslatef(0.5, 0.5, 0.5);


      // scale the texture
      glScalef(this->scTexX, this->scTexY, this->scTexZ);

      glTranslatef(this->trTexX, this->trTexY, this->trTexZ);
  
      // a rotation just to make the picture more interesting 
      glRotatef(-this->rotTexZ, 0.0, 0.0, 1.0);
      glRotatef(-this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(-this->rotTexX, 1.0, 0.0, 0.0);

      // center the texture coords around the [0,1] cube 
      glTranslatef(-0.5, -0.5, -0.5);

      glColor4f (1.0, 1.0, 1.0, 1.0);

      glMatrixMode(GL_MODELVIEW);

      if (slice <= 0)
	 r = 0.0;
      if (slice > numslices)
	 r = 1.0;
      else
	 r = (float) slice / (float) numslices;

      glBegin(GL_QUADS);
      {
	 glTexCoord3f(0, 0, r);
	 glVertex3f(-1.0, -1.0, 0); 
	 glTexCoord3f(1, 0, r);
	 glVertex3f(1.0, -1.0, 0); 
	 glTexCoord3f(1,  1, r);
	 glVertex3f(1.0, 1.0, 0); 
	 glTexCoord3f(0, 1, r);
	 glVertex3f(-1.0, 1.0, 0);
      }
      glEnd();

      glMatrixMode(GL_TEXTURE);
      glPopMatrix();

   }
   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glDisable(GL_TEXTURE_3D);
}


// --------------------------------------------------
void S3DDirectr::scale(double x, double y, double z)
{
   this->scTexX = x;
   this->scTexY = y;
   this->scTexZ = z;
}


// --------------------------------------------------
void S3DDirectr::move(double x, double y, double z)
{
   this->trTexX = x;
   this->trTexY = y;
   this->trTexZ = z;
}


// --------------------------------------------------
void S3DDirectr::rotate(double x, double y, double z)
{
   int i;

   this->rotTexX = x;
   this->rotTexY = y;
   this->rotTexZ = z;


   while (this->rotTexX > 360)
      this->rotTexX -= 360; 
   
   while (this->rotTexY > 360)
      this->rotTexY -= 360; 
   
   while (this->rotTexZ > 360)
      this->rotTexZ -= 360; 

   while (this->rotTexX < 0)
      this->rotTexX += 360; 
   
   while (this->rotTexY < 0)
      this->rotTexY += 360; 
   
   while (this->rotTexZ < 0)
      this->rotTexZ += 360; 

}


// --------------------------------------------------
double S3DDirectr::usedMemory(void)
{
   double memory;
   int i;

   memory = 0;

   if (this->data != 0)
      memory += this->data->usedMemory();

   if (this->normaldata != 0)
      memory += this->normaldata->usedMemory();

   if (this->palette != 0)
      memory += this->palette->usedMemory();

   if (this->shininess != 0)
      memory += this->shininess->usedMemory();

   return memory;
}

