#include "octnode.hh"


// --------------------------------------------------
S3DOctNode::S3DOctNode (void)
{
   int i;

   this->level = 0;
   this->rotTexX = this->rotTexX =  this->rotTexY = 0.0;
   
   this->data = 0;
   this->normaldata = 0;
   this->palette = 0;
   this->shininess = 0;

   for (i = 0; i < 8; i ++)
      this->child[i] = 0;

   this->octx = 0;
   this->octy = 0;
   this->octz = 0;
   this->octw = 1.0;
   this->octh = 1.0;
   this->octd = 1.0;

   this->idpal0 = 0;
   this->idtex3D = 0;
   this->idtexnormal3D = 0;
}


// --------------------------------------------------
S3DOctNode::S3DOctNode (S3DDataSet *dst)
{
   int i;

   this->level = 0;
   this->rotTexX = this->rotTexX =  this->rotTexY = 0.0;
   
   for (i = 0; i < 8; i ++)
      this->child[i] = 0;

   this->data = dst->getData("gray_ub");
   this->normaldata = dst->getData("normal_ub");
   this->palette = dst->getData("palette_ub");
   this->shininess = dst->getData("shininess_ub");

   this->octx = 0;
   this->octy = 0;
   this->octz = 0;
   this->octw = 1.0;
   this->octh = 1.0;
   this->octd = 1.0;

   this->idpal0 = 0;
   this->idtex3D = 0;
   this->idtexnormal3D = 0;
}


// --------------------------------------------------
S3DOctNode::S3DOctNode(S3DOctNode &node)
{
   // TODO
}


// --------------------------------------------------
S3DOctNode::~S3DOctNode (void)
{
   // This object will not free the data
}


// --------------------------------------------------
S3DOctNode *S3DOctNode::getChild (unsigned char pos)
{
   return this->child[pos];
}


// --------------------------------------------------
void S3DOctNode::directPreRender(void)
{
   int i, j, k;
   unsigned int w, h, d;
   unsigned long int pos;
   unsigned char f;
   GLenum format;


   if (this->data == 0)
      return;

   if (f & S3DData::DATA_UNSIGNED_BYTE == 0)
   {
      std::cerr << "Warning: The type of the data must be unsigned byte to"
		<< " render it directly to the GPU" << std::endl;
      return;
   }

   w = this->data->getWidth();
   h = this->data->getHeight();
   d = this->data->getDepth();

   glActiveTexture(GL_TEXTURE0); // Multitexture
   glEnable(GL_TEXTURE_3D);
   if (this->idtex3D != 0)
      glDeleteTextures(1, &(this->idtex3D));
   glGenTextures(1, &(this->idtex3D));

   glBindTexture(GL_TEXTURE_3D, this->idtex3D);
   
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP);
   
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
//   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   switch (this->data->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   f = this->data->formatsAvailable();
   glTexImage3D(GL_TEXTURE_3D, 0, format, w, h, d, 0, format, 
		GL_UNSIGNED_BYTE, this->data->getRawUB());

   // Prerender normal too:
   if (this->normaldata == 0)
      return;

   glActiveTexture(GL_TEXTURE2); // Multitexture
   glEnable(GL_TEXTURE_3D);
   if (this->idtexnormal3D != 0)
      glDeleteTextures(1, &(this->idtexnormal3D));
   glGenTextures(1, &(this->idtexnormal3D));

   glBindTexture(GL_TEXTURE_3D, this->idtexnormal3D);
   
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP);
   
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//   glTexParameteri(GL_TEXTURE_3D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
//   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

   glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB, w, h, d, 0, GL_RGB, 
		GL_UNSIGNED_BYTE, this->normaldata->getRawUB());
}


// --------------------------------------------------
void S3DOctNode::pointsRender(void)
{
   unsigned long int i, j, k;
   unsigned long int w, h, d;
   unsigned char *v;

   if (this->data == 0)
      return;

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_1D);
   glDisable(GL_BLEND);


   w = this->data->getWidth();
   h = this->data->getHeight();
   d = this->data->getDepth();

   glPushMatrix();
   {
      // a rotation just to make the picture more interesting 
      glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
      glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);
      
      glBegin(GL_POINTS);
      for (k = 0; k < d; k++)
	 for (j = 0; j < h; j++)
	    for (i = 0; i < w; i++)
	    {
	       v = (unsigned char *) this->data->getData(i, j, k);

	       switch (this->data->getSPC())
	       {
		  case 1: {
		     glColor3ub (*v, *v, *v);
		  } break;

		  case 3: {
		     glColor3ub (v[0], v[1], v[2]);
		  } break;

		  case 4: {
		     glEnable(GL_BLEND);
		     glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
		     glColor4ub (v[0], v[1], v[2], v[3]);
		  } break;
	       }
	       glVertex3f(i / (float) w - 0.5, 
			  j / (float) h - 0.5, 
			  k / (float) d - 0.5);
	    }
      glEnd();

   }
   glPopMatrix();
   
}


// --------------------------------------------------
void S3DOctNode::bboxRender(bool solid)
{
   unsigned long int i, j, k;
   double x, y, z;
   unsigned char *v;
   double anglex, angley;
   

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_1D);
   glDisable(GL_BLEND);

   glPushMatrix();
   {
      if (this->level == 0)
      {
	 // a rotation just to make the picture more interesting 
	 glRotatef(this->rotTexX, 1.0, 0.0, 0.0);
	 glRotatef(this->rotTexY, 0.0, 1.0, 0.0);
	 glRotatef(this->rotTexZ, 0.0, 0.0, 1.0);
      }

      // center the box
      glTranslatef (-0.5, -0.5, -0.5);

      glPushMatrix();
      {
	 glScalef(0.5, 0.5, 0.5);
	 
	 for (i = 0; i < 8; i ++)
	 {
	    if (this->child[i] != 0)
	    {
	       x = (i & 0x01);
	       y = (i & 0x02) >> 1;
	       z = (i & 0x04) >> 2; // * 0.25;
	       glPushMatrix();
	       {
		  glTranslatef(x + 0.5, y + 0.5, z + 0.5);
		  this->child[i]->bboxRender(solid);
	       }
	       glPopMatrix();
	    }
	 }
      }
      glPopMatrix();

      glDisable(GL_BLEND);
      S3DPrimitive3D::drawAxis(0.5, 0.5, 0.5, 0.5);

      glColor3f (0.0, 0.0, 0.8);
      S3DPrimitive3D::drawBox(GL_LINE_STRIP, 0, 0, 0, 1, 1, 1);
      
      if (solid)
      {
	 glEnable(GL_BLEND);
	 glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

	 glColor4f (0.0, 0.3, 0.6, 0.3);
	 S3DPrimitive3D::drawBox(GL_POLYGON, 0, 0, 0, 1, 1, 1);
      }
   }
   glPopMatrix();
}


// --------------------------------------------------
void S3DOctNode::setPalette(void)
{
   unsigned int format;

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glEnable(GL_TEXTURE_1D);

   if (this->idpal0 != 0)
      glDeleteTextures(1, &(this->idpal0));
   glGenTextures(1, &(this->idpal0));

   glBindTexture(GL_TEXTURE_1D, this->idpal0);
   
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP);

   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);   
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);


   switch (this->palette->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   glTexImage1D(GL_TEXTURE_1D, 0, format, 256, 0, format, 
		GL_UNSIGNED_BYTE, this->palette->getRawUB());

   glActiveTexture(GL_TEXTURE0); // Multitexture
}


// --------------------------------------------------
void S3DOctNode::setMaterials(void)
{
   unsigned int format;

   glActiveTexture(GL_TEXTURE3); // Multitexture
   glEnable(GL_TEXTURE_1D);

   if (this->idsh0 != 0)
      glDeleteTextures(1, &(this->idsh0));
   glGenTextures(1, &(this->idsh0));

   glBindTexture(GL_TEXTURE_1D, this->idsh0);
   
   glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP);

   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_NEAREST);   
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MAG_FILTER, GL_LINEAR);
//   glTexParameteri(GL_TEXTURE_1D,GL_TEXTURE_MIN_FILTER, GL_LINEAR);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);


   switch (this->shininess->getSPC())
   {
      case 1: {
	 format = GL_LUMINANCE;
      } break;

      case 3: {
	 format = GL_RGB;
      } break;

      case 4: {
	 format = GL_RGBA;
      } break;
   }

   glTexImage1D(GL_TEXTURE_1D, 0, format, 256, 0, format, 
		GL_UNSIGNED_BYTE, this->shininess->getRawUB());

   glActiveTexture(GL_TEXTURE0); // Multitexture
}


// --------------------------------------------------
void S3DOctNode::directRender(unsigned int numslices)
{
   double r, dr, z, dz;
   unsigned int i;
   float material_diffuse[4] = {1.0, 1.0, 1.0, 1.0};

   if (this->data == 0)
      return;

   glEnable (GL_LIGHTING) ;

   glActiveTexture(GL_TEXTURE0); // Multitexture

   glDisable(GL_TEXTURE_2D);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


   glEnable(GL_TEXTURE_1D);
   glEnable(GL_TEXTURE_3D);
   glBindTexture(GL_TEXTURE_3D, this->idtex3D);
//   glDisable(GL_TEXTURE_3D);


   glActiveTexture(GL_TEXTURE2); // Multitexture
   glBindTexture(GL_TEXTURE_3D, this->idtexnormal3D);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   glActiveTexture(GL_TEXTURE1); // Multitexture
   glEnable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_1D);
   glBindTexture(GL_TEXTURE_1D, this->idpal0);

   glActiveTexture(GL_TEXTURE3); // Multitexture
   glEnable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_1D);
   glBindTexture(GL_TEXTURE_1D, this->idsh0);

   glActiveTexture(GL_TEXTURE0); // Multitexture
   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glMatrixMode(GL_TEXTURE);
      glLoadIdentity();
   
      // center the texture coords around the [0,1] cube 
      glTranslatef(0.5, 0.5, 0.5);
  
      // a rotation just to make the picture more interesting 
      glRotatef(-this->rotTexZ, 0.0, 0.0, 1.0);
      glRotatef(-this->rotTexY, 0.0, 1.0, 0.0);
      glRotatef(-this->rotTexX, 1.0, 0.0, 0.0);


      r = -0.87;
      dr = 1.74 / (float) numslices;
//      z = -0.5;
      z = -1.0;
      dz = 1.00 / (float) numslices;

      material_diffuse[4] = (float) i / (float) (numslices);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
      glColor4f (1, 1, 1, (float) i / (float) (1000 * numslices));
//	    glColor4f (1, 1, 1, 1);



      glMatrixMode(GL_MODELVIEW);
      for (i = 0; i < numslices; i++) 
      {

	 glBegin(GL_QUADS);
	 {
	    glMultiTexCoord3f(GL_TEXTURE0, -0.87, -0.87, r);
	    glVertex3f(-1.0, -1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, 0.87, -0.87, r);
	    glVertex3f(1.0,-1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, 0.87,  0.87, r);
	    glVertex3f(1.0, 1.0, z); 
	    glMultiTexCoord3f(GL_TEXTURE0, -0.87, 0.87, r);
	    glVertex3f(-1.0, 1.0, z);
	 }
	 glEnd();
	 r += dr;
	 z += dz;
      }
   }
   glPopMatrix();
   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_1D);
}


// --------------------------------------------------
double S3DOctNode::rotate(double x, double y, double z)
{
   int i;

   this->rotTexX = x;
   this->rotTexY = y;
   this->rotTexZ = z;

/*
   while (this->rotTexX > 360)
      this->rotTexX -= 360; 
   
   while (this->rotTexY > 360)
      this->rotTexY -= 360; 
   
   while (this->rotTexZ > 360)
      this->rotTexZ -= 360; 

   while (this->rotTexX < 0)
      this->rotTexX += 360; 
   
   while (this->rotTexY < 0)
      this->rotTexY += 360; 
   
   while (this->rotTexZ < 0)
      this->rotTexZ += 360; 
*/

   for (i = 0; i < 8; i ++)
      if (this->child[i] != 0)
	 this->child[i]->rotate(this->rotTexX, this->rotTexY, this->rotTexZ);
}


// --------------------------------------------------
double S3DOctNode::usedMemory(void)
{
   double memory;
   int i;

   if (this->data != 0)
      memory = this->data->usedMemory();
   else
      memory = 0;

   for (i = 0; i < 8; i++)
      if (this->child[i] != 0)
	 memory += this->child[i]->usedMemory();

   return memory;
}


// --------------------------------------------------
unsigned int S3DOctNode::getLevel(void)
{
   return this->level;
}


// --------------------------------------------------
void S3DOctNode::setLevel(unsigned int l)
{
   this->level = l;
}


// --------------------------------------------------
void S3DOctNode::setCoord(double x, double y, double z, 
			  double w, double h, double d)
{
   this->octx = x;
   this->octy = y;
   this->octz = z;
   this->octw = w;
   this->octh = h;
   this->octd = d;
}


// --------------------------------------------------
void S3DOctNode::subdivide(unsigned int criteria, double value)
{
   bool deletedata; 
   bool stop = true;
   unsigned int x, y, z, w, h, d;
   S3DData *newdata;
   int i, j, k;
   double a0, a1, a2, b0, b1, b2;

   if (this->data == 0)
      return;

   switch (criteria)
   {
      case S3DOctNode::STOP_PERCENT: {
	 // TODO
	 std::cerr << "Not done yet :(\n";
      } break;
   
      case S3DOctNode::STOP_SIZE: {
	 if ( (this->data->getWidth() > value) ||
	      (this->data->getHeight() > value) ||
	      (this->data->getDepth() > value) )
	    stop = false;
      } break;

      case S3DOctNode::STOP_LEVEL: {
	 // TODO
	 std::cerr << "Not done yet :(\n";
      } break;
   }

   deletedata = false;

   if (!stop)
   {
      w = this->data->getWidth() / 2;
      h = this->data->getHeight() / 2;
      d = this->data->getDepth() / 2;

      for (i = 0; i < 8; i ++)
      {
	 x = (i & 0x01) * w;
	 y = ((i & 0x02) >> 1) * h;
	 z = ((i & 0x04) >> 2) * d;

	 this->child[i] = 0;

	 newdata = this->data->copy(x, y, z, w, h, d);
//	 newnormaldata = this->normaldata->copy(x, y, z, w, h, d);
	 if (newdata != 0)
	 {

/* TODO
	    this->child[i] = new S3DOctNode(newdataset);
*/
	    this->child[i]->setLevel(this->level + 1);

	    // Select the position of the nodes and its size:
	    b0 = this->octw * 0.5;
	    b1 = this->octh * 0.5;
	    b2 = this->octd * 0.5;

	    a0 = this->octx + b0 * (i & 0x01);
	    a1 = this->octy + b1 * ((i & 0x02) >> 1);
	    a2 = this->octz + b2 * ((i & 0x04) >> 2);

	    // Set the polar position of the children
	    this->child[i]->setCoord(a0, a1, a2, b0, b1, b2);

	    deletedata = true;
	    this->child[i]->subdivide(criteria, value);
	 }
	 else
	    std::cerr << "Node empty: " <<x<< ", " <<y<< ", " <<z<< ")\n";
      }

      if (deletedata)
      {
	 delete this->data;
	 this->data = 0;
      }
   }

   return;
}

