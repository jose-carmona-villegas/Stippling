#ifndef __DATASET__
#define __DATASET__

#include <GL/glew.h>
#include <vector>
#include "data.hh"

/** @class   S3DDataSet dataset.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is the set of 3D data of a volume, 
 *           it can contain any kind of volume
 *
 *  @bug     Not tested yet
 */

class S3DDataSet {
   public:

      // ----------------------------------------------------------------
      // Dictionary for types of data:
      // ------------------------------

      // The data is color (RGBA) of unsgned byte (4 spc):
      // "rgba_ub"

      // The data is color (RGBA) of double (4 spc):
      // "rgba_d"

      // The data is gray scale of unsigned byte (1 spc):
      // "gray_ub"

      // The data is gray scale of double (1 spc):
      // "gray_d"

      // The data is the normals, unsigned byte (3 spc):
      // "normal_ub"

      // The data is the normals, double (3 spc):
      // "normal_d"

      // The data is an array of colors, unsigned byte (4 spc):
      // "palette_ub"

      // The data is an array of colors, double (4 spc):
      // "palette_d"

      // ***************************************** //
      // ADD HERE YOUR NEW STANDARD TYPES OF DATA  //
      // ***************************************** //

      // ----------------------------------------------------------------


      /** 
       * @post Constructor. Inizialite the empty data set.
       */
      S3DDataSet(void);

      /** 
       * @post Destructor. Clean the data set.
       */
      ~S3DDataSet(void);


      /** 
       * @param[in] name The name of the data
       * @param[in] data The data to add
       * @pre name must be a non empty valid name
       * @post Add new data to the data set
       * @warning Data are not copied so DO NOT delete data in other place and 
       *          DO NOT use it in other place. If you want to be sure about 
       *          your original data, use: data->copy()
       */
      void addData(const char *name, S3DData *data);

      /** 
       * @param[in] name The name of the data
       * @param[in] data The data to set
       * @pre name must be a non empty valid name
       * @post Change data to other, if there was other with that name, 
       *       the old data is removed
       * @warning Data are not copied so DO NOT delete data in other place and 
       *          DO NOT use it in other place. If you want to be sure about 
       *          your original data, use: data->copy()
       */
      void setData(const char *name, S3DData *data);

      /** 
       * @param[in] name The name of the data
       * @param[in] data The data to remove
       * @pre name must be a non empty valid name
       * @post Remove the data 
       * @warning The data are removed from memory too
       */
      void removeData(const char *name);

      /** 
       * @param[in] name The name of the data
       * @pre name must be a non empty valid name
       * @post The data with the given name 
       * @warning This is not a copy, so, do not free the array
       */
      S3DData *getData(const char *name);

      /** 
       * @param[in] name The name of the data
       * @pre name must be a non empty valid name
       * @post The index of the data, 
       *       or a number less than 0, if is was not found
       */
      long long int getIndexFromData(const char *name);

      /** 
       * @param[in] name The name of the data
       * @pre name must be a non empty valid name
       * @post The name of the file where data will be saved
       * @warning This is not a copy, so, do not free the array
       */
      const char *getFileName(const char *name);

      /** 
       * @post The used memory in bytes
       */
      double usedMemory(void);

   private:
      /// The data
      std::vector<S3DData *> data;
      /// The names
      std::vector<char *> dataname;
      /// The filenames
      std::vector<char *> filename;
};


#endif
