#include <iostream>
#include <math.h>

#include <SDL/SDL.h>
#include <GL/glew.h>

#include "shader.hh"
#include "directr.hh"


void help (void);


int main (int argc, char *argv[])
{
   int tht = 100;
   SDL_Surface *screen;
   SDL_Event event;
   const SDL_VideoInfo* info = NULL;
   int width = 800;
   int height = 800;
   int bpp = 0;
   int flags = 0;
   int quit = 0;
   const GLubyte* strm;
   GLint value;
   GLenum err;
   float fx = -360; // Test variable
   float fy = 360; // Test variable
   float fz = 180; // Test variable
   char text[1000];
   float zoom = -2;
   bool movingmouse = false;
   bool showboundingbox = true;
   long int xini = 0;
   long int yini = 0;
   long int xend = 0;
   long int yend = 0;
   long int zini = 0;
   long int zend = 0;
   float position[] = {0.0f, 0.0f, -1.0f, 1.0f };
   unsigned int moving = 0;
   Uint8 *keystate;
   unsigned int max = 600;
   bool changed = true;
   float transp[3] = {1.0, 1.0, 1.0};
   float tmp_transp[3] = {0.1, 1.0, 1.0};
   float tmpf;

   S3DData *data, *normaldata, *palette, *shininess;
   S3DDataSet *dataset;
   S3DDirectr *node;
   S3DShaderObj *shader, *shader2, *shader3, *active_shader;
   GLuint manejador;
   GLint loc;
   unsigned int i;
   unsigned char val[5];
   bool loadimages, loadmodel, savemodel;
   char *fname, *ifile, *ofile;
   float version;


   /* ----- SDL init --------------- */
   if(SDL_Init(SDL_INIT_VIDEO) < 0) 
   {
      std::cerr << "Video initialization failed: " << SDL_GetError() << "\n";
      exit(-1);
   }
   
   atexit(SDL_Quit);
	
   info = SDL_GetVideoInfo();
   bpp = info->vfmt->BitsPerPixel;
   
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

/*	flags = SDL_OPENGL | SDL_FULLSCREEN; */
   flags = SDL_OPENGL | SDL_RESIZABLE;

/* ----- Setting up the screen surface --------------- */

   screen = SDL_SetVideoMode(width, height, bpp, flags);
   if(screen == 0) 
   {
      std::cerr << "Video mode set failed: " << SDL_GetError() << "\n";
      exit(-1);
   }

   SDL_WM_SetCaption("UI test", 0);


/* ----- Checking for OpenGL 2 --------------- */
   strm = glGetString(GL_VENDOR);
   std::cerr << "Vendor: " << strm << "\n";
   strm = glGetString(GL_RENDERER);
   std::cerr << "Renderer: " << strm << "\n";
   strm = glGetString(GL_VERSION);
   std::cerr << "OpenGL Version: " << strm << "\n";

   version = atof((const char *) strm);

   if (version < 2) 
   {
      std::cerr << "Warning: OpenGL 2 not supported!\n";
   }
   strm = glGetString(GL_VERSION);
   std::cerr << "Detected OpenGL Version >= " << version << "\n";

   strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
   std::cerr << "GLSL Version: " << strm << "\n";


   // Glew init:
   err = glewInit();
   if (GLEW_OK != err)
   {
      /* Problem: glewInit failed, something is seriously wrong. */
      std::cerr << "Error: " << glewGetErrorString(err) << "\n";
      exit (-1);
   }

   std::cerr << "Status: Using GLEW " << glewGetString(GLEW_VERSION) << "\n";

   
   if (!glewGetExtension("ARB_texture_non_power_of_two"))
   {
      std::cerr << "Warning: ARB_texture_non_power_of_two may not be supported"
		<< "\n";
   }


//   SDL_EnableKeyRepeat(0, 0);


   // Volume Test:
   // ---------------------------------------------------------- 
   
   /// Load the shader:
   shader = new S3DShaderObj();
   shader->loadPrograms("../shaders/directr.vert",  // Realistic
			"../shaders/directr.frag");
   shader2 = new S3DShaderObj();
   shader2->loadPrograms("../shaders/npr0.vert",  // NPR
			 "../shaders/npr0.frag");
   shader3 = new S3DShaderObj();
   shader3->loadPrograms("../shaders/light0_direct_r.vert",  // Simple
			 "../shaders/light0_direct_r.frag");

   active_shader = shader;
   
   data = new S3DData();
   //- Make it if loaded:
   normaldata = new S3DData();
   // Palette of colors:
   palette = new S3DData(256, 1, 1, 4, S3DData::DATA_UNSIGNED_BYTE);
   // Palette of shininess:
   shininess = new S3DData(256, 1, 1, 1, S3DData::DATA_UNSIGNED_BYTE);
   //----------------------


   loadimages = loadmodel = savemodel = false;

   ifile = new char[10000];
   ifile[0] = '\0';
   ofile = new char[10000];
   ofile[0] = '\0';

   fname = new char[15000];

   strcpy (ifile, "../media/vol0");
   strcpy (ofile, "../media/vol0");

   if (argc <= 1)
      loadimages = true;
   else
   {
      i = 1;
      while (i < argc)
      {
	 if (!strncmp (argv[i], "help", 4))
	    help();

	 if (!strncmp (argv[i], "load", 4))
	    loadmodel = true;

	 if (!strncmp (argv[i], "import", 6))
	    loadimages = true;

	 if (!strncmp (argv[i], "save", 4))
	    savemodel = true;

	 if (!strncmp (argv[i], "if=", 3))
	 {
	    ifile[0] = '\0';
	    strcpy (ifile, (argv[i]) + 3);
	 }

	 if (!strncmp (argv[i], "of=", 3))
	 {
	    ofile[0] = '\0';
	    strcpy (ofile, (argv[i]) + 3);
	 }

	 i ++;
      }
   }

   std::cerr << "iFile = " << ifile << "\n";
   std::cerr << "oFile = " << ofile << "\n";


   if (loadimages)
   {
      // Load the volume:
//      data->loadFromImages(true, 256, 256, 60, 1, 
//			   "/home/german/f/rodilla_tr/blur/000079%.2d.png",
//			   1, true);
//      data->loadFromImages(true, 128, 128, 358, 1, 
//			   "/home/german/d/pelvis/m000-IM-0001-%.4d.png",
//			   1, true);
//      data->loadFromImages(true, 128, 128, 128, 1, 
//			   "/home/german/d/coro/img/m000-IM-0001-%.4d.png",
//			   1, true);
//      data->loadFromImages(true, 256, 256, 128, 1, 
//			   "/media/cdrom0/tac2/t%d.bmp", 1250, true);
//      data->loadFromImages(true, 256, 256, 256, 1, 
//			   "/Volumes/PEN 32GB/tac1/t%d.bmp", 1, true);
//      data->loadFromImages(true, 256, 256, 256, 1, 
//			   "/media/cdrom0/tac1/t%d.bmp", 1, true);
//      data->loadFromImages(true, 128, 128, 512, 2, 
//			   "/cdrom/tac1/t%d.bmp", 1, true);
//      data->loadFromImages(true, 128, 128, 231, 1, 
//			   "../../../volumes/cabeza/t%d.bmp", 1, true);

      data->loadFromImages(true, 256, 256, 32, 1, 
			   "../media/texture.png", 0, false);

//      data->loadFromRaw("../../gmod/volum/BostonTeapot.raw", 256, 256, 178, 1,
//			S3DData::DATA_UNSIGNED_BYTE);
      
//      data->loadFromRaw("../../gmod/volum/engine.raw", 256, 256, 128, 1,
//			S3DData::DATA_UNSIGNED_BYTE);

//      data->convert(4, 128, 128, 128, true);

      std::cout << "Used Memory: " << data->usedMemory() / (1024 * 1024) 
		<< " MB" << std::endl;
      std::cout << "Computing normal...";
      normaldata = data->computeNormal();
      std::cout << ". OK.\n";
  

      for (i = 0; i < 256; i ++)
      {

	 val[0] = 0;
	 val[1] = 0;
	 val[2] = 0;
	 val[3] = 0;
	 val[4] = 0;
	 


	 if ((i > 88) && (i < 122))
	 {
	    val[0] = 255;
	    val[1] = 255;
	    val[2] = 250;
	    val[3] = 60;
	 }

	 if ((i > 172) && (i < 209))
	 {
	    val[0] = 255;
	    val[1] = 200;
	    val[2] = 100;
	    val[3] = 100;
	 }


	 if ((i >= 50) && (i <= 90))
	 {
	    val[0] = 255;
	    val[1] = 231;
	    val[2] = 180;
	    val[3] = 10;
	    val[4] = 0;
	 }


	 if ((i >= 103) && (i <= 112))
	 {
	    val[0] = 255;
	    val[1] = 255;
	    val[2] = 250;
	    val[3] = 5;
	    val[4] = 0;
	 }

	 if ((i >= 127) && (i <= 140))
	 {
	    val[0] = 255;
	    val[1] = 0;
	    val[2] = 0;
	    val[3] = 128;
	    val[4] = 200;
	 }

	 if ((i >= 141) && (i <= 255))
	 {
	    val[0] = 255;
	    val[1] = 255;
	    val[2] = 0;
	    val[3] = 128;
	    val[4] = 250;
	 }

/*
	 if ((i >= 6) && (i <= 24))
	 {
	    val[0] = 255;
	    val[1] = 157;
	    val[2] = 157;
	    val[3] = 200;
	    val[4] = 0;
	 }

	 if ((i >= 30) && (i <= 44))
	 {
	    val[0] = 254;
	    val[1] = 100;
	    val[2] = 100;
	    val[3] = 50;
	    val[4] = 0;
	 }


	 if ((i >= 51) && (i <= 228))
	 {
	    val[0] = 255;
	    val[1] = 255;
	    val[2] = 254;
	    val[3] = 255;
	    val[4] = 255;
	 }
*/

	 if (i >= 100)
	 {
	    val[0] = val[1] = val[2] = i - 100; // Transform everything in grey
	    val[3] = i - 100;
	 }

	 palette->setData (val, i, 0, 0);
	 
	 shininess->setData (val + 4, i, 0, 0);
      }
   }

   if (loadmodel)
   {
      std::cerr << "Loading ...." << "\n";   

      fname[0] = '\0';
      sprintf(fname, "%s%s", ifile, "sh.pcos");
      shininess->loadPCOS(fname);   
      fname[0] = '\0';
      sprintf(fname, "%s%s", ifile, "pal.pcos");
      palette->loadPCOS(fname);
      fname[0] = '\0';
      sprintf(fname, "%s%s", ifile, "norm.pcos");
      normaldata->loadPCOS(fname);
      fname[0] = '\0';
      sprintf(fname, "%s%s", ifile, "data.pcos");
      data->loadPCOS(fname);
      std::cerr << "OK. Loaded." << "\n";
   }

   if (savemodel)
   {
      std::cerr << "Saving ...." << "\n";
      fname[0] = '\0';
      sprintf(fname, "%s%s", ofile, "sh.pcos");
      shininess->savePCOS(fname);   
      fname[0] = '\0';
      sprintf(fname, "%s%s", ofile, "pal.pcos");
      palette->savePCOS(fname);
      fname[0] = '\0';
      sprintf(fname, "%s%s", ofile, "norm.pcos");
      normaldata->savePCOS(fname);
      fname[0] = '\0';
      sprintf(fname, "%s%s", ofile, "data.pcos");
      data->savePCOS(fname);
      std::cerr << "OK. Saved." << "\n";
   }


   dataset = new S3DDataSet();
   dataset->addData("gray_ub", data);
   dataset->addData("rgba_ub", data);
   dataset->addData("normal_ub", normaldata);
   dataset->addData("palette_ub", palette);
   dataset->addData("shininess_ub", shininess);

   node = new S3DDirectr(dataset);

   node->directPreRender();
   node->setPalette();
   node->setMaterials();

   std::cout << "Used Memory in node: " << node->usedMemory() / (1024 * 1024) 
	     << " MB" << std::endl;

	
/* ------------ Init ----------- */ 
   glEnable(GL_CULL_FACE);
   glEnable(GL_DEPTH_TEST);
   
   // Draw something:
   glMatrixMode(GL_PROJECTION);
   glViewport(0, 0, width, height);
   glLoadIdentity();
   gluPerspective(60, 1.33, 1.0, 60.0);


/* ----- Event cycle --------------- */
   quit = 0;
   while (!quit) 
   {
      while (SDL_PollEvent(&event)) 
      {
	 switch (event.type) 
	 {
	    // If the mouse is pressed:
	    case SDL_MOUSEBUTTONDOWN: {
	       if (SDL_GetModState() & KMOD_CTRL)
		  moving = 0;
	       else
		  moving = 1;

	       movingmouse = true;
	       xini = event.button.x;
	       xend = event.button.x;
	       zini = event.button.y;
	       zend = event.button.y;
	       yini = event.button.y;
	       yend = event.button.y;

	       changed = true;
	    } break;

	    // If the mouse is released:
	    case SDL_MOUSEBUTTONUP: {
	       movingmouse = false;

	       if (moving == 1)
	       {
		  fx += (yend - yini) / 10.0;
		  fz += (zend - zini) / 10.0;
		  fy += (xend - xini) / 10.0;
	       }

	       xini = event.button.x;
	       xend = event.button.x;
	       yini = event.button.y;
	       yend = event.button.y;
	       zini = event.button.y;
	       zend = event.button.y;

	       changed = true;
	    } break;

	    // If the mouse is moved:
	    case SDL_MOUSEMOTION: {
	       if (movingmouse)
	       {
		  xend = event.button.x;

		  if (SDL_GetModState() & KMOD_SHIFT)
		  {
		     zend = event.button.y;
		     yini = yend;
		  }
		  else
		  {
		     yend = event.button.y;
		     zend = zini;
		  }
		  changed = true;
	       }
	    } break;

	    // If a key is pressed:
	    case SDL_KEYDOWN: {
	       keystate = SDL_GetKeyState(NULL);
	       if (keystate[SDLK_SPACE])
	       {
		  showboundingbox = !showboundingbox;
		  changed = true;
	       }

	       if (keystate[SDLK_F1])
	       {
		  active_shader = shader;
		  for (i = 0; i < 3; i ++)
		  {
		     tmpf = transp[i];
		     transp[i] = tmp_transp[i];
		     tmp_transp[i] = tmpf;
		  }
		  changed = true;
	       }

	       if (keystate[SDLK_F2])
	       {
		  for (i = 0; i < 3; i ++)
		  {
		     tmpf = transp[i];
		     transp[i] = tmp_transp[i];
		     tmp_transp[i] = tmpf;
		  }
		  active_shader = shader2;
		  changed = true;
	       }

	       if (keystate[SDLK_F3])
	       {
		  dataset->setData("gray_ub", 0);
		  dataset->setData("normal_ub", 0);
		  dataset->setData("palette_ub", 0);
		  dataset->setData("shininess_ub", 0);
		  active_shader = shader3;

		  for (i = 0; i < 3; i ++)
		  {
		     tmpf = transp[i];
		     transp[i] = tmp_transp[i];
		     tmp_transp[i] = tmpf;
		  }
		  changed = true;
	       }

	       if ( (keystate[SDLK_KP_PLUS]) || (keystate[SDLK_PLUS]) )
	       {
		  max += 100;
		  changed = true;
	       }

	       if ( (keystate[SDLK_KP_MINUS]) || (keystate[SDLK_MINUS])
		    && (max > 100) )
	       {
		  max -= 100;
		  changed = true;
	       }

	       if (keystate[SDLK_UP])
	       {
		  if (zoom < 100)
		  {
		     zoom += 0.1;
		     changed = true;
		  }
	       }
	       else
		  if (keystate[SDLK_DOWN])
		  {
		     if (zoom > -100)
		     {
			zoom += -0.1;
			changed = true;
		     }
		  }

	       if ( (keystate[SDLK_LEFT]) || 
		    (keystate[SDLK_RIGHT]) )
	       {
		  if (tht <= 0)
		  {
		     tht = 0;
		  }
		  else
		     if (tht >= 255)
		     {
			tht = 255;
		     }


		  if (keystate[SDLK_LEFT])
		     tht += 5;
		  else
		     tht -= 5;

		  for (i = 0; i < 256; i ++)
		  {
		     if (i < tht)
		     {
			val[0] = 0;
			val[1] = 0;
			val[2] = 0;
			val[3] = 0;
			val[4] = 0;
		     }
		     else
		     {
			val[0] = i - tht;
			val[1] = i - tht;			   
			val[2] = i - tht;
			val[3] = i - tht;
			val[4] = i - tht;
		     }
		     palette->setData (val, i, 0, 0);
		     shininess->setData (val + 4, i, 0, 0);
		  }
		  node->setPalette();
		  node->setMaterials();

		  changed = true;
	       }

	       if (keystate[SDLK_RETURN])
	       {
		  for (i = 0; i < 256; i ++)
		  {
		     if (i < 30)
		     {
			val[0] = 0;
			val[1] = 0;
			val[2] = 0;
			val[3] = 0;
			val[4] = 0;
		     }
		     else
		     {
			val[0] = i;
			val[1] = i;			   
			val[2] = i;
			val[3] = i;
			val[4] = i / 4;
		     }
		     palette->setData (val, i, 0, 0);
		     shininess->setData (val + 4, i, 0, 0);
		  }
		  node->setPalette();
		  node->setMaterials();

		  changed = true;
	       }

	       if (keystate[SDLK_1])
		  if (transp[0] > 0.0)
		  {
		     transp[0] -= 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_2])
		  if (transp[0] < 1.0)
		  {
		     transp[0] += 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_3])
		  if (transp[1] > 0.0)
		  {
		     transp[1] -= 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_4])
		  if (transp[1] < 1.0)
		  {
		     transp[1] += 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_5])
		  if (transp[2] > 0.0)
		  {
		     transp[2] -= 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_6])
		  if (transp[2] < 1.0)
		  {
		     transp[2] += 0.025;
		     changed = true;
		  }

	       if (keystate[SDLK_7])
	       {
		  transp[0] = transp[1] = transp[2] = 1.0;
		  changed = true;
	       }

	       if (keystate[SDLK_8])
	       {
		  transp[0] = transp[1] = transp[2] = 0.05;
		  changed = true;
	       }
	    } break;

	    // If you touch the close button:
	    case SDL_QUIT: {
	       quit = 1;
	       SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, 
				   SDL_DEFAULT_REPEAT_INTERVAL);
	    } break;
    
	    // If the screen is resized:
	    case SDL_VIDEORESIZE: {
	       screen = SDL_SetVideoMode(event.resize.w, 
					 event.resize.h, 
					 bpp, flags); 
	       if(screen == 0)
	       {
		  std::cerr << "Video resize failed: " << SDL_GetError() 
			    << "\n";
		  exit (-1);
	       }
	       else
	       {
		  // Resize
		  width = event.resize.w;
		  height = event.resize.h;
	 
		  glEnable(GL_CULL_FACE);
		  glEnable(GL_DEPTH_TEST);
	 
		  // Draw something:
		  glMatrixMode(GL_PROJECTION);
		  glViewport(0, 0, width, height);
		  glLoadIdentity();
		  gluPerspective(60, 1.33, 1.0, 60.0);

		  changed = true;
	       }

	    } break;

	    default : {

	    } break;
	 
	 }
      }

      // Render the Volume
      if (changed)
      {
	 glClearColor(0.90, 0.90, 0.99, 0.0);
//	 glClearColor(0.8, 0.8, 0.9, 0.0);
	 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	 
	 glMatrixMode(GL_MODELVIEW);
	 glLoadIdentity();
	 
	 glTranslatef (0, 0, zoom);
	 	 
	 // ----------------------

	 
	 if ( (movingmouse == true) && (moving == 0))
	 {
	    position[0] = (yend - yini) / 10.0;
	    position[1] = (xend - xini) / 10.0;
	 }
	 
	 if ( (movingmouse == true) && (moving == 1))
	 {
	    node->rotate(fx  + (yend - yini) / 10.0,
			 fy  + (xend - xini) / 10.0, 
			 fz  +  (zend - zini) / 10.0);
	 }
	 else
	    node->rotate(fx, fy, fz);

 
	 if (showboundingbox)
	    node->bboxRender(false);

	 if (active_shader != shader3)
	 {
	    manejador = active_shader->getProgram();
	    active_shader->useProgram();
	    loc = glGetUniformLocation(manejador, "tex");
	    glUniform1i (loc, 0);
	    loc = glGetUniformLocation(manejador, "tex1D");
	    glUniform1i (loc, 1);
	    loc = glGetUniformLocation(manejador, "texnormal");
	    glUniform1i (loc, 2);
	    loc = glGetUniformLocation(manejador, "shininess");
	    glUniform1i (loc, 3);
	    loc = glGetUniformLocation(manejador, "specialtr");
	    glUniform3f(loc, transp[0], transp[1], transp[2]);
	    
	    
	    glEnable(GL_LIGHT0);
	    glLightfv(GL_LIGHT0, GL_POSITION, position);
	    if (movingmouse == true)
	       node->directRender(max / 20);
	    else
	       node->directRender(max);
	    active_shader->doNotUseProgram();
	 }
	 else
	 {
	    active_shader->doNotUseProgram();
/*
	    manejador = active_shader->getProgram();
	    active_shader->useProgram();
	    loc = glGetUniformLocation(manejador, "tex");
	    glUniform1i (loc, 0);
	    loc = glGetUniformLocation(manejador, "incTex");
	    glUniform3f (loc, 1/64.0, 1/64.0, 1/64.0);
	    loc = glGetUniformLocation(manejador, "lightPos");
	    glUniform3f (loc, position[0], position[1], position[2]);
	    loc = glGetUniformLocation(manejador, "threshold");
	    glUniform1f (loc, 0.4);
*/
//	    glDisable(GL_LIGHT0);
	    if (movingmouse == true)
	    {
	       glActiveTexture(GL_TEXTURE0); // Multitexture
	       glEnable(GL_TEXTURE_3D);
	       glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
	       node->directSimpleRender(max / 20);
	    }
	    else
	       node->directRender(max);
	    active_shader->doNotUseProgram();
	 }

	 
	 glDisable (GL_TEXTURE_1D);
	 glDisable (GL_TEXTURE_2D);
	 glDisable (GL_TEXTURE_3D);
	 
	 SDL_GL_SwapBuffers();
	 changed = false;

	 if (!movingmouse)
	 {
	    std::cerr << "* Special variables: \n";
	    for (i = 0; i < 3; i ++)
	    {
	       std::cerr << " sp[" << i << "] = " <<  transp[i] << ";";
	    }
	    std::cerr << "\n";
	 }
      }

//      SDL_Delay(10);
   }
  
   SDL_Quit();

   return 0;
}


// Show the help:
void help (void)
{
   std::cerr << "\n";
   std::cerr << "help         Show this help.\n";
   std::cerr << "import       Import the default volume from a image.\n";
   std::cerr << "save         Save the volume.\n";
   std::cerr << "load         Load a volume.\n";
   std::cerr << "if=<file>    Change the name of the input file to <file>.\n";
   std::cerr << "of=<file>    Change the name of the output file to <file>.\n";
   std::cerr << "\n";
   std::cerr << "Keys:\n";
   std::cerr << "Drag Mouse:  Move the model.\n";
   std::cerr << "Ctrl+Mouse:  Move the light.\n";
   std::cerr << "SPACE KEY:   Hide/show bounding box.\n";
   std::cerr << "LEFT KEY:    Thresdhold -\n";
   std::cerr << "RIGHT KEY:   Thresdhold +\n";
   std::cerr << "UP KEY:      Zoom +\n";
   std::cerr << "DOWN KEY:    Zoom -\n";
   std::cerr << "RETURN KEY:  Change to default materials (irreversible).\n";
   std::cerr << "KEY 1:       Opacity - (x).\n";
   std::cerr << "KEY 2:       Opacity + (x).\n";
   std::cerr << "KEY 3:       Opacity - (y).\n";
   std::cerr << "KEY 4:       Opacity + (y).\n";
   std::cerr << "KEY 5:       Opacity - (z).\n";
   std::cerr << "KEY 6:       Opacity + (z).\n";
   std::cerr << "KEY 7:       Opacity to default.\n";
   std::cerr << "KEY 8:       Opacity to 0.01.\n";
   std::cerr << "\n";
}
