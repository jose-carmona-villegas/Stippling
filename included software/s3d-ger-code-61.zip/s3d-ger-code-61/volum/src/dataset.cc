#include "dataset.hh"


// --------------------------------------------------
S3DDataSet::S3DDataSet (void)
{
   // Nothing :)
}

// --------------------------------------------------
S3DDataSet::~S3DDataSet (void)
{
   unsigned int i;

   if (this->data.size() > 0)
   {
      for (i = 0; i < this->data.size(); i ++)
	 if (this->data[i] != 0)
	    delete (this->data[i]);
   }

   if (this->dataname.size() > 0)
   {
      for (i = 0; i < this->dataname.size(); i ++)
	 if (this->dataname[i] != 0)
	    delete [] (this->dataname[i]);
   }

   if (this->filename.size() > 0)
   {
      for (i = 0; i < this->filename.size(); i ++)
	 if (this->filename[i] != 0)
	    delete [] (this->filename[i]);
   }
}


// --------------------------------------------------
void S3DDataSet::addData(const char *name, S3DData *d)
{
   char *str, *str2;

   if ((name == 0) || (strlen(name) <= 0))
      std::cerr << "Error: name can not be an empty string.\n";

   str = new char[strlen(name) + 1];
   str2 = new char[strlen(name) + 5];
   str[0] = '\0';
   str2[0] = '\0';

   this->data.push_back(d);

   strcpy (str, name);
   this->dataname.push_back(str);

   sprintf (str2, "%s.vlm", name); // Put an extension: .vlm
   this->filename.push_back(str2);

}

// --------------------------------------------------
void S3DDataSet::setData(const char *name, S3DData *d)
{
   this->removeData(name);
   this->addData(name, d);
}

// --------------------------------------------------
void S3DDataSet::removeData(const char *name)
{
   unsigned long int i;

   std::vector<S3DData*>::iterator iterdata;
   std::vector<char*>::iterator iterdataname;
   std::vector<char*>::iterator iterfilename;

   iterdata = this->data.begin();
   iterdataname = this->dataname.begin();
   iterfilename = this->filename.begin();
   for (i = 0; i < this->data.size(); i++)
   {
      if (!strcmp(*iterdataname, name))
      {
	 this->data.erase(iterdata);
	 this->dataname.erase(iterdataname);
	 this->filename.erase(iterfilename);

	 return;
      }
      
      iterdata++;
      iterdataname++;
      iterfilename++;
   }

   std::cerr << "WARNING: Name \"" << name << "\" not found\n";
   return;
}

// --------------------------------------------------
S3DData *S3DDataSet::getData(const char *name)
{
   long long int i;

   i = this->getIndexFromData (name);
   if (i < 0)
      return 0;

   return this->data[i];
}

// --------------------------------------------------
const char *S3DDataSet::getFileName(const char *name)
{
   long long int i;

   i = this->getIndexFromData (name);
   if (i < 0)
      return 0;

   return this->filename[i];
}

// --------------------------------------------------
long long int S3DDataSet::getIndexFromData(const char *name)
{
   unsigned int i;
   
   for (i = 0; i < this->dataname.size(); i ++)
   {
      if (!strcmp(name, this->dataname[i]))
	 return i;
   }
   
   return -1;
}

// --------------------------------------------------
double S3DDataSet::usedMemory(void)
{
   unsigned long int i;
   double sum;
   S3DData *d;

   sum = 0.0;

   for (i = 0; i < this->data.size(); i ++)
   {
      d = this->data[i];
      sum += (d->usedMemory() + strlen(this->dataname[i]) + 
	      strlen(this->filename[i]));
   }

   return sum;
}

