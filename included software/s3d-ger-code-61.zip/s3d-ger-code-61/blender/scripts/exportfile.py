#!/usr/bin/python
# -*- coding: utf-8 -*-
#!BPY

"""
Name: 'S3D-GER exporter'
Blender: 244
Group: 'Export'
Tooltip: 'S3D-GER exporter'
"""

import math
import Blender
from Blender.BGL import *
from Blender import Draw
from Blender import Camera, Object, Scene
from Blender import Window
from Blender.Window import DrawProgressBar
from Blender.Scene import Render



# ------------------------------------------------------------------------
""" GLOBALS """
DIROUT = "./out/"
InitialFrame = 0
Frame = 0
idR = 0
idG = 0
idB = 1
CurrentScene = None
Meshes = None
Camera = None
TOANGLE = 180.0 / math.pi


# ------------------------------------------------------------------------
def getScene():
  """ Function to get the Scene"""
  scn = Scene.GetCurrent()    # get current scene
  scnName = scn.getName()    # get current name
  context = scn.getRenderingContext()
  
  return (scn, scnName, context)


# ------------------------------------------------------------------------
def getCamera(scene):
  """ Get the camera. The function takes the following arguments:
      scene: is an array with the scene and its name 
      scene can be obtained with getScene """
  scn = scene[0]
  camObj = scn.objects.camera   # get the camera object

  return (camObj, camObj.getData())


# ------------------------------------------------------------------------
def saveMesh(obj, drawIDs):
  global idR, idG, idB

  glMatrixMode(GL_MODELVIEW)
  glPushMatrix()

  glTranslatef(obj.getLocation("worldspace")[0],
               obj.getLocation("worldspace")[1],
               obj.getLocation("worldspace")[2])

#  glTranslatef(obj.LocX, obj.LocY, obj.LocZ)

  #angle = obj.rot
  angle = obj.getEuler("worldspace")
  glRotatef(angle[0] * TOANGLE, 1, 0, 0);
  glRotatef(angle[1] * TOANGLE, 0, 1, 0);
  glRotatef(angle[2] * TOANGLE, 0, 0, 1);

  glScalef(obj.getSize("worldspace")[0],
           obj.getSize("worldspace")[1],
           obj.getSize("worldspace")[2])
 
  mesh = obj.getData(mesh=True)

  # Get the matrices
  if drawIDs == True:
    pm = Buffer(GL_FLOAT, [4,4])
    mm = Buffer(GL_FLOAT, [4,4])
    glGetFloatv(GL_PROJECTION_MATRIX, pm)
    glGetFloatv(GL_MODELVIEW_MATRIX, mm)
    pmatrix = Blender.Mathutils.Matrix(pm.list[0], pm.list[1], 
                                       pm.list[2], pm.list[3])
    mmatrix = Blender.Mathutils.Matrix(mm.list[0], mm.list[1], 
                                       mm.list[2], mm.list[3])
    tmatrix = pmatrix * mmatrix

  # The first id cannot be 0
  r = idR
  g = idG
  b = idB
  for f in mesh.faces:
    if drawIDs == True:
      id = r * (256 * 256) + g * 256 + b
      glColor3ub(r, g, b)
      print "ID Face:", id
    else:
      glColor3f(1, 0, 0)

    glBegin(GL_POLYGON)
    for v in f.v:
      glVertex3f(v.co.x, v.co.y, v.co.z)
      if drawIDs:
        vp = (v.co.x, v.co.y, v.co.z)
        # Revisar esto mejor DEBUG
        vp3d = apply_transform(vp, tmatrix)
        print "2D Vertex:", vp3d[0], vp3d[1]
        print "3D Vertex:", v.co
    glEnd()
    if drawIDs == True:
      b = b + 1
      if b > 255:
        b = 0
        g = g + 1
        if g > 255:
          g = 0
          r = r + 1
  idR = r
  idG = g
  idB = b
  glPopMatrix()
  return


# ------------------------------------------------------------------------
def getObjects(scene):
  """ Get the meshes of a scene. The function takes the following arguments:
      scene: is an array with the scene and its name 
      scene can be obtained with getScene """ 
  # get a list of mesh objects
  scn = scene[0]
  objs = [ob for ob in scn.objects if ob.type == 'Mesh']
  return objs


def saveScene(filename):
	""" Save a scene in the format S3D-GER """

	# The cursor indicates to wait
	Blender.Window.WaitCursor(1)

	CurrentScene = getScene()

	InitialFrame = Blender.Get('curframe')
	EndFrame = Blender.Get('endframe')

	Frame = Blender.Get('staframe')
	Blender.Set('curframe', Frame)

	Meshes = getObjects(CurrentScene)
	Camera = getCamera(CurrentScene)

	f = open(filename, 'w')
	f.write('# S3D_GER FORMAT v1.0a\n')
	f.write('# by Germán Arroyo\n')
	f.write('\n') # A return of line is the same that a comment
	f.write('\n')

	# Save the number of iterations and the resolution of the final image
	f.write('# Number of iterations\n')
	f.write('!START FRAME: ' + str(InitialFrame) + "\n")
	f.write('!END FRAME: ' + str(EndFrame) + "\n")
        f.write('!FPS: ' + str(CurrentScene[2].fps) + "\n")

	w = CurrentScene[2].sizeX
	h = CurrentScene[2].sizeY

	f.write('# Render size\n')
	f.write('!RENDER WIDTH: ' + str(w) + "\n")
	f.write('!RENDER HEIGHT: ' + str(h) + "\n")
	
	f.write('# Specifications of the current camera\n')
	if w >= h:
		aspect = float(w) / float(h)
	else:
		aspect = float(h) / float(w)

	# Compute the degrees of the camera
	factor = Camera[1].lens / 32.0
	ratio = float(w) / float(h)
	fovy = math.atan(0.5 / ratio / factor)
	fov = fovy * 360 / math.pi

	f.write('!CURRENT CAMERA: ' + '\n')
	f.write('!+NAME: ' + Camera[0].getName() + '\n')
	f.write('!+FOV: ' + str(fov) + '\n')
	f.write('!+ASPECT: ' + str(aspect) + '\n')
	f.write('!+CLIP START: ' + str(Camera[1].clipStart) + '\n')
	f.write('!+CLIP END: ' + str(Camera[1].clipEnd) + '\n')
        loc = Camera[0].getLocation("worldspace")
        strloc = (str(loc[0]) + " " + 
                  str(loc[1]) + " " + 
                  str(loc[2]))
        angle = Camera[0].getEuler("worldspace")
        strangle = (str(angle[0] * TOANGLE) + " " + 
                    str(angle[1] * TOANGLE) + " " + 
                    str(angle[2] * TOANGLE))
        f.write('!+POSITION: ' + strloc + '\n')
        f.write('!+ROTATION: ' + strangle + '\n')

	f.write('# Number of objects in the scene\n')
	f.write('!NUM OF OBJ: ' + str(len(Meshes)) + "\n")
	f.write('# Information of the objects\n')
	id = 0
	for o in Meshes:
		f.write('!ID OBJ: ' + str(id) + "\n")
		f.write('!+NAME: ' + o.getName() + "\n")
		loc = o.getLocation("worldspace")
		strloc = (str(loc[0]) + " " + 
			  str(loc[1]) + " " + 
			  str(loc[2]))
		angle = o.getEuler("worldspace")
		strangle = (str(angle[0] * TOANGLE) + " " + 
			    str(angle[1] * TOANGLE) + " " + 
			    str(angle[2] * TOANGLE))
		ssize = o.getSize("worldspace")
		strsize = (str(ssize[0]) + " " + 
			   str(ssize[1]) + " " + 
			   str(ssize[2]))
		
		f.write('!+POSITION: ' + strloc + "\n")
		f.write('!+ROTATION: ' + strangle + "\n")
		f.write('!+SCALE: ' + strsize + "\n")
		id += 1

	f.write('# ------------------------ \n')

	id = 0
	for o in Meshes:
		mesh = o.getData(mesh=True)
		#	for fc in mesh.faces:
		#		f.write(str(fc.verts) + "\n")
		f.write('!MESH OBJ: ' + str(id) + "\n")
		f.write('!+VERTICES: ' + str(len(mesh.verts)) + "\n")
		for v in mesh.verts: 
			f.write(str(v.co.x) + " ")
			f.write(str(v.co.y) + " ")
			f.write(str(v.co.z) + "\n")
		f.write('!+FACES: ' + str(len(mesh.faces)) + "\n")
		for fc in mesh.faces:
			for idf in fc.v:
				f.write(str(idf.index) + " ")
			f.write("\n")
		id += 1

	f.write('# ------------------------ \n')

	f.write('!ANIMATION TYPE: ' + 'SIMPLE' + "\n")

	for Frame in range(Blender.Get('staframe'),Blender.Get('endframe') + 1):
		f.write('!FRAME: ' + str(Frame) + "\n")
                time = float(Frame) / float(CurrentScene[2].fps)

                Blender.Set('curframe', Frame)
                print
                print "Time:", time

		# Compute the degrees of the camera
		factor = Camera[1].lens / 32.0
		ratio = float(w) / float(h)
		fovy = math.atan(0.5 / ratio / factor)
		fov = fovy * 360 / math.pi

		f.write('!CURRENT CAMERA: ' + '\n')
                loc = Camera[0].getLocation("worldspace")
                strloc = (str(loc[0]) + " " + 
                          str(loc[1]) + " " + 
                          str(loc[2]))
                angle = Camera[0].getEuler("worldspace")
                strangle = (str(angle[0] * TOANGLE) + " " + 
                            str(angle[1] * TOANGLE) + " " + 
                            str(angle[2] * TOANGLE))
                f.write('!+POSITION: ' + strloc + '\n')
                f.write('!+ROTATION: ' + strangle + '\n')


		id = 0
		for o in Meshes:
                  #ipo = o.getIpo()
                  #if (ipo != None):
                  #  curve = ipo.getCurves()
                  #  for c in curve:
                  #    print c.getName(), ",", c.evaluate(time)

                  f.write('!ID OBJ: ' + str(id) + "\n")
                  loc = o.getLocation("worldspace")
                  strloc = (str(loc[0]) + " " + 
                            str(loc[1]) + " " + 
                            str(loc[2]))
                  angle = o.getEuler("worldspace")
                  strangle = (str(angle[0] * TOANGLE) + " " + 
                              str(angle[1] * TOANGLE) + " " + 
                              str(angle[2] * TOANGLE))
                  ssize = o.getSize("worldspace")
                  strsize = (str(ssize[0]) + " " + 
                             str(ssize[1]) + " " + 
                             str(ssize[2]))
                  
                  f.write('!+POSITION: ' + strloc + "\n")
                  f.write('!+ROTATION: ' + strangle + "\n")
                  f.write('!+SCALE: ' + strsize + "\n")
                  id += 1
	f.close()
	# Get back to normal cursor 
	Blender.Window.WaitCursor(0)
	return


# ------------------------------------------------------------------------
""" MAIN """

Blender.Window.FileSelector(saveScene, "EXPORT FILE", "scene.ger")

#Draw.Redraw(True)
#Draw.Register(show_win, ev, None)      # start the main loop

