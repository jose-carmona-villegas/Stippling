#include "selection.hh"


// --------------------------------------------------
S3DSelection::S3DSelection(void)
{
   this->x = 0.0;
   this->y = 0.0;
   this->z = 0.0;

   this->w = 0.0;
   this->h = 0.0;

   this->r = 131.0 / 255.0;
   this->g = 249.0 / 255.0;
   this->b = 195.0 / 255.0;
   this->alpha = 0.6;

   this->timer = SDL_GetTicks();

   return;
}


// --------------------------------------------------
S3DSelection::~S3DSelection()
{
}


// --------------------------------------------------
void S3DSelection::setPos(float x, float y, float z)
{
   this->x = x;
   this->y = y;
   this->z = z;
}

// --------------------------------------------------
void S3DSelection::setSize(float w, float h)
{
   this->w = w;
   this->h = h;
}

// --------------------------------------------------
void S3DSelection::draw(void)
{
   Uint32 t;
//   Uint32 flag = 0x55555555;
   Uint32 flag;
   Uint32 f;
   Uint32 n;


   t = SDL_GetTicks();
   flag = 0xFFF0FFF0;
   f = 0x0;

   glDisable (GL_TEXTURE_1D);
   glDisable (GL_TEXTURE_2D);
   glDisable (GL_TEXTURE_3D);
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   glColor4f (this->r, this->g, this->b, this->alpha);
   S3DPrimitive3D::drawPlane(GL_POLYGON, this->x, this->y, this->z, 
			     this->w, this->h);
   glColor4f (0.0, 0.0, 0.0, 1.0);
   glEnable (GL_LINE_STIPPLE);

   n = (t - this->timer) / 100;

   if (n > 16)
   {
      this->timer = t;
      f = flag;
   }
   else
   {
      f = flag >> n;
   }

   glLineStipple(1, f);
   glLineWidth(2);
   S3DPrimitive3D::drawPlane(GL_LINE_STRIP, this->x, this->y, this->z, 
			     this->w, this->h);
   glLineWidth(1);
   glDisable(GL_LINE_STIPPLE);
   
}


// --------------------------------------------------
void S3DSelection::setColor(float r, float g, float b, float a)
{
   this->r = r;
   this->g = g;
   this->b = b;
   this->alpha = a;
}


// --------------------------------------------------
float S3DSelection::getX(void)
{
   return this->x;
}


// --------------------------------------------------
float S3DSelection::getY(void)
{
   return this->y;
}


// --------------------------------------------------
float S3DSelection::getZ(void)
{
   return this->z;
}

