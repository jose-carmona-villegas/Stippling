#include "interface.hh"


// --------------------------------------------------
S3DInterface::S3DInterface(S3DTheme *th, int x, int y, int w, int h)
{
   this->x = x;
   this->y = y;

   this->w = w;
   this->h = h;

   this->xmouse = this->ymouse = 0;

   this->donotdraw = false;

   this->freeid = 1;
   this->idevent = 0;
   
   this->theme = th;

   this->fbo = 0;
   this->imgfbo = 0;
   this->firstFBO = true;

   this->etimer = SDL_GetTicks(); /// Timer for events

   this->keyflag = 0x00000000;

   this->save_events = false;
   this->load_events = false;
   this->screenshot = false;
   this->slot_events = 0;
   this->namefile = 0;
   this->pspeed = 1;

   this->scbuffer = new unsigned char[this->w * this->h * 3];
   this->scframe = 0;
   this->scclock = SDL_GetTicks();
}


// --------------------------------------------------
S3DInterface::~S3DInterface()
{
   // Free the fbo and the texture (FBO)
   if (this->fbo != 0)
      delete this->fbo;

   if (this->scbuffer != 0)
      delete [] this->scbuffer;
}


// --------------------------------------------------
void S3DInterface::setPos (int x, int y)
{
   this->x = x;
   this->y = y;
}


// --------------------------------------------------
void S3DInterface::setSize (int w, int h)
{
   this->w = w;
   this->h = h;
}


// --------------------------------------------------
void S3DInterface::add (S3DComponent *c)
{
   unsigned int aux;
   int i;
   

   if (c != 0)
   {
      this->lcomp.push_back(c);

      aux = this->freeid + c->getIDNeeded() - 1;

      c->setID(this->freeid, aux);
      this->freeid += c->getIDNeeded();
   }

   return;
}


// --------------------------------------------------
void S3DInterface::readEventsSDL (SDL_Event *event)
{
   S3DComponent *c, *changefocus;
   float garbage;
   unsigned long int indexfocus;
   bool repaint;
   int i;
   unsigned char *buffer;
   unsigned int key;
   SDLMod mod;
   unsigned int e;
   bool loadskip = false;


   repaint = false;
   this->idevent = 0;

   e = event->type;
   if (this->load_events)
   {
      if (e != SDL_KEYDOWN)
      {
	 // load the event
	 this->infile.read((char *) &e, sizeof(unsigned int));
//      std::cerr << "Event = " << e << "\n";
	 
	 if (this->infile.eof())
	 {
	    // end of file found
	    e = event->type;
	    this->load_events = false;
	    
	    // Close the file:
	    delete [] this->namefile;
	    this->namefile = 0;
	    this->infile.close();
	    std::cerr << "The recorded file has finished\n";

	    // Finish the screenshots if it is active:
	    if (this->screenshotauto)
	    {
	       this->screenshotauto = false;
	       this->screenshot = false;
	    }
	       
	 }
      }
      else
	 loadskip = true;
   }
   else
   {
      if (this->save_events)
      {
	 // save the event
	 this->outfile.write((const char *) &e, sizeof(unsigned int));
      }
   }

   if (e == 0)
      return;
	  
   switch(e) { /* Process the appropiate event type */

      case SDL_KEYUP: {  /* Handle a KEYDOWN event */
	 this->keyflag = 0x00000000;
      } break;

      case SDL_KEYDOWN: {  /* Handle a KEYDOWN event */
	 key = event->key.keysym.sym;

	 if ((key == SDLK_RSHIFT) || (key == SDLK_LSHIFT))
	    this->keyflag |= S3DComponent::SHIFTKEY;
	 
	 if ((key == SDLK_RCTRL) || (key == SDLK_LCTRL))
	    this->keyflag |= S3DComponent::CTRLKEY;

	 if ((key == SDLK_RALT) || (key == SDLK_LALT))
	    this->keyflag |= S3DComponent::ALTKEY;

	 if ((key == SDLK_RMETA) || (key == SDLK_LMETA))
	    this->keyflag |= S3DComponent::METAKEY;

/*
	 printf ("Key pressed:\n");
	 printf ("       SDL sim: %i\n", event->key.keysym.sym);
	 printf ("       modifiers: %i\n", event->key.keysym.mod);
	 printf ("       unicode: %i (if enabled with SDL_EnableUNICODE)\n",
		 event->key.keysym.unicode);
*/
	 for (i = 0; i < this->lcomp.size(); i++)
	 {
	    c = this->lcomp[i];

	    if (c->getEvents() & S3DComponent::KEY_DOWN)
	    {
	       if (c->getFocus() == true)
	       {
		  key = event->key.keysym.sym;

		  if (key == SDLK_F11)
		  {
		     if (this->load_events == true)
		     {
			std::cerr << "Stopping playing capture: " 
				  << this->slot_events << ". \n";
			this->load_events = false;

			// Close the file:
			delete [] this->namefile;
			this->namefile = 0;
			this->infile.close();
		     }
		     else
			if (this->save_events == false)
			{
			   std::cerr << "Playing capture: " 
				     << this->slot_events << "\n";
			   this->load_events = true;

			      // Open the file:
			      this->namefile = new char[100];
			      this->namefile[0] = '\0';
			      sprintf(this->namefile, 
				      "capture%04d.mot", this->slot_events);
			      this->infile.open(this->namefile, 
						std::ofstream::binary);
			}
		  }

		  if (key == SDLK_F12)
		     if (this->screenshot == false)
		     {
			this->screenshot = true;
			std::cerr<< "Taking screenshots...\n";
			this->scclock = SDL_GetTicks();
		     }
		     else
		     {
			if (event->key.keysym.mod & KMOD_CTRL)
			{
			   std::cerr<< "Clock active: screenshots"
				    << " will finish when then next"
				    << " playing stop.\n";
			   this->screenshotauto = true;
			}
			else
			{
			   this->screenshot = false;
			   std::cerr<< "Stopping screenshots.\n";
			}
		     }

		  if (key == SDLK_F9)
			if (this->load_events == false)
			   if (this->save_events == false)
			   {
			      this->save_events = true;
			      std::cerr << "Saving capture in slot: " 
				        << this->slot_events << "...\n";

			      // Open the file:
			      this->namefile = new char[100];
			      this->namefile[0] = '\0';
			      sprintf(this->namefile, 
				      "capture%04d.mot", this->slot_events);
			      this->outfile.open(this->namefile, 
						 std::ofstream::binary);
			   }
			   else
			   {
			      this->save_events = false;
			      std::cerr << "Stopping capture in slot: " 
				        << this->slot_events << ".\n";

			      // Close the file:
			      delete [] this->namefile;
			      this->namefile = 0;
			      this->outfile.close();
			   }

		  if (key == SDLK_F10)
		     if ( (this->load_events == false) && 
			  (this->save_events == false) )
			if (event->key.keysym.mod & KMOD_SHIFT)
			{
			   if (this->slot_events != 0)
			      this->slot_events --;

			   std::cerr<< "Pressed state key (-): " 
				    << this->slot_events << " \n";
			   
			}
			else
			{
			   this->slot_events ++;
			   std::cerr<< "Pressed state key (+): "
				    << this->slot_events << " \n";
			}

		  if (key == SDLK_KP_MINUS)
		  {
		     if (event->key.keysym.mod & KMOD_SHIFT)
		     {
			if (this->pspeed > 1)
			   this->pspeed --;
		     }
		     else
			if (event->key.keysym.mod & KMOD_CTRL)
			{
			   if (this->pspeed > 100)
			      this->pspeed -= 100;
			}
		     
		     std::cerr<< "Playing speed: x" 
			      << this->pspeed << " \n";
		  }

		  if (key == SDLK_KP_PLUS)
		  {
		     if (event->key.keysym.mod & KMOD_SHIFT)
			this->pspeed ++;
		     else
			if (event->key.keysym.mod & KMOD_CTRL)
			   this->pspeed += 100;
		     
		     std::cerr<< "Playing speed: x" 
			      << this->pspeed << " \n";
		     
		  }


		  if ( (key != SDLK_RSHIFT) && (key != SDLK_LSHIFT) &&
		       (key != SDLK_RCTRL) && (key != SDLK_LCTRL) &&
		       (key != SDLK_RMETA) && (key != SDLK_LMETA) &&
		       (key != SDLK_RSUPER) && (key != SDLK_LSUPER) &&
		       (key != SDLK_MENU) && (key != SDLK_CAPSLOCK) &&
		       (key != SDLK_MODE) && (key != SDLK_COMPOSE) &&
		       (key != SDLK_RALT) && (key != SDLK_LALT) )
		  {
		     if ( (event->key.keysym.mod & KMOD_CAPS) ||
			  (event->key.keysym.mod & KMOD_SHIFT) )
		     {
			if ( (key >= 'A') && (key <= 'z') )
			   key = key - ('a' - 'A');
			else
			   key = key - ('0' - '!' + 1);
		     }

		     if (event->key.keysym.mod & KMOD_ALT)
		     {
			key = key + 123 - ' ';
		     }

		     if (event->key.keysym.mod & KMOD_LCTRL)
		     {
			if (key == '7')
			   key = '/';
		     }

		     if (event->key.keysym.mod & KMOD_RCTRL)
		     {
			if (key == '7')
			   key = '\\';
		     }

//		     if ( (key >= ' ') || (key == '\b') ||
//			  (key == '\n') || (key == '\r') ) 
//		     {
		     if (this->save_events)
		     {
			this->outfile.write((const char *) &this->xmouse, 
					    sizeof(float));
			this->outfile.write((const char *) &this->ymouse, 
					    sizeof(float));
			this->outfile.write((const char *) &key, 
					    sizeof(unsigned int));
			this->outfile.write((const char *) &this->idevent, 
					    sizeof(unsigned long long int));
		     }
		     else
			if ( (this->load_events) && (!loadskip) )
			{
/*
			   this->infile.read((char *) &this->xmouse, 
					       sizeof(float));
			   this->infile.read((char *) &this->ymouse, 
					       sizeof(float));
*/
			   this->infile.read((char *) &garbage, 
					       sizeof(float));
			   this->infile.read((char *) &garbage, 
					       sizeof(float));
			   this->infile.read((char *) &key, 
					       sizeof(unsigned int));
			   this->infile.read((char *) &this->idevent, 
					       sizeof(unsigned long long int));
			}

		     c->eventKeyDown (this->xmouse, this->ymouse, 
				      key, this->idevent);
//		  }
		  }
	       }
	    }
	 }
      } break;
	 
      case SDL_MOUSEMOTION: {
/*
	 printf ("Mouse moved to: (%i,%i) ", 
		 event->motion.x, event->motion.y);
	 printf ("change: (%i,%i)\n", 
		 event->motion.xrel, event->motion.yrel);
	 printf ("       button state: %i\n", event->motion.state);
*/ 
	 this->xmouse =  event->motion.x;
	 this->ymouse =  this->h - event->motion.y;

//	 repaint = true;
	 if (SDL_GetTicks() - this->etimer > 50)
	 {
	    repaint = true;
	    this->etimer = SDL_GetTicks();
	 }


	 // Save/load if repaint is necessary and xmouse and ymouse
	 if (this->save_events)
	 {
	    this->outfile.write((const char *) &this->xmouse, 
				sizeof(float));
	    this->outfile.write((const char *) &this->ymouse, 
				sizeof(float));
	    this->outfile.write((const char *) &repaint, sizeof(bool));
	 }
	 else
	    if (this->load_events)
	    {
	       this->infile.read((char *) &this->xmouse, 
				 sizeof(float));
	       this->infile.read((char *) &this->ymouse, 
				 sizeof(float));
	       this->infile.read((char *) &repaint, sizeof(bool));
	    }

      } break;
	 
      case SDL_MOUSEBUTTONDOWN: {
/*
	 printf ("Mouse button %i ", event->button.button);
	 printf ("pressed with mouse at (%i,%i)\n",
		 event->button.x,event->button.y);
*/

	 this->xmouse =  event->motion.x;
	 this->ymouse =  this->h - event->motion.y;

	 switch (event->button.button)
	 {
	    case SDL_BUTTON_LEFT: {
	       this->button = this->keyflag | S3DComponent::LEFTBUTTON;
	    } break;

	    case SDL_BUTTON_RIGHT: {
	       this->button = this->keyflag | S3DComponent::RIGHTBUTTON;
	    } break;

	    case SDL_BUTTON_MIDDLE: {
	       this->button = this->keyflag | S3DComponent::MIDDLEBUTTON;
	    } break;

	    case SDL_BUTTON_WHEELUP: {
	       this->button = this->keyflag | S3DComponent::WHEELUPBUTTON;
	    } break;

	    case SDL_BUTTON_WHEELDOWN: {
	       this->button = this->keyflag | S3DComponent::WHEELDOWNBUTTON;
	    } break;
	 }
	 repaint = true;
      } break;
	 
      case SDL_MOUSEBUTTONUP: {
/*
	 printf ("Mouse button %i ", event->button.button);
	 printf ("released with mouse at (%i,%i)\n",
		 event->button.x, event->button.y);
*/
	 this->xmouse =  event->motion.x;
	 this->ymouse =  this->h - event->motion.y;

	 this->button = 0;


	 repaint = true;
      } break;
   }

   if (repaint == true)
   {
/*
      if (this->firstFBO)
      {
	 this->fbo = new S3DFBO(this->w, this->h);
	 this->fbo->attachTexture2D(GL_RGB, GL_RGB, GL_UNSIGNED_BYTE, 
				    GL_NEAREST);

	 this->firstFBO = false;
      }
*/
      // Render in the fbo:
//      this->fbo->renderFBO();
      if (!this->load_events)
      {
//	 glViewport(this->x, this->y, this->w, this->h); 

	 glDisable(GL_TEXTURE_1D);
	 glDisable(GL_TEXTURE_2D);
	 glDisable(GL_TEXTURE_3D);
	 glDisable(GL_BLEND);

	 glDepthMask(false); 

	 glMatrixMode(GL_PROJECTION); 
	 glLoadIdentity();
	 glOrtho((float) this->x, (float) this->x + this->w, 
		 (float) this->y, (float) this->y + this->h, -10, 10);
	 
	 glMatrixMode(GL_MODELVIEW);
	 glPushMatrix();
	 {
	    glLoadIdentity();
	    
	    glClearColor(0.0, 0.0, 0.0, 1.0);
	    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	    
	    
	    for (i = 0; i < this->lcomp.size(); i++)
	    {
	       c = this->lcomp[i];
	       glDisable(GL_BLEND);
               glDepthFunc(GL_ALWAYS);
	       c->draw(true);
	       glDisable(GL_BLEND);
	    }
	 
	    buffer = new unsigned char[2 * 3];
	    
	    glReadPixels((int) this->xmouse, (int) this->ymouse, 
			 1, 1, GL_RGB, GL_UNSIGNED_BYTE, buffer);
	    
	    this->idevent = buffer[2] * 256 * 256 + buffer[1] * 256 + buffer[0];
	    // Save the idevent
	    if (this->save_events)
	       this->outfile.write((const char *) &this->idevent, 
				   sizeof(unsigned long int));

/*
	 std::cerr << "Red: " << (int) buffer[0] << ", "
		   << "Green: " << (int) buffer[1]  << ", "
		   << "Blue: " << (int) buffer[2] << "; "
		   << "In: (" << i % this->w << ", " 
		   << i / this->w << "); "
		   << "ID = " << this->idevent
		   << std::endl;
*/
	    delete [] buffer;
	 }
	 glPopMatrix();
      }
//      this->fbo->renderFramebuffer();
      // Go back to the framebuffer


      if (this->load_events)
	 this->infile.read((char *) &this->idevent,
			   sizeof(unsigned long int));

      this->donotdraw = true;
      glDepthMask(true); 


      indexfocus = 0;
      changefocus = 0;
      // Send the events:
      for (i = 0; i < this->lcomp.size(); i ++)
      {
	 c = this->lcomp[i];

	 if ( (e == SDL_MOUSEBUTTONDOWN) && 
	      (c->getEvents() & S3DComponent::MOUSE_DOWN) ) 
	 {
	    if ( (this->idevent > 0) && (this->idevent >= c->getMinID()) && 
		 (this->idevent <= c->getMaxID()) )
	    {
	       c->setFocus(true); // First set the focus and then send the event
	       if (this->save_events)
	       {
		  this->outfile.write((const char *) &this->xmouse, 
				      sizeof(float));
		  this->outfile.write((const char *) &this->ymouse, 
				      sizeof(float));
		  this->outfile.write((const char *) &button, 
				      sizeof(unsigned int));
		  this->outfile.write((const char *) &this->idevent, 
				      sizeof(unsigned long long int));
	       }
	       else
		  if (this->load_events)
		  {
		     this->infile.read((char *) &this->xmouse, 
				       sizeof(float));
		     this->infile.read((char *) &this->ymouse, 
				       sizeof(float));
		     this->infile.read((char *) &button, 
				       sizeof(unsigned int));
		     this->infile.read((char *) &this->idevent, 
				       sizeof(unsigned long long int));
		  }
	       c->eventMouseButtonDown (this->xmouse, this->ymouse, 
					this->button, this->idevent);
	       indexfocus = i;
	       changefocus = c;
	    }
	    else
	       c->setFocus(false);
	 }

	 if ( (e == SDL_MOUSEBUTTONUP) && 
	      (c->getEvents() & S3DComponent::MOUSE_UP) ) 
	 {
	    if (this->save_events)
	    {
	       this->outfile.write((const char *) &this->xmouse, 
				   sizeof(float));
	       this->outfile.write((const char *) &this->ymouse, 
				   sizeof(float));
	       this->outfile.write((const char *) &button, 
				   sizeof(unsigned int));
	       this->outfile.write((const char *) &this->idevent, 
				   sizeof(unsigned long long int));
	    }
	    else
	       if (this->load_events)
	       {
		  this->infile.read((char *) &this->xmouse, 
				    sizeof(float));
		  this->infile.read((char *) &this->ymouse, 
				    sizeof(float));
		  this->infile.read((char *) &button, 
				    sizeof(unsigned int));
		  this->infile.read((char *) &this->idevent, 
				    sizeof(unsigned long long int));
	       }
	    c->eventMouseButtonUp (this->xmouse, this->ymouse, 
				   this->button, this->idevent);
	 }

	 if ( (e == SDL_MOUSEMOTION) && 
	      (c->getEvents() & S3DComponent::MOUSE_MOTION) && 
	      (this->idevent >= c->getMinID()) && 
	      (this->idevent <= c->getMaxID()) )
	 {
	    if (this->save_events)
	    {
	       this->outfile.write((const char *) &this->xmouse, 
				   sizeof(float));
	       this->outfile.write((const char *) &this->ymouse, 
				   sizeof(float));
	       this->outfile.write((const char *) &button, 
				   sizeof(unsigned int));
	       this->outfile.write((const char *) &this->idevent, 
				   sizeof(unsigned long long int));
	    }
	    else
	       if (this->load_events)
	       {
		  this->infile.read((char *) &this->xmouse, 
				    sizeof(float));
		  this->infile.read((char *) &this->ymouse, 
				    sizeof(float));
		  this->infile.read((char *) &button, 
				    sizeof(unsigned int));
		  this->infile.read((char *) &this->idevent, 
				    sizeof(unsigned long long int));
	       }
	    c->eventMouseMotion (this->xmouse, this->ymouse, 
				 this->button, this->idevent);
	 }
      }

      if (changefocus != 0)
      {
	 this->lcomp[indexfocus] = this->lcomp[this->lcomp.size() - 1];
	 this->lcomp[this->lcomp.size() - 1] = changefocus;
      }
   }

}


// --------------------------------------------------
void S3DInterface::draw (void)
{
   int i;
   S3DComponent *c;
   GLuint mousetex;
   SDL_Event e;
   unsigned int zero = 0;
   unsigned int j;
   S3DImage *img;
   char *namefile;

   
   glViewport(this->x, this->y, this->w, this->h); 
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity();
   glOrtho((float) this->x, (float) this->x + this->w, 
	   (float) this->y, (float) this->y + this->h, -10, 10);

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();
   {
      glLoadIdentity();

      glDepthMask(false); 
      glDepthFunc(GL_ALWAYS);
//      glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

      this->theme->setMouse(0); // We set the mouse to the first texture

      for (i = 0; i < this->lcomp.size(); i++)
      {
	 c = this->lcomp[i];
	 c->draw(false); // FALSE
      }

      glColor4f(1.0, 1.0, 1.0, 0.9);
      mousetex = this->theme->getMouse();
      if (mousetex != 0)
      {
	 glEnable(GL_BLEND);
	 glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	 glDisable(GL_TEXTURE_1D);
	 glEnable(GL_TEXTURE_2D);
	 glDisable(GL_TEXTURE_3D);
	 glBindTexture (GL_TEXTURE_2D, mousetex);
	 S3DPrimitive3D::drawPlane (GL_POLYGON, this->xmouse, 
				    this->ymouse - 32, 0.0, 
				    32, 32);
      }

      glDisable(GL_TEXTURE_1D);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_TEXTURE_3D);
      glDisable(GL_BLEND);
   }
   glPopMatrix();
   glDepthMask(true); 

   if (this->donotdraw == true)
   {
      this->donotdraw = false;
   }
   else
   {
      e.type = 0;
      // Send an event if it is loading the events
      if (this->load_events)
      {
	 for (j = 0; j < pspeed; j ++)
	 {
	    this->donotdraw = true;
	    this->readEventsSDL(&e);
	 }
      }
      else
	 // If saving events
	 if (this->save_events)
	    this->outfile.write((const char *) &zero, sizeof(unsigned int));


      // If we are capturing the screen:

      if ( (this->screenshot) && (this->scclock - SDL_GetTicks() > 500) )
      {

	 glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	 glReadBuffer(GL_BACK);
	 glReadPixels(this->x, this->y, 
		      this->w, this->h, GL_RGB, GL_UNSIGNED_BYTE, 
		      this->scbuffer);

	 img = new S3DImage(this->w, this->h, 3, this->scbuffer);
	 img->flip(false, true);
	 namefile = new char[100];
	 namefile[0] = '\0';
#ifdef WINDOWS
	 sprintf (namefile, "./%04d_screenshot%08g.bmp", this->slot_events,
		  (double) this->scframe);
#else
	 sprintf (namefile, "/tmp/%04d_screenshot%08g.bmp", this->slot_events,
		  (double) this->scframe);
#endif
	 img->save(namefile);
	 delete img;
	 delete [] namefile;

	 this->scframe ++;
      }


      SDL_GL_SwapBuffers();
   }
}

