#include "label.hh"
//#define FORCE_POW_OF_TWO


// --------------------------------------------------
S3DLabel::S3DLabel(TTF_Font *f, float psize)
{
   this->ltext = 0;
   this->psize = psize;
   this->fnt = f;
   this->align = S3DLabel::LEFT;

   this->x = 0;
   this->y = 0;
   this->z = 0;

   this->color.b = 0;
   this->color.g = 0;
   this->color.r = 0;
   this->alpha = 1.0;

   this->id = 0;
}


// --------------------------------------------------
S3DLabel::~S3DLabel()
{
   if (this->ltext != 0)
      delete [] this->ltext;
}


// --------------------------------------------------
void S3DLabel::draw(void)
{
   int w, h;
   float width, height;

   w = h = 0;

   if ( (this->ltext == 0) || (this->fnt == 0) )
      return;

   TTF_SizeText(this->fnt, this->ltext, &w, &h);
   width = ((float) w) * this->psize;
   height = ((float) h) * this->psize;

   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

   glColor4f (1.0, 1.0, 1.0, this->alpha);
   
   if (this->id != 0)
   {
      glEnable (GL_TEXTURE_2D);
      glBindTexture (GL_TEXTURE_2D, this->id);

      glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
      glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
      glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   }
   else
   {
      glDisable (GL_TEXTURE_1D);
      glDisable (GL_TEXTURE_2D);
      glDisable (GL_TEXTURE_3D);
   }
   
   glBegin (GL_QUADS);
   {
      glTexCoord2f (0.0, 1.0);
      glVertex3f (this->x, this->y, this->z);
      glTexCoord2f (1.0, 1.0);
      glVertex3f (this->x + width, this->y, this->z);
      glTexCoord2f (1.0, 0.0);
      glVertex3f (this->x + width, this->y + height, this->z);
      glTexCoord2f (0.0, 0.0);
      glVertex3f (this->x, this->y + height, this->z);
   }
   glEnd();

   glDisable (GL_TEXTURE_2D);
}


// --------------------------------------------------
const char *S3DLabel::getText (void)
{
   return this->ltext;
}


// --------------------------------------------------
void S3DLabel::setText (const char *text)
{
   if (this->ltext != 0)
   {
      if ((text != 0) && (!strcmp(this->ltext, text)) )
	 return; // They are the same text

      delete [] this->ltext;
   }

   if ( (text == 0) || (strlen (text) == 0) )
   {
      this->ltext = 0;
      
      if (this->id != 0)
      {
	 glDeleteTextures (1, &(this->id));
	 this->id = 0;
      }

      return;
   }

   this->ltext = new char[strlen (text) + 20];
   this->ltext[0] = '\0';
   sprintf(this->ltext, "%s", text);

   this->updateTexture();
}


// --------------------------------------------------
void S3DLabel::updateTexture (void)
{
   SDL_Surface *text_surface;
   int offset;
   float *c;
   S3DImage *img;
   unsigned int flag;
   char *footext;
   int minx, maxx, miny, maxy, advance;
   int w, h;
   unsigned int i;


   if ((this->ltext == 0) || (this->ltext[0] == '\0'))
   {
      return;
   }

   text_surface = TTF_RenderText_Blended(this->fnt, this->ltext, this->color);
   if (!text_surface) 
   {
      std::cerr << "Error with fonts :( in S3DLabel\n";
      return;
   }

   img = new S3DImage(text_surface);

#ifdef FORCE_POW_OF_TWO
   img->scaleNearest2Pow (img->getWidth(), img->getHeight(),
			  S3DImage::QUALITY);
//			  S3DImage::PERFORMANCE);
//			  S3DImage::OPENGL);
#endif

//   if (this->id != 0)
//     glDeleteTextures (1, &(this->id));


   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_2D);
   if (this->id == 0)
      glGenTextures (1, &(this->id));

   glBindTexture (GL_TEXTURE_2D, this->id);

   if (this->id == 0)
      std::cerr << "Something strange with textures :S\n";

   switch (img->getBPP())
   {
      case 1: {
	 glTexImage2D (GL_TEXTURE_2D, 0, GL_LUMINANCE, 
		       img->getWidth(), 
		       img->getHeight(),
		       0, GL_LUMINANCE, GL_UNSIGNED_BYTE, 
		       img->getRaw());
      } break;

      case 2: {
	 glTexImage2D (GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA, 
		       img->getWidth(), 
		       img->getHeight(),
		       0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, 
		       img->getRaw());
      } break;


      case 3: {
	 glTexImage2D (GL_TEXTURE_2D, 0, GL_RGB, 
		       img->getWidth(), 
		       img->getHeight(),
		       0, GL_RGB, GL_UNSIGNED_BYTE, 
		       img->getRaw());
      } break;


      case 4: {
	 glTexImage2D (GL_TEXTURE_2D, 0, GL_RGBA, 
		       img->getWidth(), 
		       img->getHeight(),
		       0, GL_RGBA, GL_UNSIGNED_BYTE, 
		       img->getRaw());
      } break;

      default: {
	 std::cerr << "Something strange with textures :S\n";
      };
   }

   glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

   delete img;
}


// --------------------------------------------------
void S3DLabel::setFont (TTF_Font *font)
{
   this->fnt = font;
   this->updateTexture();
}


// --------------------------------------------------
void S3DLabel::setAlignment (unsigned int flag)
{
   this->align = flag;
   this->updateTexture();
}


// --------------------------------------------------
void S3DLabel::setColor (float r, float g, float b, float a)
{
   unsigned int rf = (unsigned char) (r * 255.0);
   unsigned int gf = (unsigned char) (g * 255.0);
   unsigned int bf = (unsigned char) (b * 255.0);
   float af = a;


   if ( (rf != this->color.r) ||
	(gf != this->color.g) ||
	(bf != this->color.b) ||
	(af != this->alpha) )
   {
      this->color.r = rf;
      this->color.g = gf;
      this->color.b = bf;
      this->alpha = a;

      this->updateTexture();
   }
}


// --------------------------------------------------
void S3DLabel::setPos (float x, float y, float z)
{
   this->x = x;
   this->y = y;
   this->z = z;
}

// --------------------------------------------------
void S3DLabel::setColor (SDL_Color c)
{
   this->color.r = c.r;
   this->color.g = c.g;
   this->color.b = c.b;

   this->updateTexture();
}


// --------------------------------------------------
float S3DLabel::getWidth (void)
{
   int w, h;
   float width;

   if ( (this->ltext == 0) || (this->fnt == 0) )
      return 0.0;

   TTF_SizeText(this->fnt, this->ltext, &w, &h);
   width = ((float) w) * this->psize;

   return width;
}


// --------------------------------------------------
float S3DLabel::getHeight (void)
{
   int w, h;
   float height;

   if ( (this->ltext == 0) || (this->fnt == 0) )
      return 0.0;

   TTF_SizeText(this->fnt, this->ltext, &w, &h);
   height = ((float) h) * this->psize;

   return height;
}


