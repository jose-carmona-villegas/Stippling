#include "preview.hh"


// --------------------------------------------------
S3DPreview::S3DPreview(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   srand(time(0));

   this->theme = theme;

   this->sendpredrawevents = false;

   this->wprev = 256;
   this->hprev = 256;

   this->init();

   // Optimization must be initialized
   this->eventChangePos(0, 0);
   this->eventResize(0, 0);
}


// --------------------------------------------------
S3DPreview::S3DPreview(S3DTheme *theme, float x, float y, float w, float h,
		       unsigned int fbow, unsigned int fboh) :
   S3DComponent (x, y, w, h)
{
   srand(time(0));

   this->theme = theme;

   this->wprev = fbow;
   this->hprev = fboh;


   this->init();

   // Optimization must be initialized
   this->eventChangePos(x, y);
   this->eventResize(w, h);
}


// --------------------------------------------------
void S3DPreview::init(void)
{
   this->posSelected = -1;
   this->dirSelected = -1;

   this->forceUpd = false;

   this->fbo_back = 0;
   this->imgfbo_back = 0;

   this->selectedAxis = X_SELECTED;

   this->redraw_backbuffer = true;

   this->size = 2.5;
   this->unit_size = 20;
   this->unit_rotation = 1.0;
   this->unit_movement = 1.0;

   this->angle = 0;

   this->changed = true;
   this->firstFBO = true;
   this->fbo = 0;
   this->imgfbo = 0;

   this->backup = 0;

   this->updtimer = SDL_GetTicks();
   this->refreshTime = 500;
}


// --------------------------------------------------
S3DPreview::~S3DPreview()
{
   // Free the fbo and the texture (FBO)
   if (this->fbo != 0)
      delete this->fbo;


   // Free the fbo and the texture of the back (FBO)
   if (this->fbo_back != 0)
      delete this->fbo_back;
}


// --------------------------------------------------
unsigned int S3DPreview::getType(unsigned long int id)
{
   return S3DComponent::PREVIEW;
}


// --------------------------------------------------
unsigned long int S3DPreview::getIDNeeded(void)
{
   return 51; // All the vectors, positions and the background
}


// --------------------------------------------------
unsigned int S3DPreview::getWidthFBO(void)
{
   return this->wprev;
}


// --------------------------------------------------
unsigned int S3DPreview::getHeightFBO(void)
{
   return this->hprev;
}


// --------------------------------------------------
void S3DPreview::drawProjectionInFBO(void)
{
   glLoadIdentity();
   gluPerspective(45, this->hprev / this->wprev, 1, 1000);
   glDisable(GL_TEXTURE_2D);
}


// --------------------------------------------------
void S3DPreview::cameraInFBO(void)
{
   glLoadIdentity();
   glTranslatef(0, 0, -100);
}


// --------------------------------------------------
void S3DPreview::drawModelInFBO(void)
{

   glClearColor((rand() % 255) / 255.0,
		(rand() % 255) / 255.0, 
		(rand() % 255) / 255.0, 1.0);
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   
   glRotatef (this->angle, 1, 1, 0);
   glColor4f (1 - this->angle / 360, 1 - this->angle / 360.0, 0, 1);
   S3DPrimitive3D::drawCircle(GL_TRIANGLE_FAN, 0.0, 0.0, 0.0, 20.0);
   this->angle ++;
   if (this->angle > 360)
      this->angle = 0;
}


// --------------------------------------------------
bool S3DPreview::initFBO(void)
{
   if ((this->fbo != 0) && (this->fbo_back != 0))
      return false;

   this->fbo = new S3DFBO(this->wprev, this->hprev, 
			  4, GL_RGBA, GL_UNSIGNED_BYTE, GL_LINEAR, true);

   this->fbo_back = new S3DFBO(32, 32,
      //this->wprev, this->hprev, 
			       3, GL_RGB, GL_UNSIGNED_BYTE, GL_NEAREST, false);

   this->fbo_back->isValid();

   this->update();

   return this->fbo->isValid();
}


// --------------------------------------------------
void S3DPreview::setRefreshTime(unsigned int t)
{
   this->refreshTime = t;
}


// --------------------------------------------------
void S3DPreview::forceUpdate(bool f)
{
   this->forceUpd = f;
   if (f == true)
   {
      this->initFBO();
   }
   else
   {
      // Free the fbo and the texture (FBO)
      if (this->fbo != 0)
      {
	 delete this->fbo;
	 this->fbo = 0;
      }
      
      // Free the fbo and the texture of the back (FBO)
      if (this->fbo_back != 0)
      {
	 delete this->fbo_back;      
	 this->fbo_back = 0;
      }
   }
}


// --------------------------------------------------
void S3DPreview::sendPreDrawEvents(bool s)
{
   this->sendpredrawevents = s;
}


// --------------------------------------------------
void S3DPreview::update(void)
{
   this->changed = true;
   this->updtimer = SDL_GetTicks();
}


// --------------------------------------------------
S3DVector *S3DPreview::computeDirection (float a, float b, float g)
{
   S3DVector *v, *v2;
   GLfloat *matrix;
   S3DMatrix *m, *m2;
   
   v = new S3DVector (0, 1, 0);
   m = new S3DMatrix (S3DMatrix::UNDEFINED, 3);

   while (a > 360)
      a -= 360;
   while (a < -360)
      a += 360;

   while (b > 360)
      b -= 360;
   while (b < -360)
      b += 360;
   
   while (g > 360)
      g -= 360;
   while (g < -360)
      g += 360;


   m->setRotateMatrix(a * M_PI / 180.0, 1, 0, 0);
   v2 = v->mult3x3Matrix(m);
   delete v;
   v = v2;

   m->setRotateMatrix(b * M_PI / 180.0, 0, 1, 0);
   v2 = v->mult3x3Matrix(m);
   delete v;
   v = v2;

   m->setRotateMatrix(g * M_PI / 180.0, 0, 0, 1);
   v2 = v->mult3x3Matrix(m);
   delete v;
   v = v2;

   return v;
}


// --------------------------------------------------
void S3DPreview::addDirection (const char *name, float a, float b, float g)
{
   S3DVector *v, *w;
   S3DLabel *lab;
   
   if (this->ldir.size() + this->lpos.size() < 50)
   {
      lab = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.4);
      lab->setText(name);
      v = this->computeDirection (a, b, g);

      w = new S3DVector(6);
      w->set(0, v->get(0));
      w->set(1, v->get(1));
      w->set(2, v->get(2));
      w->set(3, a);
      w->set(4, b);
      w->set(5, g);

      delete v;

      this->ldir.push_back(w);

      this->lnamedir.push_back(lab);
   }
}


// --------------------------------------------------
void S3DPreview::addPosition (const char *name, float x, float y, float z)
{
   S3DLabel *lab;

   if (this->ldir.size() + this->lpos.size() < 50)
   {
      lab = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.4);
      lab->setText(name);
      this->lpos.push_back(new S3DVector(x, y, z));
      this->lnamepos.push_back(lab);
   }
}


// --------------------------------------------------
S3DVector *S3DPreview::getDirection (unsigned int i)
{
   return this->ldir[i];
}


// --------------------------------------------------
S3DVector *S3DPreview::getPosition (unsigned int i)
{
   return this->lpos[i];
}


// --------------------------------------------------
unsigned int S3DPreview::getNDirections (void)
{
   return this->ldir.size();
}


// --------------------------------------------------
unsigned int S3DPreview::getNPositions (void)
{
   return this->lpos.size();
}


// --------------------------------------------------
void S3DPreview::setSize (unsigned int flag, float s)
{
   switch(flag)
   {
      case SIZE: {
	 this->size = s;
      } break;
      case UNIT_SIZE: {
	 this->unit_size = s;
      } break;
      case UNIT_MOVEMENT: {
	 this->unit_movement = s;
      } break;
      case UNIT_ROTATION: {
	 this->unit_rotation = s;
      } break;
   }
}


// --------------------------------------------------
void S3DPreview::drawPosition(float x, float y, float z)
{
   glClear(GL_DEPTH_BUFFER_BIT);
   glDepthMask(false); 
   S3DPrimitive3D::drawCircle(GL_TRIANGLE_FAN, x, y, z, this->size);
}


// --------------------------------------------------
void S3DPreview::drawDirection(float x, float y, float z)
{
   glClear(GL_DEPTH_BUFFER_BIT);
   glDepthMask(false); 
   glPushMatrix();
   glRotatef(x, 1, 0, 0);
   glRotatef(y, 0, 1, 0);
   glRotatef(z, 0, 0, 1);
   S3DPrimitive3D::drawConnector(0, 0, 0, 0, 
				 this->unit_size, 0.0,
				 this->size, 
				 false, true);
   glPopMatrix();
//   S3DPrimitive3D::drawConnector(0, 0, 0, x * this->unit_size, 
//				 y * this->unit_size, z * this->unit_size,
//				 this->size * 0.5, 
//				 false, true);
}


// --------------------------------------------------
void S3DPreview::draw(bool select)
{

   if (select == false)
   {
      if (this->sendpredrawevents)
	 this->sendEvent(this, "predraw", 0, 0, 0, 0, 0, 0);
      
      this->drawFrontBuffer();
   }
   else
   {
      if ( (this->lpos.size() > 0) || (this->ldir.size() > 0) )
	 if (!this->getProperty(S3DComponent::HIDED))
	    this->drawBackBuffer();
   }

}


// --------------------------------------------------
void S3DPreview::drawArrows(bool select)
{
   unsigned int id, i, j;
   float alpha;

   // Do not draw anything if there are no arrows:
   if ( (this->lpos.size() <= 0) && (this->ldir.size() <= 0) )
      return;

   glDepthMask(true); 

   // Draw the directions and positions
   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);
   glDisable(GL_BLEND);

   if (select == true)
   {
      id = this->getMinID();
      glClearColor(this->getRedFromId(id) / 255.0,
		   this->getGreenFromId(id) / 255.0,
		   this->getBlueFromId(id) / 255.0, 1.0);
      glClear(GL_COLOR_BUFFER_BIT);
   }
   else
      glClear(GL_DEPTH_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

   glMatrixMode(GL_TEXTURE);
   glPushMatrix();

   glMatrixMode(GL_PROJECTION);
   glPushMatrix();

   this->drawProjectionInFBO();

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();

   this->cameraInFBO();

   glMatrixMode(GL_MODELVIEW);


   for (i = 0; i < this->lpos.size(); i ++)
   {
      if ((select == false) && 
	  (this->posSelected >= 0) && (this->posSelected == i))
      {
	 if (this->selectedAxis & X_SELECTED)
	 {
	    glLineWidth(this->size);
	    alpha = 1.0;
	 }
	 else
	 {
	    glLineWidth(1.0);
	    alpha = 0.1;
	 }
	    
	 glColor4f (alpha, 0.0, 0.0, 0.9);
	 S3DPrimitive3D::drawConnector(-10000, 
				       this->lpos[i]->Y(), 
				       this->lpos[i]->Z(), 
				       10000, 
				       this->lpos[i]->Y(),
				       this->lpos[i]->Z(), 
				       false, false, 0);
	 if (this->selectedAxis & Y_SELECTED)
	 {
	    glLineWidth(this->size);
	    alpha = 1.0;
	 }
	 else
	 {
	    glLineWidth(1.0);
	    alpha = 0.1;
	 }
	 glColor4f (0.0, alpha, 0.0, 0.9);
	 S3DPrimitive3D::drawConnector(this->lpos[i]->X(),
				       -10000,
				       this->lpos[i]->Z(),
				       this->lpos[i]->X(),  
				       10000,
				       this->lpos[i]->Z(), 
				       false, false, 0);
	 if (this->selectedAxis & Z_SELECTED)
	 {
	    glLineWidth(this->size);
	    alpha = 1.0;
	 }
	 else
	 {
	    glLineWidth(1.0);
	    alpha = 0.1;
	 }
	 glColor4f (0.0, 0.0, alpha, 0.9);
	 S3DPrimitive3D::drawConnector(this->lpos[i]->X(),
				       this->lpos[i]->Y(),
				       -10000, 
				       this->lpos[i]->X(), 
				       this->lpos[i]->Y(),
				       10000, 
				       false, false, 0);
	    
	    
	 glColor4f (0.0, 0.0, 1.0, 1.0);
      }
      else
	 glColor4f (0.0, 0.0, 0.2, 1.0);
	 
      if (this->lpos[i] != 0)
      {
	 if (select == true)
	 {
	    id = this->getMinID() + i + 1;
	    glColor4ub (this->getRedFromId(id),
			this->getGreenFromId(id),
			this->getBlueFromId(id), 255);
	 }
	 else
	 {
	    glColor4f (1.0, 1.0, 0.5, 0.9);
	 }

	 this->drawPosition(this->lpos[i]->X(), 
			    this->lpos[i]->Y(), 
			    this->lpos[i]->Z());
	 
	 if (select == false)
	 {
	    glPushMatrix();
	    {
	       glTranslatef(this->lpos[i]->X(), 
			    this->lpos[i]->Y() + this->size,
			    this->lpos[i]->Z());
//			glRotatef(180, 1, 0, 0);
	       glEnable(GL_BLEND);
	       glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	       this->lnamepos[i]->draw();
	       glDisable(GL_BLEND);
	    }
	    glPopMatrix();
	 }
      }
   }
      
   j = i + 1;
   for (i = 0; i < this->ldir.size(); i ++)
   {
	 
      if ((select == false) && 
	  (this->dirSelected >= 0) && (this->dirSelected == i))
      {
	 glPushMatrix();
	 {
	    if (this->selectedAxis & Z_SELECTED)
	    {
	       glLineWidth(this->size);
	       alpha = 1.0;
	    }
	    else
	    {
	       glLineWidth(1.0);
	       alpha = 0.1;
	    }
	    glColor4f (0.0, 0.0, alpha, 0.9);
	    S3DPrimitive3D::drawCircle(GL_LINE_STRIP, 0, 0, 0, 
				       this->unit_size);
	 }
	 glPopMatrix();
	    
	 glPushMatrix();
	 {
	    glRotatef(90, 1, 0, 0);
	    if (this->selectedAxis & Y_SELECTED)
	    {
	       glLineWidth(this->size);
	       alpha = 1.0;
	    }
	    else
	    {
	       glLineWidth(1.0);
	       alpha = 0.1;
	    }
	    glColor4f (0.0, alpha, 0.0, 0.9);
	    S3DPrimitive3D::drawCircle(GL_LINE_STRIP, 0, 0, 0, 
				       this->unit_size);
	 }
	 glPopMatrix();
	    
	 glPushMatrix();
	 {
	    glRotatef(90, 0, 1, 0);
	    if (this->selectedAxis & X_SELECTED)
	    {
	       glLineWidth(this->size);
	       alpha = 1.0;
	    }
	    else
	    {
	       glLineWidth(1.0);
	       alpha = 0.1;
	    }
	    glColor4f (alpha, 0.0, 0.0, 0.9);
	    S3DPrimitive3D::drawCircle(GL_LINE_STRIP, 0, 0, 0, 
				       this->unit_size);
	 }
	 glPopMatrix();
	    
	 glColor4f (0.0, 0.0, 1.0, 1.0);
      }
      else
	 glColor4f (0.0, 0.0, 0.0, 1.0);
	 
      if (this->ldir[i] != 0)
      {
	 if (select == true)
	 {
	    id = this->getMinID() + i + j;
	    glColor4ub (this->getRedFromId(id),
			this->getGreenFromId(id),
			this->getBlueFromId(id), 255);
	 }
	 else
	 {
	    glColor4f (1.0, 1.0, 0.5, 0.9);
	 }

	 this->drawDirection(this->ldir[i]->get(3), 
			     this->ldir[i]->get(4), 
			     this->ldir[i]->get(5));

//	 S3DPrimitive3D::drawConnector(0, 0, 0, 
//				       this->ldir[i]->X() * this->unit_size,
//				       this->ldir[i]->Y() * this->unit_size,
//				       this->ldir[i]->Z() * this->unit_size,
//				       this->size * 0.5, 
//				       false, true);
	 if (select == false)
	 {
	    glPushMatrix();
	    {
	       glRotatef (this->ldir[i]->get(3), 1.0, 0.0, 0.0);
	       glRotatef (this->ldir[i]->get(4), 0.0, 1.0, 0.0);
	       glRotatef (this->ldir[i]->get(5), 0.0, 0.0, 1.0);
	       glTranslatef(0.0, this->unit_size, 0.0);
	       glEnable(GL_BLEND);
	       glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	       this->lnamedir[i]->draw();
	       glDisable(GL_BLEND);
	    }
	    glPopMatrix();
	 }
      }
   }

   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();

   glMatrixMode(GL_TEXTURE);
   glPopMatrix();

   glMatrixMode(GL_MODELVIEW);
}


// --------------------------------------------------
void S3DPreview::drawBackBuffer(void)
{
   float s;
   unsigned int id;
   unsigned int i, j;
   unsigned char *buffer;
   S3DImage *img;

//   if ((this->lpos.size() <= 0) && (this->ldir.size() <= 0))
//      return;

   if (this->redraw_backbuffer == true)
   {
      if (!this->forceUpd)
      {
	 this->fbo_back = new S3DFBO(32, 32,
				     //this->wprev, this->hprev, 
				     3, GL_RGB, GL_UNSIGNED_BYTE, GL_NEAREST, 
				     false);

	 this->fbo_back->isValid();
      }
   
      this->fbo_back->renderFBO();
      {
	 // Draw arrows:
	 glMatrixMode(GL_MODELVIEW);
	 this->drawArrows(true);
	 glMatrixMode(GL_MODELVIEW);

	 this->redraw_backbuffer = false;
	 this->update();

	 if (!this->forceUpd)
	 {
	    if (this->imgfbo_back != 0)
	       glDeleteTextures(1, &(this->imgfbo_back));
	    this->imgfbo_back = this->capture(0, 32, 32);
	 }
      }
      this->fbo_back->renderFramebuffer();
      glMatrixMode(GL_MODELVIEW);

      if (this->forceUpd)
	    this->imgfbo_back = this->fbo_back->getTexture();
	 else
	    if (this->fbo_back != 0)
	    {
	       delete this->fbo_back;
	       this->fbo_back = 0;
	    }
   }   

   glMatrixMode(GL_MODELVIEW);
   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_1D);
   glEnable(GL_TEXTURE_2D);
   glDisable(GL_BLEND);
   glColor4f (1.0, 1.0, 1.0, 1.0);
   glBindTexture (GL_TEXTURE_2D, this->imgfbo_back);
   
   s = this->theme->getValue(S3DTheme::SPACEVALUE);
   S3DPrimitive3D::drawPlane(GL_POLYGON, this->getX() + s,
			     this->getY() + s, 0.0, 
			     this->getWidth(), this->getHeight(), false);
   
   glDisable(GL_TEXTURE_2D);

}


// --------------------------------------------------
void S3DPreview::drawFBO(void)
{
   if (this->changed == false)
      return;

   if (!this->forceUpd)
      this->fbo = new S3DFBO(this->wprev, this->hprev, 
			     4, GL_RGBA, GL_UNSIGNED_BYTE, GL_LINEAR, true);

   this->fbo->isValid();

   this->fbo->renderFBO();
   {
      glPushAttrib(GL_ALL_ATTRIB_BITS);
      glDepthMask(true); 
      
      glClearColor(1, 1, 1, 1);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glDisable(GL_BLEND);
         
      glMatrixMode(GL_PROJECTION);
      glPushMatrix();
      
      glMatrixMode(GL_TEXTURE);
      glPushMatrix();
     
      glMatrixMode(GL_MODELVIEW);
      glPushMatrix();
      {
      
	 // We must change this flag before other 
	 // components changing the flag while they are drawing
	 this->changed = false;

	 // ---------------
	 glMatrixMode(GL_PROJECTION);
	 if (this->getNListeners() <= 0)
	 {
	    this->forceUpdate(true);
	    this->drawProjectionInFBO();
	 }
	 else
	 {
	    this->sendEvent(this, "draw_projection_fbo", 0, 0, 0, 0, 0, 0);
	 }
	 // ---------------
	 
	 glMatrixMode(GL_MODELVIEW);
	 
	 // Draw something
	 if (this->getNListeners() <= 0)
	 {
	    this->cameraInFBO();
	 }
	 else
	 {
	    this->sendEvent(this, "camera_fbo", 0, 0, 0, 0, 0, 0);
	 }
	 
	 glMatrixMode(GL_MODELVIEW);
	 
	 if (this->getNListeners() <= 0)
	 {
	    this->drawModelInFBO();
	 }
	 else
	 {
	    this->sendEvent(this, "draw_model_fbo", 0, 0, 0, 0, 0, 0);
	 }

      }
      glMatrixMode(GL_MODELVIEW);
      glPopMatrix();
      
      glMatrixMode(GL_TEXTURE);
      glPopMatrix();
    
      glMatrixMode(GL_PROJECTION);
      glPopMatrix();
      
      glMatrixMode(GL_MODELVIEW);

    
      // Draw arrows:
      this->drawArrows(false);

      glPopAttrib();
      glMatrixMode(GL_MODELVIEW);

      if (!this->forceUpd)
      {
	 if (this->imgfbo != 0)
	    glDeleteTextures(1, &(this->imgfbo));
	 this->imgfbo = this->capture(0);
      }
   }
   this->fbo->renderFramebuffer();

   if (this->forceUpd)
      this->imgfbo = this->fbo->getTexture();
   else
      if (this->fbo != 0)
      {
	 delete this->fbo;
	 this->fbo = 0;
      }
}


// --------------------------------------------------
void S3DPreview::drawFrontBuffer(void)
{
   float s;
   float alpha;
   unsigned int id;
   unsigned int i, j;
   unsigned char *buffer;

   glDepthMask(false);
//   this->changed = true; // DEBUG

   glEnable(GL_TEXTURE_2D);

   if ( (this->updtimer - SDL_GetTicks() > this->refreshTime) && 
	((this->changed == true) || (this->imgfbo == 0)) )
   {
      this->updtimer = SDL_GetTicks();

      this->drawFBO();

      glMatrixMode(GL_MODELVIEW);
   }

   glDepthMask(false);

   glMatrixMode(GL_MODELVIEW);

   glDisable(GL_TEXTURE_3D);
   glDisable(GL_TEXTURE_1D);
   if (!this->getProperty(S3DComponent::HIDED))
   {
      glEnable(GL_TEXTURE_2D);
      
      glColor4f (1.0, 1.0, 1.0, 1.0);
      glDisable(GL_BLEND);
      glBindTexture (GL_TEXTURE_2D, this->imgfbo);
      
      s = this->theme->getValue(S3DTheme::SPACEVALUE);
      S3DPrimitive3D::drawPlane(GL_POLYGON, this->getX() + s * 2,
				this->getY() + s * 2, 0.0, 
				this->getWidth() - s * 2, 
				this->getHeight() - s * 2, false);
   }
      
   if ((this->getNListeners() <= 0) || (this->forceUpd == true))
      this->update();

   if ((this->posSelected >= 0) || (this->dirSelected >= 0))
      this->theme->setMouse(-1);
   
   glDisable(GL_TEXTURE_2D);
}


// --------------------------------------------------
unsigned int S3DPreview::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DPreview::eventMouseMotion (float x, float y, unsigned int buttons,
				   unsigned int idevent)
{
   S3DMatrix *m;
   S3DVector *v, *v2;
   float xf, yf, zf;
   
   if (this->posSelected >= 0)
   {
      if (this->selectedAxis & X_SELECTED)
	 this->selected_vector->X(x * this->unit_movement - this->prevx);

      if (this->selectedAxis & Y_SELECTED)
	 this->selected_vector->Y(-y * this->unit_movement - this->prevy);
      
      if (this->selectedAxis & Z_SELECTED)
	 this->selected_vector->Z(-y * this->unit_movement - this->prevz) ;

      if (this->forceUpd)
      	 this->sendEvent(this, "move_position",
			 x, y, buttons, 0, 
			 this->selected_vector, 
			 this->posSelected);
      this->update();
   }

   if (this->dirSelected >= 0)
   {
      if (this->selectedAxis & X_SELECTED)
      {
	 this->selected_vector->set(3, 
				    -(y - this->prevx) * this->unit_rotation);
	 v = this->computeDirection(this->selected_vector->get(3), 
				    this->selected_vector->get(4), 
				    this->selected_vector->get(5)); 
	 this->selected_vector->set(0, v->X());
	 this->selected_vector->set(1, v->Y());
	 this->selected_vector->set(2, v->Z());
	 if (this->forceUpd)
	    this->sendEvent(this, "move_direction",
			    x, y, buttons, 0, 
			    this->selected_vector, 
			    this->dirSelected);
      }

      if (this->selectedAxis & Y_SELECTED)
      {
	 this->selected_vector->set(4, (y - this->prevy) * this->unit_rotation);
	 v = this->computeDirection(this->selected_vector->get(3), 
				    this->selected_vector->get(4), 
				    this->selected_vector->get(5)); 
	 this->selected_vector->set(0, v->X());
	 this->selected_vector->set(1, v->Y());
	 this->selected_vector->set(2, v->Z());
	 if (this->forceUpd)
	    this->sendEvent(this, "move_direction",
			    x, y, buttons, 0, 
			    this->selected_vector, 
			    this->dirSelected);
      }


      if (this->selectedAxis & Z_SELECTED)
      {
	 this->selected_vector->set(5, (y - this->prevz) * this->unit_rotation);
	 v = this->computeDirection(this->selected_vector->get(3), 
				    this->selected_vector->get(4), 
				    this->selected_vector->get(5)); 
	 this->selected_vector->set(0, v->X());
	 this->selected_vector->set(1, v->Y());
	 this->selected_vector->set(2, v->Z());
	 if (this->forceUpd)
	    this->sendEvent(this, "move_direction",
			    x, y, buttons, 0, 
			    this->selected_vector, 
			    this->dirSelected);
      }



      this->update();
   }

   return;
}


// --------------------------------------------------
void S3DPreview::eventMouseButtonDown (float x, float y, unsigned int button,
				       unsigned int idevent)
{
   long int id;
   float xf, yf, zf, xz_dist;
   S3DMatrix *m;

   if ((this->ldir.size() == 0) && (this->lpos.size() == 0))
      return;

   if ( (idevent >= this->getMinID() + 1) && (idevent <= this->getMaxID()) )
   {
      id = idevent - 1 - this->getMinID();
      if (id < this->lpos.size())
      {
	 this->posSelected = id;
	 this->dirSelected = -1;
	 this->selected_vector = this->lpos[id];
	 
	 this->prevx = x * this->unit_movement - this->selected_vector->X();
	 this->prevy = -y * this->unit_movement - this->selected_vector->Y();
	 this->prevz = -y * this->unit_movement - this->selected_vector->Z();

	 this->update();
	 return;
      }
      else
      {
	 id = idevent - 1 - this->getMinID() - this->lpos.size();
	 this->dirSelected = id;
	 this->posSelected = -1;

	 this->selected_vector = this->ldir[id];

	 this->prevx = y + this->selected_vector->get(3);
	 this->prevy = y + this->selected_vector->get(4);
	 this->prevz = y + this->selected_vector->get(5);

	 this->update();
	 return;
      }
   }
   else
      if (idevent == this->getMinID())
      {
	 this->posSelected = -1;
	 this->dirSelected = -1;

	 this->update();
      }
   return;
}


// --------------------------------------------------
GLuint S3DPreview::capture(const char *fname, unsigned int w, unsigned int h)
{
   GLuint texture = 0;
   unsigned char *buffer;
   S3DImage *timg;

   if (w == 0)
      w = this->wprev;
   if (h == 0)
      h = this->hprev;

   buffer = new unsigned char[w * h * 3];
   glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, buffer);   

      
   texture = S3DPrimitive3D::setTexture2D(GL_TEXTURE0, 
					  GL_LINEAR, GL_CLAMP,
					  GL_REPLACE, buffer,
					  3, w, h);
   if (fname != 0)   
   {
      timg = new S3DImage (w, h, 3, buffer);
      timg->convert(4);
      timg->flip(false, true);
      timg->save(fname);
      delete timg;      
   }

   delete [] buffer;

   return texture;
}


// --------------------------------------------------
void S3DPreview::eventMouseButtonUp (float x, float y, unsigned int button,
				   unsigned int idevent)
{
   if (this->posSelected >= 0)
   {
      if (!this->forceUpd)
      	 this->sendEvent(this, "move_position",
			 x, y, button, 0, 
			 this->selected_vector, 
			 this->posSelected);

      this->redraw_backbuffer = true;
      this->posSelected = -1;
      this->update();
   }
   if (this->dirSelected >= 0)
   {
      if (!this->forceUpd)
	 this->sendEvent(this, "move_direction",
			 x, y, button, 0, 
			 this->selected_vector, 
			 this->dirSelected);

      this->redraw_backbuffer = true;
      this->dirSelected = -1;
      this->update();
   }

   return;
}

// --------------------------------------------------
void S3DPreview::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{

   switch(key)
   {
      case 'x': case 'X': {
	 this->selectedAxis = X_SELECTED;
	 this->update();
      } break;

      case 'y': case 'Y': {
	 this->selectedAxis = Y_SELECTED;
	 this->update();
      } break;

      case 'z': case 'Z': {
	 this->selectedAxis = Z_SELECTED;
	 this->update();
      } break;

      case '\n': case '\r': case ' ': {
	 this->update();
      } break;
	 
      default: {
	 this->update();
      } break;

   }

   return;
}


// --------------------------------------------------
void S3DPreview::eventIDChanged (long long int difference)
{
   return;
}


// --------------------------------------------------
void S3DPreview::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DPreview::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DPreview::listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n)
{
   // This component does not listen
   this->update();
   return;
}

