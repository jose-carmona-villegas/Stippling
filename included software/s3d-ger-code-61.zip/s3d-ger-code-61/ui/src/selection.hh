#ifndef __SELECTION__
#define __SELECTION__

#include <GL/glew.h>
#include <fstream>
#include "vector.hh"
#include "image.hh"
#include "primitive3d.hh"

/** @class   S3DSelection selection.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a selection
 *
 *  @bug     No bugs detected yet
 */

class S3DSelection {
   public:

      /** 
       * @post Constructor. Inizialite the empty selection.
       */
      S3DSelection(void);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DSelection(void);

      /**
       * @post Set the position of the component
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] z The z coordinate of the component
       */
      void setPos(float x, float y, float z);

      /**
       * @post Set the size of the component
       * @param[in] w The w coordinate of the component
       * @param[in] h The h coordinate of the component
       */
      void setSize(float w, float h);       
      
      /**
       * @post Draw the component 
       * @param[in] scrn If true draw in the visual way, 
       *                 if false draw the component with the id
       */
      void draw(void);

      /**
       * @post Set the color of the selection
       * @pre All values must be between 0 and 1
       * @param[in] r The red component
       * @param[in] g The green component
       * @param[in] b The blue component
       * @param[in] a The alpha component
       */
      void setColor(float r, float g, float b, float a);

      /**
       * @post The x position
       */
      float getX(void);

      /**
       * @post The y position
       */
      float getY(void);

      /**
       * @post The z position
       */
      float getZ(void);

      

   protected:


   private:
      /// Size of the object
      float w, h;
      /// Position of the object
      float x, y, z;
      /// Color of the selection
      float r, g, b;
      /// Transparency of the box
      float alpha;
      /// Timer for animations
      Uint32 timer;
};


#endif
