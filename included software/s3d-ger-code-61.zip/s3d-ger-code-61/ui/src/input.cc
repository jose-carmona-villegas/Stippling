#include "input.hh"


// --------------------------------------------------
S3DInput::S3DInput(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;
   this->text = 0;
   this->tittle = 0;

   this->nchr = 0;
   this->notfit = false;

   this->tittleLabel = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 1);
   this->textLabel = new S3DLabel(theme->getFont(S3DTheme::INPUTTEXTFONT), 1);


   this->cTimer = this->updateTimer();
   this->number = false;
   this->setPos(0, 0);
   this->setSize(0, 0);

   // Optimization must be initialized
   this->eventChangePos(0, 0);
   this->eventResize(0, 0);
}

// --------------------------------------------------
S3DInput::S3DInput(S3DTheme *theme, float x, float y, float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->theme = theme;
   this->text = 0;
   this->tittle = 0;   

   this->nchr = 0;
   this->notfit = false;

   this->tittleLabel = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 
				   1.0);
   this->textLabel = new S3DLabel(theme->getFont(S3DTheme::INPUTTEXTFONT),    
				  1.0);
   this->number = false;
   this->setPos(x, y);
   this->setSize(w, h);

   // Optimization must be initialized
   this->eventChangePos(x, y);
   this->eventResize(w, h);
}


// --------------------------------------------------
S3DInput::~S3DInput()
{
   if (this->text != 0)
      delete [] this->text;

   if (this->tittle != 0)
      delete [] this->tittle;

   if (this->tittleLabel != 0)
      delete this->tittleLabel;

   if (this->textLabel != 0)
      delete this->textLabel;
}


// --------------------------------------------------
unsigned int S3DInput::getType(unsigned long int id)
{
   return S3DComponent::TEXTINPUT;
}


// --------------------------------------------------
unsigned long int S3DInput::getIDNeeded(void)
{
   return 1; // Only the text is clickable, not the background yet
}

// --------------------------------------------------
void S3DInput::setText(const char *ti, const char *te)
{
   float h, s;
   int p;
   char *strtmp;
   char *cti, *cte;

   if (ti != 0)
   {
      cti = new char[strlen(ti) + 1];
      cti[0] = '\0';
      strcpy(cti, ti);
   }

   if (te != 0)
   {
      cte = new char[strlen(te) + 1];
      cte[0] = '\0';
      strcpy(cte, te);
   }

   if (this->tittle != 0)
      delete [] this->tittle;

   if (ti == 0)
   {
      this->tittle = 0;
   }
   else
   {
      this->tittle = new char[strlen(cti) + 1];
      this->tittle[0] = '\0';
      sprintf(this->tittle, "%s", cti);

      delete [] cti;
   }
      
   if (this->tittleLabel != 0)
      this->tittleLabel->setText(this->tittle);


   if (this->text != 0)
      delete [] this->text;
   
   if (te == 0)
      this->text = 0;
   else
   {
      this->text = new char[strlen(cte) + 1];
      this->text[0] = '\0';
      sprintf(this->text, "%s", cte);
      delete [] cte;
   }

   if (this->textLabel != 0)
      if ((this->notfit == true) && (this->nchr > 0))
      {
 	 p = strlen(this->text) - this->nchr;
	 if (p < 0)
	    p = 0;

	 if (this->text != 0)
	 {
	    this->textLabel->setText(this->text + p);
         }
      }
      else
	 this->textLabel->setText(this->text);


   if (this->getWidth() == 0)
   {
      s = this->theme->getValue(S3DTheme::SPACEVALUE);

      if (this->tittle != 0)
	 h = this->tittleLabel->getWidth();
      else
	 h = 0;

      if (this->text != 0)
      {
	 h += this->textLabel->getWidth();
	 h = h + s * 3;
      }
      else
	 h = h + s;

      this->setSize (h, this->getHeight());
   }


   if (this->getHeight() == 0)
   {
      if (this->tittle != 0)
	 h = this->tittleLabel->getHeight();
      else
	 h = 0;

      if ((this->text != 0) && (h < this->textLabel->getHeight()))
	 h = this->textLabel->getHeight();

      h = h / 2.0 + this->theme->getValue(S3DTheme::SPACEVALUE);
      this->setSize (this->getWidth(), h);
   }

   return;
}


// --------------------------------------------------
const char *S3DInput::getTitle(void)
{
   return this->tittle;
}


// --------------------------------------------------
const char *S3DInput::getText(void)
{
   return this->text;
}


// --------------------------------------------------
void S3DInput::draw(bool select)
{
   float r, s;
   float x;
   unsigned long int id;
   unsigned int flag;
   float cursorcolor[4];

   if (this->getProperty(S3DComponent::HIDED))
      return;

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);


   if (select == true)
   {
      glDisable(GL_BLEND);

      id = this->getMinID();
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);

      s = this->theme->getValue(S3DTheme::SPACEVALUE);
      x = this->optx;
      if (this->tittleLabel != 0)
      {
	 x += this->tittleLabel->getWidth() + s;
      }
      if (this->textLabel != 0)
      {
	 S3DPrimitive3D::drawPlane(GL_POLYGON, x, this->opty, 0.0, 
				   this->getWidth(), this->getHeight());
      }
   }
   else
   {
      flag = S3DTheme::FGINPUTTEXTCOLOR;
      cursorcolor[0] = this->theme->getColor(flag, S3DTheme::RED);
      cursorcolor[1] = 1.0 - this->theme->getColor(flag, S3DTheme::BLUE);
      cursorcolor[2] = 1.0 - this->theme->getColor(flag, S3DTheme::GREEN);
      cursorcolor[3] = 1.0;
      if (cursorcolor[0] < 0.0)
	 cursorcolor[0] = 0;
      if (cursorcolor[1] < 0.0)
	 cursorcolor[1] = 0;
      if (cursorcolor[2] < 0.0)
	 cursorcolor[2] = 0;
      if (cursorcolor[3] < 0.0)
	 cursorcolor[3] = 0;

      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
/*
      r = this->theme->getValue(S3DTheme::CORNERVALUE);
      glColor4f (this->theme->getColor(S3DTheme::BGINPUTTEXTCOLOR, 
				       S3DTheme::RED),
		 this->theme->getColor(S3DTheme::BGINPUTTEXTCOLOR, 
				       S3DTheme::GREEN),
		 this->theme->getColor(S3DTheme::BGINPUTTEXTCOLOR, 
				       S3DTheme::BLUE),
		 this->theme->getColor(S3DTheme::BGINPUTTEXTCOLOR, 
				       S3DTheme::ALPHA));
      S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 
				       this->getX() + this->getWidth(),
				       this->getY() + this->getHeight(),
				       0.0, 
				       this->getWidth(), this->getHeight(), r);
*/
      if (this->tittleLabel != 0)
      {
	 x = this->optx;
	 s = this->theme->getValue(S3DTheme::SPACEVALUE);
	 this->tittleLabel->setPos(x, this->opty, 0.0);
	 flag = S3DTheme::FGTEXTCOLOR;
	 this->tittleLabel->setColor(this->theme->getColor(flag,
							   S3DTheme::RED),
				     this->theme->getColor(flag,
							   S3DTheme::GREEN),
				     this->theme->getColor(flag,
							   S3DTheme::BLUE),
				     this->theme->getColor(flag,
							   S3DTheme::ALPHA));
	 x += this->tittleLabel->getWidth() + s;
	 this->tittleLabel->draw();
      }

      if (this->textLabel != 0)
      {
	 if (this->getFocus() == false)
	    flag = S3DTheme::FGINPUTTEXTCOLOR;
	 else
	    flag = S3DTheme::FGSELECTEDINPUTTEXTCOLOR;

	 this->textLabel->setColor(this->theme->getColor(flag,
							 S3DTheme::RED),
				   this->theme->getColor(flag,
							 S3DTheme::GREEN),
				   this->theme->getColor(flag,
							 S3DTheme::BLUE),
				   this->theme->getColor(flag,
							 S3DTheme::ALPHA));


	 this->textLabel->setPos(x, this->opty, 0.0);
	 this->textLabel->draw();
      }

      // Draw the Cursor
      if (this->getFocus() == true) 
      {

	 if ((this->getTimer() - this->cTimer) % 1000 > 500)
	 {
	    glColor4f (cursorcolor[0], cursorcolor[1],
		       cursorcolor[2], cursorcolor[3]);
	    
	    S3DPrimitive3D::drawPlane(GL_POLYGON, 
				      x + this->textLabel->getWidth(), 
				      this->opty, 0.0, 
				      s, this->getHeight() * 0.8);

	    if (this->notfit == true)
	    {
	       glEnable(GL_BLEND);
	       glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	       glLineWidth(1);
	       glColor4f (this->theme->getColor(S3DTheme::FRAMECOLOR, 
						S3DTheme::RED),
			  this->theme->getColor(S3DTheme::FRAMECOLOR, 
						S3DTheme::GREEN),
			  this->theme->getColor(S3DTheme::FRAMECOLOR, 
						S3DTheme::BLUE),
			  0.5);

	       S3DPrimitive3D::drawConnector(s * 1.5 +
					     this->getX(),
					     this->opty + s * 1.5, 0.0,
					     this->getX(), 
					     this->opty + s * 1.5, 0.0,
					     s * 1.5, false, true);
	    }
	    
//	    r = this->theme->getValue(S3DTheme::CORNERVALUE);
//	    glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE));
	 }
	 glColor4f (this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::RED),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::GREEN),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::BLUE),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::ALPHA));
	 r = 2 * s;
	 if (this->tittleLabel != 0)
	    r += this->tittleLabel->getWidth();
	 if (this->textLabel != 0)
	    r += this->textLabel->getWidth();
	 
	 S3DPrimitive3D::drawPlane(GL_POLYGON, 
				   this->optx,
				   this->getY(),
				   0.0, 
				   r, s);
	 glLineWidth(1);
	 
	 
      }
/*      
      glColor4f (this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::RED),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::GREEN),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::BLUE),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::ALPHA));
      glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE));
      S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP, 
				       this->getX() + this->getWidth(),
				       this->getY() + this->getHeight(),
				       0.0, 
				       this->getWidth(), this->getHeight(), r);
*/
      glLineWidth (this->theme->getValue(1));

   }

   
}

// --------------------------------------------------
void S3DInput::setNumbers (bool n)
{
   this->number = n;
}

// --------------------------------------------------
unsigned int S3DInput::getEvents (void)
{
   return (S3DComponent::MOUSE_DOWN | S3DComponent::KEY_DOWN);
}


// --------------------------------------------------
void S3DInput::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DInput::eventMouseButtonDown (float x, float y, unsigned int button,
				     unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DInput::eventMouseButtonUp (float x, float y, unsigned int button,
				   unsigned int idevent)
{
   return;
}

// --------------------------------------------------
void S3DInput::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{
   char *newtext;
   int le;
   float l;
   unsigned int i;
   float s = this->theme->getValue(S3DTheme::SPACEVALUE);

   if (key == '\b')
   {
      if ((this->text != 0) && (strlen(this->text) > 0) )
      {
	 this->text[strlen(this->text) - 1] = '\0'; 
	 this->setText(this->tittle, this->text);      
      }
      return;
   }

   if ((key == '\r') || (key == '\n'))
   {
      this->setFocus(false);

      if (this->text != 0)
	 this->sendEvent(this, "string_value_changed", x, y, 
			 S3DComponent::NONE,
			 key, this->text, strlen(this->text));
      return;
   }

   if (this->tittleLabel != 0)
      l = this->tittleLabel->getWidth() + 3.5 * s;
   else
      l =  3.5 * s;

   if ( (this->textLabel != 0) && 
	(this->textLabel->getWidth() > this->getWidth() - l) )
   {
      if ( (this->notfit == false) && (this->text != 0) )
	 if (strlen(this->text) - 2 >= 0)
	 {
	    this->nchr = strlen(this->text) - 2;
	    this->notfit = true;
	 }
	 else
	    this->nchr = 0;
   }
   else 
      this->notfit = false;



   if (this->number == true)
   {
      if ( (key == '-') && (this->text != 0) && (strlen(this->text) > 0) )
	 return;

      if ( (key == ',') || (key == '\'') )
	 key = '.';
	   
      if ( (key != '.') && (key != '-') && ((key < '0') || (key > '9')) )
	 return;

      // Avoid duplicate periods: 3.4.5 or ..4
      if ( (key == '.') && (this->text != 0) ) 
      {
	 i = 0;
	 while (i < strlen(this->text))
	 {
	    if (this->text[i] == key)
	       return;
	    i ++;
	 }
      }
   }



   if (this->text != 0)
   {
      le = strlen(this->text) + 5;

      newtext = new char[le];
      newtext[0] = '\0';
      sprintf(newtext, "%s%c", this->text, key);

      this->setText(this->tittle, newtext);
   }
   else
   {
      newtext = new char[4];
      newtext[0] = key;
      newtext[1] = '\0';
      this->setText(this->tittle, newtext);
   }



   return;
}


// --------------------------------------------------
void S3DInput::eventIDChanged (long long int difference)
{
   return;
}


// --------------------------------------------------
void S3DInput::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DInput::eventChangePos (float newX, float newY)
{
   float s = this->theme->getValue(S3DTheme::SPACEVALUE);
   this->optx = this->getX() + s;
   this->opty = this->getY() + s;
   return;
}


// --------------------------------------------------
void S3DInput::listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n)
{
   // This component does not listen
   return;
}

