#include "button.hh"


// --------------------------------------------------
S3DButton::S3DButton(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->idPressed = 0;
   this->idReleased = 0;
   this->idDragged = 0;
   this->idMouseOver = 0;
   this->idReleasedOFF = 0;
   this->idMouseOverOFF = 0;
   this->pressed = false;
   this->mouseOver = false;
   this->tristate = false;
   this->state = false;
   this->draggable = false;
   this->dragging = false;
}

// --------------------------------------------------
S3DButton::S3DButton(S3DTheme *theme, float x, float y, float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->idPressed = 0;
   this->idReleased = 0;
   this->idDragged = 0;
   this->idMouseOver = 0;
   this->idReleasedOFF = 0;
   this->idMouseOverOFF = 0;
   this->pressed = false;
   this->mouseOver = false;
   this->tristate = false;
   this->state = false;
   this->draggable = false;
   this->dragging = false;
}


// --------------------------------------------------
S3DButton::~S3DButton()
{
}


// --------------------------------------------------
void S3DButton::setTristate(bool select)
{
   this->tristate = select;
}


// --------------------------------------------------
void S3DButton::setDraggable(bool select)
{
   this->draggable = select;
}


// --------------------------------------------------
void S3DButton::draw(bool select)
{
   float r, s;
   float w, v; 
   float sx, sy;
   unsigned int id;


   if (this->getProperty(S3DComponent::HIDED))
      return;


   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   s = this->theme->getValue(S3DTheme::SPACEVALUE);
   sx = this->getX() + s;
   sy = this->getY() + s;

   if (select == true)
   {
      glDisable(GL_BLEND);
      
      id = this->getMinID();
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);

      S3DPrimitive3D::drawPlane(GL_POLYGON, 
				sx, sy, 0.0,
				this->getWidth(), this->getHeight());

   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glColor4f(1.0, 1.0, 1.0, 1.0);
      if ( (this->pressed == false) && (this->mouseOver == false) &&
	   (this->idReleased != 0) )
      {
	 glEnable(GL_TEXTURE_2D);
	 if ((this->tristate == true) &&
	     (this->state == false) && 
	     (this->idReleasedOFF != 0))
	    glBindTexture(GL_TEXTURE_2D, this->idReleasedOFF);
	 else
	    glBindTexture(GL_TEXTURE_2D, this->idReleased);
      }
      else
	 if ( (this->pressed == true) && (this->idPressed != 0) )
	 {
	    glEnable(GL_TEXTURE_2D);
	    glBindTexture(GL_TEXTURE_2D, this->idPressed);
	 }
	 else
	    if ( (this->mouseOver == true) && (this->idMouseOver != 0) )
	    {
	       glEnable(GL_TEXTURE_2D);
	       if ((this->tristate == true) &&
		   (this->state == false) && 
		   (this->idMouseOverOFF != 0))
		  glBindTexture(GL_TEXTURE_2D, this->idMouseOverOFF);
	       else
		  glBindTexture(GL_TEXTURE_2D, this->idMouseOver);
	    }
      S3DPrimitive3D::drawPlane(GL_POLYGON, 
				sx, sy, 0.0,
				this->getWidth(), this->getHeight());

      if (this->dragging == true)
      {
	 if (this->idDragged != 0)
	    glBindTexture(GL_TEXTURE_2D, this->idDragged);
	 else
	    if (this->idMouseOver != 0)
	       glBindTexture(GL_TEXTURE_2D, this->idMouseOver);
	    else
	       glDisable(GL_TEXTURE_2D);

	 S3DPrimitive3D::drawPlane(GL_POLYGON, 
				   this->getX() + this->mx,
				   this->getY() + this->my,
				   0.0,
				   this->getWidth(), this->getHeight());
      }

   }

   glDisable(GL_TEXTURE_2D);   
}


// --------------------------------------------------
bool S3DButton::getState (void)
{
   return this->state;
}


// --------------------------------------------------
void S3DButton::setState (bool s)
{
   this->state = s;
}


// --------------------------------------------------
void S3DButton::setIDDragged (GLuint n)
{
   this->idDragged = n;
}


// --------------------------------------------------
void S3DButton::setIDPressed (GLuint n)
{
   this->idPressed = n;
}


// --------------------------------------------------
void S3DButton::setIDReleased (GLuint n)
{
   this->idReleased = n;
}


// --------------------------------------------------
void S3DButton::setIDReleasedOFF (GLuint n)
{
   this->idReleasedOFF = n;
}


// --------------------------------------------------
void S3DButton::setIDMouseOver (GLuint n)
{
   this->idMouseOver = n;
}


// --------------------------------------------------
void S3DButton::setIDMouseOverOFF (GLuint n)
{
   this->idMouseOverOFF = n;
}


// --------------------------------------------------
unsigned int S3DButton::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DButton::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   if (this->getMinID() == idevent)
      this->mouseOver = true;
   else
      this->mouseOver = false;

   if (this->dragging == true)
   {
      this->mx = x - this->prevx;
      this->my = y - this->prevy;
   }

   return;
}


// --------------------------------------------------
void S3DButton::eventMouseButtonDown (float x, float y, unsigned int button,
				     unsigned int idevent)
{
   if (this->getMinID() == idevent)
   {
      this->pressed = true;
      if (this->draggable == true)
      {
	 this->dragging = true;
	 this->prevx = x;
	 this->prevy = y;
	 this->mx = 0;
	 this->my = 0;
      }
   }
   return;
}


// --------------------------------------------------
void S3DButton::eventMouseButtonUp (float x, float y, unsigned int button,
				   unsigned int idevent)
{
   if ( (this->pressed == true) && (this->tristate == true) &&
	(idevent == this->getMinID()))
   {
      if (this->state == false)
	 this->state = true;
      else
	 this->state = false;

      this->sendEvent(this, "button_state_changed", x, y, 
		      button, S3DComponent::NONE, &(this->state), 0);
   }

   if (this->pressed == true)
   {
      this->pressed = false;
      if (idevent == this->getMinID())
	 this->sendEvent(this, "button_pressed", x, y, 
			 button, S3DComponent::NONE, 0, 0);
   }


   if (this->draggable == true)
   {
      if ( (idevent != this->getMinID()) && (this->dragging == true) )
      {
	 this->sendEvent(this, "element_dropped", x, y, 
			 button, S3DComponent::NONE, &(this->idDragged), 
			 idevent);
	 this->dragging = false;
      }
   }
   return;
}

// --------------------------------------------------
void S3DButton::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{
}


// --------------------------------------------------
void S3DButton::eventIDChanged (long long int difference)
{
   return;
}


// --------------------------------------------------
unsigned long int S3DButton::getIDNeeded(void)
{
   // Only the background of the button
   return 1;
}


// --------------------------------------------------
unsigned int S3DButton::getType(unsigned long int id)
{
   return S3DComponent::BUTTON;
}


// --------------------------------------------------
void S3DButton::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DButton::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DButton::listenEvent(S3DListener *sender, const char *msg, 
			    float x, float y, unsigned int button, 
			    unsigned int key, 
			    void *data, unsigned int n)
{
   // This component does not listen
   return;
}

