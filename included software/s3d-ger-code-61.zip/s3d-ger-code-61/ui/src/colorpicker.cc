#include "colorpicker.hh"


// --------------------------------------------------
S3DColorPicker::S3DColorPicker(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->red = 1.0;
   this->green = this->blue = 0.0;
   this->color = new S3DColor (0, 0, 0, 1.0);
   this->slider = new S3DSlider (theme, 0, 0, 0, 0);
   this->slider->setID(this->getMinID() + 2, 
		       this->getMinID() + this->slider->getIDNeeded() + 1);
   this->slider->setTitle("Alpha:");
   this->slider->setValue(this->color->A());
   this->slider->showButtons(false);
   this->slider->showTitle(false);

   this->tittleLabel = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 1);


   this->movingHueSlider = false;
   this->movingSquareSlider = false;

   this->slider->addListener(this);

   this->prevx = this->prevy = this->prevv0 = this->prevv1;
}

// --------------------------------------------------
S3DColorPicker::S3DColorPicker(S3DTheme *theme, float x, float y, 
			       float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->red = 1.0;
   this->green = this->blue = 0.0;
   this->color = new S3DColor (0.0, 0.0, 0.0, 1.0);
   this->slider = new S3DSlider (theme, 0, 0, w, 0);
   this->slider->setID(this->getMinID() + 2, 
		       this->getMinID() + this->slider->getIDNeeded() + 1);
   this->slider->setTitle("Alpha:");
   this->slider->setValue(this->color->A());

   this->movingHueSlider = false;
   this->movingSquareSlider = false;
   this->slider->showButtons(false);
   this->slider->showTitle(false);

   this->slider->addListener(this);

   this->tittleLabel = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 1);

   this->prevx = this->prevy = this->prevv0 = this->prevv1;
}


// --------------------------------------------------
S3DColorPicker::~S3DColorPicker()
{
   if (this->tittleLabel != 0)
      delete this->tittleLabel;

   if (this->slider != 0)
      delete this->slider;
}


// --------------------------------------------------
unsigned int S3DColorPicker::getType(unsigned long int id)
{
   return S3DComponent::COLORPICKER;
}


// --------------------------------------------------
unsigned long int S3DColorPicker::getIDNeeded(void)
{
 // Only the ColorPicker (both bars) and the slider are clickable
   return 2 + this->slider->getIDNeeded();
}


// --------------------------------------------------
void S3DColorPicker::drawTranspBG(float x0, float y0, float x1, float y1, 
				  float p)
{
   unsigned char *buffer;
   unsigned int i, j;
   unsigned long int pos;
   unsigned int wt, ht;
   float rt = (y1 - y0) / (x1 - x0);
   GLuint idback;

   wt = 4;
   ht = 4;

   glDisable(GL_BLEND);
   glEnable(GL_TEXTURE_2D);
   
   buffer = new unsigned char[wt * ht * 3];
   for (i = 0; i < wt; i ++)
      for (j = 0; j < ht; j ++)
      {
	 pos = (i + j * wt) * 3;

	 if ( ( (i % 2 == 0) && (j % 2 != 0) ) ||
	      ( (i % 2 != 0) && (j % 2 == 0) ) )
	 {
	    buffer[pos] = 200;
	    buffer[pos + 1] = 200;
	    buffer[pos + 2] = 255;
	 }
	 else
	 {
	    buffer[pos] = 0;
	    buffer[pos + 1] = 0;
	    buffer[pos + 2] = 80;
	 }
      }


   idback = S3DPrimitive3D::setTexture2D(GL_TEXTURE0, GL_NEAREST, 
					 GL_REPEAT, GL_REPLACE, buffer,
					 3, wt, ht);
   
   glMatrixMode(GL_TEXTURE);
   glPushMatrix();
   {
      glLoadIdentity();
      glMatrixMode(GL_MODELVIEW);
      glPushMatrix();
      {
//	 glLoadIdentity();
	 
	 glBindTexture(GL_TEXTURE_2D, idback);
	 glBegin(GL_QUADS);
	 
	 glTexCoord2f (0.0, 0.0);
	 glVertex3f (x0 + this->getX(),  y0 + this->getY(),  0);
	 
	 glTexCoord2f (p, 0.0);
	 glVertex3f (x1 + this->getX(),  y0 + this->getY(),  0);
	 
	 glTexCoord2f (p, p * rt);
	 glVertex3f (x1 + this->getX(),  y1 + this->getY(),  0);
	 
	 glTexCoord2f (0.0, p * rt);
	 glVertex3f (x0 + this->getX(),  y1 + this->getY(),  0);
	 glEnd();
      }
      glPopMatrix();
      glMatrixMode(GL_MODELVIEW);
   }
   glMatrixMode(GL_TEXTURE);
   glPopMatrix();

   glMatrixMode(GL_MODELVIEW);

   delete [] buffer;
   glDeleteTextures(1, &idback);

   glEnable(GL_BLEND);
   glDisable(GL_TEXTURE_2D);
   

}


// --------------------------------------------------
void S3DColorPicker::showAlphaTitle(bool show)
{
   this->slider->showTitle(show);
}

// --------------------------------------------------
void S3DColorPicker::setTitle(const char *title)
{
   this->tittleLabel->setText(title);
}

// --------------------------------------------------
void S3DColorPicker::draw(bool select)
{
   float r, s;
   float w, h; 
   unsigned int id;
   float inc, h2;
   unsigned int flag;


   if (this->getProperty(S3DComponent::HIDED))
      return;



   if (this->getFocus() == false)
      this->slider->setFocus(false);
  
   this->color->RGBtoHSV();
   if (this->color->H() >= 360)
   {
      this->color->H(0);
      this->color->HSVtoRGB();
      this->color->RGBtoHSV();
   }

   this->color->A(this->slider->getValue());

   glPushMatrix();

   s = this->theme->getValue(S3DTheme::SPACEVALUE);

   glTranslatef(s, s, 0.0);


   w = this->getHeight() * 0.8;
   h = w;
   h2 = h * 0.1;
   inc = w * 0.16667; // (w / 6)

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);
   if (select == true)
   {
      glDisable(GL_BLEND);

      glPushMatrix();
      {
         glTranslatef(this->getX(), this->getY() - h * 0.4, 0.0);
         this->slider->draw(true);
      }
      glPopMatrix();

      // Movement:
      this->color->RGBtoHSV();
      id = this->getMinID(); // ID of the hue slider
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);      
      S3DPrimitive3D::drawPlane (GL_POLYGON, 
				 this->getX() + this->color->H() / 360.0 * w - 
				 inc,
				 this->getY(), 0, inc * 2.25, h2);

      id ++; // ID of the circle
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);      
      S3DPrimitive3D::drawCircle (GL_TRIANGLE_FAN,
                                  this->getX() + this->color->V() * w,
                                  this->getY() + this->color->S() * (w - h2)
                                  + h2, 0, inc);
   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glShadeModel(GL_SMOOTH);
      glBegin(GL_POLYGON);
      {
	 glColor4f(0.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX(), this->getY() + h2, 0.0);
	 glColor4f(1.0, 1.0, 1.0, 1.0);
	 glVertex3f(this->getX() + w, this->getY() + h2, 0.0);
	 glColor4f(this->red, this->green, this->blue, 1.0);
	 glVertex3f(this->getX() + w, this->getY() + h, 0.0);
	 glColor4f(0.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX(), this->getY() + h, 0.0);
      }
      glEnd();

      glBegin(GL_QUAD_STRIP);
      {
	 glColor4f(1.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX(), this->getY(), 0.0);
	 glColor4f(1.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX(), this->getY() + h2, 0.0);

	 glColor4f(1.0, 1.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc, this->getY(), 0.0);
	 glColor4f(1.0, 1.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc, this->getY() + h2, 0.0);

	 glColor4f(0.0, 1.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc * 2, this->getY(), 0.0);
	 glColor4f(0.0, 1.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc * 2, this->getY() + h2, 0.0);


	 glColor4f(0.0, 1.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 3, this->getY(), 0.0);
	 glColor4f(0.0, 1.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 3, this->getY() + h2, 0.0);

	 glColor4f(0.0, 0.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 4, this->getY(), 0.0);
	 glColor4f(0.0, 0.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 4, this->getY() + h2, 0.0);

	 glColor4f(1.0, 0.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 5, this->getY(), 0.0);
	 glColor4f(1.0, 0.0, 1.0, 1.0);
	 glVertex3f(this->getX() + inc * 5, this->getY() + h2, 0.0);

	 glColor4f(1.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc * 6, this->getY(), 0.0);
	 glColor4f(1.0, 0.0, 0.0, 1.0);
	 glVertex3f(this->getX() + inc * 6, this->getY() + h2, 0.0);

      }
      glEnd();

      glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE) * 0.1);
      if (this->color->A() < 1.0)
      {
	 this->drawTranspBG(0, h, w, h + h * 0.2, 5);
/*
	 glColor4f(1.0, 1.0, 1.0, 1.0);
	 S3DPrimitive3D::drawPlane (GL_POLYGON, 0, h, 0, w, h * 0.2);
	 glColor4f(1.0, 0.0, 0.0, 1.0);
	 S3DPrimitive3D::drawCircle (GL_LINE_STRIP, w * 0.5, h * 1.1, 
				     0, h * 0.1);
	 glColor4f(0.0, 0.0, 1.0, 1.0);
	 S3DPrimitive3D::drawCircle (GL_LINE_STRIP, w * 0.5, h * 1.1, 
				     0, h * 0.05);
*/

      }

      glColor4f(this->color->R(), this->color->G(), this->color->B(), 
		this->color->A());
      S3DPrimitive3D::drawPlane (GL_POLYGON, this->getX() + 0, 
                                 this->getY() + h, 0, w, h * 0.2);


      glColor4f(0.0, 0.0, 0.0, 1.0);
      S3DPrimitive3D::drawPlane (GL_LINE_STRIP, this->getX() + 0, 
                                 this->getY() + h, 0, w, h * 0.2);

      // Movement:
      this->color->RGBtoHSV();
      glColor4f(0.0, 0.0, 0.0, 1.0);
      S3DPrimitive3D::drawPlane (GL_LINE_STRIP, 
				 this->getX() + this->color->H() / 360.0 * w,
				 this->getY(), 0, inc * 0.25, h2);
      glColor4f(1.0 - this->color->R(), 
		1.0 - this->color->G(), 
		1.0 - this->color->B(), 
		1.0);
      S3DPrimitive3D::drawCircle (GL_LINE_STRIP,
                                  this->getX() + this->color->V() * w,
                                  this->getY() + this->color->S() * (w - h2) 
                                  + h2,
				  0, inc * 0.25);
      glLineWidth (1.0);


      glPushMatrix();
      {
         glTranslatef(this->getX(), this->getY() - h * 0.4, 0.0);
         this->slider->draw(false);	 
      }
      glPopMatrix();

      this->tittleLabel->setPos(this->getX(), 
				this->getY() + this->getWidth(), 0.0);
      flag = S3DTheme::FGTEXTCOLOR;
      this->tittleLabel->setColor(this->theme->getColor(flag,
							S3DTheme::RED),
				  this->theme->getColor(flag,
							S3DTheme::GREEN),
				  this->theme->getColor(flag,
							S3DTheme::BLUE),
				  this->theme->getColor(flag,
							S3DTheme::ALPHA));
      this->tittleLabel->draw();
   }

   
   glPopMatrix();
}


// --------------------------------------------------
void S3DColorPicker::setColor (float r, float g, float b, float a)
{
   this->color->setRGB(r, g, b);
   this->color->A(a);
   this->slider->setValue(a);
}

// --------------------------------------------------
S3DColor *S3DColorPicker::getColor (void)
{
   return this->color;
}

// --------------------------------------------------
float S3DColorPicker::getRed (void)
{
   return this->color->R();
}


// --------------------------------------------------
float S3DColorPicker::getGreen (void)
{
   return this->color->G();
}


// --------------------------------------------------
float S3DColorPicker::getBlue (void)
{
   return this->color->B();
}


// --------------------------------------------------
float S3DColorPicker::getAlpha (void)
{
   return this->color->A();
}


// --------------------------------------------------
unsigned int S3DColorPicker::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DColorPicker::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   float w, h;
   S3DColor *c;
   float inc;
   float h2;
 
   if (this->movingHueSlider == true)
   {
      this->color->RGBtoHSV();
      c = new S3DColor ();
      w = this->getHeight() * 0.8;
      
      inc = (x - this->prevx) / w;
      this->color->H(360 * (inc + this->prevv0));
      if (this->color->H() > 359)
	 this->color->H(359);
      if (this->color->H() < 0)
	 this->color->H(0);
      this->color->HSVtoRGB();
      c->setHSV(this->color->H(), 1.0, 1.0);
      c->HSVtoRGB();
      this->red = c->R();
      this->green = c->G();
      this->blue = c->B();
      delete c;

      this->color->HSVtoRGB();

      this->sendEvent(this, "color_value_changed", x, y, 
		      buttons, S3DComponent::NONE, (this->color), 0);
      return;
   }


   if (this->movingSquareSlider == true)
   {
      this->color->RGBtoHSV();
      h = w = this->getHeight() * 0.8;
      h2 = h * 0.1;
      inc = (x - this->prevx) / w;
      this->color->V(inc + this->prevv0);
      inc = (y - this->prevy) / (h - h2);
      this->color->S(inc + this->prevv1);
      if (this->color->S() > 1)
	 this->color->S(1);
      if (this->color->S() < 0)
	 this->color->S(0);
      if (this->color->V() > 1)
	 this->color->V(1);
      if (this->color->V() < 0)
	 this->color->V(0);


      this->color->HSVtoRGB();

      this->sendEvent(this, "color_value_changed", x, y, 
		      buttons, S3DComponent::NONE, (this->color), 0);
      return;
   }

   this->slider->eventMouseMotion(x, y, buttons, idevent);
   return;
}


// --------------------------------------------------
void S3DColorPicker::eventMouseButtonDown (float x, float y, 
					   unsigned int button,
					   unsigned int idevent)
{
   if (idevent == this->getMinID())
   {
      this->color->RGBtoHSV();
      this->movingHueSlider = true;
      this->prevx = x;
      this->prevv0 = this->color->H() / 360.0;
      this->movingSquareSlider = false;

      return;
   }


   if (idevent == this->getMinID() + 1)
   {
      this->color->RGBtoHSV();
      this->movingSquareSlider = true;
      this->prevx = x;
      this->prevy = y;
      this->prevv0 = this->color->V();
      this->prevv1 = this->color->S();
      this->movingHueSlider = false;

      return;
   }

   if ( (idevent >= this->slider->getMinID()) &&
	(idevent <= this->slider->getMaxID()))
   {
      this->slider->setFocus(true);
   }

   this->slider->eventMouseButtonDown(x, y, button, idevent);
   return;
}


// --------------------------------------------------
void S3DColorPicker::eventMouseButtonUp (float x, float y, unsigned int button,
					 unsigned int idevent)
{
   if (this->movingHueSlider == true)
      this->movingHueSlider = false;
   if (this->movingSquareSlider == true)
      this->movingSquareSlider = false;
   
   this->slider->eventMouseButtonUp(x, y, button, idevent);
   return;
}

// --------------------------------------------------
void S3DColorPicker::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{
   if (this->slider->getFocus() == true)
   {
      this->slider->eventKeyDown (x, y, key, idevent);
   }

   return;
}


// --------------------------------------------------
void S3DColorPicker::eventIDChanged (long long int difference)
{
   this->slider->setID(this->slider->getMinID() + difference, 
		       this->slider->getMaxID() + difference);
   return;
}


// --------------------------------------------------
void S3DColorPicker::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DColorPicker::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DColorPicker::listenEvent(S3DListener *sender, const char *msg, 
				 float x, float y, unsigned int button, 
				 unsigned int key, 
				 void *data, unsigned int n)
{
   if (sender == this->slider)
   {
      this->sendEvent(this, "color_value_changed", x, y, 
		      button, key, (this->color), 0);      
   }

   // This component does not listen
   return;
}

