#include <iostream>
#include <math.h>

#include <SDL/SDL.h>
#include <GL/glew.h>
#include "vector.hh"
#include "imgcache.hh"
#include "selection.hh"
#include "label.hh"
#include "interface.hh"
#include "input.hh"
#include "container.hh"
#include "groupcontainer.hh"
#include "slider.hh"
#include "colorpicker.hh"
#include "button.hh"
#include "menu.hh"
#include "preview.hh"
#include "shader.hh"
#include "colorpicker.hh"
#include "filechooser.hh"
#include "static.hh"


int main (int argc, char *argv[])
{
   bool showUI = false;
   Uint8 *keystate;
   S3DVector *t0 = new S3DVector(0.0, 1.0);
   S3DVector *t1 = new S3DVector(1.0, 1.0);
   S3DVector *t2 = new S3DVector(1.0, 0.0);
   S3DVector *t3 = new S3DVector(0.0, 0.0);
   S3DVector *v0 = new S3DVector(-1.0, -1.0, 0.0);
   S3DVector *v1 = new S3DVector(1.0, -1.0, 0.0);
   S3DVector *v2 = new S3DVector(1.0, 1.0, 0.0);
   S3DVector *v3 = new S3DVector(-1.0, 1.0, 0.0);
   S3DVector *vt = new S3DVector(3);
   S3DVector *vbn = new S3DVector(3);
   SDL_Surface *screen;
   SDL_Event event;
   const SDL_VideoInfo* info = NULL;
   int width = 700;
   int height = 700;
   int bpp = 0;
   int flags = 0;
   int quit = 0;
   const GLubyte* strm;
   GLint value;
   GLenum err;
   float f = 0; // Test variable
   char text[1000];
   unsigned int i;
   S3DSelection *select;
   S3DLabel *label;
   S3DStatic *staticElement;
   TTF_Font *fnt;
   int cnt = -10000;
   char *str;
   S3DInterface *ui;
   S3DTheme *theme;
   S3DFileChooser *cp0;
   S3DImagesCache *imgc;
   S3DContainer *container0;
   S3DSlider *slider0, *slider1, *slider2;
   S3DGroupContainer *group;
   S3DImage *texture0, *texture1;
   float material[] = { 1.0f, 0.6f, 0.5f, 1.0f };
   float specRefl[] = { 0.8f, 0.8f, 0.8f, 1.0f };
   GLfloat dLight[] = {0.5f, 0.5f, 0.5f , 1.0f};
   GLfloat sLight[] = {1.0f, 1.0f, 1.0f , 1.0f};
   GLfloat pLight[] = {1.0, 1.0, 1.0, 0.0};
   S3DShaderObj *shd;
   float shaderSel = 0;
   int loc, locv1, locv0;
   int x, y;
   bool s = false;
   bool ctrlp = false;
   S3DFileChooser *fc;
   char *texfname0;
   float version;

   str = new char[1000];

   /* ----- SDL init --------------- */
   if(SDL_Init(SDL_INIT_VIDEO) < 0) 
   {
      std::cerr << "Video initialization failed: " << SDL_GetError() << "\n";
      exit(-1);
   }
   
   atexit(SDL_Quit);
	
   info = SDL_GetVideoInfo();
   bpp = info->vfmt->BitsPerPixel;
   std::cerr << bpp << std::endl;
   
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);


   /*	flags = SDL_OPENGL | SDL_FULLSCREEN; */
   flags = SDL_OPENGL; //  | SDL_RESIZABLE;


   /* ----- Setting up the screen surface --------------- */

   screen = SDL_SetVideoMode(width, height, bpp, flags);
   if(screen == 0) 
   {
      std::cerr << "Video mode set failed: " << SDL_GetError() << "\n";
      exit(-1);
   }

   SDL_WM_SetCaption("UI / Shader Test", 0);


   /* ----- Checking for OpenGL 2 --------------- */
   strm = glGetString(GL_VENDOR);
   std::cerr << "Vendor: " << strm << "\n";
   strm = glGetString(GL_RENDERER);
   std::cerr << "Renderer: " << strm << "\n";
   strm = glGetString(GL_VERSION);
   std::cerr << "OpenGL Version: " << strm << "\n";

   version = atof((const char *) strm);

   if (version < 2) 
   {
      std::cerr << "Warning: OpenGL 2 not supported!\n";
   }
   strm = glGetString(GL_VERSION);
   std::cerr << "Detected OpenGL Version >= " << version << "\n";

   strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
   std::cerr << "GLSL Version: " << strm << "\n";


   // Glew init:
   err = glewInit();
   if (GLEW_OK != err)
   {
      /* Problem: glewInit failed, something is seriously wrong. */
      std::cerr << "Error: " << glewGetErrorString(err) << "\n";
      exit (-1);
   }

   std::cerr << "Status: Using GLEW " << glewGetString(GLEW_VERSION) << "\n";


   // UI Test:
   // ---------------------------------------------------------- 
   SDL_ShowCursor(SDL_DISABLE);
   if(TTF_Init() == -1)
      return 1;

   fnt = TTF_OpenFont("../media/default.ttf", 36);
   if(!fnt) 
   {
      std::cerr << "TTF_OpenFont: " << TTF_GetError() << "\n";
   }

   /* ------------------------- */
   imgc = new S3DImagesCache();
   
   glActiveTexture(GL_TEXTURE0);
   imgc->addImage("../media/arrow.png");
   imgc->addImage("../media/hfash.png");
   imgc->addImage("../media/indicator.png");
   imgc->addImage("../media/lbreleased.png");
   imgc->addImage("../media/lbpressed.png");
   imgc->addImage("../media/lbover.png");
   imgc->addImage("../media/rbreleased.png");
   imgc->addImage("../media/rbpressed.png");
   imgc->addImage("../media/rbover.png");
   imgc->addImage("../media/upfolder.png");
   imgc->addImage("../media/folder.png");
   imgc->addImage("../media/file.png");
   imgc->addImage("../media/select.png");
   imgc->addImage("../media/search.png");

   texture0 = new S3DImage();
//   texture0->load("../media/texture0.png");
   texture1 = new S3DImage();
   texture1->load("../media/texture1.png");

   // We need to put the images in the memory of the GPU
   glActiveTexture(GL_TEXTURE0);
   imgc->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_CLAMP, GL_REPLACE);


   theme = new S3DTheme("../media/default.ttf", 20, "../media/default.ttf", 16);
   ui = new S3DInterface(theme, 0, 0, width, height);
   theme->addMouseTexture(imgc->getTexture2D("../media/arrow.png"));


   // INTERFACE
   container0 = new S3DContainer(theme, 400, 100, 0, 0);   

   staticElement = new S3DStatic(theme, 0, 210, 100, 90);
   staticElement->setImage("../media/lamp1.png");
   staticElement->setText("lamp");

   slider0 = new S3DSlider(theme, 0, 150, 200, 50);
   slider0->setTitle("X Angle: ");
   slider0->setMinValue(0);
   slider0->setMaxValue(360);
   slider0->setIncrement(1);
   slider0->setTextures(imgc->getTexture2D("../media/indicator.png"), 
                        imgc->getTexture2D("../media/hfash.png"), 
                        imgc->getTexture2D("../media/lbreleased.png"), 
                        imgc->getTexture2D("../media/lbover.png"), 
                        imgc->getTexture2D("../media/lbpressed.png"), 
                        imgc->getTexture2D("../media/rbreleased.png"), 
                        imgc->getTexture2D("../media/rbover.png"), 
                        imgc->getTexture2D("../media/rbpressed.png"));

   slider1 = new S3DSlider(theme, 0, 75, 200, 50);
   slider1->setTitle("Y Angle: ");
   slider1->setMinValue(0);
   slider1->setMaxValue(360);
   slider1->setIncrement(1);
   slider1->setTextures(imgc->getTexture2D("../media/indicator.png"), 
                        imgc->getTexture2D("../media/hfash.png"), 
                        imgc->getTexture2D("../media/lbreleased.png"), 
                        imgc->getTexture2D("../media/lbover.png"), 
                        imgc->getTexture2D("../media/lbpressed.png"), 
                        imgc->getTexture2D("../media/rbreleased.png"), 
                        imgc->getTexture2D("../media/rbover.png"), 
                        imgc->getTexture2D("../media/rbpressed.png"));

   slider2 = new S3DSlider(theme, 0, 0, 200, 50);
   slider2->setTitle("Z Angle: ");
   slider2->setMinValue(0);
   slider2->setMaxValue(360);
   slider2->setIncrement(1);
   slider2->setTextures(imgc->getTexture2D("../media/indicator.png"), 
                        imgc->getTexture2D("../media/hfash.png"), 
                        imgc->getTexture2D("../media/lbreleased.png"), 
                        imgc->getTexture2D("../media/lbover.png"), 
                        imgc->getTexture2D("../media/lbpressed.png"), 
                        imgc->getTexture2D("../media/rbreleased.png"), 
                        imgc->getTexture2D("../media/rbover.png"), 
                        imgc->getTexture2D("../media/rbpressed.png"));

   fc = new S3DFileChooser(theme, 0, 325, 200, 200);
   fc->setTextures(imgc->getTexture2D("../media/upfolder.png"), 
                   imgc->getTexture2D("../media/folder.png"), 
                   imgc->getTexture2D("../media/file.png"), 
                   imgc->getTexture2D("../media/select.png"), 
                   imgc->getTexture2D("../media/search.png"), 
                   imgc->getTexture2D("../media/indicator.png"), 
                   imgc->getTexture2D("../media/hfash.png"), 
                   imgc->getTexture2D("../media/lbreleased.png"), 
                   imgc->getTexture2D("../media/lbover.png"), 
                   imgc->getTexture2D("../media/lbpressed.png"), 
                   imgc->getTexture2D("../media/rbreleased.png"), 
                   imgc->getTexture2D("../media/rbover.png"),  
                   imgc->getTexture2D("../media/rbpressed.png"));
   fc->changeDir("../media");
   fc->setDefaultFile("texture0.png");
   fc->setTitle("Select a file:");
   texfname0 = fc->getFile();
   texture0->load(texfname0);
   texture0->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_REPEAT, GL_MODULATE);

   container0->add(fc);
   container0->add(staticElement);
   container0->add(slider0);
   container0->add(slider1);
   container0->add(slider2);

   ui->add(container0);


   // Set the textures:

   texture1->setTexture2D(GL_TEXTURE1, GL_NEAREST, GL_REPEAT, GL_MODULATE);
   glActiveTexture(GL_TEXTURE0);

   // Load shaders:
   shd = new S3DShaderObj();
   shd->loadPrograms("../shaders/bump.vert", "../shaders/bump.frag");
   
   /* ----- Event cycle --------------- */
   quit = 0;
   while (!quit) 
   {
      // move the light:
      if (!ctrlp)
      {
         if (!s)
            pLight[1]+=0.001;
         else
            pLight[1]-=0.001;
      }

      if (pLight[1] > 2)
	 s = true;
      else
	 if (pLight[1] < -2)
	    s = false;

/*
      std::cout << pLight[0] << ", " << pLight[1] << ", " << pLight[2] << "\n";
*/
      glClearColor(0.0, 0.0, 0.0, 0.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      glDisable(GL_CULL_FACE);
      glEnable(GL_DEPTH_TEST);
      glDepthMask(true); // Enable the z buffer 

      // Draw something:
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluPerspective(45, 1.33, 1.0, 60.0);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      
      glDisable(GL_TEXTURE_1D);
      glDisable(GL_TEXTURE_3D);
      glEnable(GL_TEXTURE_2D);
      
      glFrontFace(GL_CCW);


      // lighting
      glEnable(GL_LIGHTING);
      glEnable(GL_LIGHT0);

      glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

      // material
      glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, material);
      glMaterialfv(GL_FRONT, GL_SPECULAR, specRefl);
      glMateriali(GL_FRONT, GL_SHININESS, 60);


      // textures
      if (shaderSel == 1)
      {
         glActiveTexture(GL_TEXTURE1);
         glBindTexture(GL_TEXTURE_2D, texture1->getTexture2D());
      }
      
      if (shaderSel == 0)
      {
         // empty the texture if there is no shader
         glActiveTexture(GL_TEXTURE1);
         glBindTexture(GL_TEXTURE_2D, 0);
      }

      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, texture0->getTexture2D());
	
	

      if (shaderSel == 1)
      {

	 // shader
	 shd->useProgram();
	
	 loc = glGetUniformLocationARB(shd->getProgram(), "DecalTex");
	 glUniform1i(loc, 0);
	
	 loc = glGetUniformLocationARB(shd->getProgram(), "BumpTex");
	 glUniform1i(loc, 1);

      }
      
      if (shaderSel == 0)
	 shd->doNotUseProgram();

      glDisable(GL_COLOR_MATERIAL);

      //light
      glLightfv(GL_LIGHT0, GL_DIFFUSE, dLight);
      glLightfv(GL_LIGHT0, GL_SPECULAR, sLight);
      glLightfv(GL_LIGHT0, GL_POSITION, pLight);

      glActiveTexture(GL_TEXTURE0);
      glPushMatrix();
      {
         
	 glTranslatef (0, 0, -3);
	 glRotatef (slider0->getValue(), 1.0, 0.0, 0.0);
	 glRotatef (slider1->getValue(), 0.0, 1.0, 0.0);
	 glRotatef (slider2->getValue(), 0.0, 0.0, 1.0);

	 if (shaderSel == 1)
	 {
	    locv0 = glGetAttribLocation(shd->getProgram(), "tangent");
	    vt->tangent(v0, v1, t0, t1);
	    locv1 = glGetAttribLocation(shd->getProgram(), "binormal");
	    vbn->binormal(v0, v1, t0, t1);
	 }
	 
	 glBegin (GL_POLYGON);
	 {
	    glColor3f (1, 1, 1);

	    glNormal3f(0, 0, 1);

	    if (shaderSel == 1)
	    {
	       glVertexAttrib3f(locv0, vt->X(), vt->Y(), vt->Z());
	       glVertexAttrib3f(locv1, vbn->X(), vbn->Y(), vbn->Z());
	    }
	    glTexCoord2dv (t0->getRaw());
	    glVertex3dv (v0->getRaw());

	    
	    if (shaderSel == 1)
	    {
	       glVertexAttrib3f(locv0, vt->X(), vt->Y(), vt->Z());
	       glVertexAttrib3f(locv1, vbn->X(), vbn->Y(), vbn->Z());
	    }
	    glTexCoord2dv (t1->getRaw());
	    glVertex3dv (v1->getRaw());
	    
	    if (shaderSel == 1)
	    {
	       glVertexAttrib3f(locv0, vt->X(), vt->Y(), vt->Z());
	       glVertexAttrib3f(locv1, vbn->X(), vbn->Y(), vbn->Z());
	    }
	    glTexCoord2dv (t2->getRaw());
	    glVertex3dv (v2->getRaw());
	    
	    if (shaderSel == 1)
	    {
	       glVertexAttrib3f(locv0, vt->X(), vt->Y(), vt->Z());
	       glVertexAttrib3f(locv1, vbn->X(), vbn->Y(), vbn->Z());
	    }
	    glTexCoord2dv (t3->getRaw());
	    glVertex3dv (v3->getRaw());
	 }
	 glEnd();
      }
      glPopMatrix();

      shd->doNotUseProgram();

      glActiveTexture(GL_TEXTURE1);
      glBindTexture(GL_TEXTURE_2D, 0);
      glDisable(GL_TEXTURE_3D);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_TEXTURE_1D);
      glActiveTexture(GL_TEXTURE0);

      glDisable(GL_TEXTURE_2D);
      glDisable(GL_LIGHTING);
      glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
      /*
	str[0] = '\0';
	sprintf (str, "Number: %d", cnt);
	cnt ++;
	if (cnt > 10000)
	cnt = -10000;
	label->setText(str);
      */
      // ----------------------

      //      label->draw();
      //      select->draw();

      // ----------------------

      while (SDL_PollEvent(&event)) 
      {
	 switch (event.type) 
	 {
	    // If you touch the close button:
	    case SDL_QUIT: {
	       quit = 1;
	    } break;

            case SDL_MOUSEMOTION: {
               if (!ctrlp)
               {
                  x = event.motion.xrel; 
                  y = event.motion.yrel;
               }
               else
               {
                  pLight[0] += (event.motion.xrel - x) / 700.0;
                  pLight[1] += (y - event.motion.xrel) / 700.0;
                  std::cerr << "Light = " << pLight[0] 
                            << ", " << pLight[1]
                            << ", " << pLight[2] << "\n";
               }
            } break;

	    case SDL_KEYUP: {
               ctrlp = false;
            } break;

	    case SDL_KEYDOWN: {
	       keystate = SDL_GetKeyState(NULL);

	       if (keystate[SDLK_LCTRL]) // move light
	       {
		  ctrlp = true;
               }

               if (keystate[SDLK_r]) // reset
               {
                  pLight[0] = 1.0;
                  pLight[1] = 1.0;
               }

	       if (keystate[SDLK_SPACE]) // change shader
	       {
		  shaderSel ++;
		  if (shaderSel > 1)
		     shaderSel = 0;
	       }

	       if (keystate[SDLK_i]) // show interface
	       {
		  showUI = !showUI;
	       }

	    } break;

	       // If the screen is resized:
	    case SDL_VIDEORESIZE: {
	       screen = SDL_SetVideoMode(event.resize.w, 
	       event.resize.h, 
	       bpp, flags); 
	       if(screen == 0)
	       {
		  std::cerr << "Video resize failed: " << SDL_GetError() 
			    << "\n";
		  exit (-1);
	       }
	       else
	       {
		  // Resize
		  width = event.resize.w;
		  height = event.resize.h;

		  // When resize, the viewport must be updated:

	       }

	    } break;

	    default : {
	    } break;	 
	 }

	 // Read events
	 if (showUI)
	    ui->readEventsSDL(&event);

      }
      

      // Render the UI

      if (fc->getFile() != 0)
	 if (strcmp(fc->getFile(), texfname0))
	 {
	    delete [] texfname0;
	    texfname0 = fc->getFile();
	    texture0->load(texfname0);
	    texture0->setTexture2D(GL_TEXTURE0, GL_NEAREST, 
				   GL_REPEAT, GL_MODULATE);
	 }

      if (showUI)
	 ui->draw();
      else
	 SDL_GL_SwapBuffers();

      SDL_Delay(1);
   }
  
   SDL_Quit();

   return 0;
}


