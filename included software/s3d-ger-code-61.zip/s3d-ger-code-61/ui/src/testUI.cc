#include <iostream>
#include <math.h>

#include <SDL/SDL.h>
#include <GL/glew.h>
#include "imgcache.hh"
#include "selection.hh"
#include "label.hh"
#include "interface.hh"
#include "input.hh"
#include "container.hh"
#include "groupcontainer.hh"
#include "slider.hh"
#include "colorpicker.hh"
#include "button.hh"
#include "menu.hh"
#include "preview.hh"

int main (int argc, char *argv[])
{
   SDL_Surface *screen;
   SDL_Event event;
   const SDL_VideoInfo* info = NULL;
   int width = 700;
   int height = 700;
   int bpp = 0;
   int flags = 0;
   int quit = 0;
   const GLubyte* strm;
   GLint value;
   GLenum err;
   float f = 0; // Test variable
   char text[1000];
   unsigned int i;
   S3DSelection *select;
   S3DLabel *label;
   TTF_Font *fnt;
   int cnt = -10000;
   char *str;
   S3DInterface *ui;
   S3DTheme *theme;
   S3DInput *input0, *input1;
   S3DContainer *container0;
   S3DContainer *container1;
   S3DContainer *container2;
   S3DContainer *container3;
   S3DButton *bt0;
   S3DButton *btm[10];
   S3DGroupContainer *group;
   S3DSlider *slider0;
   S3DColorPicker *cp0;
   S3DImagesCache *imgc;
   S3DMenu *menu;
   S3DPreview *prev0, *prev1, *prev2, *prev3, *prev4;
   float version;

   str = new char[1000];

   /* ----- SDL init --------------- */
   if(SDL_Init(SDL_INIT_VIDEO) < 0) 
   {
      std::cerr << "Video initialization failed: " << SDL_GetError() << "\n";
      exit(-1);
   }
   
   atexit(SDL_Quit);
	
   info = SDL_GetVideoInfo();
   bpp = info->vfmt->BitsPerPixel;
   std::cerr << bpp << std::endl;
   
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);


/*	flags = SDL_OPENGL | SDL_FULLSCREEN; */
   flags = SDL_OPENGL; //  | SDL_RESIZABLE;


/* ----- Setting up the screen surface --------------- */

   screen = SDL_SetVideoMode(width, height, bpp, flags);
   if(screen == 0) 
   {
      std::cerr << "Video mode set failed: " << SDL_GetError() << "\n";
      exit(-1);
   }

   SDL_WM_SetCaption("UI test", 0);


/* ----- Checking for OpenGL 2 --------------- */
   strm = glGetString(GL_VENDOR);
   std::cerr << "Vendor: " << strm << "\n";
   strm = glGetString(GL_RENDERER);
   std::cerr << "Renderer: " << strm << "\n";
   strm = glGetString(GL_VERSION);
   std::cerr << "OpenGL Version: " << strm << "\n";

   version = atof((const char *) strm);

   if (version < 2) 
   {
      std::cerr << "Warning: OpenGL 2 not supported!\n";
   }
   strm = glGetString(GL_VERSION);
   std::cerr << "Detected OpenGL Version >= " << version << "\n";

   strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
   std::cerr << "GLSL Version: " << strm << "\n";


   // Glew init:
   err = glewInit();
   if (GLEW_OK != err)
   {
      /* Problem: glewInit failed, something is seriously wrong. */
      std::cerr << "Error: " << glewGetErrorString(err) << "\n";
      exit (-1);
   }

   std::cerr << "Status: Using GLEW " << glewGetString(GLEW_VERSION) << "\n";


   // UI Test:
   // ---------------------------------------------------------- 
   SDL_ShowCursor(SDL_DISABLE);
   if(TTF_Init() == -1)
      return 1;

   fnt = TTF_OpenFont("../media/default.ttf", 36);
   if(!fnt) 
   {
      std::cerr << "TTF_OpenFont: " << TTF_GetError() << "\n";
   }

   /* ------------------------- */
   imgc = new S3DImagesCache();

   imgc->addImage("../media/arrow.png");
   imgc->addImage("../media/lamp.png");
   imgc->addImage("../media/lamp_g.png");
   imgc->addImage("../media/lamp_p.png");
   imgc->addImage("../media/lamp1.png");
   imgc->addImage("../media/lamp_g1.png");

   // We need to put the images in the memory of the GPU
   imgc->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_CLAMP, GL_REPLACE);

   theme = new S3DTheme("../media/default.ttf", 20, "../media/default.ttf", 16);
   ui = new S3DInterface(theme, 0, 0, width, height);
   group = new S3DGroupContainer(theme);
   theme->addMouseTexture(imgc->getTexture2D("../media/arrow.png"));
   
   menu = new S3DMenu(theme, 10, 10, 0, 0);
   menu->setProperty(S3DComponent::NOZOOM, 1);
   menu->setProperty(S3DComponent::NOMOVE, 1);

   prev0 = new S3DPreview(theme, 0, 0, 100, 100);
   prev1 = new S3DPreview(theme, 100, 0, 100, 100);
   prev2 = new S3DPreview(theme, 200, 0, 100, 100);
   prev3 = new S3DPreview(theme, 300, 0, 100, 100);
   prev4 = new S3DPreview(theme, 400, 0, 100, 100);

   prev0->addDirection ("Test", 1, 1, 1);
   prev0->addDirection ("Dir", -1, 1, 1);
   prev0->addPosition ("Pos", 0, 0, 0);

   container2 = new S3DContainer(theme, 400, 300, 0, 0);
   container2->addSlot(S3DContainer::SLOT_PARAM_OUTPUT, "test1", 
		       S3DContainer::SLOT_COLOR);
   container2->setProperty(S3DComponent::NOZOOM, 1);
   container2->setProperty(S3DComponent::NOMOVE, 1);

   container1 = new S3DContainer(theme, 400, 400, 0, 0);
   container1->addSlot(S3DContainer::SLOT_PARAM_OUTPUT, "test2", 
		      S3DContainer::SLOT_STRING);

   container3 = new S3DContainer(theme, 400, 400, 0, 0);
   container3->addSlot(S3DContainer::SLOT_PARAM_OUTPUT, "test3", 
		      S3DContainer::SLOT_BOOL);

   container0 = new S3DContainer(theme, 200, 100, 0, 0);

   container0->addSlot(S3DContainer::SLOT_VOLUM_INPUT, "test1", 
		      S3DContainer::SLOT_VOLUME);
   container0->addSlot(S3DContainer::SLOT_VOLUM_INPUT, "test1", 
		      S3DContainer::SLOT_VOLUME);
   container0->addSlot(S3DContainer::SLOT_VOLUM_OUTPUT, "test2", 
		      S3DContainer::SLOT_VOLUME);
   container0->addSlot(S3DContainer::SLOT_VOLUM_OUTPUT, "test2", 
		      S3DContainer::SLOT_VOLUME);
   container0->addSlot(S3DContainer::SLOT_PARAM_INPUT, "test3", 
		      S3DContainer::SLOT_STRING);
   container0->addSlot(S3DContainer::SLOT_PARAM_INPUT, "test3", 
		      S3DContainer::SLOT_COLOR);
   container0->addSlot(S3DContainer::SLOT_PARAM_INPUT, "test33", 
		      S3DContainer::SLOT_BOOL);
   container0->addSlot(S3DContainer::SLOT_PARAM_INPUT, "test34", 
		      S3DContainer::SLOT_BOOL);
   container0->addSlot(S3DContainer::SLOT_PARAM_OUTPUT, "test4", 
		      S3DContainer::SLOT_FLOAT);
   container0->addSlot(S3DContainer::SLOT_PARAM_OUTPUT, "test4", 
		      S3DContainer::SLOT_STRING);
   bt0 = new S3DButton(theme, 0, 0, 64, 64);
   bt0->setIDPressed(imgc->getTexture2D("../media/lamp_p.png"));
   bt0->setIDReleased(imgc->getTexture2D("../media/lamp_g.png"));
   bt0->setIDMouseOver(imgc->getTexture2D("../media/lamp.png"));
   bt0->setIDMouseOverOFF(imgc->getTexture2D("../media/lamp1.png"));
   bt0->setIDReleasedOFF(imgc->getTexture2D("../media/lamp_g1.png"));
   bt0->setTristate(true);
   
   for (i = 0; i < 10; i ++)
   {
      btm[i] = new S3DButton(theme, 0, 0, 64, 64);
      btm[i]->setIDDragged(imgc->getTexture2D("../media/lamp1.png"));
      btm[i]->setIDPressed(imgc->getTexture2D("../media/lamp.png"));
      btm[i]->setIDReleased(imgc->getTexture2D("../media/lamp_g1.png"));
      btm[i]->setIDMouseOver(imgc->getTexture2D("../media/lamp.png"));

      btm[i]->setDraggable(true);

      menu->add(btm[i]);
   }

   cp0 = new S3DColorPicker(theme, 0, 0, 250, 100);
   input0 = new S3DInput(theme, 0, 0, 0, 0);
   input0->setText ("Text:", "something");
   input1 = new S3DInput(theme, 0, 0, 0, 0);
   input1->setText (0, "change me!");
   slider0 = new S3DSlider(theme, 0, 0, 200, 50);


//   container0->add(slider0);
   container0->add(prev0);
   container0->add(prev1);
   container0->add(prev2);
   container0->add(prev3);
   container0->add(prev4);

 // Avoid garbage because it doesn't listen 
   prev0->removeListener(container0);
   prev1->removeListener(container0);
   prev2->removeListener(container0);
   prev3->removeListener(container0);
   prev4->removeListener(container0);
//   container0->add(input0);
   container1->add(input1);
   container2->add(cp0);
   container3->add(bt0);
   
   container1->setBGTheme(S3DTheme::BGINPUTTEXTCOLOR);
   container0->setBGTheme(S3DTheme::BGSLIDERCOLOR);
   container2->setBGTheme(S3DTheme::BGCOLORPICKERCOLOR);
   container3->setBGTheme(S3DTheme::BGCHECKBOXCOLOR);


//   ui->add(container0); 
//   ui->add(container1); 

   group->add(container0); 
   group->add(container1); 
   group->add(container2); 
   group->add(container3); 
   group->add(menu);

   ui->add(group);




//   ui->add(container);


   /* ------------------------- */
   label = new S3DLabel(fnt, 0.005);
   label->setPos(-0.5, 0, -3);
   label->setText("UI Test!_");

   /* ------------------------- */
   select = new S3DSelection();
   select->setPos(0, 0, -1);
   select->setSize(0.3, 0.3);


/* ----- Event cycle --------------- */
   quit = 0;
   while (!quit) 
   {
      glClearColor(0.99, 0.99, 0.99, 0.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      glDisable(GL_CULL_FACE);
      glEnable(GL_DEPTH_TEST);
      glDepthMask(true); // Enable the z buffer 

      // Draw something:
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluPerspective(45, 1.33, 1.0, 60.0);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();
      
      glDisable(GL_TEXTURE_1D);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_TEXTURE_3D);
      glPushMatrix();
      {

	 f += 0.05;
	 if (f > 360)
	    f = 0;
	 
	 glTranslatef (0, 0, -4);
	 glRotatef (f, 1.0, 1.0, 1.0);
	 
	 glBegin (GL_POLYGON);
	 glColor3f (1, 1, 0);
	 glTexCoord2f (0.0, 0.0);
	 glVertex3f (-1.0, -1.0, 0.0);
	 glTexCoord2f (1.0, 0.0);
	 glVertex3f ( 1.0, -1.0, 0.0);
	 glTexCoord2f (1.0, 1.0);
	 glVertex3f ( 1.0,  1.0, 0.0);
	 glTexCoord2f (0.0, 1.0);
	 glVertex3f (-1.0,  1.0, 0.0);
	 glEnd();
      }
      glPopMatrix();
/*
      str[0] = '\0';
      sprintf (str, "Number: %d", cnt);
      cnt ++;
      if (cnt > 10000)
	 cnt = -10000;
      label->setText(str);
*/
      // ----------------------

//      label->draw();
//      select->draw();

      // ----------------------

      while (SDL_PollEvent(&event)) 
      {
	 switch (event.type) 
	 {
	    // If you touch the close button:
	    case SDL_QUIT: {
	       quit = 1;
	    } break;
	    
	    // If the screen is resized:
	    case SDL_VIDEORESIZE: {
	       screen = SDL_SetVideoMode(event.resize.w, 
					 event.resize.h, 
					 bpp, flags); 
	       if(screen == 0)
	       {
		  std::cerr << "Video resize failed: " << SDL_GetError() 
			    << "\n";
		  exit (-1);
	       }
	       else
	       {
		  // Resize
		  width = event.resize.w;
		  height = event.resize.h;

		  // When resize, the viewport must be updated:

	       }

	    } break;

	    default : {
	       // Read events
	       ui->readEventsSDL(&event);
	    } break;
	 
	 }
      }
      

      // Render the UI
      //SDL_GL_SwapBuffers();
      ui->draw();

      SDL_Delay(1);
   }
  
   SDL_Quit();

   return 0;
}
