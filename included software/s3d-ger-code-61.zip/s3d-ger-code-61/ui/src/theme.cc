#include "theme.hh"


// --------------------------------------------------
S3DTheme::S3DTheme(void)
{
   this->setFont(S3DTheme::LABELFONT, "../media/default.ttf", 36);
   this->setFont(S3DTheme::INPUTTEXTFONT, "../media/default.ttf", 36);

   this->mousetex = 0;

   this->init();
   return;
}


// --------------------------------------------------
S3DTheme::S3DTheme(const char *label_font, unsigned int size0, 
		   const char *input_font, unsigned int size1)
{
   this->setFont(S3DTheme::LABELFONT, label_font, size0);
   this->setFont(S3DTheme::INPUTTEXTFONT, input_font, size1);

   this->init();
   return;
}


// --------------------------------------------------
S3DTheme::~S3DTheme()
{
   if (this->labelFont != 0)
      TTF_CloseFont(this->labelFont);

   if (this->inputFont != 0)
      TTF_CloseFont(this->inputFont);
}


// --------------------------------------------------
void S3DTheme::setColor(unsigned int flag, float r, float g, float b, float a)
{
   switch(flag)
   {
      case FGTEXTCOLOR: {
	 this->fgTextColor[0] = r;
	 this->fgTextColor[1] = g;
	 this->fgTextColor[2] = b;
	 this->fgTextColor[3] = a;
      } break;

      case FRAMECOLOR: {
	 this->fgFrameColor[0] = r;
	 this->fgFrameColor[1] = g;
	 this->fgFrameColor[2] = b;
	 this->fgFrameColor[3] = a;
      } break;

      case FGINPUTTEXTCOLOR: {
	 this->fgInputColor[0] = r;
	 this->fgInputColor[1] = g;
	 this->fgInputColor[2] = b;
	 this->fgInputColor[3] = a;
      } break;

      case FGSELECTEDINPUTTEXTCOLOR: {
	 this->fgInputSelectedColor[0] = r;
	 this->fgInputSelectedColor[1] = g;
	 this->fgInputSelectedColor[2] = b;
	 this->fgInputSelectedColor[3] = a;
      } break;

      case BGINPUTTEXTCOLOR: {
	 this->bgInputColor[0] = r;
	 this->bgInputColor[1] = g;
	 this->bgInputColor[2] = b;
	 this->bgInputColor[3] = a;
      } break;

      case FGCHECKBOXCOLOR: {
	 this->fgCheckBoxColor[0] = r;
	 this->fgCheckBoxColor[1] = g;
	 this->fgCheckBoxColor[2] = b;
	 this->fgCheckBoxColor[3] = a;
      } break;

      case BGCHECKBOXCOLOR: {
	 this->bgCheckBoxColor[0] = r;
	 this->bgCheckBoxColor[1] = g;
	 this->bgCheckBoxColor[2] = b;
	 this->bgCheckBoxColor[3] = a;
      } break;

      case FGCOLORPICKERCOLOR :{
	 this->fgCPickerColor[0] = r;
	 this->fgCPickerColor[1] = g;
	 this->fgCPickerColor[2] = b;
	 this->fgCPickerColor[3] = a;
      } break;

      case BGCOLORPICKERCOLOR :{
	 this->bgCPickerColor[0] = r;
	 this->bgCPickerColor[1] = g;
	 this->bgCPickerColor[2] = b;
	 this->bgCPickerColor[3] = a;
      } break;

      case FGSLIDERCOLOR :{
	 this->fgSliderColor[0] = r;
	 this->fgSliderColor[1] = g;
	 this->fgSliderColor[2] = b;
	 this->fgSliderColor[3] = a;
      } break;

      case BGSLIDERCOLOR :{
	 this->bgSliderColor[0] = r;
	 this->bgSliderColor[1] = g;
	 this->bgSliderColor[2] = b;
	 this->bgSliderColor[3] = a;
      } break;

      case BGVOLUMECOLOR :{
	 this->bgVolumeColor[0] = r;
	 this->bgVolumeColor[1] = g;
	 this->bgVolumeColor[2] = b;
	 this->bgVolumeColor[3] = a;
      } break;

      case BGGMODCOLOR :{
	 this->bgGModColor[0] = r;
	 this->bgGModColor[1] = g;
	 this->bgGModColor[2] = b;
	 this->bgGModColor[3] = a;
      } break;

      case BGMENUCOLOR :{
	 this->bgMenuColor[0] = r;
	 this->bgMenuColor[1] = g;
	 this->bgMenuColor[2] = b;
	 this->bgMenuColor[3] = a;
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist! "
		   << "in S3DTheme::setColor" 
		   << std::endl;
      } break;
   }   
}


// --------------------------------------------------
void S3DTheme::setValue(unsigned int flag, float v)
{
   switch(flag)
    {
      case SPACEVALUE: {
	 this->space = v;
      } break;

      case CORNERVALUE: {
	 this->corner = v;
      } break;

      case FRAMEWIDTHVALUE: {
	 this->framewidth = v;
      } break;

      case FONTSIZEVALUE: {
	 this->fontsize = v;
      } break;

      case SHADOWSIZEVALUE: {
	 this->shadowsizevalue = v;
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist!"
		   << " in S3DTheme::setValue" 
		   << std::endl;
      } break;
   }
}


// --------------------------------------------------
void S3DTheme::setFont(unsigned int flag, const char *file, unsigned int size)
{
   switch(flag)
    {
      case LABELFONT: {
	 this->labelFont = TTF_OpenFont(file, size);
	 if(this->labelFont == 0) 
	 {
	    std::cerr << "TTF_OpenFont: " << TTF_GetError() << "\n";
	 }
      } break;

      case INPUTTEXTFONT: {
	 this->inputFont = TTF_OpenFont(file, size);
	 if(this->inputFont == 0) 
	 {
	    std::cerr << "TTF_OpenFont: " << TTF_GetError() << "\n";
	 }
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist! in S3DTheme::setFont" 
		   << std::endl;
      } break;
   }
}


// --------------------------------------------------
void S3DTheme::setFont(unsigned int flag, TTF_Font *font)
{
   switch(flag)
   {
      case LABELFONT: {
	 this->labelFont = font;
      } break;

      case INPUTTEXTFONT: {
	 this->inputFont = font;
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist! in S3DTheme::setFont" 
		   << std::endl;
      } break;
   }
}


// --------------------------------------------------
TTF_Font *S3DTheme::getFont(unsigned int flag)
{
   switch(flag)
   {
      case LABELFONT: {
	 return this->labelFont;
      } break;

      case INPUTTEXTFONT: {
	 return this->inputFont;
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist! in S3DTheme::getFont" 
		   << std::endl;
      } break;
   }

   return 0;
}

// --------------------------------------------------
float S3DTheme::getValue(unsigned int flag)
{
   switch(flag)
   {
      case SPACEVALUE: {
	 return this->space;
      } break;
	 
      case CORNERVALUE: {
	 return this->corner;
      } break;
	 
      case FRAMEWIDTHVALUE: {
	 return this->framewidth;
      } break;
	 
      case FONTSIZEVALUE: {
	 return this->fontsize;
      } break;
	 
      case SHADOWSIZEVALUE: {
	 return this->shadowsizevalue;
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist!"
		   << " in S3DTheme::getValue" 
		   << std::endl;
      } break;
   }

   return 0;
}

// --------------------------------------------------
float S3DTheme::getColor(unsigned int flag, unsigned int channel)
{
   switch(flag)
   {
      case FGTEXTCOLOR: {
	 return this->fgTextColor[channel];
      } break;

      case FRAMECOLOR: {
	 return this->fgFrameColor[channel];
      } break;

      case FGINPUTTEXTCOLOR: {
	 return this->fgInputColor[channel];
      } break;

      case FGSELECTEDINPUTTEXTCOLOR: {
	 return this->fgInputSelectedColor[channel];
      } break;

      case BGINPUTTEXTCOLOR: {
	 return this->bgInputColor[channel];
      } break;

      case FGCHECKBOXCOLOR: {
	 return this->fgCheckBoxColor[channel];
      } break;

      case BGCHECKBOXCOLOR: {
	 return this->bgCheckBoxColor[channel];
      } break;

      case FGCOLORPICKERCOLOR :{
	 return this->fgCPickerColor[channel];
      } break;

      case BGCOLORPICKERCOLOR :{
	 return this->bgCPickerColor[channel];
      } break;

      case FGSLIDERCOLOR :{
	 return this->fgSliderColor[channel];
      } break;

      case BGSLIDERCOLOR :{
	 return this->bgSliderColor[channel];
      } break;

      case BGVOLUMECOLOR :{
	 return this->bgVolumeColor[channel];
      } break;

      case BGGMODCOLOR :{
	 return this->bgGModColor[channel];
      } break;

      case BGMENUCOLOR :{
	 return this->bgMenuColor[channel];
      } break;

      default: {
	 std::cerr << "Warning: That flag does not exist! "
		   << "in S3DTheme::getColor" 
		   << std::endl;
      } break;
   }   

   return 0;
}


// --------------------------------------------------
void S3DTheme::init(void)
{
   this->space = 5;
   this->corner = 7;
   this->framewidth = 0.5;
   this->shadowsizevalue = 10;

   this->setColor(FGTEXTCOLOR, 0.0, 0.0, 0.0, 1.0);
   this->setColor(FRAMECOLOR, 0.0, 0.0, 0.0, 1.0);

   this->setColor(FGINPUTTEXTCOLOR, 0.11, 0.13, 0.14, 1.0);
   this->setColor(FGSELECTEDINPUTTEXTCOLOR, 0.22, 0.27, 0.31, 1.0);

   this->setColor(FGSLIDERCOLOR, 0.67, 0.83, 0.0, 1.0);
   this->setColor(FGCHECKBOXCOLOR, 1.0, 0.33, 0.33, 1.0);
   this->setColor(FGCOLORPICKERCOLOR, 0.50, 0.50, 0.0, 1.0);

   this->setColor(BGSLIDERCOLOR, 0.46, 1.0, 0.66, 0.65);
   this->setColor(BGCHECKBOXCOLOR, 0.89, 0.76, 0.76, 0.65);
   this->setColor(BGCOLORPICKERCOLOR, 0.78, 0.89, 0.95, 0.65);
   this->setColor(BGGMODCOLOR, 0.83, 1.0, 0.83, 0.65);
   this->setColor(BGMENUCOLOR, 1.0, 1.0, 1.0, 0.35);
   this->setColor(BGINPUTTEXTCOLOR, 0.79, 0.76, 0.87, 0.65);
   this->setColor(BGVOLUMECOLOR, 0.96, 0.86, 0.63, 0.65);
}


// --------------------------------------------------
void S3DTheme::setMouse (int i)
{
   if ((i < 0) || (i >= this->lmouse.size()))
      this->mousetex = 0;
   else
      this->mousetex = this->lmouse[i];
}


// --------------------------------------------------
void S3DTheme::addMouseTexture (GLuint i)
{
   this->lmouse.push_back(i);
}


// --------------------------------------------------
GLuint S3DTheme::getMouse (int i)
{
   if (i < 0)
      return 0;
   if (i >= this->lmouse.size())
      return 0;

   this->lmouse[i];
}


// --------------------------------------------------
GLuint S3DTheme::getMouse (void)
{
   return this->mousetex;
}
