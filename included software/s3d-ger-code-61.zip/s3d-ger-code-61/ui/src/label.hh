#ifndef __LABEL__
#define __LABEL__

#include <iostream>
#include <list>
#include <vector>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <GL/glew.h>
#include "image.hh"


/** @class  S3DLabel label.hh
 *  @author Germ�n Arroyo
 *  @date   2007
 *  @brief  This class is a component to show very simple text
 *
 *  @bug    No bugs detected yet
 */

class S3DLabel {
   public:

      /// Align to the left
      static const unsigned int LEFT               = 0;

      /// Align to the center
      static const unsigned int CENTER             = 1;

      /// Align to the right
      static const unsigned int RIGHT              = 2;

      /**
      * @pre f must be a valid font
      * @param[in] f The font
      * @param[in] psize The size of a point
      * @post Constructor. Inizialite the empty component.
      */
      S3DLabel(TTF_Font *f, float psize);

      /** @post Destructor. Memory is freed here.
       */
      ~S3DLabel();

      /**
       * @post Render the component if it is visible
       */
      void draw (void);

      /**
       * @post The text of the component
       * @warning The returned pointer is not a copy. Do not free it.
       */
      const char *getText (void);

      /**
       * @pre text must be not 0
       * @post Change the text of the component
       * @param[in] text The text
       */
      void setText (const char *text);

      /**
       * @post Change the aligment of the text
       * @param[in] flag The type of alignment
       */
      void setAlignment (unsigned int flag);

      /**
       * @post Change the font of the text
       * @param[in] font The font of the text
       * @warning  font is never freed by this object
       */
      void setFont (TTF_Font *font);

      /**
       * @post Change the color of the text
       * @param[in] r The red component (between 0, and 1)
       * @param[in] g The green component (between 0, and 1)
       * @param[in] b The blue component (between 0, and 1)
       * @param[in] a The alpha channel (between 0, and 1)
       */
      void setColor (float r, float g, float b, float a);

      /**
       * @post Change the color of the text
       * @param[in] c The color in SDL format
       */
      void setColor (SDL_Color c);

      /**
       * @post Change the position of the text
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       */
      void setPos (float x, float y, float z);

      /**
       * @post The width of the label in points
       */
      float getWidth (void);

      /**
       * @post The height of the label in points
       */
      float getHeight (void);


   protected:
      /**
       * @post Update the texture of the text
       */
      void updateTexture (void);


   private:
      char *ltext; /// The text
      GLuint id; /// Id of the texture
      TTF_Font *fnt; /// Inner font
      unsigned int align; /// Alignment of the text
      SDL_Color color; /// The color of the font
      float alpha;
      float x, y, z; /// Position of the component
      float psize; /// The size of a point
};


#endif

