#ifndef __COMPONENT__
#define __COMPONENT__

#include <GL/glew.h>
#include <fstream>
#include <vector>
#include "vector.hh"
#include "image.hh"
#include "primitive3d.hh"
#include "listener.hh"

/** @class   S3DComponent component.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class define a component in a User Interface
 *
 *  @bug     No bugs detected yet
 */

class S3DComponent : public S3DListener {
   public:

      /** Properties of the component (by default everything is 0):
	  These flags are used to comunicate the component with the 
	  manager or the group scheme component, so they can be ignored

	  Use custom flags from number 100
      **/

      /// A property of the component defined by the user (by default it is 0)
      static const unsigned int PROPERTY0        = 0;

      /// A property of the component defined by the user (by default it is 0)
      static const unsigned int PROPERTY1        = 1;

      /// A property of the component defined by the user (by default it is 0)
      static const unsigned int PROPERTY2        = 2;

      /// A property of the component defined by the user (by default it is 0)
      static const unsigned int PROPERTY3        = 3;

      /// A property of the component defined by the user (by default it is 0)
      static const unsigned int PROPERTY4        = 4;

      /// The component is hided
      static const unsigned int HIDED            = 5;
      
      /// The component is selected
      static const unsigned int SELECTED         = 6;
      
      /// The component is affected by zoom if it is 0
      static const unsigned int NOZOOM           = 7;

      /// The component is affected by movement if it is 0
      static const unsigned int NOMOVE           = 8;

      /// The component is selectable if it is 0
      static const unsigned int NOSELECTABLE     = 9;

      /// The component cannot be deleted if it is distinct of 0
      static const unsigned int PERMANENT        = 10;

      /// The component do not show border if it is distinct of 0
      static const unsigned int NOBORDER         = 11;

      /// The component do not show the shadow if it is distinct of 0
      static const unsigned int NOSHADOW         = 12;

      /// The component (only containers) is static and cannot be moved
      static const unsigned int STATIC           = 13;

      /// The component do not have rounded corners if active
      static const unsigned int NOROUNDCORNERS   = 14;

      /// The containers do not show the background
      static const unsigned int HIDEDBACKGROUND  = 15;

      /// The component is selectable if it is 0
      static const unsigned int UNDEFINED        = 100;


      /// Event: Do nothing
      static const unsigned int NONE             = 0x0000;

      /// Event: Do all things
      static const unsigned int ALL              = 0xFFFF;

      /// Event: Mouse clicked
      static const unsigned int MOUSE_DOWN       = 0x0001;

      /// Event: Mouse released
      static const unsigned int MOUSE_UP         = 0x0002;

      /// Event: Key pressed
      static const unsigned int KEY_DOWN         = 0x0004;

      /// Event: Mouse moved
      static const unsigned int MOUSE_MOTION     = 0x0008;


      /// Component: abstract component
      static const unsigned int ABSTRACT         = 0x00;

      /// Component: text input
      static const unsigned int TEXTINPUT        = 0x01;

      /// Component: slide bar
      static const unsigned int SLIDERBAR        = 0x02;

      /// Component: check button
      static const unsigned int CHECKBUTTON      = 0x03;

      /// Component: color picker
      static const unsigned int COLORPICKER      = 0x04;

      /// Component: container
      static const unsigned int CONTAINER        = 0x05;

      /// Component: slot
      static const unsigned int SLOT             = 0x06;

      /// Component: group of containers to make schemes
      static const unsigned int GROUPCONTAINER   = 0x07;

      /// Component: button
      static const unsigned int BUTTON           = 0x08;

      /// Component: menu
      static const unsigned int MENU             = 0x09;

      /// Component: preview
      static const unsigned int PREVIEW          = 0x0A;

      /// Component: file chooser
      static const unsigned int FILECHOOSER      = 0x0B;

      // Component: defined by the user
      // ANY_VALUE                              >= 0x100;

      /// Left button
      static const unsigned int LEFTBUTTON         = 0x01;

      /// Middle button
      static const unsigned int MIDDLEBUTTON       = 0x02;

      /// Right button
      static const unsigned int RIGHTBUTTON        = 0x03;

      /// Wheel up button
      static const unsigned int WHEELUPBUTTON      = 0x04;

      /// Wheel down button
      static const unsigned int WHEELDOWNBUTTON    = 0x05;

      /// Shift key pressed
      static const unsigned int SHIFTKEY           = 0x010000;

      /// Ctrl key pressed
      static const unsigned int CTRLKEY            = 0x020000;

      /// Alt key pressed
      static const unsigned int ALTKEY             = 0x040000;

      /// Meta key pressed
      static const unsigned int METAKEY            = 0x080000;


      /** 
       * @post Constructor. Inizialite the empty selection.
       */
      S3DComponent(void);

      /** 
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty selection.
       */
      S3DComponent(float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DComponent(void);

      /**
       * @post Set the position of the component
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       */
      void setPos(float x, float y);

      /**
       * @post The x coordinate of the component
       */
      float getX (void);

      /**
       * @post The y coordinate of the component
       */
      float getY (void);

      /**
       * @post Set the property given by p
       * @param[in] p The property (see the flags)
       * @param[in] v The value
       */
      void setProperty(unsigned int p, unsigned int value);

      /**
       * @post The property given by p
       * @param[in] p The property (see the flags)
       */
      unsigned int getProperty(unsigned int p);

      /**
       * @post The width of the component
       */
      float getWidth (void);

      /**
       * @post The height of the component
       */
      float getHeight (void);

      /**
       * @post Set the size of the component, if w and h is 0, the component try
       *       to resize to the optimum size
       * @param[in] w The w coordinate of the component
       * @param[in] h The h coordinate of the component
       */
      void setSize(float w, float h);       

      /**
       * @pre id must be greater than 0
       * @post Draw the component
       * @param[in] id It is the identification number in order to select the 
       *               component
       */
      void setID(unsigned long int min_id, unsigned long int max_id);       

      /**
       * @post The minimal ID of the component
       */
      unsigned long int getMinID(void);       

      /**
       * @post The maximal ID of the component
       */
      unsigned long int getMaxID(void);       

      /**
       * param[in] f True if it has the focus, false in other case
       * @post The IDs needed by the component to be selected
       */
      void setFocus(bool f);       

      /**
       * @post The Focus
       */
      bool getFocus(void);       

      /**
       * @pre tip A valid tip or 0
       * @post The tip
       */
      void setTip(const char *tip);       

      /**
       * @post The tip
       */
      const char *getTip(void);       

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    NONE
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

   protected:

      /**
       * param[in] t The new value for the timer
       * @post Change the timer
       */
      void setTimer(Uint32 t);       

      /**
       * @post The value of the timer
       */
      Uint32 getTimer(void);       

      /**
       * @post Update and get the value of the timer
       */
      Uint32 updateTimer(void);       

      /**
       * @post The red component of the ID (as BGR)
       */
      Uint32 getStippleSelected (void);

      /**
       * @post The red component of the ID (as BGR)
       */
      unsigned char getRedFromId (unsigned long int id);

      /**
       * @post The red component of the ID (as BGR)
       */
       unsigned char getGreenFromId (unsigned long int id);

      /**
       * @post The red component of the ID (as BGR)
       */
      unsigned char getBlueFromId (unsigned long int id);

      /**
       * @pre id must be greater than 0
       * @post Draw the component
       * @param[in] id It is the identification number in order to select the 
       *               component
       */
      void setMinID(unsigned long int min_id);       

      /**
       * @pre id must be greater than 0
       * @post Draw the component
       * @param[in] id It is the identification number in order to select the 
       *               component
       */
      void setMaxID(unsigned long int max_id);       



   private:
      std::vector<unsigned int> property; /// Properties of the component
      float w, h; /// Size of the object
      float x, y; /// Position of the object
      Uint32 timer; /// Timer for animations
      Uint32 sttimer; /// Timer for stipple in selection
      unsigned long int minId; /// The range of id of the component
      unsigned long int maxId; /// The range of id of the component
      bool focus; /// If the component has a focus or not
      S3DComponent *cmpevent; /// Needed because the events
      char *tip; /// The tip
};

#endif
