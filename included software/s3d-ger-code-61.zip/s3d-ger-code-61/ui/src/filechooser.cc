#include "filechooser.hh"


// --------------------------------------------------
S3DFileChooser::S3DFileChooser(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{

   this->slider = new S3DSlider(theme, this->getX(), this->getY(), 0, 0);
   this->init(theme, "./");
}


// --------------------------------------------------
S3DFileChooser::S3DFileChooser(S3DTheme *theme, const char *dir) : 
                S3DComponent (0, 0, 0, 0)
{

   this->slider = new S3DSlider(theme, this->getX(), this->getY(), 0, 0);
   this->init(theme, dir);
}


// --------------------------------------------------
S3DFileChooser::S3DFileChooser(S3DTheme *theme, float x, float y, 
			       float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->setPos(x, y);  
   this->setSize(w, h);

   this->slider = new S3DSlider(theme, this->getX(), this->getY(),
                                w, 0);
   this->init(theme, "./");
}


// --------------------------------------------------
S3DFileChooser::S3DFileChooser(S3DTheme *theme, const char *dir, 
                               float x, float y, 
			       float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->setPos(x, y);  
   this->setSize(w, h);

   this->slider = new S3DSlider(theme, this->getX(), this->getY(),
                                w, 0);
   this->init(theme, dir);
}


// --------------------------------------------------
void S3DFileChooser::init(S3DTheme *theme, const char *dir)
{
   int i;

   this->index = 0;
   this->theme = theme;

   this->textLabel = new S3DLabel(theme->getFont(S3DTheme::INPUTTEXTFONT), 1);
   this->textLabel->setText("--");

   this->titleLabel = new S3DLabel(theme->getFont(S3DTheme::INPUTTEXTFONT), 1);
   this->titleLabel->setText("--");


   this->cTimer = this->updateTimer();

   this->fileName = new S3DFileMgr(dir);
   this->fileName->hideMsg(true);

   this->slider->setID(this->getMinID() + 2, 
                       this->getMinID() + 2 + this->slider->getIDNeeded() - 1);

   this->slider->setMinValue(1);
   this->slider->setMaxValue(this->fileName->numOfElements());
   this->slider->setIncrement(1);
   this->slider->setValue(1);
   this->slider->showTitle(false);
   this->slider->addListener(this);
   this->slider->sendPeriodicEvent(true);

   this->usedTextures = this->slider->getMaxValue();
   this->fnameT = new char*[this->usedTextures];
   this->texture = new GLuint[this->usedTextures];
   this->imgt = new S3DImage*[this->usedTextures];
   for (i = 0; i < this->usedTextures; i ++)
   {
      this->imgt[i] = new S3DImage();
      this->fnameT[i] = 0;
      this->texture[i] = 0;
   }

   this->fbo = 0;

   this->anim = 1.0;
   this->zoomAnim2 = 0;
   this->anim2 = 2.5;
   this->loadTextures();

   this->upTexture = 0;
   this->fileTexture = 0;
   this->dirTexture = 0;
   this->selectTexture = 0;
   this->searchTexture = 0;
   this->noValidTexture = 0;

   this->searching = true;

   this->fboUpdate = true;
}


// --------------------------------------------------
S3DFileChooser::~S3DFileChooser()
{
   if (this->fbo != 0)
   {
      delete this->fbo;
      this->fbo = 0;
   }

}


// --------------------------------------------------
void S3DFileChooser::setTextures (GLuint upfolder, GLuint folder, GLuint file,
                                  GLuint select, GLuint search, 
                                  GLuint ind, GLuint hfash, 
                                  GLuint bLreleased, GLuint bLover, 
                                  GLuint bLpress, 
                                  GLuint bRreleased, GLuint bRover,
                                  GLuint bRpress)
{
   this->upTexture = upfolder;
   this->fileTexture = file;
   this->dirTexture = folder;
   this->selectTexture = select;
   this->searchTexture = search;
   this->noValidTexture = fileTexture;

   this->slider->setTextures (ind, hfash, bLreleased, bLover,
                              bLpress, bRreleased, bRover, bRpress);

   this->loadTextures();
}


// --------------------------------------------------
void S3DFileChooser::setTitle (const char *t)
{
   this->titleLabel->setText(t);
}


// --------------------------------------------------
void S3DFileChooser::setDefaultFile (const char *fname)
{
   this->anim = 1.0;
   this->searching = false;

   this->index = 0;
   while ( (this->index < this->slider->getMaxValue()) &&
	   (strcmp(fname, this->fnameT[this->index])) )
   {
      this->index ++;
   }

   if (this->index >= this->slider->getMaxValue())
      return;

   this->slider->setValue(this->index + 1);

   if (this->fnameT[this->index] != 0)
      this->textLabel->setText(this->fnameT[this->index]);
   return;
}


// --------------------------------------------------
void S3DFileChooser::draw3DFiles (bool select)
{
   float distance;
   float angle;
   GLuint t;
   int i;
   float f;

   if ( (this->fboUpdate) || (this->anim <= 1))  
   {
      this->fboUpdate = false;


      if (this->anim > 1)
         this->anim = 1;


      if (this->fbo == 0)
      {
         this->fbo = new S3DFBO(512,  512,
                                4, GL_RGBA, GL_UNSIGNED_BYTE, GL_LINEAR, true);

         this->fbo->isValid();
         if (this->fbo == 0)
            return;
      }

      this->fbo->renderFBO();
      {
         glDepthMask(true); 
         glDepthFunc(GL_LEQUAL);

         glViewport(0, 0, 512, 512);
         glClearColor(0, 0, 0, 0);
         glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

         glMatrixMode(GL_PROJECTION);
         glPushMatrix();
         {
            glLoadIdentity();
            gluPerspective(60, 1.33, 0.01, 60.0);
              
            glMatrixMode(GL_MODELVIEW);
            glPushMatrix();
            {
               glLoadIdentity();


               glDisable(GL_TEXTURE_1D);
               glDisable(GL_TEXTURE_3D);


               glEnable(GL_BLEND);
               glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

               angle = 180.0 / (float) this->usedTextures;
	       distance = this->usedTextures * 0.8;

               glTranslatef (0, 0, -distance - this->anim2);
	       glPushMatrix();
	       {
		  glDisable(GL_TEXTURE_2D);
		  glColor4f(0.65, 0.76, 0.85, 0.70);
		  glTranslatef(0, -1, 0);
		  glRotatef(-90, 1, 0, 0);
		  glLineWidth(2.0);
		  S3DPrimitive3D::drawCircle (GL_TRIANGLE_FAN,
					      0, 0, 0, distance );
		  glColor4f(0.65, 0.76, 0.85, 0.80);
	       }
	       glPopMatrix();

               glEnable(GL_TEXTURE_2D);
               for (i = 0; i < this->usedTextures; i ++)
               {   
                  if ( (i >= 0) && (i < this->usedTextures) )
                  {
                     glPushMatrix();
                     {
                        if (!this->rightDir)
                           f = -(this->index - i - 1 + this->anim) * angle;
                        else
                           f = -(this->index - i + 1 - this->anim) * angle;
                        glRotatef(f, 0, 1, 0);

                        glTranslatef(0, 0, distance);

                        glEnable(GL_TEXTURE_2D);
                        glBindTexture(GL_TEXTURE_2D, this->texture[i]);
                        glColor4f(1, 1, 1, 1);
                        S3DPrimitive3D::drawPlane (GL_POLYGON, -1, -1, 0, 2, 2);

                        if ( (this->texture[i] == this->dirTexture) )
                        {
                           glPushMatrix();
                           {
                              if (this->fnameT[i] != 0)
                                 this->textLabel->setText(this->fnameT[i]);
                              glScalef (0.02, 0.02, 1.0);

                              this->textLabel->setColor(0.96, 0.25, 0.53, 1.0);
                              this->textLabel->setPos(-40, -10, 0.0001);
                              this->textLabel->draw();
                           }
                           glPopMatrix();
                        }

                     }
                     glPopMatrix();
                  }
               }
            }
            glPopMatrix();

            glMatrixMode(GL_PROJECTION);
         }
         glPopMatrix();

         glMatrixMode(GL_MODELVIEW);
         glDepthFunc(GL_ALWAYS);
         glDepthMask(false); 

      }
      this->fbo->renderFramebuffer();

      if (this->fnameT[this->index] != 0)
         this->textLabel->setText(this->fnameT[this->index]);
   }

   t = this->fbo->getTexture();


   glMatrixMode(GL_MODELVIEW);

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_3D);
   glEnable(GL_TEXTURE_2D);
   glBindTexture(GL_TEXTURE_2D, t);
   S3DPrimitive3D::drawPlane (GL_POLYGON, 
                              this->getX() + this->getWidth() * 0.1,
                              this->getY() + this->slider->getHeight(), 
                              0,
                              this->getWidth() * .8, this->getWidth()*.8, 
                              false);
   glDisable(GL_TEXTURE_2D);


   if (this->anim <= 1.0)
      this->anim += 0.01;   
}


// --------------------------------------------------
void S3DFileChooser::loadTextures(void)
{
   int i, j;
   bool noerr;
   char *str = 0;
   int used;

   this->fileName->removeDot();
   this->slider->setMaxValue(this->fileName->numOfElements());
   used = this->slider->getMaxValue();

   for (i = 0; i < this->usedTextures; i ++)
   {
      if (this->imgt[i] != 0)
         delete this->imgt[i];

      if (this->fnameT[i] != 0)
         delete [] this->fnameT[i];
   }

   delete [] this->imgt;
   delete [] this->texture;
   delete [] this->fnameT;


   this->usedTextures = used;

   this->imgt = new S3DImage*[used];
   this->texture = new GLuint[used];
   this->fnameT = new char*[used];


   j = 0;
   while (j < used)
   {
      this->imgt[j] = 0;
      this->texture[j] = 0;
      this->fnameT[j] = 0;

      str = this->fileName->getFileName(j, false);

      this->fnameT[j] = str;

      str = this->fileName->getFileName(j, true);
      if (this->fileName->isDirectory(j))
         noerr = false;
      else
      {
         this->imgt[j] = new S3DImage();
         noerr = this->imgt[j]->load(str);
      }

      if (noerr)
      {
         this->texture[j] = this->imgt[j]->setTexture2D(GL_TEXTURE0,
                                                        GL_NEAREST,
                                                        GL_REPEAT, 
                                                        GL_MODULATE);
      }
      else
      {
         if ( (!strcmp("..", this->fnameT[j])) ||
              (!strcmp("..\\", this->fnameT[j])) ||
              (!strcmp("../", this->fnameT[j])) )
            this->texture[j] = this->upTexture;
         else
            if (this->fileName->isDirectory(j))
               this->texture[j] = this->dirTexture;
            else 
               if (this->fileName->isFile(j))
                  this->texture[j] = this->fileTexture;
               else
                  this->texture[j] = 0;
      }

      if (str != 0)
         delete [] str;
      
      j ++;
   }

   if (this->fnameT[this->index] != 0)
      this->textLabel->setText(this->fnameT[this->index]);
}


// --------------------------------------------------
unsigned int S3DFileChooser::getType(unsigned long int id)
{
   return S3DComponent::FILECHOOSER;
}


// --------------------------------------------------
unsigned long int S3DFileChooser::getIDNeeded(void)
{
 // Only the slider, the button and the file are clickable
   return 2 + this->slider->getIDNeeded();
}


// --------------------------------------------------
void S3DFileChooser::draw(bool select)
{
   float r, s;
   float w, h; 
   unsigned int id;
   float tpos, h2;
   unsigned int flag;

   if (this->getProperty(S3DComponent::HIDED))
      return;

   if (this->getFocus() == false)
      this->slider->setFocus(false);

   s = this->theme->getValue(S3DTheme::SPACEVALUE);

   glPushMatrix();

   s = this->theme->getValue(S3DTheme::SPACEVALUE);

   glTranslatef(s, s, 0.0);



   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   if (this->searching)
      h2 = this->slider->getHeight();
   else
      h2 = 0;

   tpos = this->textLabel->getHeight();

   if (select == true)
   {
      glDisable(GL_BLEND);

      this->slider->draw(true);


      // Movement:
      if ( (!this->searching) ||  
	   ( (this->texture[this->index] != this->upTexture) && 
	     (this->texture[this->index] != this->noValidTexture) && 
	     (this->texture[this->index] != this->dirTexture)) )
	 id = this->getMinID() + 1; // ID 
      else
	 id = this->getMinID(); // ID 
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);      
      S3DPrimitive3D::drawPlane (GL_POLYGON, 
                                 this->getX() + s,
                                 this->getY() + h2,
                                 0,
                                 this->getWidth() - s * 2, 
				 this->getHeight() - h2);

    
      id = this->getMinID() + 1; // ID of the selected file
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);      
      S3DPrimitive3D::drawPlane (GL_POLYGON, 
                                 this->getX(),
                                 this->getY() + h2, 0,
				 tpos, tpos);

   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glColor4f(1, 1, 1, 1);

      if (this->searching)
	 this->slider->draw(false);

      if (this->searching)
	 this->draw3DFiles(false);
      else
      {
	 glEnable(GL_TEXTURE_2D);
	 glBindTexture(GL_TEXTURE_2D, this->texture[this->index]);
	 S3DPrimitive3D::drawPlane(GL_POLYGON, this->getX() + s,
				   this->getY() + s + 
				   this->textLabel->getHeight(), 
				   0,
				   this->getWidth() - s * 4,
				   this->getHeight() - s * 4 - 
				   this->titleLabel->getHeight() * 1.5);
      }

      glEnable(GL_TEXTURE_2D);
      if (!this->searching)
	 glBindTexture(GL_TEXTURE_2D, this->searchTexture);
      else
	 glBindTexture(GL_TEXTURE_2D, this->selectTexture);
      S3DPrimitive3D::drawPlane (GL_POLYGON, 
                                 this->getX(),
                                 this->getY() + h2, 0,
                                 tpos, tpos);

      if (this->searching)
      {
	 this->textLabel->setColor(0, 0, 0, 1.0);
	 this->textLabel->setPos(this->getX() + tpos, 
				 this->getY() + h2,
				 0.0);
      }
      else
      {
	 this->textLabel->setColor(0, 0.1, 0, 1.0);
	 this->textLabel->setPos(this->getX() + tpos,
				 this->getY(), 0.0);
      }
      this->textLabel->draw();


      this->titleLabel->setColor(0.1, 0.0, 0, 1.0);
      this->titleLabel->setPos(this->getX(),
			       this->getY() + this->getHeight() -
			       this->titleLabel->getHeight(), 0.0);
      this->titleLabel->draw();

      glDisable(GL_TEXTURE_2D);
      glLineWidth (1.0);
   }

   
   glPopMatrix();
}


// --------------------------------------------------
void S3DFileChooser::getInDir (const char *dir)
{
   this->fboUpdate = true;

   this->index = 0;
   this->fileName->getInDir(dir);
   this->slider->setMinValue(1);
   this->slider->setMaxValue(this->fileName->numOfElements());
   this->slider->setIncrement(1);
   this->slider->setValue(1);
   this->loadTextures();
}


// --------------------------------------------------
void S3DFileChooser::changeDir (const char *dir)
{
   this->fboUpdate = true;

   this->fileName->switchDir(dir);
   this->slider->setMinValue(1);
   this->slider->setMaxValue(this->fileName->numOfElements());
   this->slider->setIncrement(1);
   this->slider->setValue(1);
   this->loadTextures();
}


// --------------------------------------------------
GLuint S3DFileChooser::getTexture (void)
{
   if (this->searching)
      return 0;

   return this->texture[this->index];
}


// --------------------------------------------------
char *S3DFileChooser::getFile (void)
{
   if (this->searching)
      return 0;

   return this->fileName->getFileName(this->index, true); 
}


// --------------------------------------------------
unsigned int S3DFileChooser::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DFileChooser::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   float w, h;
   S3DColor *c;
   float inc;
   float h2;

   this->slider->eventMouseMotion(x, y, buttons, idevent);

   return;
}


// --------------------------------------------------
void S3DFileChooser::eventMouseButtonDown (float x, float y, 
					   unsigned int button,
					   unsigned int idevent)
{

   if (idevent == this->getMinID())
   {
      if ( (this->texture[this->index] == this->upTexture) || 
           (this->texture[this->index] == this->dirTexture) )
         this->getInDir(this->fnameT[this->index]);

      this->anim = 1.0;      
      return;
   }

   if (idevent == this->getMinID() + 1)
   {
      if ( (this->texture[this->index] != this->upTexture) && 
	   (this->texture[this->index] != this->noValidTexture) && 
           (this->texture[this->index] != this->dirTexture) )
      {
	 if (this->searching)
	 {
	    this->zoomAnim2 = 1;
	    this->sendEvent(this, "file_selected", x, y, 
			    0, S3DComponent::NONE, 
			    (this->fileName->getFileName(this->index, true)),
			    this->texture[this->index]);

	 }
	 else
	 {
	    this->zoomAnim2 = -1;
	 }
	 
	 this->searching = !this->searching;
      }

      return;
   }

   /*

   if (idevent == this->getMinID() + 1)
   {

      return;
   }
*/
/*
   if ( (idevent >= this->slider->getMinID()) &&
	(idevent <= this->slider->getMaxID()))
   {
      std::cerr << "?\n";
      this->slider->setFocus(true);
   }
*/

   this->slider->setFocus(true);
   this->slider->eventMouseButtonDown(x, y, button, idevent);

   return;
}


// --------------------------------------------------
void S3DFileChooser::eventMouseButtonUp (float x, float y, unsigned int button,
					 unsigned int idevent)
{
//   if (this->movingSquareSlider == true)
//      this->movingSquareSlider = false;
   
   this->slider->eventMouseButtonUp(x, y, button, idevent);

   return;
}

// --------------------------------------------------
void S3DFileChooser::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{

   return;
}


// --------------------------------------------------
void S3DFileChooser::eventIDChanged (long long int difference)
{
   this->slider->setID(this->slider->getMinID() + difference, 
		       this->slider->getMaxID() + difference);

   return;
}


// --------------------------------------------------
void S3DFileChooser::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DFileChooser::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DFileChooser::listenEvent(S3DListener *sender, const char *msg, 
				 float x, float y, unsigned int button, 
				 unsigned int key, 
				 void *data, unsigned int n)
{
   if (sender = this->slider)
   {
      this->fboUpdate = true;


      if (this->index == this->slider->getValue() - 2)
      {
         this->anim = 0.0;
         this->rightDir = false;
      }
      else
         if (this->index == this->slider->getValue())
         {
            this->anim = 0.0;
            this->rightDir = true;
         }
         else
            if (this->index == this->slider->getValue() - 1)
            {
               this->fboUpdate = false;
            }
            else
               this->anim = 2;

      this->index = (int) (this->slider->getValue() - 1);
      if (this->fnameT[this->index] != 0)
         this->textLabel->setText(this->fnameT[this->index]);      
   }



   // This component does not listen
   return;
}

