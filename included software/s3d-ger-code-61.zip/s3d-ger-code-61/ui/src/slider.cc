#include "slider.hh"


// --------------------------------------------------
S3DSlider::S3DSlider(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->init(theme);

   // Optimization must be initialized   
   this->setSize(this->input->getWidth() * 2, this->input->getHeight());
   this->eventChangePos(0, 0);
   this->eventResize(0, 0);
   this->sendEventOnMove = false;
}


// --------------------------------------------------
S3DSlider::S3DSlider(S3DTheme *theme, float x, float y, float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->init(theme);

   // Optimization must be initialized
   this->setSize(w, h);
   this->eventChangePos(x, y);
   this->eventResize(w, h);
   this->sendEventOnMove = false;
}


// --------------------------------------------------
void S3DSlider::init(S3DTheme *theme)
{
   int sl = this->getMinID() + 1;

   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->value = 0.0;
   this->minvalue = 0.0;
   this->maxvalue = 1.0;
   this->increment = 0.01;

   this->input = new S3DInput (this->theme, this->getX(), this->getY(), 0, 0);
   this->input->setText("Value: ", "0000.0000");
   this->input->setID(sl, sl + this->input->getIDNeeded() - 1);
   sl += this->input->getIDNeeded();
   this->input->setNumbers(true);
//   this->input->setPos(this->getX(), this->opth50);
   this->input->setPos(0, this->getHeight());

   this->movingSlider = false;
   this->prevx = 0;
   this->prevy = 0;

   this->hfashion = 0;
   this->indicator = 0;
   this->indicatorSize = 0;

   this->indicatorProportional = false;

   this->sTitle = true;
   this->sButtons = true;


   this->lButt = new S3DButton(theme, 0, this->getY(), 64, 64);
   this->lButt->setIDPressed(0);
   this->lButt->setIDReleased(0);
   this->lButt->setIDMouseOver(0);

   this->rButt = new S3DButton(theme, this->getX() + this->getWidth(),
                               this->getY(), 64, 64);
   this->rButt->setIDPressed(0);
   this->rButt->setIDReleased(0);
   this->rButt->setIDMouseOver(0);

   this->lButt->setID(sl, sl + this->lButt->getIDNeeded() - 1);
   sl += this->lButt->getIDNeeded();

   this->rButt->setID(sl, sl + this->rButt->getIDNeeded() - 1);
   sl += this->rButt->getIDNeeded();

   this->lButt->addListener(this);
   this->rButt->addListener(this);
}

// --------------------------------------------------
S3DSlider::~S3DSlider()
{
   if (this->input == 0)
      delete this->input;
}


// --------------------------------------------------
void S3DSlider::setTitle(const char *t)
{
   this->input->setText(t, this->input->getText());
}


// --------------------------------------------------
unsigned int S3DSlider::getType(unsigned long int id)
{
   return S3DComponent::SLIDERBAR;
}


// --------------------------------------------------
unsigned long int S3DSlider::getIDNeeded(void)
{
   // Only the slider and the text are clickable
   return (2 + this->input->getIDNeeded() + this->lButt->getIDNeeded() +
           this->rButt->getIDNeeded());
}


// --------------------------------------------------
void S3DSlider::draw(bool select)
{
   float r, s;
   float w, v; 
   float w0, w1, wb;
   unsigned int id;


   if (this->getProperty(S3DComponent::HIDED))
      return;

   glPushMatrix(); // safe 

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   if (this->getFocus() == false)
   {
      this->input->setFocus(false);
      this->lButt->setFocus(false);
      this->rButt->setFocus(false);
   }

   this->input->setPos(this->getX(), this->opth50);

   s = this->theme->getValue(S3DTheme::SPACEVALUE);
   r = this->theme->getValue(S3DTheme::CORNERVALUE);
   w = this->optw;

   if (this->minvalue == this->maxvalue)
      v = 0.0;
   else
      v = (this->value - this->minvalue) / (this->maxvalue - this->minvalue);

   wb = this->getX() + s;
   w0 = wb + v * w * 2;
   w1 = wb + w;


   if (select == true)
   {
      glDisable(GL_BLEND);
      if (this->sTitle)
      {
         glPushMatrix();
         {
	    this->input->setPos(this->s6 * 4,0);
            glTranslatef(this->getX(), 
			 this->getY() + this->getHeight() * 0.5, 0.0);
            this->input->draw(true);
         }
         glPopMatrix();
      }

      // Indicator
//      glPushMatrix();
      
      if (this->sButtons)
      {
         this->lButt->draw(true);
         glTranslatef(this->s6 * 4 + s, 0, 0);
      }

      id = this->getMinID(); // ID of the slider
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);      
      if (this->indicator == 0)
         S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN,
		    		          w0, 
				          this->getY() + this->opth50,
				          0.0, 
				          this->indicatorSize, this->opth25, r);
      else
         S3DPrimitive3D::drawPlane(GL_POLYGON,
		    		   w0 - s, 
                                   this->getY(),
				   0.0, 
				   this->indicatorSize * 1.5, this->opth25*2);
      
      if (this->sButtons)
      {
         glTranslatef(-this->s6 * 4, 0, 0);
         this->rButt->draw(true);
      }

//      glPopMatrix();
   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      if (this->sTitle)
      {
         glPushMatrix();
         {
	    this->input->setPos(this->s6 * 4,0);
            glTranslatef(this->getX(), 
			 this->getY() + this->getHeight() * 0.5, 0.0);
            this->input->draw(false);
         }
         glPopMatrix();
      }

//      glPushMatrix();
      if (this->sButtons)
      {
         glEnable(GL_TEXTURE_2D);
         this->lButt->draw(false);
         glTranslatef(this->s6 * 4 + s, 0, 0);
         glDisable(GL_TEXTURE_2D);
      }

      // Fashion:
      if (this->hfashion == 0)
      {
         glColor4f(this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::RED)* 0.5,
		   this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::GREEN)* 0.5,
		   this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::BLUE)* 0.5,
		   this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::ALPHA));
         S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN,
		  		          w1, 
				          this->getY() + this->opth25 +
				          this->s3, 0.0, w, this->s3, r);

         glColor4f(this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::RED),
                this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::GREEN),
		this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::BLUE),
		this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::ALPHA));
         glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE) * 0.5);
         S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP,
				          w1,
				          this->getY() + this->opth25 +
				          this->s3, 0.0, w, this->s3h, r);
      }
      else
      {
         glEnable(GL_TEXTURE_2D);
         glBindTexture(GL_TEXTURE_2D, this->hfashion);
         S3DPrimitive3D::drawPlane(GL_POLYGON,
                                   this->getX() + s3 * 4, 
				   this->getY() +
				   this->s3, 0.0, w*2, this->s3h*20);
         glDisable(GL_TEXTURE_2D);
      }

      // Indicator:


      if (this->indicator == 0)
      {
         glColor4f(this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::RED),
		   this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::GREEN),
		   this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
                                         S3DTheme::BLUE),
	           this->theme->getColor(S3DTheme::FGSLIDERCOLOR, 
				         S3DTheme::ALPHA));
         S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN,
				          w0,
				          this->getY() + this->opth25,
				          0.0, 
				          this->indicatorSize, this->opth25, r);

         glColor4f(this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::RED),
                   this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::GREEN),
		   this->theme->getColor(S3DTheme::FRAMECOLOR, S3DTheme::BLUE),
		   this->theme->getColor(S3DTheme::FRAMECOLOR, 
                                         S3DTheme::ALPHA));
         S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP,
		  		          w0,
				          this->getY() + this->opth25,
				          0.0, 
				          this->indicatorSize, this->opth25, r);
      }
      else
      {
         glEnable(GL_TEXTURE_2D);
         glBindTexture(GL_TEXTURE_2D, this->indicator);
         S3DPrimitive3D::drawPlane(GL_POLYGON,
		    		   w0 - s, 
                                   this->getY(),
				   0.0, 
				   this->indicatorSize * 1.5, this->opth25*2);
         glDisable(GL_TEXTURE_2D);
      }

      if (this->sButtons)
      {
         glTranslatef(-this->s6 * 4, 0, 0);
         glEnable(GL_TEXTURE_2D);
         this->rButt->draw(false);
         glDisable(GL_TEXTURE_2D);
      }


//      glPopMatrix();

      glLineWidth (1.0);

   }
   
   glPopMatrix(); // safe
   
   
}


// --------------------------------------------------
void S3DSlider::sendPeriodicEvent(bool d)
{
   this->sendEventOnMove = d;
}


// --------------------------------------------------
void S3DSlider::showTitle (bool f)
{
   this->sTitle = f;
}


// --------------------------------------------------
void S3DSlider::showButtons (bool f)
{
   this->sButtons = f;
}


// --------------------------------------------------
void S3DSlider::setIndicatorProportional(bool f)
{
   this->indicatorProportional = f;
   this->setIncrement(this->indicator);
}


// --------------------------------------------------
void S3DSlider::setTextures (GLuint ind, GLuint hfash, 
                             GLuint bLreleased, GLuint bLover, GLuint bLpress, 
                             GLuint bRreleased, GLuint bRover, GLuint bRpress)
{
   this->hfashion = hfash;
   this->indicator = ind;

   this->lButt->setIDPressed(bLpress);
   this->lButt->setIDReleased(bLreleased);
   this->lButt->setIDMouseOver(bLover);

   this->rButt->setIDPressed(bRpress);
   this->rButt->setIDReleased(bRreleased);
   this->rButt->setIDMouseOver(bRover);

   return;
}

// --------------------------------------------------
void S3DSlider::setIncrement (float v)
{
   float s, inc;

   this->increment = v;

   s = this->theme->getValue(S3DTheme::SPACEVALUE);
   this->s3 = s * 0.3;
   this->s3h = this->getHeight() * 0.03;
   this->s6 = s * 0.3 * 4;

   if (this->increment == 0)
      inc = 100;
   else
      inc = (this->maxvalue - this->minvalue) / this->increment;

   if ( (this->indicatorProportional) && (inc < 100))
      this->indicatorSize = this->getWidth() / inc;
   else 
      this->indicatorSize = this->s6;

}


// --------------------------------------------------
void S3DSlider::setValue (float v)
{
   char *str;

   if (v == this->value)
      return;

   if ( (v >= this->minvalue) && (v <= this->maxvalue) )
   {
      str = new char[10000];
      str[0] = '\0';
      this->value = v;
      sprintf(str, "%g", v);
      this->input->setText(this->input->getTitle(), str);
      delete [] str;
   }
}


// --------------------------------------------------
void S3DSlider::setMinValue (float v)
{
   this->minvalue = v;

   if (this->minvalue > this->value)
      this->setValue(this->minvalue);
}


// --------------------------------------------------
void S3DSlider::setMaxValue (float v)
{
   this->maxvalue = v;

   if (this->maxvalue < this->value)
      this->setValue(this->maxvalue);
}


// --------------------------------------------------
float S3DSlider::getValue (void)
{
   return this->value;
}


// --------------------------------------------------
float S3DSlider::getMinValue (void)
{
   return this->minvalue;
}


// --------------------------------------------------
float S3DSlider::getMaxValue (void)
{
   return this->maxvalue;
}


// --------------------------------------------------
unsigned int S3DSlider::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DSlider::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   float w, v, s;

 
   if (this->movingSlider == true)
   {
      s = this->theme->getValue(S3DTheme::SPACEVALUE);
      v = (x - this->prevx) / (this->optw * 2.0);

      this->setValue(this->prevy +
		     v * (this->getMaxValue() - this->getMinValue()) + 
		     this->getMinValue());

      if (this->sendEventOnMove)
         this->sendEvent(this, "float_value_changed", x, y, 
                         0, S3DComponent::NONE, &(this->value), 0);
   }

   this->lButt->eventMouseMotion(x, y, buttons, idevent);
   this->rButt->eventMouseMotion(x, y, buttons, idevent);
   return;
}


// --------------------------------------------------
void S3DSlider::eventMouseButtonDown (float x, float y, unsigned int button,
				     unsigned int idevent)
{
   float w; 

   if (idevent == this->getMinID())
   {
      this->movingSlider = true;
      this->prevx = x;
      this->prevy = this->value;
   }

   if ((idevent >= this->lButt->getMinID()) && 
       (idevent <= this->lButt->getMaxID()) )
   {
      this->lButt->setFocus(true);
      this->lButt->eventMouseButtonDown(x, y, button, idevent);
      return;
   }

   if ((idevent >= this->rButt->getMinID()) && 
       (idevent <= this->rButt->getMaxID()) )
   {
      this->rButt->setFocus(true);
      this->rButt->eventMouseButtonDown(x, y, button, idevent);
      return;
   }

   if ((idevent >= this->input->getMinID()) && 
       (idevent <= this->input->getMaxID()) )
      this->input->setFocus(true);
   else
      this->input->setFocus(false);
}


// --------------------------------------------------
void S3DSlider::eventMouseButtonUp (float x, float y, unsigned int button,
				   unsigned int idevent)
{
   if (this->input->getFocus() == false)
      this->setValue(atof(this->input->getText()));


   if (this->movingSlider == true)
   {
      this->sendEvent(this, "float_value_changed", x, y, 
		      button, S3DComponent::NONE, &(this->value), 0);
      
      this->movingSlider = false;
   }

   this->lButt->eventMouseButtonUp(x, y, button, idevent);
   this->rButt->eventMouseButtonUp(x, y, button, idevent);
   return;
}

// --------------------------------------------------
void S3DSlider::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{
   char *s;
   if ((key == '\r') || (key == '\n'))
   {
      s = new char[100000];

      this->setValue(atof(this->input->getText()));
      this->sendEvent(this, "float_value_changed", x, y, 
		      S3DComponent::NONE,
		      key, &(this->value), 0);
      s[0] = '\0';
      sprintf (s, "%g", this->getValue()); 
      this->input->setText(this->input->getTitle(), s);
      
      delete [] s;
   }

   if (this->input->getFocus() == true)
   {
      this->input->eventKeyDown (x, y, key, idevent);
   }
   else
      this->setValue(atof(this->input->getText()));

   if (this->lButt->getFocus())
      this->lButt->eventKeyDown (x, y, key, idevent);

   if (this->rButt->getFocus())
      this->rButt->eventKeyDown (x, y, key, idevent);
}


// --------------------------------------------------
void S3DSlider::eventIDChanged (long long int difference)
{
   this->input->setID(this->input->getMinID() + difference, 
		      this->input->getMaxID() + difference);

   this->lButt->setID(this->lButt->getMinID() + difference, 
		      this->lButt->getMaxID() + difference);
   this->rButt->setID(this->rButt->getMinID() + difference, 
		      this->rButt->getMaxID() + difference);
   return;
}

// --------------------------------------------------
void S3DSlider::eventResize (float newWidth, float newHeight)
{
   float s;
   float inc;

   s = this->theme->getValue(S3DTheme::SPACEVALUE);
   this->s3 = s * 0.3;
   this->s3h = this->getHeight() * 0.03;
   this->s6 = s * 0.3 * 4;

   if (this->increment == 0)
      inc = 100;
   else
      inc = (this->maxvalue - this->minvalue) / this->increment;

   if ( (this->indicatorProportional) && (inc < 100))
      this->indicatorSize = this->getWidth() / inc;
   else 
      this->indicatorSize = this->s6;

//   this->optw = (this->getWidth() - this->input->getWidth()) - s;
   this->optw = this->getWidth() / 3.0 - s;

   this->opth50 = this->getHeight() * 0.5;
   this->opth25 = this->getHeight() * 0.25;


   this->lButt->setSize(this->s6*4, this->s6*4);
   this->rButt->setSize(this->s6*4, this->s6*4);
   this->lButt->setPos(this->getX(), this->getY());
   this->rButt->setPos(this->getX()+ s + this->optw * 2 + this->rButt->getWidth(), this->getY());
//this->getWidth() - 2 * this->rButt->getWidth(), this->getY());



   if (this->getWidth() == 0)
   {
      this->input->setSize(this->input->getWidth() * 2, this->getHeight());
      this->setSize(this->input->getWidth() * 2, this->getHeight());
   }

   if (this->getHeight() == 0)
   {
      this->input->setSize(this->getWidth(), this->input->getHeight() + 2 * s);
      this->setSize(this->getWidth(), this->input->getHeight() + 2 * s);
   }
   


   return;
}


// --------------------------------------------------
void S3DSlider::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DSlider::listenEvent(S3DListener *sender, const char *msg, 
			    float x, float y, unsigned int button, 
			    unsigned int key, 
			    void *data, unsigned int n)
{
   if (sender == this->lButt)
   {
      if (this->value - this->increment < this->minvalue)
         this->setValue(this->minvalue);
      else
         this->setValue(this->value - this->increment);

      this->sendEvent(this, "float_value_changed", x, y, 
		      button, S3DComponent::NONE, &(this->value), 0);      
      return;
   }

   if (sender == this->rButt)
   {
      if (this->value + this->increment > this->maxvalue)
         this->setValue(this->maxvalue);
      else
         this->setValue(this->value + this->increment);

      this->sendEvent(this, "float_value_changed", x, y, 
		      button, S3DComponent::NONE, &(this->value), 0);      
      return;
   }

   // This component does not listen
   return;
}

