#ifndef __INPUT__
#define __INPUT__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "component.hh"
#include "theme.hh"
#include "label.hh"

/** @class   S3DInput input.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is an input component
 *
 *  @bug     No bugs detected yet
 */

class S3DInput : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DInput(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DInput(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DInput(void);

      /**
       * param[in] tittle It is the text before the other text, if it is 0
       *                 the colors will change to the colors of the tittle
       * param[in] text It is the new text (it can be changed by the user)
       * @post Change a value of the user interface
       */
      void setText(const char *tittle, const char *text);

      /**
       * @post The title of the component
       * @warning Do not free the pointer, it is NOT a copy
       */
      const char *getTitle(void);

      /**
       * @post The text of the component
       * @warning Do not free the pointer, it is NOT a copy
       */
      const char *getText(void);

      /**
       * param[in] n If the input text only accepts numbers or not
       * @post Change the input mode
       */
      void setNumbers(bool n);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "string_value_changed"
       *            data = the string (char *), it is not a copy! [do not free]
       *            n = size of the string
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);


   private:
      S3DTheme *theme; // theme
      char *text, *tittle; /// The text
      S3DLabel *tittleLabel, *textLabel; /// The labels
      Uint32 cTimer; /// Timer for the component
      bool number; /// It allows only to input numbers ([1-9]|-|.) 
      bool notfit; /// If the text does not fit 
      unsigned int nchr; /// Number of maximal characters in the input
      float optx, opty; /// To optimize
};


#endif
