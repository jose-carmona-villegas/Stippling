#ifndef __THEME__
#define __THEME__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include <vector>
#include "vector.hh"
#include "image.hh"
#include "primitive3d.hh"

/** @class   S3DTheme theme.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is the UI theme
 *
 *  @bug     No bugs detected yet
 */

class S3DTheme {
   public:

      /// Red component
      static const unsigned int RED               = 0;

      /// Green component
      static const unsigned int GREEN             = 1;

      /// Blue component
      static const unsigned int BLUE              = 2;

      /// Alpha component
      static const unsigned int ALPHA             = 3;

      /// Font of the Label
      static const unsigned int LABELFONT         = 0;

      /// Font of the Input Text
      static const unsigned int INPUTTEXTFONT     = 1;

      /// Color of the Label
      static const unsigned int FGTEXTCOLOR               = 0;

      /// Color of the Frame
      static const unsigned int FRAMECOLOR                = 1;

      /// Color of the Input Text
      static const unsigned int FGINPUTTEXTCOLOR          = 2;

      /// Color of the Selected Input Text
      static const unsigned int FGSELECTEDINPUTTEXTCOLOR  = 3;

      /// Color of the Slider
      static const unsigned int FGSLIDERCOLOR             = 4;

      /// Color of the Check Box
      static const unsigned int FGCHECKBOXCOLOR           = 5;

      /// Color of the Check Box
      static const unsigned int FGCOLORPICKERCOLOR        = 6;

      /// Background Color of the Input Text
      static const unsigned int BGINPUTTEXTCOLOR          = 7;

      /// Background Color of the Slider
      static const unsigned int BGSLIDERCOLOR             = 8;

      /// Background Color of the Check Box
      static const unsigned int BGCHECKBOXCOLOR           = 9;

      /// Background Color of the Color Picker
      static const unsigned int BGCOLORPICKERCOLOR        = 10;

      /// Background Color of the Volume
      static const unsigned int BGVOLUMECOLOR             = 11;

      /// Background Color of the GMOD
      static const unsigned int BGGMODCOLOR               = 12;

      /// Background Color of the Menu
      static const unsigned int BGMENUCOLOR               = 13;

      /// Value of the space between the frame and the components inside
      static const unsigned int SPACEVALUE          = 0;

      /// Value of the corner to round it or not
      static const unsigned int CORNERVALUE         = 1;

      /// Value of the width of the border in frames
      static const unsigned int FRAMEWIDTHVALUE     = 2;

      /// Value of the font size
      static const unsigned int FONTSIZEVALUE       = 3;

      /// Value of the width of the border in frames
      static const unsigned int SHADOWSIZEVALUE     = 4;


      /** 
       * @post Constructor. Inizialite the empty selection.
       */
      S3DTheme(void);

      /** 
       * @post Constructor. Inizialite the empty selection.
       */
      S3DTheme(const char *label_font, unsigned int size0, 
	       const char *input_font, unsigned int size1);

      /**
       * param[in] flag It is the flag of the thing to change
       * param[in] r The red value between 0 and 1
       * param[in] g The green value between 0 and 1
       * param[in] b The blue value between 0 and 1
       * param[in] a The alpha value between 0 and 1
       * @post Change a color of the user interface
       */
      void setColor(unsigned int flag, float r, float g, float b, float a);

      /**
       * param[in] flag It is the flag of the thing to change
       * param[in] v The new value
       * @post Change a value of the user interface
       */
      void setValue(unsigned int flag, float v);

      /**
       * param[in] flag It is the flag of the font to change
       * param[in] file The name of the file to change the font
       * param[in] size The size of the font
       * @post Change a value of the user interface
       */
      void setFont(unsigned int flag, const char *file, unsigned int size);

      /**
       * warning Do not use the same font pointer in more methods or objects
       *         because the pointer will be freeded automatically
       * param[in] flag It is the flag of the font to change
       * param[in] font The new font (it must not be freeded)
       * @post Change a value of the user interface
       */
      void setFont(unsigned int flag, TTF_Font *font);

      /**
       * param[in] flag It is the flag of the font to change
       * @post The font of some kind of component
       */
      TTF_Font *getFont(unsigned int flag);

      /**
       * param[in] flag It is the flag of the thing to change
       * @post The value of some thing in the user interface
       */
      float getValue(unsigned int flag);

      /**
       * param[in] flag It is the flag of the thing to change
       * param[in] channel It is the flag of the channel, can be one of this:
       *           RED, GREEN, BLUE, ALPHA
       * @post The value of some thing in the user interface
       */
      float getColor(unsigned int flag, unsigned int channel);

      /**
       * @post Set the mouse icon
       * @param[in] index The index of the texture in the list, if index is a 
       *            negative number, the mouse will disappear
       */
      void setMouse(int index); 

      /**
       * @post Get the mouse icon
       * @param[in] index The index of the texture in the list, if index is a 
       *            negative number it will return 0
       */
      GLuint getMouse(int index); 

      /**
       * @post Get the default mouse icon
       */
      GLuint getMouse(void); 

      /**
       * @post Set the mouse icon
       * @param[in] texture The id of the texture
       */
      void addMouseTexture(GLuint texture); 



      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DTheme(void);


   protected:

      /** 
       * @post Initialize all the values but the fonts
       */
      void init(void);

   private:
      TTF_Font *labelFont, *inputFont; /// Fonts
      float space; /// Space between the frames and the text inside
      float corner; /// Round value of the frames
      float framewidth; /// The size of the frames
      float shadowsizevalue; /// The size of the shadow if any
      float fontsize; /// The size of the font
      float fgTextColor[4]; /// Color of the FG text
      float fgFrameColor[4]; /// Color of the border in the frame
      float fgInputColor[4]; /// Color of the FG text in the input
      float fgInputSelectedColor[4]; /** Color of the FG text in the input 
					 when it is selected **/
      float fgCheckBoxColor[4]; /// Color of the checkboxes
      float fgSliderColor[4]; /// Color of the FG containers in the slider 
      float fgCPickerColor[4]; /// Color of the FG color picker
      float bgSliderColor[4]; /// Color of the BG containers in the slider 
      float bgCPickerColor[4]; /// Color of the BG color picker
      float bgInputColor[4]; /// Color of the BG containers in the input text
      float bgCheckBoxColor[4]; /// Color of the BG containers in checkboxes
      float bgVolumeColor[4]; /// Color of the BG containers in volumes
      float bgGModColor[4]; /// Color of the BG containers in gmods
      float bgMenuColor[4]; /// Color of the BG containers in menus
      GLuint mousetex; /// Texture of the mouse
      std::vector <GLuint> lmouse; /// List of textures for the mouse
};


#endif
