#ifndef __STATIC_COMPONENT__
#define __STATIC_COMPONENT__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "color.hh"
#include "component.hh"
#include "filemgr.hh"
#include "slider.hh"
#include "theme.hh"


/** @class   S3DStatic static.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a static component that displays an image or label
 *
 *  @bug     No bugs detected yet
 */

class S3DStatic : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DStatic(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DStatic(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DStatic(void);

      /**
       * @pre t must be a valid title or 0
       * @post Set a title
       * @param[in] t The title
       */
      void setText (const char *t);

      /**
       * @pre t must be a valid path to a file
       * @post Set an image
       * @param[in] t The title
       */
      void setImage (const char *t);

      /**
       * @pre id must be a valid texture
       * @post Set an image
       * @param[in] t The title
       * @warning The texture is not freed by this component
       */
      void setImageID (GLuint id);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
			     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @note EVENTS of this component:
       *       -    msg = "file_selected"
       *            data = pointer to a path (char *) [do not free]
       *            n = the texture ID in OpenGL format [do not delete]
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key,  
			       void *data, unsigned int n);


   protected:

      /** 
       * @param[in] theme A valid theme
       * @post Part of the constructor. Inizialite the empty component.
       */
      void init(S3DTheme *theme);


   private:
      S3DTheme *theme; // theme
      S3DLabel *textLabel; /// The title
      S3DImage *titleImg; /// The image
      GLuint id; /// The texture
};


#endif
