#include "component.hh"


// --------------------------------------------------
S3DComponent::S3DComponent(void)
{
   this->minId = 0;
   this->maxId = 0;
   this->timer = SDL_GetTicks();
   this->sttimer = SDL_GetTicks();
   this->focus = 0;

   this->tip = 0;

   this->setPos(0, 0);
   this->setSize(0, 0);
}


// --------------------------------------------------
S3DComponent::S3DComponent(float x, float y, float w, float h)
{
   this->minId = 0;
   this->maxId = 0;
   this->timer = SDL_GetTicks();
   this->sttimer = SDL_GetTicks();
   this->focus = 0;

   this->tip = 0;

   this->setPos(x, y);
   this->setSize(w, h);
}


// --------------------------------------------------
S3DComponent::~S3DComponent()
{
   if (this->tip != 0)
      delete [] this->tip;
}


// --------------------------------------------------
void S3DComponent::setPos (float x, float y)
{
   if ((this->x != x) || (this->y != y))
   {
      this->x = x;
      this->y = y;

      this->eventChangePos (x, y);
   }
}


// --------------------------------------------------
void S3DComponent::setTip (const char *t)
{
   if (this->tip != 0)
      delete [] this->tip;

   if (t == 0)
   {
      this->tip = 0;
      return;
   }

   this->tip = new char[strlen(t)+ 1];
   this->tip[0] = '\0';
   strcpy(this->tip, t);

   return;
}


// --------------------------------------------------
const char *S3DComponent::getTip (void)
{
   return this->tip;
}


// --------------------------------------------------
float S3DComponent::getX (void)
{
   return this->x;
}


// --------------------------------------------------
float S3DComponent::getY (void)
{
   return this->y;
}


// --------------------------------------------------
void S3DComponent::setSize (float w, float h)
{
   if ((this->w != w) || (this->h != h))
   {
      this->w = w;
      this->h = h;
      this->eventResize (w, h);
   }
}


// --------------------------------------------------
float S3DComponent::getWidth (void)
{
   return this->w;
}


// --------------------------------------------------
float S3DComponent::getHeight (void)
{
   return this->h;
}


// --------------------------------------------------
void S3DComponent::draw(bool select)
{
// You should copy this line in all the derived classes from this
//   if ( (this->select == true) && (this->id == 0) )
   return;
}


// --------------------------------------------------
void S3DComponent::setID(unsigned long int minId, unsigned long int maxId)
{
   this->eventIDChanged(minId - this->minId);

   this->minId = minId;
   this->maxId = maxId;
}  


// --------------------------------------------------
unsigned long int S3DComponent::getMinID(void)
{
   return this->minId;
}


// --------------------------------------------------
unsigned long int S3DComponent::getMaxID(void)
{
   return this->maxId;
}


// --------------------------------------------------
unsigned long int S3DComponent::getIDNeeded(void)
{
   return 0;
}


// --------------------------------------------------
void S3DComponent::setFocus(bool f)
{
   this->focus = f;
}


// --------------------------------------------------
bool S3DComponent::getFocus(void)
{
   return this->focus;
}


// --------------------------------------------------
unsigned int S3DComponent::getType (unsigned long int id)
{
   return ABSTRACT;
}

// --------------------------------------------------
void S3DComponent::setTimer(Uint32 t)
{
   this->timer = t;
}


// --------------------------------------------------
Uint32 S3DComponent::getTimer(void)
{
   return  SDL_GetTicks();
}


// --------------------------------------------------
void S3DComponent::setProperty(unsigned int p, unsigned int value)
{
   while (p >= this->property.size())
      this->property.push_back(0);
   this->property[p] = value;
}

// --------------------------------------------------
unsigned int S3DComponent::getProperty(unsigned int p)
{
   if (p < this->property.size())
      return this->property[p];
   else
      return 0;
}

// --------------------------------------------------
Uint32 S3DComponent::updateTimer(void)
{
   this->timer = SDL_GetTicks();   
   return this->timer;
}


// --------------------------------------------------
unsigned char S3DComponent::getBlueFromId (unsigned long int id)
{
   return (id >> 16) & 0x000000FF; 
}

// --------------------------------------------------
unsigned char S3DComponent::getGreenFromId (unsigned long int id)
{
   return (id >> 8) & 0x000000FF; 
}


// --------------------------------------------------
unsigned char S3DComponent::getRedFromId (unsigned long int id)
{
   return id & 0x000000FF; 
}


// --------------------------------------------------
unsigned int S3DComponent::getEvents (void)
{
   return NONE;
}


// --------------------------------------------------
void S3DComponent::eventMouseMotion (float x, float y, unsigned int buttons,
				     unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DComponent::eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DComponent::eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent)
{
   return;
}

// --------------------------------------------------
void S3DComponent::eventKeyDown (float x, float y, unsigned int key, 
				 unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DComponent::setMinID (unsigned long int id)
{
   this->eventIDChanged(id - this->minId);

   this->minId = id;
} 


// --------------------------------------------------
void S3DComponent::setMaxID (unsigned long int id)
{
   this->eventIDChanged(id - this->maxId);

   this->maxId = id;
} 


// --------------------------------------------------
void S3DComponent::eventIDChanged (long long int difference)
{
   return;
}


// --------------------------------------------------
void S3DComponent::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DComponent::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DComponent::listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n)
{
   // This component does not listen
   return;
}


// --------------------------------------------------
Uint32 S3DComponent::getStippleSelected (void)
{
   Uint32 flag = 0xFFF0FFF0;
   Uint32 f = 0x0;
   Uint32 t = SDL_GetTicks();   
   Uint32 n;
   
   n = (t - this->sttimer) / 100;
   if (n > 16)
   {
      this->sttimer = t;
   }
   else
   {
      f = flag >> n;
   }

   return f;
}

