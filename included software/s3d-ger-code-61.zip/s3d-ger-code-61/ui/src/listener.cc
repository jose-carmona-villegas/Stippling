#include "listener.hh"


// --------------------------------------------------
S3DListener::S3DListener(void)
{
}


// --------------------------------------------------
S3DListener::~S3DListener()
{
}


// --------------------------------------------------
void S3DListener::addListener (S3DListener *list)
{
//   if (this->getListener(list) < this->lcomp.size())
//      return;

   this->lcomp.push_back(list);

//   std::cerr << "ADD Number of listeners of " << this << " is " 
//	     << this->lcomp.size() << "\n";
}


// --------------------------------------------------
void S3DListener::removeListener (S3DListener *list)
{
   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i ++)
      if (this->lcomp[i] == list)
      {
	 this->lcomp.erase(this->lcomp.begin() + i);

//	 std::cerr << "REMOVE Number of listeners of " << this << " is " 
//		   << this->lcomp.size() << "\n";

	 return;
      }

}


// --------------------------------------------------
S3DListener *S3DListener::getListener (unsigned int i)
{
   if (i < this->lcomp.size())
      return this->lcomp[i];

   return 0;
}


// --------------------------------------------------
unsigned int S3DListener::getListener (S3DListener *list)
{
   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i ++)
      if (this->lcomp[i] == list)
	 return i;

   return this->lcomp.size();
}


// --------------------------------------------------
unsigned int S3DListener::getNListeners (void)
{
   return this->lcomp.size();
}


// --------------------------------------------------
void S3DListener::sendEvent(S3DListener *sender, const char *msg, 
			    float x, float y, unsigned int button, 
			    unsigned int key, 
			    void *data, unsigned int n)
{
   unsigned int i;

//   std::cerr << "DEBUG: **** Event " << msg << std::endl;

   for (i = 0; i < this->lcomp.size(); i ++)
      if (this->lcomp[i] != 0)
      {
	 this->lcomp[i]->listenEvent(sender, msg, x, y, button, key, data, n);

/*
	 std::cerr << "DEBUG: Event sended: \'" << msg << "\' from " << sender 
		   << " with mouse in (" << x << ", " << y 
		   << ") and the key = " << key << std::endl;
*/
      }
   return;
}


// --------------------------------------------------
void S3DListener::listenEvent(S3DListener *sender, const char *msg, 
			      float x, float y, unsigned int button, 
			      unsigned int key, 
			      void *data, unsigned int n)
{
   // Do nothing by default
}
