#ifndef __COLORPICKER__
#define __COLORPICKER__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "color.hh"
#include "component.hh"
#include "theme.hh"
#include "slider.hh"

/** @class   S3DColorPicker colorpicker.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is an color picker component
 *
 *  @bug     No bugs detected yet
 */

class S3DColorPicker : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DColorPicker(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DColorPicker(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DColorPicker(void);

      /**
       * param[in] r The red component between 0 and 1
       * param[in] g The green component between 0 and 1
       * param[in] b The blue component between 0 and 1
       * param[in] a The alpha component between 0 and 1
       * @post Change the color
       */
      void setColor(float r, float g, float b, float a);

      /**
       * post The color of the color picker object
       * @warning Do not free the returned pointer
       */
      S3DColor *getColor(void);

      /**
       * param[in] n The new minimal value
       * @post Change the value
       */
      void setMinValue(float n);

      /**
       * @post The the red component
       */
      float getRed(void);

      /**
       * @post The the blue component
       */
      float getBlue(void);

      /**
       * @post The the green component
       */
      float getGreen(void);

      /**
       * @post The the alpha component
       */
      float getAlpha(void);

      /**
       * @param[in] show If the title is shown or not
       * @post Show or hide the alpha title
       */
      void showAlphaTitle(bool show);

      /**
       * @param[in] title The title
       * @post Change the title
       */
      void setTitle(const char *title);

      /**
       * @param[in] x0 The first x coordinate
       * @param[in] y0 The first y coordinate
       * @param[in] x1 The second x coordinate
       * @param[in] y1 The second y coordinate
       * @param[in] p The texture is repeated p times
       * @post Draw a typical transparent background
       */
      void drawTranspBG(float x0, float y0, float x1, float y1, float p);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "color_value_changed"
       *            data = pointer to a color value (S3DColor *) [do not free]
       *            n = undefined
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key,  
			       void *data, unsigned int n);


   private:
      S3DTheme *theme; // theme
      Uint32 cTimer; /// Timer for the component
      S3DColor *color; /// The main color
      float red, green, blue; /// The color 2
      S3DSlider *slider; /// Slider for the alpha channel
      float prevx, prevy; /// Previous x and y
      bool movingHueSlider; /// The hue slider is moving
      bool movingSquareSlider; /// The square slider is moving
      float prevv0, prevv1; /// Previous values
      S3DLabel *tittleLabel; /// The title
};


#endif
