#ifndef __PREVIEW__
#define __PREVIEW__

#include <GL/glew.h>
#include <fstream>
#include <math.h>
#include <SDL/SDL_ttf.h>
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()
#include "framebuffer.hh"
#include "primitive3d.hh"
#include "component.hh"
#include "theme.hh"
#include "label.hh"

/** @class   S3DPreview preview.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a preview
 *
 *  @bug     No bugs detected yet
 */

class S3DPreview : public S3DComponent {
   public:

      /// This change the size of the points and headers of the arrows
      static const unsigned int SIZE             = 0x0000;

      /// This change the size of the arrows and the distances
      static const unsigned int UNIT_SIZE        = 0x0001;

      /// This change the rotation of the arrows
      static const unsigned int UNIT_ROTATION    = 0x0002;

      /// This change the movement of the positions
      static const unsigned int UNIT_MOVEMENT    = 0x0003;

      /// If the x axis is selected
      static const unsigned int X_SELECTED       = 0x0001;

      /// If the x axis is selected
      static const unsigned int Y_SELECTED       = 0x0002;

      /// If the x axis is selected
      static const unsigned int Z_SELECTED       = 0x0004;


      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DPreview(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @param[in] fbow The width of the FBO
       * @param[in] fboh The height of the FBO
       * @post Constructor. Inizialite the empty component.
       */
      S3DPreview(S3DTheme *theme, float x, float y, float w, float h,
		 unsigned int fbow=256, unsigned int fboh=256);

      /** 
       * @post Initialize the object
       */
      void init(void);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DPreview(void);

      /**
       * @post Initialize all the parameters of the FBO, if everything is OK it
       *       returns true, in other case it returns false
       */
      bool initFBO(void);

      /**
       * @post The width of the FBO
       */
      unsigned int getWidthFBO(void);

      /**
       * @post The height of the FBO
       */
      unsigned int getHeightFBO(void);

      /**
       * @param[in] f If update will be forced or not
       * @post Force the update the FBO if f is true
       */
      void forceUpdate(bool f);

      /**
       * @param[in] t The new time
       * @post Change the time to refresh the component if it is update
       */
      void setRefreshTime(unsigned int t);

      /**
       * @param[in] s If send the events or not
       * @post Send the predraw events if it is active
       */
      void sendPreDrawEvents(bool s);

      /**
       * @post Update the FBO
       */
      void update(void);

      /**
       * @param[in] flag One of these: SIZE, UNIT_SIZE
       * @param[in] s The size
       * @post Change the size of the components and units
       */
      void setSize(unsigned int flag, float s);

      /**
       * @param[in] a The alpha angle (in x axis)
       * @param[in] b The beta angle (in y axis)
       * @param[in] g The gamma angle (in z axis)
       * @post Add a vector using three angles, if a = b = g = 0 
       *       the direction will be (0, -1, 0)
       */
      void addDirection (const char *name, float a, float b, float g);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Add a position, the vector is normalized automatically   
       */
      void addPosition (const char *name, float x, float y, float z);

      /**
       * @param[in] i The index
       * @post The vector in the position i in the way: (x, y, z, a, b, g)
       */
      S3DVector *getDirection (unsigned int i);

      /**
       * @param[in] i The index
       * @post The position in the position i
       */
      S3DVector *getPosition (unsigned int i);

      /**
       * @post The number of directions
       */
      unsigned int getNDirections (void);

      /**
       * @post The number of positions
       */
      unsigned int getNPositions (void);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "predraw" (every time this component is draw)
       *            data = undefined
       *            n = undefined
       *       -    msg = "draw_projection_fbo"
       *            data = undefined
       *            n = undefined
       *       -    msg = "draw_model_fbo"
       *            data = undefined
       *            n = undefined
       *       -    msg = "camera_fbo"
       *            data = undefined
       *            n = undefined
       *       -    msg = "move_position"
       *            data = (S3DVector *) [do not delete]
       *            n = the index of the position
       *       -    msg = "move_direction"
       *            data = (S3DVector *) [do not delete]
       *            n = the index of the direction
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

      /**
       * @param[in] w The width of the capture
       *            if w = 0 => it will take the main FBO width
       * @param[in] h The height of the capture, 
       *            if h = 0 => it will take the main FBO height
       * @param[in] if fname != 0 => save a bmp with that name
       * @post Capture the FBO and return a texture
       */
      GLuint capture(const char *fname, unsigned int w = 0, unsigned int h = 0);

   protected:

      /**
       * @post Prepare the proyection and the flags
       */
      virtual void drawProjectionInFBO(void);

      /**
       * @post Draw the transformations of the camera
       */
      virtual void cameraInFBO(void);

      /**
       * @post Draw the default mode in the preview
       */
      virtual void drawModelInFBO(void);

      /**
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @param[in] z The z coordinate
       * @post Draw the position given by the coordinates
       */
      virtual void drawPosition(float x, float y, float z);

      /**
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @param[in] z The z coordinate
       * @post Draw the direction given by the coordinates
       */
      virtual void drawDirection(float x, float y, float z);

      /**
       * @post Draw the front buffer
       */
      void drawFrontBuffer(void);

      /**
       * @post Draw the back buffer
       */
      void drawBackBuffer(void);

      /**
       * @post Draw the arrows in the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void drawArrows(bool select);       

      /**
       * @param[in] a The alpha angle (in x axis)
       * @param[in] b The beta angle (in y axis)
       * @param[in] g The gamma angle (in z axis)
       * @post Compute a 3d vector with the new direction after computing 
       *       the direction from the angles (by default the returned vector
       *       when a = b = g = 0 is (0, -1, 0)
       */
      S3DVector *computeDirection (float a, float b, float g);

   protected:

      /**
       * @post Draw the FBO
       */
      void drawFBO(void);

      
   private:
      S3DTheme *theme; /// Theme
      bool firstFBO; /// To define a FBO
      S3DFBO *fbo; /// The FBO
      GLuint imgfbo; /// The texture of the FBO
      GLuint wprev, hprev; /// The size of the preview frame buffer object
      bool changed; /// The image in the preview changed
      bool redraw_backbuffer; /// Redraw the back buffer
      float angle; /// The angle of the test draw
      std::vector <S3DVector *> ldir; /// List of directions 
      std::vector <S3DVector *> lpos; /// List of positions 
      float size; /// The size of the point and the head of the arrows 
      float unit_size; /// The size of a unit (used for movement and arrows)
      float unit_rotation; /// The unit of rotation
      float unit_movement; /// The unit of movement
      S3DFBO *fbo_back; /// The fbo back
      GLuint imgfbo_back; /// The texture of the fbo back
      long int posSelected; /// The selected point 
      long int dirSelected; /// The selected direction
      unsigned int selectedAxis; /// The selected axis
      float prevx, prevy, prevz; /// The previous values of the mouse
      S3DVector *selected_vector; /// The selected vector
      S3DVector *prevv; /// The previous vector
      std::vector <S3DLabel *> lnamedir, lnamepos; /// Lists with names
      unsigned char *backup; /// The backup of the all screen
      GLuint depthBuffer; /// The depth buffer in the FBO
      bool forceUpd; /// Force to update the component
      Uint32 updtimer, refreshTime; /// Timer for updates
      bool sendpredrawevents; /// Send the predraw events or not
};


#endif
