#include "container.hh"


// --------------------------------------------------
S3DContainer::S3DContainer(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;
   this->init();
}

// --------------------------------------------------
S3DContainer::S3DContainer(S3DTheme *theme, float x, float y, float w, float h)
   : S3DComponent (x, y, w, h)
{
   this->theme = theme;
   this->init();
}


// --------------------------------------------------
S3DContainer::~S3DContainer()
{
}


// --------------------------------------------------
void S3DContainer::init(void)
{
   this->freeid = 101;
   this->focus = this->getFocus();
   this->moving = false;
   this->autoResize = true;
   this->bgColor = S3DTheme::BGMENUCOLOR;
   this->firsttime = true;
   this->starttimer = SDL_GetTicks();
   this->shadow_h = 0;
   this->shadow_v = 0;

   this->allhided = false;
   this->allshowed = false;
}


// --------------------------------------------------
unsigned int S3DContainer::getType(unsigned long int id)
{
   unsigned long int i;
   unsigned long int idf;

//   std::cerr << "ID = " << id << ", MIN_ID = " << this->getMinID() << "\n";

   if (id == this->getMinID())
      return S3DComponent::CONTAINER;

   if (id < this->getMinID() + 101)
      return S3DComponent::SLOT;

   idf = id - this->getMinID() - 101;
   for (i = 0; i < this->lcomp.size(); i ++)
      if ( (idf >= this->lcomp[i]->getMinID()) && 
	   (idf <= this->lcomp[i]->getMaxID()) ) 
	 return this->lcomp[i]->getType(id);

   return 0;
}


// --------------------------------------------------
S3DComponent *S3DContainer::getComponent(unsigned int i)
{
//   std::cerr << this->lcomp.size() << "\n";
   return this->lcomp[i];
}


// --------------------------------------------------
unsigned int S3DContainer::getNComponents(void)
{
   return this->lcomp.size();
}


// --------------------------------------------------
unsigned long int S3DContainer::getNSlots(void)
{
   return this->lslotType.size();
}


// --------------------------------------------------
void S3DContainer::removeComponent(S3DComponent *c)
{
   unsigned long int i;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      if (this->lcomp[i] == c)
      {
	 this->lcomp.erase(this->lcomp.begin() + i);
	 return;
      }
   }
}


// --------------------------------------------------
void S3DContainer::add(S3DComponent *c)
{
   unsigned int aux0, aux1;
   int i;
   float s;

   aux0 = this->getMinID() + this->freeid;
   aux1 = aux0 + c->getIDNeeded() - 1;

   if ( (c != 0) && (aux1 - this->getMinID() < 1000))
   {
      c->setID(aux0, aux1);
      this->freeid += c->getIDNeeded();

      this->lcomp.push_back(c);

      c->addListener(this);
   }
   else
      std::cerr << "Warning: Not enough space "
		<< "for this component in container!\n";

   if ( (this->getWidth() == 0)  || (this->autoResize == true) )
   {
      s = 0;
      for (i = 0; i < this->lcomp.size(); i++)
      {
	 if (this->lcomp[i] != 0)
	    if (s < this->lcomp[i]->getX() + this->lcomp[i]->getWidth())
	       s = this->lcomp[i]->getX() + this->lcomp[i]->getWidth();
      }

      s += 4.0 * this->theme->getValue(S3DTheme::SPACEVALUE);
      this->setSize(s, this->getHeight() + 
		    this->theme->getValue(S3DTheme::SPACEVALUE));
   }


   if ( (this->getHeight() == 0) || (this->autoResize == true) )
   {
      s = 0;
      for (i = 0; i < this->lcomp.size(); i++)
      {
	 if (this->lcomp[i] != 0)
 	    if (s < this->lcomp[i]->getY() + this->lcomp[i]->getHeight())
	       s = this->lcomp[i]->getY() + this->lcomp[i]->getHeight();
      }

      s += 4.0 * this->theme->getValue(S3DTheme::SPACEVALUE);
      this->setSize(this->getWidth() + 
		    this->theme->getValue(S3DTheme::SPACEVALUE), s);
   }

   return;
}


// --------------------------------------------------
unsigned long int S3DContainer::getIDNeeded(void)
{
   return 1000; /* The background is clickable, and the slots (max 100) and 
		   the other components (max 899) */
}

// --------------------------------------------------
void S3DContainer::draw(bool select)
{
   long long int df = 0;
   float r, s, sx, sy;
   float halfw, halfh;
   float x;
   int i;
   unsigned long int id, cnt0, cnt1;
   float sl0, sl1, sl2, sl3; // positions of the slot
   unsigned int flag;
   float zoom;

   // If the component is hided, it must hide every subcomponent and draw them
   if (this->getProperty(S3DComponent::HIDED))
   {
      glMatrixMode(GL_MODELVIEW);
      glPushMatrix(); // Protect the other components
      {
	 s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
	 glTranslatef(this->getX() + s, this->getY() + s, 0.0);
	 for (i = 0; i < this->lcomp.size(); i++)
	 {
	    if (this->allhided == false)
	       this->lcomp[i]->setProperty(S3DComponent::HIDED, 1);
	    this->lcomp[i]->draw(select);
	 }

	 this->allhided = true;
	 this->allshowed = false;
      }
      glMatrixMode(GL_MODELVIEW);
      glPopMatrix();
 
      return;
   }

   // If the container is showed again, it must show every contained element
   if (this->allshowed == false)
   {
      for (i = 0; i < this->lcomp.size(); i++)
	 this->lcomp[i]->setProperty(S3DComponent::HIDED, 0);
      this->allshowed = true;
      this->allhided = false;
   }

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   glPushMatrix(); // Protect other components


   if (this->firsttime == true)
   {
      zoom = (SDL_GetTicks() - this->starttimer) / 700.0;
      if (zoom <= 0)
	 zoom = 0.1;

      if (zoom >= 1.0)
      {
	 zoom = 1;
	 this->firsttime = false;
      }
      else
      { //BUG
/*
	 glTranslatef(this->getX(), this->getY(), 0.0);
	 glScalef(zoom, zoom, 1.0);
	 glTranslatef(-this->getX(), -this->getY(), 0.0);
*/
      }

   }
   
   s = 3.0 * this->theme->getValue(S3DTheme::SPACEVALUE);

   // Update the focus
   if ((this->focus == true) && (this->getFocus() == false))
   {
      this->focus = false;
      for (i = 0; i < this->lcomp.size(); i ++)
	 if (this->lcomp[i] != 0)
	    this->lcomp[i]->setFocus(false);
   }
   else
      this->focus = this->getFocus();

   halfw = this->getWidth() * 0.5;
   halfh = this->getHeight() * 0.5;
   if (select == true)
   {
      glDisable(GL_BLEND);

      id = this->getMinID(); // ID of the background
      glColor4ub (this->getRedFromId(id),
		  this->getGreenFromId(id),
		  this->getBlueFromId(id), 255);

      if (!this->getProperty(S3DComponent::NOROUNDCORNERS))
      {
	 r = this->theme->getValue(S3DTheme::CORNERVALUE);
	 S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 
					  this->getX() + halfw - s,
					  this->getY() + halfh,
					  0.0, 
					  halfw, halfh + s * 2, r);
      }
      else
      {
	 S3DPrimitive3D::drawBox(GL_TRIANGLE_FAN, 
				 this->getX(),
				 this->getY(),
				 0.0, 
				 this->getWidth(), this->getHeight(), 0.0);
      }

      /// Draw the slots if any
      s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
      sl0 =  this->getY() + s * 3;
      sl1 =  this->getX() + s * 3;
      sl2 =  this->getY() + this->getHeight() - s * 3;
      sl3 =  this->getX() + this->getWidth() - s * 3;
      for (i = 0; i < this->lslotPos.size(); i ++)
      {
	 switch (this->lslotPos[i])
	 {
	    case SLOT_VOLUM_INPUT: {
	       sy = sl0 + s * 5;
	       sx = this->getX() - s;
	    } break;

	    case SLOT_VOLUM_OUTPUT: {
	       sy = sl2 - s * 5;
	       sx = this->getX() + this->getWidth() + s;
	    } break;

	    case SLOT_PARAM_INPUT: {
	       sx = sl1 + s * 5;
	       sy = this->getY() - s;
	    } break;

	    case SLOT_PARAM_OUTPUT: {
	       sx = sl3 - s * 5;
	       sy = this->getY() + this->getHeight() + s;
	    } break;
	 }

	 id = this->getMinID() + i + 1; // ID of the slots
	 glColor4ub (this->getRedFromId(id),
		     this->getGreenFromId(id),
		     this->getBlueFromId(id), 255);

	 if ( (this->lslotPos[i] == SLOT_PARAM_OUTPUT) || 
	      (this->lslotPos[i] == SLOT_VOLUM_OUTPUT) )
	    S3DPrimitive3D::drawCircle(GL_TRIANGLE_FAN, 
				       sx + s, sy + s, 0.0, s*3);
	 else
	    S3DPrimitive3D::drawPlane(GL_POLYGON, 
				      sx - 4 * s, sy - 4 * s, 0.0, 
				      s*6, s*6);

	 switch (this->lslotPos[i])
	 {
	    case SLOT_VOLUM_INPUT: {
	       sl0 += s * 6.5;
	    } break;

	    case SLOT_VOLUM_OUTPUT: {
	       sl2 -= s * 6.5;
	    } break;

	    case SLOT_PARAM_INPUT: {
	       sl1 += s * 6.5;
	    } break;

	    case SLOT_PARAM_OUTPUT: {
	       sl3 -= s * 6.5;
	    } break;
	 }

      }

      glPushMatrix(); // Protect the other components
      {
	 s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
	 glTranslatef(this->getX() + s, this->getY() + s, 0.0);
	 for (i = 0; i < this->lcomp.size(); i++)
	    this->lcomp[i]->draw(true);
      }
      glPopMatrix();
   
   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      r = this->theme->getValue(S3DTheme::SHADOWSIZEVALUE);

      if (!this->getProperty(S3DContainer::NOSHADOW))
      {
	 if (this->shadow_v != 0)
	 {
	    glEnable(GL_TEXTURE_2D);
	    glBindTexture(GL_TEXTURE_2D, this->shadow_v);
	    glColor4f (1, 1, 1, 1);
            S3DPrimitive3D::drawPlane(GL_POLYGON, 
                                      this->getX() + this->getWidth() - r,
                                      this->getY() - r, 0.0, 
                                      r * 2, this->getHeight() - r * 2);
	 }
	 else
	 {
	    glDisable(GL_TEXTURE_2D);
	    glColor4f (0, 0, 0, 0.6);
	 }
         

	 
	 if (this->shadow_h != 0)
	 {
	    glEnable(GL_TEXTURE_2D);
	    glBindTexture(GL_TEXTURE_2D, this->shadow_h);
	    glColor4f (1, 1, 1, 1);

            S3DPrimitive3D::drawPlane(GL_POLYGON, 
                                      this->getX() + r,
				      this->getY() - r, 0.0, 
				      this->getWidth() - r * 2, r * 2);
	 }
	 else
	 {
	    glDisable(GL_TEXTURE_2D);
	    glColor4f (0, 0, 0, 0.6);
	 }

	 glDisable(GL_TEXTURE_2D);
      }


      glColor4f (this->theme->getColor(this->bgColor, 
				       S3DTheme::RED),
		 this->theme->getColor(this->bgColor,
				       S3DTheme::GREEN),
		 this->theme->getColor(this->bgColor,
				       S3DTheme::BLUE),
		 this->theme->getColor(this->bgColor,
				       S3DTheme::ALPHA));
      if (!this->getProperty(S3DComponent::HIDEDBACKGROUND))
      {
	 if (!this->getProperty(S3DComponent::NOROUNDCORNERS))
	 {
	    r = this->theme->getValue(S3DTheme::CORNERVALUE);
	    S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 
					     this->getX() + halfw - s,
					     this->getY() + halfh,
					     0.0, 
					     halfw, halfh + s * 2, r);
	 }
	 else
	 {
	    S3DPrimitive3D::drawBox(GL_TRIANGLE_FAN, 
				    this->getX(),
				    this->getY(),
				    0.0, 
				    this->getWidth(), this->getHeight(), 0.0);
	 }
      }

      if (this->getFocus())
      {
	 glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE));
      }
      else
      {
	 glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE) * 0.5);
      }
      glColor4f (this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::RED),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::GREEN),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::BLUE),
		 this->theme->getColor(S3DTheme::FRAMECOLOR, 
				       S3DTheme::ALPHA));

      // If the component is selected
      if (this->getProperty(S3DComponent::SELECTED) && 
	  !this->getProperty(S3DComponent::NOSELECTABLE))
      {
	 glEnable (GL_LINE_STIPPLE);
	 glLineStipple(1, this->getStippleSelected());
	 glLineWidth(2);
      }

      if ( (this->getProperty(S3DComponent::SELECTED)) ||
	   (!this->getProperty(S3DComponent::NOBORDER)) )
      {

	 if (!this->getProperty(S3DComponent::NOROUNDCORNERS))
	 {
	    r = this->theme->getValue(S3DTheme::CORNERVALUE);
	    S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP,  
					     this->getX() + halfw - s,
					     this->getY() + halfh,
					     0.0, 
					     halfw, halfh + s * 2, r);
	 }
	 else
	 {
	    S3DPrimitive3D::drawBox(GL_LINE_STRIP,  
				    this->getX(),
				    this->getY(),
				    0.0, 
				    this->getWidth(), this->getHeight(), 0.0);
	 }
      }


      /* If the component is selected disable the selection 
	 for others components */
      if (this->getProperty(SELECTED) && 
	  !this->getProperty(NOSELECTABLE))
      {
	 glDisable (GL_LINE_STIPPLE);
      }

      /// Draw the slots if any
      s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
      sl0 =  this->getY() + s * 3;
      sl1 =  this->getX() + s * 3;
      sl2 =  this->getY() + this->getHeight() - s * 3;
      sl3 =  this->getX() + this->getWidth() - s * 3;
      for (i = 0; i < this->lslotPos.size(); i ++)
      {
	 switch (this->lslotPos[i])
	 {
	    case SLOT_VOLUM_INPUT: {
	       sy = sl0 + s * 5;
	       sx = this->getX() - s;
	    } break;

	    case SLOT_VOLUM_OUTPUT: {
	       sy = sl2 - s * 5;
	       sx = this->getX() + this->getWidth() + s;
	    } break;

	    case SLOT_PARAM_INPUT: {
	       sx = sl1 + s * 5;
	       sy = this->getY() - s;
	    } break;

	    case SLOT_PARAM_OUTPUT: {
	       sx = sl3 - s * 5;
	       sy = this->getY() + this->getHeight() + s;
	    } break;
	 }

	 switch (this->lslotType[i])
	 {
	    case SLOT_STRING: {
	       flag = S3DTheme::BGINPUTTEXTCOLOR;
	    } break;

	    case SLOT_FLOAT: {
	       flag = S3DTheme::BGSLIDERCOLOR;
	    } break;

	    case SLOT_COLOR: {
	       flag = S3DTheme::BGCOLORPICKERCOLOR;
	    } break;

	    case SLOT_BOOL: {
	       flag = S3DTheme::BGCHECKBOXCOLOR;
	    } break;

	    case SLOT_VOLUME: {
	       flag = S3DTheme::BGVOLUMECOLOR;
	    } break;
	 }

	 glColor4f (this->theme->getColor(flag, 
					  S3DTheme::RED) * 0.9,
		    this->theme->getColor(flag, 
					  S3DTheme::GREEN) * 0.9,
		    this->theme->getColor(flag, 
					  S3DTheme::BLUE) * 0.9,
		    this->theme->getColor(flag, 
					  S3DTheme::ALPHA));
	 
	 if ( (this->lslotPos[i] == SLOT_PARAM_OUTPUT) || 
	      (this->lslotPos[i] == SLOT_VOLUM_OUTPUT) )
	    S3DPrimitive3D::drawCircle(GL_TRIANGLE_FAN, 
				       sx + s, sy + s, 0.0, s*3);
	 else
	    S3DPrimitive3D::drawPlane(GL_POLYGON, 
				      sx - 4 * s, sy - 4 * s, 0.0, 
				      s*6, s*6);


	 glColor4f (this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::RED),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::GREEN),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::BLUE),
		    this->theme->getColor(S3DTheme::FRAMECOLOR, 
					  S3DTheme::ALPHA));

	 glLineWidth (this->theme->getValue(S3DTheme::FRAMEWIDTHVALUE));

	 if ( (this->lslotPos[i] == SLOT_PARAM_OUTPUT) || 
	      (this->lslotPos[i] == SLOT_VOLUM_OUTPUT) )
	    S3DPrimitive3D::drawCircle(GL_LINE_STRIP, 
				       sx + s, sy + s, 0.0, s * 3);
	 else
	    S3DPrimitive3D::drawPlane(GL_LINE_STRIP, 
				      sx - 4 * s, sy - 4 * s, 0.0, 
				      s*6, s*6);

	 switch (this->lslotPos[i])
	 {
	    case SLOT_VOLUM_INPUT: {
	       sl0 += s * 6.5;
	    } break;

	    case SLOT_VOLUM_OUTPUT: {
	       sl2 -= s * 6.5;
	    } break;

	    case SLOT_PARAM_INPUT: {
	       sl1 += s * 6.5;
	    } break;

	    case SLOT_PARAM_OUTPUT: {
	       sl3 -= s * 6.5;
	    } break;
	 }

      }


      glLineWidth (this->theme->getValue(1));

      glPushMatrix(); // Protect the other components
      {
	 s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
	 glTranslatef(this->getX() + s, this->getY() + s, 0.0);
	 for (i = 0; i < this->lcomp.size(); i++)
	    this->lcomp[i]->draw(false);
      }
      glPopMatrix();
   }


   glPopMatrix(); // Protect other components
}


// --------------------------------------------------
unsigned int S3DContainer::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DContainer::eventMouseMotion (float x, float y, unsigned int button,
				     unsigned int idevent)
{
   unsigned int i;
   S3DComponent *c;

   if ( (this->moving == true) && (button == S3DComponent::LEFTBUTTON))
   {
      this->setPos(x + this->prevx, y + this->prevy);
      return;
   }

   this->setTip("");
   for (i = 0; i < this->lcomp.size(); i++)
   {
      c = this->lcomp[i];

      if (c != 0)
      {
	 if (c->getEvents() & S3DComponent::MOUSE_MOTION)
	 {
	    this->lcomp[i]->eventMouseMotion(x, y, button, idevent);
	 }

	 if ( (idevent >= c->getMinID()) && 
	      (idevent <= c->getMaxID()) )
	 {
	    this->setTip(c->getTip());
	 }
	 
      }

   }

   return;
}


// --------------------------------------------------
void S3DContainer::eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent)
{
   unsigned int i;
   S3DComponent *c, *changefocus = 0;
   unsigned long int indexfocus = 0;

   if ( (idevent == this->getMinID()) && 
	(!this->getProperty(S3DComponent::STATIC)) &&
	(button == S3DComponent::LEFTBUTTON) )
   {
      this->moving = true;
      this->prevx = -x + this->getX();
      this->prevy = -y + this->getY();
   }

   for (i = 0; i < this->lcomp.size(); i++)
   {
      c = this->lcomp[i];
      
      if ( (c != 0) && (c->getEvents() & S3DComponent::MOUSE_DOWN) &&
	   (idevent >= c->getMinID()) && (idevent <= c->getMaxID()) )
      {
	 this->lcomp[i]->eventMouseButtonDown(x, y, button, idevent);
	 c->setFocus(true);
	 indexfocus = i;
	 changefocus = c;
      }
      else
	 c->setFocus(false);
   }

   if (changefocus != 0)
   {
      this->lcomp[indexfocus] = this->lcomp[this->lcomp.size() - 1];
      this->lcomp[this->lcomp.size() - 1] = changefocus;
   }

   return;
}


// --------------------------------------------------
void S3DContainer::eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent)
{
   unsigned int i;
   S3DComponent *c;

   this->moving = false;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      c = this->lcomp[i];

      if ((c != 0) && (c->getEvents() & S3DComponent::MOUSE_UP))
	 this->lcomp[i]->eventMouseButtonUp(x, y, button, idevent);
   }

   return;
}

// --------------------------------------------------
void S3DContainer::eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent)
{
   int i;

   for (i = 0; i < this->lcomp.size(); i++)
      if ((this->lcomp[i] != 0) && (this->lcomp[i]->getFocus() == true) &&
	  (this->lcomp[i]->getEvents() & S3DComponent::KEY_DOWN))
	 this->lcomp[i]->eventKeyDown(x, y, key, idevent);
   return;
}


// --------------------------------------------------
void S3DContainer::addSlot (unsigned int pos, const char *name, 
			    unsigned int type)
{
   char *namecopy;

   if (name != 0)
   {
      namecopy = new char[strlen(name) + 2];
      memcpy(namecopy, name, strlen(name) + 1);
   }
   else
      namecopy = 0;

   this->lslotType.push_back(type);
   this->lslotPos.push_back(pos);
   this->lslotName.push_back(namecopy);
}


// --------------------------------------------------
const char *S3DContainer::getNameSlot (unsigned long int id)
{
   unsigned long int i;

   i = id - this->getMinID() - 1;
   return this->lslotName[i];
}


// --------------------------------------------------
unsigned int S3DContainer::getPosSlot (unsigned long int id)
{
   unsigned long int i;

   i = id - this->getMinID() - 1;
   return this->lslotPos[i];
}


// --------------------------------------------------
unsigned int S3DContainer::getTypeSlot (unsigned long int id)
{
   unsigned long int i;

   i = id - this->getMinID() - 1;
   return this->lslotType[i];  
}


// --------------------------------------------------
float S3DContainer::getXSlot (unsigned long int id)
{
   unsigned long int i;
   float sl0, sl1, sl2, sl3;
   float sx, sy, s;

   id = id - this->getMinID() - 1;

   s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
   sl0 =  this->getY() + s * 2.5;
   sl1 =  this->getX() + s * 2.5;
   sl2 =  this->getY() + this->getHeight() - s * 2.5;
   sl3 =  this->getX() + this->getWidth() - s * 2.5;
   for (i = 0; i < this->lslotPos.size(); i ++)
   {
      switch (this->lslotPos[i])
      {
	 case SLOT_VOLUM_INPUT: {
	    sy = sl0 + s * 5;
	    sx = this->getX() - s;
	 } break;
	    
	 case SLOT_VOLUM_OUTPUT: {
	    sy = sl2 - s * 5;
	    sx = this->getX() + this->getWidth() + s;
	 } break;
	    
	 case SLOT_PARAM_INPUT: {
	    sx = sl1 + s * 5;
	    sy = this->getY() - s;
	 } break;
	    
	 case SLOT_PARAM_OUTPUT: {
	    sx = sl3 - s * 5;
	    sy = this->getY() + this->getHeight() + s;
	 } break;
      }
      
      if (id == i)
	 return sx;

      switch (this->lslotPos[i])
      {
	 case SLOT_VOLUM_INPUT: {
	    sl0 += s * 6.5;
	 } break;
	    
	 case SLOT_VOLUM_OUTPUT: {
	    sl2 -= s * 6.5;
	 } break;
	    
	 case SLOT_PARAM_INPUT: {
	    sl1 += s * 6.5;
	 } break;
	    
	 case SLOT_PARAM_OUTPUT: {
	    sl3 -= s * 6.5;
	 } break;
      }
   }
}


// --------------------------------------------------
float S3DContainer::getYSlot (unsigned long int id)
{
   unsigned long int i;
   float sl0, sl1, sl2, sl3;
   float sx, sy, s;

   id = id - this->getMinID() - 1;

   s = this->theme->getValue(S3DTheme::SPACEVALUE);	 
   sl0 =  this->getY() + s * 2.5;
   sl1 =  this->getX() + s * 2.5;
   sl2 =  this->getY() + this->getHeight() - s * 2.5;
   sl3 =  this->getX() + this->getWidth() - s * 2.5;
   for (i = 0; i < this->lslotPos.size(); i ++)
   {
      switch (this->lslotPos[i])
      {
	 case SLOT_VOLUM_INPUT: {
	    sy = sl0 + s * 5;
	    sx = this->getX() - s;
	 } break;
	    
	 case SLOT_VOLUM_OUTPUT: {
	    sy = sl2 - s * 5;
	    sx = this->getX() + this->getWidth() + s;
	 } break;
	    
	 case SLOT_PARAM_INPUT: {
	    sx = sl1 + s * 5;
	    sy = this->getY() - s;
	 } break;
	    
	 case SLOT_PARAM_OUTPUT: {
	    sx = sl3 - s * 5;
	    sy = this->getY() + this->getHeight() + s;
	 } break;
      }
      
      if (id == i)
	 return sy;
      
      switch (this->lslotPos[i])
      {
	 case SLOT_VOLUM_INPUT: {
	    sl0 += s * 6.5;
	 } break;
	    
	 case SLOT_VOLUM_OUTPUT: {
	    sl2 -= s * 6.5;
	 } break;
	    
	 case SLOT_PARAM_INPUT: {
	    sl1 += s * 6.5;
	 } break;
	    
	 case SLOT_PARAM_OUTPUT: {
	    sl3 -= s * 6.5;
	 } break;
      }
   }
}


// --------------------------------------------------
bool S3DContainer::isSlot (unsigned long int id)
{
//   std::cerr << this->getMinID() << std::endl;
   if ( (id - this->getMinID() > 1) &&
	(id - this->getMinID() < 101) )
      return true;

   return false;
}


// --------------------------------------------------
unsigned long int S3DContainer::getSlotNumber (unsigned long int id)
{
   return id - 1 - this->getMinID();
}


// --------------------------------------------------
void S3DContainer::setAutoresize (bool autoresize)
{
   this->autoResize = autoresize;
}


// --------------------------------------------------
void S3DContainer::eventIDChanged (long long int df)
{
   unsigned long int i;

   for (i = 0; i < this->lcomp.size(); i++)
      if (this->lcomp[i] != 0)
	 this->lcomp[i]->setID(this->lcomp[i]->getMinID() + df, 
			       this->lcomp[i]->getMaxID() + df);
   return;
}


// --------------------------------------------------
void S3DContainer::setBGTheme (unsigned int bg)
{
   this->bgColor = bg;
}


// --------------------------------------------------
void S3DContainer::setShadow (GLuint sh, GLuint sv)
{
   this->shadow_h = sh;
   this->shadow_v = sv;
}


// --------------------------------------------------
void S3DContainer::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DContainer::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DContainer::listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n)
{
   // Send in broadcast the message
   this->sendEvent(sender, msg, x, y, button, key, data, n);

//   std::cerr << "x DEBUG: Event " << msg << " from " << sender 
//	     << " to " << this << "\n";

   return;
}

