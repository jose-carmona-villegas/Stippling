#ifndef __GROUPCONTAINER__
#define __GROUPCONTAINER__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "primitive3d.hh"
#include "component.hh"
#include "theme.hh"
#include "container.hh"
#include "selection.hh"
#include "label.hh"

/** @class   S3DGroupContainer groupcontainer.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a group of container
 *
 *  @bug     No bugs detected yet
 */

class S3DGroupContainer : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DGroupContainer(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DGroupContainer(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DGroupContainer(void);
      
      /**
       * @post Add a new component to the manager
       * @param[in] c The component
       */
      void add(S3DComponent *c); 

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @pre tip must be a valid text
       * @param[in] text The new text of the tip
       * @post Change the text of the tip
       */
      void setTipText (const char *text);       


      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "remove_arrow"
       *            (when an arrow is removed from a slot)
       *            data = array[orig, dst] (S3DContainer *[2]) [do not free]
       *            n = position in the slot (using getPosSlot)
       *       -    msg = "replace_arrow"
       *            (when an arrow is moved from a slot to another)
       *            data = array[orig, dst] (S3DContainer *[2]) [do not free]
       *            n = position in the slot (using getPosSlot)
       *       -    msg = "add_arrow"
       *            (when an arrow is added to a slot)
       *            data = array[orig, dst] (S3DContainer *[2]) [do not free]
       *            n = position in the slot (using getPosSlot)
       *       -    msg = "killed"
       *            (when a component is going to be killed)
       *            data = 0
       *            n = 0 => the component must not be removed in the listener
       *            n > 0 => the component must be removed in the listener
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

      /**
       * @pre c0 and c1 must be valid containers, 
       *      and slotNumber0 and slotNumber1 must be valid slots
       * @param[in] c0 The first container
       * @param[in] c1 The first container
       * @param[in] slotNumber0 The slot of c0
       * @param[in] slotNumber1 The slot of c1
       * @param[in] sendEvent Send a event if it is true
       * @post Connect c0 to c1
       */
      void connectContainers (S3DContainer *c0, 
			      S3DContainer *c1,
			      unsigned long int slotNumber0,
			      unsigned long int slotNumber1,
			      bool sendEvent = true);



      /**
       * @pre c0 must be a valid container, and slotNumber0 must be a valid slot
       * @param[in] c0 The first container
       * @param[in] c1 The new container
       * @param[in] slotNumber0 The slot of c0 to swap
       * @param[in] slotNumber1 The slot of c1 to swap
       * @post True if the slots are swapped
       */
      bool swapOutputs (S3DContainer *c0, S3DContainer *c1, 
			unsigned long int slotNumber0, 
			unsigned long int slotNumber1);


      /**
       * @pre c0 must be a valid container, and slotNumber0 must be a valid slot
       * @param[in] c0 The container
       * @param[in] slotNumber0 The slot of c0 to empty
       * @post True if the slot of c0 is disconected
       */
      bool disconnectContainers (S3DContainer *c0, 
				 unsigned long int slotNumber0);


      /**
       * @post True if the selected elements have been deleted
       *       False if there is no selected items
       */
      bool deleteGroup (void);

      /**
       * @pre c must be a valid container
       * @param[in] c The container
       * @post True if the container has been removed, false in other case
       */
      bool deleteContainer (S3DContainer *c);

      /**
       * @param[in] i The index of the component
       * @post The component of index i
       */
      S3DComponent *getComponent(unsigned long int i);

      /**
       * @post The number of components
       */
      unsigned long int getNComponents(void);

      /**
       * @post Draw the arrows when the boxes are connected
       */
      void drawArrows(void);


   private:
      S3DTheme *theme; // theme
      std::vector<S3DVector *> lbegArrow; /// First point of the arrow
      std::vector<S3DVector *> lendArrow; /// Final point of the arrow
      std::vector<S3DComponent *> lbegComponent; /// First component 
      std::vector<S3DComponent *> lendComponent; /// Final component
      std::vector<unsigned long int> lbegSlot; /// Final component
      std::vector<unsigned long int> lendSlot; /// Final component
      std::vector<S3DComponent *> lcomp; /// Containers
      unsigned long int freeid; /// Ids of the components
      bool drawingArrow; /// If it draws a temporal arrow
      float sx,sy; /// Beginning of the arrow, area or selection
      float ex,ey; /// End of the arrow or selection
      S3DContainer *bComp; /// First container
      S3DVector *bArr;  /// First position of the arrow
      S3DSelection *selection;  /// Selection
      bool drawingSelection;  /// Selection
      unsigned long int bSlot;  /// First slot
      float zoom; /// Zoom
      float xoff, yoff; /// Offset of the screen
      bool movingArea; /// Moving area flag
      S3DLabel *tip; /// Tip in the mouse
      S3DLabel *tip2; /// Tip in the mouse
      float tipx, tipy; /// Position of the tip
      std::vector<S3DListener *> toRemove; /** Element to remove in
					       the next visualization **/
};


#endif
