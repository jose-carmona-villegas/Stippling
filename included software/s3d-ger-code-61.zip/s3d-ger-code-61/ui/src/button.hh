#ifndef __BUTTON__
#define __BUTTON__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "component.hh"
#include "theme.hh"


/** @class   S3DButton button.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is an slider component
 *
 *  @bug     No bugs detected yet
 */

class S3DButton : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DButton(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DButton(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DButton(void);

      /**
       * param[in] n The index of the texture
       * @post Change the image of the button when it is pressed
       */
      void setIDPressed(GLuint n);

      /**
       * param[in] n The index of the texture
       * @post Change the image of the button when it is released
       */
      void setIDReleased(GLuint n);

      /**
       * param[in] n The index of the texture
       * @post Change the image of the button when it is released in tristate
       */
      void setIDReleasedOFF(GLuint n);

      /**
       * param[in] n The index of the texture
       * @post Change the image of the button when the mouse is over it
       */
      void setIDMouseOver(GLuint n);

      /**
       * param[in] n The index of the texture
       * @post Change the image of the button when the mouse 
       *       is over it in tristate
       */
      void setIDMouseOverOFF(GLuint n);

      /**
       * @param[in] n The index of the texture
       * @post Change the image of the button when the mouse 
       *       is dragging the component
       */
      void setIDDragged(GLuint n);

      /**
       * @post The state of the button
       */
      bool getState(void);

      /**
       * @post s The state of the button
       * @post Change the state of the button
       */
      void setState(bool s);

      /**
       * @param[in] s If it has states or not
       * @post Change the button to tristate or not tristate
       */
      void setTristate(bool s);

      /**
       * param[in] s If it is draggable or not
       * @post Change the button to draggable or not
       */
      void setDraggable(bool s);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "button_pressed"
       *            data = undefined
       *            n = undefined
       *       -    msg = "element_dropped"
       *            data = pointer to the id of the texture (GLuint *) 
       *                   [do not free] 
       *            n = id of the element where it was released
       *       -    msg = "button_state_changed"
       *            data = pointer to the state (boolean *) [do not free]
       *            n = undefined
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

   private:
      S3DTheme *theme; // theme
      Uint32 cTimer; /// Timer for the component
      GLuint idDragged; /// Texture when dragged
      GLuint idPressed; /// Texture when pressed
      GLuint idReleased; /// Texture when released
      GLuint idMouseOver; /// Texture when mouse is over
      GLuint idReleasedOFF; /// Texture when released in tristate
      GLuint idMouseOverOFF; /// Texture when mouse is over in tristate
      bool pressed; /// Button pressed
      bool mouseOver; /// Mouse is over
      bool tristate; /// If it is a tristate button or not
      bool draggable; /// If it is a draggable button or not
      bool state; /// State on a tristate button
      bool dragging; /// If it is dragging or not
      float prevx; /// The x previous position
      float prevy; /// The y previous position
      float mx; /// The x position of the mouse
      float my; /// The y position of the mouse
};


#endif
