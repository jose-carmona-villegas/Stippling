#include "menu.hh"


// --------------------------------------------------
S3DMenu::S3DMenu(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->index = 0;
   this->max = 7;
   this->freeid = 2;
}

// --------------------------------------------------
S3DMenu::S3DMenu(S3DTheme *theme, float x, float y, float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->theme = theme;

   this->cTimer = this->updateTimer();
   this->index = 0;
   this->max = 7;
   this->freeid = 2;
}


// --------------------------------------------------
S3DMenu::~S3DMenu()
{

}


// --------------------------------------------------
unsigned int S3DMenu::getType(unsigned long int id)
{
   return S3DComponent::MENU;
}


// --------------------------------------------------
unsigned long int S3DMenu::getIDNeeded(void)
{
   // Only the slider and the text are clickable
   return 1000; /* the borders move the menu */
}


// --------------------------------------------------
void S3DMenu::draw(bool select)
{
   float r, s;
   float w, v; 
   unsigned int id;
   unsigned int i;

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   if (select == true)
   {
      glDisable(GL_BLEND);

      glPushMatrix();
      {
	 w = 0;
	 glTranslatef(this->getX(), this->getY(), 0.0);
	 for (i = 0; i < this->lcomp.size(); i++)
	 {
	    glTranslatef(w, 0.0, 0.0);
	    this->lcomp[i]->draw(select);
	    w = this->lcomp[i]->getWidth();
	 }
      }
      glPopMatrix();

   }
   else
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glPushMatrix();
      {
	 w = 0;
	 glTranslatef(this->getX(), this->getY(), 0.0);
	 for (i = 0; i < this->lcomp.size(); i++)
	 {
	    glTranslatef(w, 0.0, 0.0);
	    this->lcomp[i]->draw(select);
	    w = this->lcomp[i]->getWidth();
	 }
      }
      glPopMatrix();
   }
   
}


// --------------------------------------------------
void S3DMenu::add (S3DComponent *c)
{
   unsigned long int aux0, aux1;

   if (c != 0)
   {
      aux0 = this->getMinID() + this->freeid;
      aux1 = aux0 + c->getIDNeeded() - 1;

      this->lcomp.push_back(c);   
      this->setSize(this->getWidth() + c->getWidth(),
		    this->getHeight() + c->getHeight());

      c->setID(aux0, aux1);
      this->freeid += c->getIDNeeded();

      this->addListener(c);
   }
}


// --------------------------------------------------
void S3DMenu::setMaxItems (unsigned long int n)
{
   this->max = n;
}


// --------------------------------------------------
unsigned int S3DMenu::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DMenu::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   float w, v, s;

   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      this->lcomp[i]->eventMouseMotion (x, y, buttons, idevent);
   }

 
   return;
}


// --------------------------------------------------
void S3DMenu::eventMouseButtonDown (float x, float y, unsigned int button,
				     unsigned int idevent)
{
   float w; 

   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      if ( (idevent >= this->getMinID()) &&
	   (idevent <= this->getMaxID()) )
	 this->lcomp[i]->eventMouseButtonDown (x, y, button, idevent);
   }


   return;
}


// --------------------------------------------------
void S3DMenu::eventMouseButtonUp (float x, float y, unsigned int button,
				   unsigned int idevent)
{
   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      this->lcomp[i]->eventMouseButtonUp (x, y, button, idevent);
   }

   return;
}

// --------------------------------------------------
void S3DMenu::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{
   unsigned int i;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      if ( (this->lcomp[i] != 0) && (this->lcomp[i]->getFocus() == true) )
	 this->lcomp[i]->eventKeyDown (x, y, key, idevent);
   }
}


// --------------------------------------------------
void S3DMenu::eventIDChanged (long long int difference)
{
   unsigned int i;
   S3DComponent *p;

   for (i = 0; i < this->lcomp.size(); i++)
   {
      p = this->lcomp[i];

      p->setID(p->getMinID() + difference, p->getMaxID() + difference);
   }
   return;
}


// --------------------------------------------------
void S3DMenu::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DMenu::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DMenu::listenEvent(S3DListener *sender, const char *msg, 
			  float x, float y, unsigned int button, 
			  unsigned int key, 
			  void *data, unsigned int n)
{
   // Send in broadcast the message
   this->sendEvent(sender, msg, x, y, button, key, data, n);

   return;
}

