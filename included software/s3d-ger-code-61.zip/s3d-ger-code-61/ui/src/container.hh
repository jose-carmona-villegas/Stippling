#ifndef __CONTAINER__
#define __CONTAINER__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "primitive3d.hh"
#include "component.hh"
#include "theme.hh"

/** @class   S3DContainer container.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a container, this container can have more containers
 *           or other components inside
 *
 *  @bug     No bugs detected yet
 */

class S3DContainer : public S3DComponent {
   public:

      /// Slot position:
      static const unsigned int SLOT_VOLUM_INPUT     = 0x00;

      /// Slot position:
      static const unsigned int SLOT_VOLUM_OUTPUT    = 0x01;

      /// Slot position:
      static const unsigned int SLOT_PARAM_INPUT     = 0x02;

      /// Slot position:
      static const unsigned int SLOT_PARAM_OUTPUT    = 0x03;

      /// Type of the slot:
      static const unsigned int SLOT_STRING    = 0x00;

      /// Type of the slot:
      static const unsigned int SLOT_FLOAT     = 0x01;

      /// Type of the slot:
      static const unsigned int SLOT_COLOR     = 0x02;

      /// Type of the slot:
      static const unsigned int SLOT_BOOL      = 0x03;

      /// Type of the slot:
      static const unsigned int SLOT_VOLUME    = 0x04;


     
      /**
       * @pre id must be a valid ID
       * @param[in] id The id to convert
       * @post The slot from an id
       */
      static unsigned long int getSlotIDfromID(unsigned long int id);



      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DContainer(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DContainer(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DContainer(void);

      /**
       * @post Init the object
       */
      void init(void);

      /**
       * @param[in] c The component
       * @post Add a new component to the manager
       */
      void add(S3DComponent *c); 

      /**
       * @pre c must be a valid component
       * @param[in] c The component to erase
       * @post Search and remove the component
       */
      void removeComponent(S3DComponent *c);

      /**
       * @param[in] i The position
       * @post The component in the position i
       */
      S3DComponent *getComponent(unsigned int i); 

      /**
       * @post The number of components inside the container
       */
      unsigned int getNComponents(void);

      /**
       * @param[in] id The id of the component
       * @post The number of the slot from the id
       */
      unsigned long int getSlotNumber(unsigned long int id);

      /**
       * @param[in] select If select is true, the colors are changed to the id
       * @post Draw the component
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    NONE
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key,  
			       void *data, unsigned int n);

      /**
       * @param[in] pos The position of the slot: 
       *                   SLOT_VOLUM_INPUT
       *                   SLOT_VOLUM_OUTPUT
       *                   SLOT_PARAM_INPUT
       *                   SLOT_PARAM_OUTPUT
       * @param[in] name A valid name for the slot
       * @param[in] type The type of the slot:
       *                  SLOT_STRING
       *                  SLOT_FLOAT
       *                  SLOT_COLOR
       *                  SLOT_BOOL
       *                  SLOT_VOLUME
       * @post Add a new slot to the component
       */
      void addSlot (unsigned int pos, const char *name, unsigned int type);

      /**
       * @param[in] id The id of the slot
       * @post The name of the slot
       */
      const char *getNameSlot (unsigned long int id);

      /**
       * @param[in] id The id of the slot
       * @post The position of the slot
       */
      unsigned int getPosSlot (unsigned long int id);

      /**
       * @param[in] id The id of the slot
       * @post If it is an slot or not
       */
      bool isSlot (unsigned long int id);
      
      /**
       * @param[in] id The id of the slot
       * @post The type of the slot
       */
      unsigned int getTypeSlot (unsigned long int id);

      /**
       * @param[in] id The id of the slot
       * @post The x position of the slot
       */
      float getXSlot (unsigned long int id);

      /**
       * @param[in] id The id of the slot
       * @post The y position of the slot
       */
      float getYSlot (unsigned long int id);

      /**
       * @param[in] autoresize If true it will auto resize
       * @post Change the auto-resize flag 
       */
      void setAutoresize (bool autoresize);

      /**
       * @param[in] bg The flag with the color of the background
       * @post Change the background color of the component
       */
      void setBGTheme (unsigned int bg);

      /**
       * @pre sh and sv must be valid textures or 0
       * @param[in] sh The horizontal shadow texture
       * @param[in] sv The vertical shadow texture
       * @post Change the background color of the component
       */
      void setShadow (GLuint sh, GLuint sv);

      /**
       * @post The number of slots
       */
      unsigned long int getNSlots (void);      

   private:
      S3DTheme *theme; // theme
      std::vector<S3DComponent *> lcomp; /// Components of the interface
      std::vector<unsigned int> lslotType; /// Type of the slots
      std::vector<unsigned int> lslotPos; /// Position of the slots
      std::vector<char *> lslotName; /// Name of the slot
      unsigned long int freeid; /// The next freeid
      bool focus; /// Manage the focus of the children
      float prevx, prevy;
      bool moving; /// If it is moving or not
      bool autoResize; /// If it is on the component will autoresize
      unsigned int bgColor; /// The ID of the background color
      Uint32 starttimer; /// Timer for animations      
      bool firsttime; /// If the component is drawn by first time
      GLuint shadow_h, shadow_v; // The textures of the shadow
      bool allhided; /// Verify if all the components have been hided
      bool allshowed; /// Verify if all the components have been showed
};


#endif
