#include "groupcontainer.hh"


// --------------------------------------------------
S3DGroupContainer::S3DGroupContainer(S3DTheme *theme) 
   : S3DComponent (0, 0, 0, 0)
{
   this->theme = theme;
   this->freeid = 1;
   this->sx = this->sy = this->ex = this->ey = 0.0;
   this->drawingArrow = false;

   this->movingArea = false;
   this->drawingSelection = false;
   this->selection = new S3DSelection();

   this->tip = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.8);
   this->tip->setText("");
   this->tipx = this->tipy = 0.0;


   this->tip2 = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.8);
   this->tip2->setText("");


   this->zoom = 0.9;
   this->xoff = 0.0;
   this->yoff = 0.0;
}

// --------------------------------------------------
S3DGroupContainer::S3DGroupContainer(S3DTheme *theme, float x, 
				     float y, float w, float h)
   : S3DComponent (x, y, w, h)
{
   this->theme = theme;
   this->freeid = 1;
   this->sx = this->sy = this->ex = this->ey = 0.0;
   this->drawingArrow = false;

   this->movingArea = false;
   this->drawingSelection = false;
   this->selection = new S3DSelection();

   this->tip = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.8);
   this->tip->setText("");
   this->tipx = this->tipy = 0.0;

   this->tip2 = new S3DLabel(theme->getFont(S3DTheme::LABELFONT), 0.8);
   this->tip2->setText("");


   this->zoom = 0.9;
   this->xoff = 0.0;
   this->yoff = 0.0;
}


// --------------------------------------------------
S3DGroupContainer::~S3DGroupContainer()
{
   if (this->selection != 0)
      delete this->selection;
}


// --------------------------------------------------
unsigned int S3DGroupContainer::getType(unsigned long int id)
{
   if (id == this->getMinID())
      return S3DComponent::GROUPCONTAINER;

   return this->lcomp[id + this->getMinID()]->getType(id);
}



// --------------------------------------------------
unsigned long int S3DGroupContainer::getNComponents(void)
{
   return this->lcomp.size();
}


// --------------------------------------------------
S3DComponent *S3DGroupContainer::getComponent(unsigned long int i)
{
   if (i >= this->lcomp.size())
      return 0;
   
   return this->lcomp[i];
}


// --------------------------------------------------
void S3DGroupContainer::add(S3DComponent *c)
{
   unsigned int aux0, aux1;
   int i;
   float s;

   aux0 = this->getMinID() + this->freeid;
   aux1 = aux0 + c->getIDNeeded() - 1;

   if ( (c != 0) /*&& (this->freeid + c->getIDNeeded() < 10000)*/ )
   {
      c->setID(aux0, aux1);
      this->freeid += c->getIDNeeded();

      this->lcomp.push_back(c);
      
      c->addListener(this);
   }

   return;
}


// --------------------------------------------------
unsigned long int S3DGroupContainer::getIDNeeded(void)
{
   return 1000000; /* the components inside */
}

// --------------------------------------------------
void S3DGroupContainer::draw(bool select)
{
   int i;
   unsigned long int id;
   long long int df = 0;

   // Clean elements before drawing them
   while (this->toRemove.size() > 0)
   {
      delete this->toRemove[this->toRemove.size() - 1];
      this->toRemove.pop_back();
   }

   glDisable(GL_TEXTURE_1D);
   glDisable(GL_TEXTURE_2D);
   glDisable(GL_TEXTURE_3D);

   glPushMatrix();
   {
      glScalef (this->zoom, this->zoom, 1.0);
      glTranslatef (this->xoff, this->yoff, 0.0);

      if (select == true)
      {
	 id = this->getMinID(); // ID of the background
	 glClearColor (this->getRedFromId(id) / 255.0,
		       this->getGreenFromId(id)/ 255.0,
		       this->getBlueFromId(id) / 255.0, 1.0);
	 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      }

      for (i = 0; i < this->lcomp.size(); i++)
      {
	 glPushMatrix();
	 if (this->lcomp[i]->getProperty(S3DComponent::NOMOVE))
	    glTranslatef (-this->xoff, -this->yoff, 0.0);

	 if (this->lcomp[i]->getProperty(S3DComponent::NOZOOM))
	    glScalef (1 / (float) this->zoom, 
		      1 / (float) this->zoom, 1.0);

	 this->lcomp[i]->draw(select);
	 glPopMatrix();
      }

      if (select == false)
      {
	 this->drawArrows();

	 if (this->drawingSelection == true)
	 {
	    this->selection->draw();
	 }

	 glPushMatrix();
	 {
	    glTranslatef(this->tipx, this->tipy, 0.0);

//	    glTranslatef(-this->xoff, -this->yoff, 0.0);
	    glScalef(1.0 / this->zoom, 1.0 / this->zoom, 1.0);

	    glTranslatef(0, -48, 0);

	    
	    glEnable(GL_BLEND);
	    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	    glDisable(GL_TEXTURE_2D);
	    glColor4f(0.8, 0.9, 1.0, 0.5);
	    S3DPrimitive3D::drawPlane(GL_POLYGON, 0, 0, 0.0, 
				      this->tip->getWidth(), 
				      this->tip->getHeight());
	    glDisable(GL_BLEND);
	    this->tip->draw();


	    glTranslatef(-this->tip2->getWidth() * 0.5, -16, 0);

	    glEnable(GL_BLEND);
	    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	    glDisable(GL_TEXTURE_2D);
	    glColor4f(1.0, 0.8, 0.8, 0.5);
	    S3DPrimitive3D::drawPlane(GL_POLYGON, 0, 0, 0.0, 
				      this->tip2->getWidth(), 
				      this->tip2->getHeight());
	    glDisable(GL_BLEND);
	    this->tip2->draw();
	 }
	 glPopMatrix();
      }

   }
   glPopMatrix();
 
}


// --------------------------------------------------
void S3DGroupContainer::drawArrows(void)
{
   unsigned int i, j;
   float x0, y0;
   float x1, y1;
   GLfloat *ctrlPoints;

   ctrlPoints = new GLfloat[4 * 3];



   if (this->drawingArrow == true)
   {
      glDisable(GL_TEXTURE_1D);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_TEXTURE_3D);
      glColor4f(0.5, 0.0, 0.0, 0.7);
      glEnable(GL_LINE_STIPPLE);
      glLineStipple(1, 0xFCFC);
      glLineWidth(3.0 * zoom);

      x0 = this->sx;
      y0 = this->sy;
      x1 = this->ex;
      y1 = this->ey;

      // Draw bezier
      ctrlPoints[0] = x0;
      ctrlPoints[1] = y0;
      ctrlPoints[2] = 0.0;

      ctrlPoints[3] = (x1 - x0) / 3 + x0;
      ctrlPoints[4] = (y1 - y0) / 2 + y0;
      ctrlPoints[5] = 0.0;

      ctrlPoints[6] = (x1 - x0) / 3 * 2 + x0;
      ctrlPoints[7] = -(y1 - y0) / 2 + y0;
      ctrlPoints[8] = 0.0;

      ctrlPoints[9]  = x1;
      ctrlPoints[10] = y1;
      ctrlPoints[11] = 0.0;

      glMap1f (GL_MAP1_VERTEX_3, 0.0, 0.99, 3, 4, ctrlPoints);
      glEnable(GL_MAP1_VERTEX_3);
      glBegin( GL_LINE_STRIP );
      {
	 for (j = 0; j < 100; j++)
	    glEvalCoord1f ((GLfloat) j / 100.0);
      }
      glEnd();
      glDisable (GL_MAP1_VERTEX_3);

/*
      S3DPrimitive3D::drawConnector(x1, y1, 0.0,
//				    x0, y0, 0.0,
				    x1, y1, 0.0,
				    6, false, true);
*/
      glLineWidth(1.0);
      glLineStipple(1, 0xF0F0);
      glDisable(GL_LINE_STIPPLE);
   }

   
   for (i = 0; i < this->lbegComponent.size(); i ++)
   {
      if ( (!this->lbegComponent[i]->getProperty(S3DComponent::HIDED)) &&
	   (!this->lendComponent[i]->getProperty(S3DComponent::HIDED)) )
      {
	 glDisable(GL_TEXTURE_1D);
	 glDisable(GL_TEXTURE_2D);
	 glDisable(GL_TEXTURE_3D);
	 glColor4f(0.0, 0.0, 0.0, 0.8);
	 glLineWidth(3.0 * zoom);
	 
	 x0 = this->lbegComponent[i]->getX() + this->lbegArrow[i]->X();
	 y0 = this->lbegComponent[i]->getY() + this->lbegArrow[i]->Y();
	 x1 = this->lendComponent[i]->getX() + this->lendArrow[i]->X();
	 y1 = this->lendComponent[i]->getY() + this->lendArrow[i]->Y();

	 if (this->lbegComponent[i]->getProperty(S3DComponent::NOZOOM))
	 {
	    x0 /= this->zoom; 
	    y0 /= this->zoom; 
	 }

	 if (this->lendComponent[i]->getProperty(S3DComponent::NOZOOM))
	 {
	    x1 /= this->zoom; 
	    y1 /= this->zoom; 
	 }

	 if (this->lbegComponent[i]->getProperty(S3DComponent::NOMOVE))
	 {
	    x0 -= this->xoff; 
	    y0 -= this->yoff; 
	 }

	 if (this->lendComponent[i]->getProperty(S3DComponent::NOMOVE))
	 {
	    x1 -= this->xoff; 
	    y1 -= this->yoff; 
	 }

	 // Draw bezier
	 ctrlPoints[0] = x0;
	 ctrlPoints[1] = y0;
	 ctrlPoints[2] = 0.0;

	 ctrlPoints[3] = (x1 - x0) / 3 + x0;
	 ctrlPoints[4] = (y1 - y0) / 2 + y0;
	 ctrlPoints[5] = 0.0;

	 ctrlPoints[6] = (x1 - x0) / 3 * 2 + x0;
	 ctrlPoints[7] = -(y1 - y0) / 2 + y0;
	 ctrlPoints[8] = 0.0;

	 ctrlPoints[9]  = x1;
	 ctrlPoints[10] = y1;
	 ctrlPoints[11] = 0.0;

	 glMap1f (GL_MAP1_VERTEX_3, 0.0, 0.99, 3, 4, ctrlPoints);
	 glEnable(GL_MAP1_VERTEX_3);
	 glBegin( GL_LINE_STRIP );
	 {
	    for (j = 0; j < 100; j++)
	       glEvalCoord1f ((GLfloat) j / 100.0);
	 }
	 glEnd();
	 glDisable (GL_MAP1_VERTEX_3);
/*
  S3DPrimitive3D::drawConnector(x1, y1, 0.0,
//				    x0, y0, 0.0,
x1, y1, 0.0, 6, false, true);	    
*/
	 glLineWidth(1.0);
      }
   }
   delete [] ctrlPoints;
   
   return;
}


// --------------------------------------------------
unsigned int S3DGroupContainer::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DGroupContainer::eventMouseMotion (float x, float y, unsigned int button,
					  unsigned int idevent)
{
   unsigned int i;
   S3DComponent *c;
   S3DContainer *ct;
   float x2, y2;
   

   if (this->movingArea == true)
   {
      this->xoff = (x / zoom - this->sx);
      this->yoff = (y / zoom - this->sy);

      return;
   }

   x /= this->zoom;
   y /= this->zoom;
   x -= this->xoff;
   y -= this->yoff;


   this->tipx = x;
   this->tipy = y;


   if (this->drawingArrow == true)
   {
      this->ex = x;
      this->ey = y;

      this->tip->setText("Moving arrow...");
      return;
   }

   if (this->drawingSelection == true)
   {
      this->selection->setSize(x - this->selection->getX(), 
			       y - this->selection->getY());
      this->tip->setText("Selecting...");
      return;
   }

   if (idevent == this->getMinID())
   {
      this->tip->setText("");
      if (button == 0)
	 return;
   }

   for (i = 0; i < this->lcomp.size(); i++)
   {
      c = this->lcomp[i];

      if (c != 0)
      {
	 if (c->getEvents() & S3DComponent::MOUSE_MOTION)
	 {
	    x2 = x;
	    y2 = y;
	    
	    if (c->getProperty(S3DComponent::NOMOVE))
	    {
	       x2 += this->xoff;
	       y2 += this->yoff;
	    }
	    
	    if (c->getProperty(S3DComponent::NOZOOM))
	    {
	       x2 *= zoom;
	       y2 *= zoom;
	    }
	    
	    this->lcomp[i]->eventMouseMotion(x2, y2, button, idevent);
	 }
	 
	 
	 if ( (idevent >= c->getMinID()) && 
	      (idevent <= c->getMaxID()) && (button == 0))
	 {
	    switch(c->getType(idevent))
	    {
	       case S3DComponent::SLOT: {
		  ct = (S3DContainer *) this->lcomp[i];
		  if (ct->getNameSlot(idevent) != 0)
		     this->tip->setText(ct->getNameSlot(idevent));
		  else
		     this->tip->setText("");
	       } break;

	       default: {
		  if (c->getTip() != 0)
		  {
		     this->tip->setText(c->getTip());
		  }
		  else
		     this->tip->setText("");
	       } break;
	    }
	 }
      }
   }

   return;
}


// --------------------------------------------------
void S3DGroupContainer::setTipText(const char *text)
{
   if (this->tip2 != 0)
      this->tip2->setText(text);

   return;
}


// --------------------------------------------------
void S3DGroupContainer::eventMouseButtonDown (float x, float y, 
					      unsigned int button,
					      unsigned int idevent)
{
   unsigned int i, j;
   S3DComponent *c, *changefocus = 0;
   S3DContainer *ct;
   unsigned long int id;
   unsigned long int indexfocus = 0;
   S3DContainer **data;
   unsigned int xorg, yorg;
   float x2, y2;
   float x0, y0;

   this->setTipText ("");

   if (button == S3DComponent::MIDDLEBUTTON)
   {
      this->movingArea = true;
      this->sx = (x / zoom  - this->xoff);
      this->sy = (y / zoom - this->yoff);
      return;
   }

   xorg = x;
   yorg = y;

   x /= this->zoom;
   y /= this->zoom;
   x -= this->xoff;
   y -= this->yoff;

   if ( (button == S3DComponent::WHEELUPBUTTON) && (this->zoom < 8.0) )
   {
      this->zoom += 0.05;
      return;
   }
   else
      if ( (button == S3DComponent::WHEELDOWNBUTTON) && (this->zoom >= 0.1) )
      {
	 this->zoom -= 0.05;
	 return;
      }
      
   if ( (this->getMinID() == idevent) && 
	(button == S3DComponent::LEFTBUTTON) )
   {
      this->drawingSelection = true;
      this->selection->setPos(x, y, 0.0);
      this->selection->setSize(0, 0);
      return;
   }


   for (i = 0; i < this->lcomp.size(); i++)
   {
      c = this->lcomp[i];

      if ( (idevent > this->getMinID()) &&
	   (idevent >= c->getMinID()) && (idevent <= c->getMaxID()) &&
	   (c->getType(idevent) == S3DComponent::SLOT) )
      {
	 ct = (S3DContainer *) c;

	 // Test the kind of input
	 if ( (ct->getPosSlot(idevent) == S3DContainer::SLOT_VOLUM_OUTPUT) ||
	      (ct->getPosSlot(idevent) == S3DContainer::SLOT_PARAM_OUTPUT) )
	 {
	    // Take the begining of the arrow:
	    this->drawingArrow = true;
	    this->ex = this->sx = x;
	    this->ey = this->sy = y;

	    this->bArr = new S3DVector(ct->getXSlot(idevent) - ct->getX(), 
				       ct->getYSlot(idevent) - ct->getY());
	    this->bComp = ct;
	    this->bSlot = idevent - ct->getMinID();
	    return;
	 }
	 else
	 {
	    // Search if connected
	    for (j = 0; j < this->lendComponent.size(); j ++)
	       if (this->lendSlot[j] == idevent - ct->getMinID())
	       {
		  // Take the end of the arrow:
		  this->disconnectContainers(ct, idevent - ct->getMinID());
		  this->drawingArrow = true;
		  this->ex = x;
		  this->ey = y;
		  return;
	       }
	 }
      }

      if ( (c != 0) && (idevent != this->getMinID()) &&
	   (c->getEvents() & S3DComponent::MOUSE_DOWN) &&
	   (idevent >= c->getMinID()) && (idevent <= c->getMaxID()) )
      {

	 x2 = x;
	 y2 = y;

	 // Select an element
	 if ((button & S3DComponent::CTRLKEY) && 
	     (button & S3DComponent::LEFTBUTTON))
	 {
	    c->setProperty(S3DComponent::SELECTED, 
			   !c->getProperty(S3DComponent::SELECTED));
	    
	    return;
	 }


	 // Remove an element
	 if ( (button & S3DComponent::SHIFTKEY) &&
	      (button & S3DComponent::LEFTBUTTON) )
	 {
	    if (c->getProperty(S3DComponent::PERMANENT))
		return;

	    if (!this->deleteGroup())
	       this->deleteContainer((S3DContainer *) c);
	    
	    return;
	 }

	 if (c->getProperty(S3DComponent::NOMOVE))
	 {
	    x2 += this->xoff;
	    y2 += this->yoff;
	 }

	 if (c->getProperty(S3DComponent::NOZOOM))
	 {
	    x2 *= zoom;
	    y2 *= zoom;
	 }

	 c->eventMouseButtonDown(x2, y2, button, idevent);
	 c->setFocus(true);
	 indexfocus = i;
	 changefocus = c;
      }
      else
	 c->setFocus(false);
   }

   if (changefocus != 0)
   {
      this->lcomp[indexfocus] = this->lcomp[this->lcomp.size() - 1];
      this->lcomp[this->lcomp.size() - 1] = changefocus;
   }

   return;
}


// --------------------------------------------------
void S3DGroupContainer::eventMouseButtonUp (float x, float y, 
					    unsigned int button,
					    unsigned int idevent)
{
   unsigned int i, j;
   S3DComponent *c;
   S3DContainer *ct;
   bool end;
   S3DVector *v;
   unsigned int p;
   unsigned int t0, t1;
   S3DContainer **data;

   x /= this->zoom;
   y /= this->zoom;
   x -= this->xoff;
   y -= this->yoff;


   end = false;

   this->drawingSelection = false;
   this->movingArea = false;


   // If the arrow is drawing:
   if (this->drawingArrow == true)
   {
      for (i = 0; i < this->lcomp.size(); i++)
      {
	 c = this->lcomp[i];

	 /* Look if the component is a container with slots. And if we are over 
	    a slot or not: */
	 if ( (idevent > this->getMinID()) &&
	      (idevent >= c->getMinID()) && (idevent <= c->getMaxID()) &&
	      (c->getType(idevent) == S3DComponent::SLOT) )
	 {
	    ct = (S3DContainer *) c;

	    p = ct->getPosSlot(idevent);

	    t0 = this->bComp->getTypeSlot(this->bSlot + 
					  this->bComp->getMinID());
	    t1 = ct->getTypeSlot(idevent);

	    /* If the slot is an input, the types are the same in 
	       distinct components: */
	    if ( ((p == S3DContainer::SLOT_VOLUM_INPUT) ||
		  (p == S3DContainer::SLOT_PARAM_INPUT) ) &&
		 ( (t0 == t1) && (ct != this->bComp) ))
 	    {
	       // Search if an arrow exists or not
	       end = false;
	       for (j = 0; (j < this->lendComponent.size()) && (!end); j++)
		  if ( (ct == this->lendComponent[j]) && 
		       (idevent == ct->getMinID() + this->lendSlot[j]) )
		  {
		     // Remove the event:
		     this->lbegComponent[j]->removeListener(
			this->lendComponent[j]);


		     // Add the events:
		     this->bComp->addListener(ct);


		     this->lbegComponent[j] = this->bComp;
		     this->lendComponent[j] = ct;
		     delete this->lbegArrow[j];
		     delete this->lendArrow[j];
		     this->lbegArrow[j] = this->bArr;
		     this->lendArrow[j] = new S3DVector(ct->getXSlot(idevent) - 
							ct->getX(), 
							ct->getYSlot(idevent) - 
							ct->getY());;
		     this->lbegSlot[j] = this->bSlot;
		     this->lendSlot[j] = idevent - ct->getMinID();
		     this->bArr = 0;
		     end = true;
		     
		     data = new S3DContainer *[2];
		     data[0] = this->bComp;
		     data[1] = ct;
		     this->sendEvent(this, "replace_arrow",
				     x, y, button, 0, 
				     data, ct->getSlotNumber(idevent));
		     this->drawingArrow = false;
		     delete [] data;
		     return; // The program can be interrupted here
		  }

	       // If not exist it means that it is a new arrow
	       if (end == false)
	       {

		  this->connectContainers(this->bComp, ct,
					  this->bSlot - 1,
					  ct->getSlotNumber(idevent));
		  end = true;
	       }
	    }
	    else
	       this->tip->setText("Types do not match!");

	 }
      }      

      if (this->bArr != 0)
	 delete this->bArr;
      this->bArr = 0;
      this->bComp = 0;
      this->bSlot = 0;


      this->drawingArrow = false;
      this->ex = this->sx = 0.0;
      this->ey = this->sy = 0.0;
   }
   else
   {
      // In case it is not a slot the event is sended:
      for (i = 0; i < this->lcomp.size(); i++)
      {
	 c = this->lcomp[i];
	 
	 if ((c != 0) && (c->getEvents() & S3DComponent::MOUSE_UP))
	    c->eventMouseButtonUp(x, y, button, idevent);
      }
   }

   return;
}

// --------------------------------------------------
void S3DGroupContainer::eventKeyDown (float x, float y, unsigned int key,
				      unsigned int idevent)
{
   int i;

   x /= this->zoom;
   y /= this->zoom;
   x -= this->xoff;
   y -= this->yoff;

   for (i = 0; i < this->lcomp.size(); i++)
      if ((this->lcomp[i] != 0) && (this->lcomp[i]->getFocus() == true) &&
	  (this->lcomp[i]->getEvents() & S3DComponent::KEY_DOWN))
	 this->lcomp[i]->eventKeyDown(x, y, key, idevent);

   return;
}


// --------------------------------------------------
void S3DGroupContainer::eventIDChanged (long long int df)
{
   unsigned long int i;

   for (i = 0; i < this->lcomp.size(); i++)
      if (this->lcomp[i] != 0)
	 this->lcomp[i]->setID(this->lcomp[i]->getMinID() + df, 
			       this->lcomp[i]->getMaxID() + df);
   return;
}


// --------------------------------------------------
void S3DGroupContainer::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DGroupContainer::eventChangePos (float newX, float newY)
{
   return;
}


// --------------------------------------------------
void S3DGroupContainer::listenEvent(S3DListener *sender, const char *msg, 
				    float x, float y, unsigned int button, 
				    unsigned int key, 
				    void *data, unsigned int n)
{
   if (!strcmp(msg, "killed"))
   {
      if (n > 0)
	 this->toRemove.push_back(sender);

      return;
   }

   // Broadcast the message
   this->sendEvent(sender, msg, x, y, button, key, data, n);

   return;
}


// --------------------------------------------------
bool S3DGroupContainer::swapOutputs (S3DContainer *c0, S3DContainer *c1, 
				     unsigned long int slotNumber0, 
				     unsigned long int slotNumber1)
{
   unsigned int j;
   unsigned long int id;
   float x0, y0;
   S3DContainer **data;
   S3DContainer *cend;
   unsigned long int cendSlot;

   std::cerr << "Searching... " << this->lbegComponent.size() << "\n";
   // Search for the slot and the component in the array:
   for (j = 0;  j < this->lbegComponent.size(); j ++)
   {
      if ( (this->lbegSlot[j] == (slotNumber0 + 1)) && 
	   (this->lbegComponent[j] == c0) )
      {
	 std::cerr << "Searching... " << j << "\n";
	 cend = (S3DContainer *) this->lendComponent[j];
	 cendSlot = this->lendSlot[j];

	 /* ----------------------- */
	 
	 // Remove arrow event:

	 data = new S3DContainer *[2];
	 data[0] = c0;
	 data[1] = cend;
	 this->sendEvent(this, "remove_arrow",
			 c0->getX(), c0->getY(), 
			 S3DComponent::LEFTBUTTON, 0, 
			 data, 
			 cendSlot - 1);
	 delete [] data;


	 this->lbegComponent[j]->removeListener(this->lendComponent[j]);

	 
	 this->lbegComponent.erase(this->lbegComponent.begin() + j);
	 this->lbegArrow.erase(this->lbegArrow.begin() + j);
	 this->lendComponent.erase(this->lendComponent.begin() + j);
	 delete this->lendArrow[j];
	 this->lendArrow.erase(this->lendArrow.begin() + j);
	 this->lbegSlot.erase(this->lbegSlot.begin() + j);
	 this->lendSlot.erase(this->lendSlot.begin() + j);

	 this->connectContainers(c1, cend, slotNumber1, cendSlot - 1, true);

	 return true;
      }
   }

   return false;
}


// --------------------------------------------------
bool S3DGroupContainer::disconnectContainers (S3DContainer *c0, 
					      unsigned long int slotNumber0)
{
   unsigned int j;
   unsigned long int id;
   float x0, y0;
   S3DContainer **data;


   //DEBUG:
   std::cerr << "Disconecting XXXXXXXX-------XXXXXX\n";

   // Search for the slot and the component in the array:
   for (j = 0;  j < this->lendComponent.size(); j ++)
   {
      id = this->lendComponent[j]->getMinID();

      if ( (this->lendSlot[j] == slotNumber0) && 
	   (this->lendComponent[j] == c0) )
      {
	 this->bComp = (S3DContainer *) this->lbegComponent[j];
	 this->bArr = this->lbegArrow[j];
	 this->bSlot = this->lbegSlot[j];

	 id = this->lbegSlot[j] + this->bComp->getMinID();

	 // The beggining of the arrow: 
	 x0 = this->bComp->getXSlot(id);
	 y0 = this->bComp->getYSlot(id);
	 

	 if (this->bComp->getProperty(S3DComponent::NOZOOM))
	 {
	    x0 /= this->zoom;
	    y0 /= this->zoom;
	 }
	 
	 if (this->bComp->getProperty(S3DComponent::NOMOVE))
	 {
	    x0 -= this->xoff;
	    y0 -= this->yoff;
	 }
	 
	 this->sx = x0;
	 this->sy = y0;
	 /* ----------------------- */
	 
	 // Remove arrow event:
	 data = new S3DContainer *[2];
	 data[0] = this->bComp;
	 data[1] = c0;
	 this->sendEvent(this, "remove_arrow",
			 c0->getX(), c0->getY(), 
			 S3DComponent::LEFTBUTTON, 0, 
			 data, 
			 slotNumber0 - 1);
	 delete [] data;

	 this->lbegComponent[j]->removeListener(this->lendComponent[j]);
	 
	 this->lbegComponent.erase(this->lbegComponent.begin() + j);
	 this->lbegArrow.erase(this->lbegArrow.begin() + j);
	 this->lendComponent.erase(this->lendComponent.begin() + j);
	 delete this->lendArrow[j];
	 this->lendArrow.erase(this->lendArrow.begin() + j);
	 this->lbegSlot.erase(this->lbegSlot.begin() + j);
	 this->lendSlot.erase(this->lendSlot.begin() + j);

	 return true;
      }
   }

   return false;
}


// --------------------------------------------------
void S3DGroupContainer::connectContainers (S3DContainer *c0, 
					   S3DContainer *c1,
					   unsigned long int slotNumber0,
					   unsigned long int slotNumber1, 
					   bool sendEvent)
{
   S3DVector *v, *vb;
   S3DContainer **data;
   unsigned long int id0, id1;

   id0 = slotNumber0 + c0->getMinID() + 1;
   id1 = slotNumber1 + c1->getMinID() + 1;

   vb = new S3DVector(c0->getXSlot(id0) - c0->getX(), 
		      c0->getYSlot(id0) - c0->getY());
   v = new S3DVector(c1->getXSlot(id1) - c1->getX(), 
		     c1->getYSlot(id1) - c1->getY());

   // Add the events:
   c0->addListener(c1);
   
   this->lbegComponent.push_back(c0);
   this->lendComponent.push_back(c1);
   this->lbegArrow.push_back(vb);
   this->lendArrow.push_back(v);
   this->lbegSlot.push_back(slotNumber0 + 1);
   this->lendSlot.push_back(slotNumber1 + 1);

   this->bArr = 0;

   if (sendEvent)
   {
      data = new S3DContainer *[2];
      data[0] = c0;
      data[1] = c1;
      this->sendEvent(this, "add_arrow", v->X(), v->Y(), 
		      S3DComponent::LEFTBUTTON, 0, 
		      data, slotNumber1);
      delete [] data;
   }

   return;
}


// --------------------------------------------------
bool S3DGroupContainer::deleteGroup(void)
{
   unsigned int i;
   std::vector <S3DContainer *> openlist; 

   for (i = 0; i < this->lcomp.size(); i ++)
   {
      if (this->lcomp[i]->getProperty(S3DComponent::SELECTED))
	 openlist.push_back((S3DContainer *) this->lcomp[i]);
   }

   if (openlist.size() == 0)
      return false;

   for (i = 0; i < openlist.size(); i ++)
      this->deleteContainer(openlist[i]);

   return true;
}


// --------------------------------------------------
bool S3DGroupContainer::deleteContainer(S3DContainer *c)
{
   unsigned int j;
   bool ok = true;
   S3DContainer **data;

   // it is important to clean all flags before delete a container
   this->drawingArrow = false;
   this->sx = this->sy = this->ex = this->ey = 0;
   if (this->bArr != 0)
      delete this->bArr;
   this->bArr = 0;
   this->drawingSelection = false;
   this->bSlot = 0;
   this->movingArea = 0;


   ok = false;

   // Search the component in the array:
   j = 0;
   while (j < this->lendComponent.size())
   {
      if ( (this->lendComponent[j] == c) || 
	   (this->lbegComponent[j] == c) ) 
      {
	 if (this->lbegComponent[j] == c)
	 {
	    // Remove arrow event:
	    data = new S3DContainer *[2];
	    data[0] = (S3DContainer *) this->lbegComponent[j];
	    data[1] = (S3DContainer *) this->lendComponent[j];

	    this->sendEvent(this, "remove_arrow",
			    0, 0, 0, 0, data, this->lendSlot[j] - 1);

	    this->lbegComponent[j]->removeListener(this->lendComponent[j]);
	 }

	 this->lbegComponent.erase(this->lbegComponent.begin() + j);
	 this->lendComponent.erase(this->lendComponent.begin() + j);
	 this->lbegArrow.erase(this->lbegArrow.begin() + j);
	 this->lendArrow.erase(this->lendArrow.begin() + j);
	 this->lbegSlot.erase(this->lbegSlot.begin() + j);
	 this->lendSlot.erase(this->lendSlot.begin() + j);
      }
      else 
	 j ++;
   }


   // Search the component
   j = 0;
   while ( (c != this->lcomp[j]) && (j < this->lcomp.size()) )
      j++;

   if (j >= this->lcomp.size())
      return false;
   else 
      ok = true;

   this->lcomp.erase(this->lcomp.begin() + j);   

   this->sendEvent(c, "killed", 0, 0, 0, 0, 0, 0);

   delete c;

   return ok;
}
