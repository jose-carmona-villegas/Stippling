#ifndef __INTERFACE__
#define __INTERFACE__

#include <GL/glew.h>
#include <fstream>
#include <vector>
#include "framebuffer.hh"
#include "vector.hh"
#include "theme.hh"
#include "image.hh"
#include "primitive3d.hh"
#include "component.hh"
#include "input.hh"

/** @class   S3DInterface interface.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is an interface, and it connects the OpenGL UI with the 
 *           usual GUI
 *
 *  @bug     No bugs detected yet
 */

class S3DInterface {
   public:

      /** 
       * @post Constructor. Inizialite the empty selection.
       */
      S3DInterface(S3DTheme *th, int x, int y, int w, int h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DInterface(void);

      /**
       * @post Set the position of the component
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] z The z coordinate of the component
       */
      void setPos(int x, int y);

      /**
       * @post Set the size of the component
       * @param[in] w The w coordinate of the component
       * @param[in] h The h coordinate of the component
       */
      void setSize(int w, int h);       

      /**
       * @post Add a new component to the manager
       * @param[in] c The component
       */
      void add(S3DComponent *c); 

      /**
       * @post Read and process events
       * @param[in] e The SDL event
       * @note This component send an event when show text:
       *            -    msg = "msg"
       *            data = text (char *) 
       *                   [do not free the pointer, it is not a copy]
       *            n = 0
       *            sender = 0
       */
      void readEventsSDL(SDL_Event *e); 

      /**
       * @post Draw all the components, you shouldn't draw anything after this
       *       method, because it changes the proyection
       */
      void draw(void);

   private:
      int w, h; /// Size of the object
      int x, y; /// Position of the object
      Uint32 timer; /// Timer for animations
      std::vector<S3DComponent *> lcomp; /// Components of the interface
      float xmouse, ymouse; /// The coordinates event
      unsigned int button; /// The button event
      bool donotdraw; /// Don't update the screen
      unsigned long int freeid; /// Free IDs
      unsigned long int idevent; /// Component to send the event
      bool firstFBO; /// To define a FBO
      S3DFBO *fbo; /// The FBO
      GLuint imgfbo; /// The texture of the FBO
      GLenum fbostatus; /// Status of the FBO
      S3DTheme *theme; /// The theme
      Uint32 etimer; /// Timer for events
      unsigned int keyflag; /// Flag for the modifiers
      bool save_events; /// Save all the events if true
      bool load_events; /// Reproduce a macro
      bool screenshot; /// Active/deactive the screenshot mode
      bool screenshotauto; /// Deactive the screenshot mode when finish the play
      std::ifstream infile; /// Input file
      std::ofstream outfile; /// Outputfile
      unsigned int slot_events; /// Slot to save or load an event
      unsigned int pspeed; /// Playing speed
      char *namefile; /// Name of the file
      unsigned char *scbuffer; /// Buffer of screenshots
      unsigned long long int scframe; /// Saved frame
      Uint32 scclock; /// Clock for screenshots
};

#endif
