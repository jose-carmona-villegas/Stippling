#ifndef __LISTENER__
#define __LISTENER__

#include <GL/glew.h>
#include <iostream>
#include <fstream>
#include <vector>

/** @class   S3DListener listener.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class can listen for any (high level) event of a component 
 *
 *  @bug     No bugs detected yet
 */

class S3DListener {
   public:

      /** 
       * @post Constructor. Inizialite the empty listener
       */
      S3DListener(void);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DListener(void);

      /**
       * @post Add a new listener to send events
       * @param[in] list The new listener
       */
      void addListener(S3DListener *list);

      /**
       * @post Remove the listener
       * @param[in] list The listener to remove
       */
      void removeListener(S3DListener *list);

      /**
       * @param[in] i The index of the listener or 0 if it is not found
       * @post The listener
       */
      S3DListener *getListener(unsigned int i);

      /**
       * @param[in] list The element
       * @post The element in the list (if the number is not valid, it 
       *       returns the size of the list)
       */
      unsigned int getListener(S3DListener *list);

      /**
       * @post The number of listeners
       */
      unsigned int getNListeners(void);

      /**
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      void sendEvent(S3DListener *sender, const char *msg,
		     float x, float y, unsigned int button, 
		     unsigned int key,  
		     void *data, unsigned int n);

      /**
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

   private:
      std::vector<S3DListener *> lcomp; /// Listeners of this listener
};

#endif
