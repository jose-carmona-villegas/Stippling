#ifndef __SLIDER__
#define __SLIDER__

#include <GL/glew.h>
#include <fstream>
#include <SDL/SDL_ttf.h>
#include "component.hh"
#include "theme.hh"
#include "input.hh"
#include "button.hh"

/** @class   S3DSlider slider.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is an slider component
 *
 *  @bug     No bugs detected yet
 */

class S3DSlider : public S3DComponent {
   public:

      /** 
       * @param[in] theme A valid theme
       * @post Constructor. Inizialite the empty component.
       */
      S3DSlider(S3DTheme *theme);

      /** 
       * @param[in] theme A valid theme
       * @param[in] x The x coordinate of the component
       * @param[in] y The y coordinate of the component
       * @param[in] w The width of the component
       * @param[in] h The height of the component
       * @post Constructor. Inizialite the empty component.
       */
      S3DSlider(S3DTheme *theme, float x, float y, float w, float h);

      /** 
       * @post Destructor. Clean the data.
       */
      ~S3DSlider(void);

      /**
       * param[in] title It is the text before the other text, if it is 0
       *                 the colors will change to the colors of the title
       * @post Change a value of the user interface
       */
      void setTitle(const char *title);

      /**
       * param[in] n The new minimal value
       * @post Change the value
       */
      void setMinValue(float n);

      /**
       * param[in] n The new maximal value
       * @post Change the value
       */
      void setMaxValue(float n);

      /**
       * param[in] n The new value
       * @post Change the value
       */
      void setValue(float n);

      /**
       * param[in] ind The texture id of the indicator
       * param[in] hfash The texture id of the horizontal fashion
       * param[in] bLreleased The texture id of the released
       *                      texture of left button
       * param[in] bLover The texture id of the over texture of left button
       * param[in] bLpress The texture id of the pressed texture of left button
       * param[in] bRreleased The texture id of the released
       *                      texture of right button
       * param[in] bRover The texture id of the over texture of right button
       * param[in] bRpress The texture id of the pressed texture of right button
       * @post Change the textures of the component
       */
      void setTextures (GLuint ind, GLuint hfash, 
                        GLuint bLreleased, GLuint bLover, GLuint bLpress, 
                        GLuint bRreleased, GLuint bRover, GLuint bRpress);

      /**
       * param[in] n The new increment
       * @post Change the increment
       */
      void setIncrement(float n);

      /**
       * param[in] f A boolean value
       * @post Change the indicator
       */
      void setIndicatorProportional(bool f);

      /**
       * param[in] f A boolean value
       * @post Show or hide the title
       */
      void showTitle(bool f);

      /**
       * param[in] f A boolean value
       * @post Show or hide the buttons
       */
      void showButtons(bool f);

      /**
       * @post The value
       */
      float getValue(void);

      /**
       * @param[in] d The boolean value
       * @post Set periodic events if d is true
       */
      void sendPeriodicEvent(bool d);

      /**
       * @post The maximal value
       */
      float getMaxValue(void);

      /**
       * @post The minimal value
       */
      float getMinValue(void);

      /**
       * @post Draw the component
       * @param[in] select If select is true, the colors are changed to the id
       */
      virtual void draw(bool select);       

      /**
       * @post The IDs needed by the component to be selected
       */
      virtual unsigned long int getIDNeeded(void);       

      /**
       * @post The type of component it is
       */
      virtual unsigned int getType (unsigned long int id);

      /**
       * @post The set of events the component uses
       */
      virtual unsigned int getEvents (void);       

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseMotion (float x, float y, unsigned int buttons, 
				     unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonDown (float x, float y, unsigned int button,
					 unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button
       * @param[in] idevent The event ID
       * @post The event when the mouse has been released
       */
      virtual void eventMouseButtonUp (float x, float y, unsigned int button,
				       unsigned int idevent);

      /**
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The key
       * @param[in] idevent The event ID
       * @post The event when a key is pressed
       */
      virtual void eventKeyDown (float x, float y, unsigned int key,
				 unsigned int idevent);

      /**
       * @param[in] difference The difference of the ids
       * @post The event when IDs change
       */
      virtual void eventIDChanged (long long int difference);

      /**
       * @param[in] newWidth The new width
       * @param[in] newHeight The new height
       * @post The event when the component is resized
       */
      virtual void eventResize (float newWidth, float newHeight);

      /**
       * @param[in] newX The new position in x
       * @param[in] newY The new position in y
       * @post The event when the component changes the size
       */
      virtual void eventChangePos (float newX, float newY);


      /**
       * @note EVENTS of this component:
       *       -    msg = "float_value_changed"
       *            data = pointer to float value (float *) [do not free]
       *            n = undefined
       * @param[in] sender The listener which send the message
       * @param[in] msg The message, it must be exact to understand something
       * @param[in] x The x position of the mouse
       * @param[in] y The y position of the mouse
       * @param[in] button The button of the mouse which is pressed
       * @param[in] key The pressed key if any (in other case 0)
       * @param[in] data Additional data if any, according to the message
       * @param[in] n The size of the array, only if data is an array
       * @post Read an event and do something
       * @warning msg must be a valid well defined message and sender must be 
       *          a valid listener in order everything works fine
       */
      virtual void listenEvent(S3DListener *sender, const char *msg, 
			       float x, float y, unsigned int button, 
			       unsigned int key, 
			       void *data, unsigned int n);

   protected:


      /**
       * @param[in] theme The theme of the component
       * @post Initialize all the variables of the class
       */
      void init (S3DTheme *theme);


   private:
      S3DTheme *theme; // theme
      Uint32 cTimer; /// Timer for the component
      float value; /// It is the value
      float minvalue; /// The minimal value
      float maxvalue; /// The maximal value
      S3DInput *input; /// The input text
      bool movingSlider; /// The slider is sliding
      float prevx, prevy; /// The previous coordinates of the slider
      float optw, opth; /// Optimization for the size of the component
      float opth25, opth50; /// Optimization for the size of the component
      float s3, s3h, s6;  /// Optimization for the size of the component
      GLuint hfashion; /// The horizontal fashion
      GLuint indicator; /// The indicator of the componet 
      float indicatorSize; /// The size of the indicator
      bool indicatorProportional; /// If it is proportional or not
      bool sTitle; /// Show the titles or not
      bool sButtons; /// Show the buttons or not
      float increment; /// The increment of the button
      S3DButton *lButt, *rButt; /// Left and right buttons
      bool sendEventOnMove; /// Flag to send events all the time
};


#endif
