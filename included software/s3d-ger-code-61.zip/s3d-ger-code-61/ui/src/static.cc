#include "static.hh"


// --------------------------------------------------
S3DStatic::S3DStatic(S3DTheme *theme) : S3DComponent (0, 0, 0, 0)
{
   this->init(theme);
}


// --------------------------------------------------
S3DStatic::S3DStatic(S3DTheme *theme, float x, float y, 
			       float w, float h) :
   S3DComponent (x, y, w, h)
{
   this->setPos(x, y);  
   this->setSize(w, h);

   this->init(theme);
}


// --------------------------------------------------
void S3DStatic::init(S3DTheme *theme)
{
   int i;

   this->theme = theme;

   this->textLabel = new S3DLabel(theme->getFont(S3DTheme::INPUTTEXTFONT), 1);
   this->textLabel->setText("");
   this->textLabel->setPos(this->getX(), this->getY(), 0.0);

   this->titleImg = 0;

   this->id = 0;
}


// --------------------------------------------------
S3DStatic::~S3DStatic()
{
   if (this->textLabel != 0)
   {
      delete this->textLabel;
   }

   if (this->titleImg != 0)
   {
      delete this->titleImg;
   }

}


// --------------------------------------------------
void S3DStatic::setText (const char *t)
{
   this->textLabel->setText(t);
}


// --------------------------------------------------
void S3DStatic::setImageID (GLuint id)
{
   this->id = id;
}


// --------------------------------------------------
void S3DStatic::setImage (const char *t)
{
   int cerror;
   if (this->titleImg != 0)
      delete this->titleImg;

   this->titleImg = new S3DImage();
   cerror = this->titleImg->load(t);
   if (!cerror)
   {
      delete this->titleImg;
      this->titleImg = 0;
   }
   else
   {
      this->titleImg->setTexture2D(GL_TEXTURE0, GL_NEAREST,
				   GL_CLAMP, GL_REPLACE);
   }

   return;
}


// --------------------------------------------------
unsigned long int S3DStatic::getIDNeeded(void)
{
 // Nothing
   return 0;
}


// --------------------------------------------------
void S3DStatic::draw(bool select)
{
   float s;

   if (this->getProperty(S3DComponent::HIDED))
      return;

   s = this->theme->getValue(S3DTheme::SPACEVALUE);

   glPushMatrix();

   if (select == false)
   {
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glColor4f(1, 1, 1, 1);

      glEnable(GL_TEXTURE_2D);

      if ( (this->titleImg != 0) || (this->id != 0) )
      {
	 if (this->id == 0)
	    glBindTexture(GL_TEXTURE_2D, this->titleImg->getTexture2D());
	 else
	    glBindTexture(GL_TEXTURE_2D, this->id);
	 S3DPrimitive3D::drawPlane(GL_POLYGON, this->getX(), this->getY(), 0,
				   this->getWidth(), this->getHeight());
      }

      this->textLabel->draw();

      glDisable(GL_TEXTURE_2D);
      glLineWidth (1.0);
   }

   
   glPopMatrix();
}


// --------------------------------------------------
unsigned int S3DStatic::getEvents (void)
{
   return (S3DComponent::ALL);
}


// --------------------------------------------------
void S3DStatic::eventMouseMotion (float x, float y, unsigned int buttons,
				 unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DStatic::eventMouseButtonDown (float x, float y, 
					   unsigned int button,
					   unsigned int idevent)
{
   return;
}


// --------------------------------------------------
void S3DStatic::eventMouseButtonUp (float x, float y, unsigned int button,
					 unsigned int idevent)
{
   return;
}

// --------------------------------------------------
void S3DStatic::eventKeyDown (float x, float y, unsigned int key,
			     unsigned int idevent)
{

   return;
}


// --------------------------------------------------
void S3DStatic::eventIDChanged (long long int difference)
{
   return;
}


// --------------------------------------------------
void S3DStatic::eventResize (float newWidth, float newHeight)
{
   return;
}


// --------------------------------------------------
void S3DStatic::eventChangePos (float newX, float newY)
{
   this->textLabel->setPos(newX, newY, 0.0);

   return;
}


// --------------------------------------------------
void S3DStatic::listenEvent(S3DListener *sender, const char *msg, 
				 float x, float y, unsigned int button, 
				 unsigned int key, 
				 void *data, unsigned int n)
{
   // This component does not listen
   return;
}

