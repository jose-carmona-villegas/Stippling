 
/**
   @todo Documentar las p�ginas principales de las documentaciones
   @todo Repasar los archivos warnings.txt para documentar lo que falta

   @mainpage

   @section secBase base's documentation
   
   This module includes basic classes.
   
*/

/**
 * @page refs References
 *
 * @anchor Hear95 @b @<Hear95@> @par
 *    Hearn, Baker;
 *    <b>Gr�ficas por Computadora</b>,
 *    <i>Prentice Hall</i>:608-609. 1995.
 *
 * @anchor Lore87 \b \<Lore87\> @par
 *    W. Lorensen, H. Cline;
      <b>Marching cubes: A high resolution 3d surface
      construction algorithm,</b>
      <i>ACM Computer Graphics</i>, 21(4):163-169. 1987.</p>

 * @anchor Mont94 \b \<Mont94\> @par
 *    C. Montani, R. Scateni, R. Scopigno;
      <b>Discretized marching cubes,</b> in
      <i>Visualization</i>, pages 281-287,
      Los Alamitos, CA, USA. 1994.

 * @anchor Wilh92 @b @<Wilh92@> @par
 *    Wilhelms, A.V. Gelder;
 *    <b>Octrees for faster isosurface generation</b>;
 *    <i>ACM Transactions on Graphics</i>, 11(3):201-227. 1992.
 *
 */
 
 /**
   @todo Documentar las p�ginas principales base
   @todo Repasar los archivos warnings.txt para documentar lo que falta
 */

