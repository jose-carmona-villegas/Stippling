#include <iostream>
#include <math.h>

#include "matrix.hh"
#include "image.hh"

int main (int argc, char *argv[])
{
   S3DImage *orig = 0;
   S3DImage *dest = 0;
   S3DImage *dest2 = 0;
   S3DMatrix *kernel = 0;
   S3DImage *t;

   orig = new S3DImage();
//   orig->load("../media/lena.png");
//   orig->load("../media/lena.jpg");
   orig->load("../media/lion.jpg");
//   orig->load("../media/circle.png");
//   orig->load("../media/chess.jpg");
//   orig->load("../media/lamp.png");

   t = new S3DImage();
   t->enableCopyDoubles();
   dest = new S3DImage();
   dest2 = new S3DImage();
   kernel = new S3DMatrix(S3DMatrix::EMPTY,6);

   dest->enableCopyDoubles();
   dest->getIterETF(orig, 3, 1, 3);
   std::cerr  << "----------------------\n";

//   t->convert(3);
//   t->save("../bin/testf/etf0.bmp");

   dest2->enableCopyDoubles();
   dest2->getSilhouette(orig, dest, 2, 1, 1);

   dest2->convert(3);
   dest2->save("../bin/testf/sil.bmp");

   return 0;

   
   // Normalization:
   kernel->setKernelConvolution(S3DMatrix::DoGAUSSnxnH, 2);
   dest->convolute(orig, kernel);
   dest->operate(S3DImage::NORMALIZE, dest);
   dest->convert(3);
   dest->save("../bin/testf/normalized.bmp");

   // Cany:
   dest->getCanny(orig, 2, 4, 0.01, 0.01, 6);
   dest->convert(3);
   dest->save("../bin/testf/canny.bmp");


   // Blur:
   kernel->setKernelConvolution(S3DMatrix::GAUSSnxn, 2);
   kernel->print("Gauss 6x6 [sigma = 2]");
   dest->convolute(orig, kernel, true);
   dest->convert(3);
   dest->save("../bin/testf/filter1.bmp");

   // Desaturate
   dest->operate(S3DImage::DESATURATE, dest);
   dest->convert(3);
   dest->save("../bin/testf/desaturated.bmp");

   // Borders:
   kernel->setKernelConvolution(S3DMatrix::DoGAUSSnxnH, 2);
   kernel->print("DoGH 6x6 [sigma = 2]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filter2.bmp");

   kernel->setKernelConvolution(S3DMatrix::DoGAUSSnxnV, 2);
   kernel->print("DoGV 6x6 [sigma = 2]");
   dest2->convolute(orig, kernel);
   dest2->convert(3);
   dest2->save("../bin/testf/filter3.bmp");

   dest->operate(S3DImage::MAGNITUDE, dest, dest2);
   dest->convert(3);
   dest->save("../bin/testf/magnitude.bmp");

   dest->operate(S3DImage::ANGLE, dest, dest2);
   dest->convert(3);
   dest->save("../bin/testf/angle.bmp");

   // Borders 2th derivative:
   kernel->setKernelConvolution(S3DMatrix::DHoGAUSSnxnH);
   kernel->print("D2oGH 6x6 [sigma = 1]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filter4.bmp");

   kernel->setKernelConvolution(S3DMatrix::DVoGAUSSnxnV);
   kernel->print("D2oGV 6x6 [sigma = 1]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filter5.bmp");

   kernel->setKernelConvolution(S3DMatrix::DHoGAUSSnxnV);
   kernel->print("DoGH-DoGV 6x6 [sigma = 1]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filter6.bmp");

   kernel->setKernelConvolution(S3DMatrix::DVoGAUSSnxnH);
   kernel->print("DoGH-DoGV 6x6 [sigma = 1]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filter7.bmp");

   // LoG:
   kernel->setKernelConvolution(S3DMatrix::LoGAUSSnxn, 2);
   kernel->print("LoG 6x6 [sigma = 2]");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filterLoG.bmp");

   // Laplace:
   kernel->setKernelConvolution(S3DMatrix::LAPLACE5x5);
   kernel->print("Laplace 5x5");
   dest->convolute(orig, kernel);
   dest->convert(3);
   dest->save("../bin/testf/filterLap.bmp");

   // Threshold to Laplace
   dest->threshold(dest, 200);
   dest->convert(3);
   dest->save("../bin/testf/filterLapT.bmp");

   if (dest != 0)
      delete dest;
   if (dest2 != 0)
      delete dest2;

   if (kernel != 0)
      delete kernel;
   if (orig != 0)
      delete orig;

   return 0;
}
