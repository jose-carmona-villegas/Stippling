#include "shader.hh"

// --------------------------------------------------
S3DShaderObj::S3DShaderObj (void)
{
   this->sh_p = 0;
   this->sh_v = 0;
   this->sh_f = 0;
   this->sh_text = 0;
   this->sh_textSize = 0;

   return;
}


// --------------------------------------------------
S3DShaderObj::S3DShaderObj (S3DShaderObj *b)
{
   if (b == 0)
   {
      this->sh_p = 0;
      this->sh_v = 0;
      this->sh_f = 0;

      if (this->sh_text != 0)
	 delete [] this->sh_text;

      this->sh_text = 0;
      this->sh_textSize = 0;
   }
   else
   {
      this->sh_p = 0;
      this->sh_v = 0;
      this->sh_f = 0;

      if (this->sh_text != 0)
	 delete [] this->sh_text;

      if (b->getText() != 0)
      {
	 this->sh_textSize = std::strlen (b->getText());
	 this->sh_text = new char [this->sh_textSize + 1];
	 std::memcpy (this->sh_text, b->getText(), this->sh_textSize);
	 this->sh_text[this->sh_textSize] = '\0';
      }
      else
      {
	 this->sh_text = 0;
	 this->sh_textSize = 0;
      }

   }
   return;
}


// --------------------------------------------------
S3DShaderObj::~S3DShaderObj (void)
{
   doNotUseProgram();
   clearShaders();
   if (this->sh_text != 0)
      delete [] this->sh_text;

   return;
}


// --------------------------------------------------
void S3DShaderObj::clearShaders () 
{
   glDetachShader(this->sh_p, this->sh_v);
   glDetachShader(this->sh_p, this->sh_f);
   glDeleteShader(this->sh_v);
   glDeleteShader(this->sh_f);
   glDeleteProgram(this->sh_p);
}


// --------------------------------------------------
void S3DShaderObj::printObjectInfoLog (GLuint obj)
{
   int infologLength = 0;
   int charsWritten  = 0;
   char* infoLog;

   if (glIsShader(obj) == GL_TRUE)
      glGetShaderiv(obj, GL_INFO_LOG_LENGTH, &infologLength);
   else
      glGetProgramiv(obj, GL_INFO_LOG_LENGTH, &infologLength);
   
   if (infologLength > 1) 
   {
      infoLog = new char[infologLength];
      if (glIsShader(obj) == GL_TRUE) 
      {
	 glGetShaderInfoLog(obj, infologLength, &charsWritten, infoLog);
 	 std::cerr << "Shader InfoLog: " << infoLog << "\n";
      }
      else 
      {
	 glGetProgramInfoLog(obj, infologLength, &charsWritten, infoLog);
 	 std::cerr << "Program InfoLog: " << infoLog << "\n";
      }

      delete [] infoLog;
   }
}


// --------------------------------------------------
void S3DShaderObj::readFile (const char *filename)
{
   std::ifstream fin; 

   if (filename == 0)
      return;

   fin.open (filename, std::ios::in | std::ios::binary);
   if (!fin.good())
      std::cerr << "Shader file not found: \'" << filename << "\'\n";
   
   fin.seekg (0, std::ios::end);
   this->sh_textSize = fin.tellg();

   if (this->sh_text != 0)
      delete [] this->sh_text;

   this->sh_text = new char[this->sh_textSize + 10];

   // Return to the beginning:
   fin.seekg (0, std::ios::beg);

   this->sh_text[0] = '\0';
   fin.read ((char*) this->sh_text, this->sh_textSize);

   this->sh_text[this->sh_textSize] = '\0';

   return;
}


// --------------------------------------------------
bool S3DShaderObj::loadPrograms (const char *fileVertex, 
				 const char *fileFragment)
{
   bool fail = true;

   this->sh_p = glCreateProgram();

   if (fileVertex != 0)
   {
      this->sh_v = glCreateShader(GL_VERTEX_SHADER);
      readFile(fileVertex);
      glShaderSource(this->sh_v, 1, (const GLchar **) &this->sh_text, NULL);
      glCompileShader(this->sh_v);
      glAttachShader(this->sh_p, this->sh_v);

      fail = false;
   }

   if (fileFragment != 0)
   {
      this->sh_f = glCreateShader(GL_FRAGMENT_SHADER);
      readFile(fileFragment);
      glShaderSource(this->sh_f, 1, (const GLchar **) &this->sh_text, NULL);
      glCompileShader(this->sh_f);
      glAttachShader(this->sh_p, this->sh_f);

      fail = false;
   }

   if (this->sh_text != 0)
   {
      delete [] this->sh_text;
      this->sh_text = 0;
   }

   if (fail)
      return fail;

   glLinkProgram(this->sh_p);
   printObjectInfoLog(this->sh_v);
   printObjectInfoLog(this->sh_f);
   printObjectInfoLog(this->sh_p);

   return fail;
}


// --------------------------------------------------
bool S3DShaderObj::loadTextPrograms (const char *vertexP, 
				     const char *fragmentP)
{
   bool fail = true;


   this->sh_p = glCreateProgram();

   if (vertexP != 0)
   {
      if (this->sh_text != 0)
	 delete [] this->sh_text;

      this->sh_textSize = strlen(vertexP);
      this->sh_text = new char[strlen(vertexP) + 1];
      this->sh_text[0] = '\0';
      strcpy(this->sh_text, vertexP);
      this->sh_text[this->sh_textSize] = '\0';


      this->sh_v = glCreateShader(GL_VERTEX_SHADER);

      glShaderSource(this->sh_v, 1, (const GLchar **) &(this->sh_text), NULL);
      glCompileShader(this->sh_v);
      glAttachShader(this->sh_p, this->sh_v);

      fail = false;
   }

   if (fragmentP != 0)
   {
      if (this->sh_text != 0)
	 delete [] this->sh_text;

      this->sh_textSize = strlen(fragmentP);
      this->sh_text = new char[this->sh_textSize + 1];
      this->sh_text[0] = '\0';
      strcpy(this->sh_text, fragmentP);
      this->sh_text[this->sh_textSize] = '\0';

      this->sh_f = glCreateShader(GL_FRAGMENT_SHADER);

      glShaderSource(this->sh_f, 1, (const GLchar **) &(this->sh_text), NULL);
      glCompileShader(this->sh_f);
      glAttachShader(this->sh_p, this->sh_f);

      fail = false;
   }

   if (this->sh_text != 0)
   {
      delete [] this->sh_text;
      this->sh_text = 0;
      this->sh_textSize = 0;
   }

   if (fail)
      return fail;

   glLinkProgram(this->sh_p);
   printObjectInfoLog(this->sh_v);
   printObjectInfoLog(this->sh_f);
   printObjectInfoLog(this->sh_p);

   return fail;
}


// --------------------------------------------------
void S3DShaderObj::useProgram (void)
{
   glUseProgram(this->sh_p);
}


// --------------------------------------------------
GLint S3DShaderObj::locate(const char *var)
{
   if (this->sh_p == 0)
      return -1;

   return glGetUniformLocationARB(this->sh_p, var);
}


// --------------------------------------------------
void S3DShaderObj::doNotUseProgram (void)
{
   glUseProgram(0);
}

// --------------------------------------------------
char *S3DShaderObj::getText (void)
{
   return this->sh_text;
}


// --------------------------------------------------
GLuint S3DShaderObj::getProgram (void)
{
   return this->sh_p;
}


// --------------------------------------------------
GLuint S3DShaderObj::getVertexS (void)
{
   return this->sh_v;
}


// --------------------------------------------------
GLuint S3DShaderObj::getFragmentS (void)
{
   return this->sh_f;
}
