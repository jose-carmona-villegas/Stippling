#include <iostream>
#include <math.h>

#include <iostream>
#include <SDL/SDL.h>
#include <GL/glew.h>
#include "scene.hh"


int main (int argc, char *argv[])
{
   SDL_Surface *screen;
   SDL_Event event;
   const SDL_VideoInfo* info = NULL;
   int version;
   int width = 800;
   int height = 800;
   int bpp = 0;
   int flags = 0;
   int quit = 0;
   const GLubyte* strm;
   GLint value;
   GLenum err;
   float f = 0; // Test variable
   char text[1000];
   unsigned int i;
   S3DScene *scene;

   // SCENE Test:
   // ---------------------------------------------------------- 
   scene = new S3DScene();
   scene->load("../media/scene.ger");
   scene->initAnimation();



   width = scene->getWidth();
   height = scene->getHeight();


   /* ----- SDL init --------------- */
   if(SDL_Init(SDL_INIT_VIDEO) < 0) 
   {
      std::cerr << "Video initialization failed: " << SDL_GetError() << "\n";
      exit(-1);
   }
   
   atexit(SDL_Quit);
	
   info = SDL_GetVideoInfo();
   bpp = info->vfmt->BitsPerPixel;
   
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

/*	flags = SDL_OPENGL | SDL_FULLSCREEN; */
   flags = SDL_OPENGL | SDL_RESIZABLE;

/* ----- Setting up the screen surface --------------- */

//   SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE, 2);
   screen = SDL_SetVideoMode(width, height, bpp, flags);
   if(screen == 0) 
   {
      std::cerr << "Video mode set failed: " << SDL_GetError() << "\n";
      exit(-1);
   }

   SDL_WM_SetCaption("UI test", 0);


/* ----- Checking for OpenGL 2 --------------- */
   strm = glGetString(GL_VENDOR);
   std::cerr << "Vendor: " << strm << "\n";
   strm = glGetString(GL_RENDERER);
   std::cerr << "Renderer: " << strm << "\n";
   strm = glGetString(GL_VERSION);
   std::cerr << "OpenGL Version: " << strm << "\n";

   version = atof((const char *) strm);

   if (version < 2) 
   {
      std::cerr << "Warning: OpenGL 2 not supported!\n";
   }
   strm = glGetString(GL_VERSION);
   std::cerr << "Detected OpenGL Version >= " << version << "\n";

   strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
   std::cerr << "GLSL Version: " << strm << "\n";


   // Glew init:
   err = glewInit();
   if (GLEW_OK != err)
   {
      /* Problem: glewInit failed, something is seriously wrong. */
      std::cerr << "Error: " << glewGetErrorString(err) << "\n";
      exit (-1);
   }

   std::cerr << "Status: Using GLEW " << glewGetString(GLEW_VERSION) << "\n";

   if (!glewGetExtension("ARB_texture_non_power_of_two"))
   {
      std::cerr << "Warning: ARB_texture_non_power_of_two may not be supported"
		<< "\n";
   }


/* ----- Event cycle --------------- */
   quit = 0;
   while (!quit) 
   {
      glClearColor(0.0, 0.0, 0.0, 0.0);
//      glClearColor(1, 0.0, 0.0, 0.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      glDisable(GL_CULL_FACE);
      glEnable(GL_DEPTH_TEST);

      glViewport(0, 0, width, height);


      // Draw something in the FBO:
      glPushMatrix();
      {
	 scene->draw();
//	 scene->nextFrame();
	 scene->updateFrame(SDL_GetTicks() / 1000.0);
	 scene->executeActions();
      }
      glPopMatrix();

      glEnable(GL_TEXTURE_2D);
      glDisable(GL_LIGHTING);
      glDisable(GL_LIGHT0);


      // ----------------------

      while (SDL_PollEvent(&event)) 
      {
	 switch (event.type) 
	 {
	    // If you touch the close button:
	    case SDL_QUIT: {
	       quit = 1;
	    } break;
	    
	    // If the screen is resized:
	    case SDL_VIDEORESIZE: {
	       screen = SDL_SetVideoMode(event.resize.w, 
					 event.resize.h, 
					 bpp, flags); 
	       if(screen == 0)
	       {
		  std::cerr << "Video resize failed: " << SDL_GetError() 
			    << "\n";
		  exit (-1);
	       }
	       else
	       {
		  // Resize
		  width = event.resize.w;
		  height = event.resize.h;

		  // When resize, the viewport must be updated:

	       }

	    } break;

	    default : {
	       // Read events
	    } break;
	 
	 }
      }


      SDL_GL_SwapBuffers();
      SDL_Delay(1);
   }
   
   /***/
   delete scene;
   /***/

   SDL_Quit();

   return 0;
}
