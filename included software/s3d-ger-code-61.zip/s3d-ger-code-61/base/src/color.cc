#include "color.hh"


// --------------------------------------------------
S3DColor::S3DColor ()
{
   this->rgb = false;
   this->hsv = false;

   this->red = this->green = this->blue = -1;
   this->hue = this->saturation = this->value = -1;

   this->alpha = 1;
}


// --------------------------------------------------
S3DColor::S3DColor (float r, float g, float b)
{
   this->red = r;
   this->green = g;
   this->blue = b;

   this->rgb = true;
   this->hsv = false;

   this->hue = this->saturation = this->value = -1;

   this->alpha = 1;
}


// --------------------------------------------------
S3DColor::S3DColor (float r, float g, float b, float a)
{
   this->red = r;
   this->green = g;
   this->blue = b;
   this->alpha = a;

   this->rgb = true;
   this->hsv = false;

   this->hue = this->saturation = this->value = -1;
}


// --------------------------------------------------
S3DColor::~S3DColor ()
{
}


// --------------------------------------------------
void S3DColor::RGBtoHSV (void)
{
    float max, min;
    float invdelta;
    float delta;

    if (this->hsv == true)
       return ;

    if (this->red > this->green)
	max = this->red;
    else
	max = this->green;

    if (this->blue > max)
	max = this->blue;

    if (this->red < this->green)
	min = this->red;
    else
	min = this->green;

    if (this->blue < min)
	min = this->blue;

    this->value = max;

    /* Next calculate saturation */
    if (max != 0)
	this->saturation = (max - min) / max;
    else
	this->saturation = 0;

    if (this->saturation == 0)
	this->hue = 360; /* H = undefined */
    else
    {
	delta = max - min;
	invdelta = 1.0 / (float) (max - min);

	if (this->red == max)
	    this->hue = (this->green - this->blue) * invdelta;
	else
	    if (this->green == max)
		this->hue = 2 + (this->blue - this->red) * invdelta;
	    else
		if (this->blue == max)
		    this->hue = 4 + (this->red - this->green) * invdelta;
	this->hue *= 60;
	if (this->hue < 0) 
	    this->hue += 360;

	if (this->hue >= 360)
	    this->hue = 360 - this->hue;
    }

    this->hsv = true;

    return;
}


// --------------------------------------------------
void S3DColor::HSVtoRGB (void)
{
   int i;
   float f, p, q, t, hf;

   if (this->rgb == true)
      return;


   if (this->saturation == 0)
      if (this->hue == 360) /* undefined */
      {
	 this->red = this->green = this->blue = this->value;
      }
      else
      {
//	 std::cerr << "S3DColor: Some kind of problem :( , "
//		   << "S == 0 but H has a value.\n";
	 this->red = this->green = this->blue = this->value;
      }
   else
   {
      hf = this->hue * (1.0 / 60.0);
      i = (int) hf;

      f = hf - i;

      p = this->value * (1 - this->saturation);
      q = this->value * (1 - (this->saturation * f));
      t = this->value * (1 - (this->saturation * (1 - f)));

      switch (i) 
      {
	 case 0: {
	    this->red = this->value;
	    this->green = t;
	    this->blue = p;
	 } break;

	 case 1: {
	    this->red = q;
	    this->green = this->value;
	    this->blue = p;
	 } break;

	 case 2: {
	    this->red = p;
	    this->green = this->value;
	    this->blue = t;
	 } break;

	 case 3: {
	    this->red = p;
	    this->green = q;
	    this->blue = this->value;
	 } break;

	 case 4: {
	    this->red = t;
	    this->green = p;
	    this->blue = this->value;
	 } break;

	 case 5: {
	    this->red = this->value;
	    this->green = p;
	    this->blue = q;
	 } break;

      }
   }

   this->rgb = true;

   return;
}


// --------------------------------------------------
void S3DColor::R (float r)
{
   this->hsv = false;
   this->rgb = true;
   this->red = r;
}


// --------------------------------------------------
void S3DColor::G (float g)
{
   this->hsv = false;
   this->rgb = true;
   this->green = g;
}


// --------------------------------------------------
void S3DColor::B (float b)
{
   this->hsv = false;
   this->rgb = true;
   this->blue = b;
}


// --------------------------------------------------
void S3DColor::A (float a)
{
   this->alpha = a;
}


// --------------------------------------------------
void S3DColor::H (float h)
{
   this->hsv = true;
   this->rgb = false;
   this->hue = h;
}


// --------------------------------------------------
void S3DColor::S (float s)
{
   this->hsv = true;
   this->rgb = false;
   this->saturation = s;
}


// --------------------------------------------------
void S3DColor::V (float v)
{
   this->hsv = true;
   this->rgb = false;
   this->value = v;
}


// --------------------------------------------------
float S3DColor::R (void)
{
   if (this->rgb == true)
      return this->red;
   else
      if (this->hsv == true)
      {
	 this->HSVtoRGB ();
	 return this->red;
      }
}


// --------------------------------------------------
float S3DColor::G (void)
{
   if (this->rgb == true)
      return this->green;
   else
      if (this->hsv == true)
      {
	 this->HSVtoRGB ();
	 return this->green;
      }
}


// --------------------------------------------------
float S3DColor::B (void)
{
   if (this->rgb == true)
      return this->blue;
   else
      if (this->hsv == true)
      {
	 this->HSVtoRGB ();
	 return this->blue;
      }
}


// --------------------------------------------------
float S3DColor::A (void)
{
   return this->alpha;
}


// --------------------------------------------------
float S3DColor::H (void)
{
   if (this->hsv == true)
      return this->hue;
   else
      if (this->rgb == true)
      {
	 this->HSVtoRGB ();
	 return this->hue;
      }
}


// --------------------------------------------------
float S3DColor::S (void)
{
   if (this->hsv == true)
      return this->saturation;
   else
      if (this->rgb == true)
      {
	 this->HSVtoRGB ();
	 return this->saturation;
      }
}


// --------------------------------------------------
float S3DColor::V (void)
{
   if (this->hsv == true)
      return this->value;
   else
      if (this->rgb == true)
      {
	 this->HSVtoRGB ();
	 return this->value;
      }
}


// --------------------------------------------------
void S3DColor::setHSV (float h, float s, float v)
{
   this->hue = h;
   this->saturation = s;
   this->value = v;

   this->hsv = true;
   this->rgb = false;
}


// --------------------------------------------------
void S3DColor::setHSV (float h, float s, float v, float a)
{
   this->hue = h;
   this->saturation = s;
   this->value = v;
   this->alpha = a;

   this->hsv = true;
   this->rgb = false;
}


// --------------------------------------------------
void S3DColor::setRGB (float r, float g, float b)
{
   this->red = r;
   this->green = g;
   this->blue = b;

   this->hsv = false;
   this->rgb = true;
}


// --------------------------------------------------
void S3DColor::setRGB (float r, float g, float b, float a)
{
   this->red = r;
   this->green = g;
   this->blue = b;
   this->alpha = a;

   this->hsv = false;
   this->rgb = true;
}


// --------------------------------------------------
S3DColor *S3DColor::copy (void)
{
   S3DColor *c = new S3DColor ();

   if (this->hsv == true)
   {
      c->setHSV (this->hue, this->saturation, this->value, this->alpha);
   }
   else
   {
      c->setRGB (this->red, this->green, this->blue, this->alpha);
   }
   
   return c;
}


// --------------------------------------------------
void S3DColor::print (void)
{
   this->print(0);
}


// --------------------------------------------------
void S3DColor::print (const char *str)
{
   unsigned int i, le;
   const char *color = "\033[22;32m";
   const char *black = "\033[22;30m";

   if (str == 0)
      std::cerr << color << "Color: {";
   else
      std::cerr << color << "Color \"" << str << "\": {";

   std::cerr << black;

   if (this->rgb)
   {
      std::cerr << "RGB(";
      std::cerr << this->red << ", ";
      std::cerr << this->green << ", ";
      std::cerr << this->blue;
      std::cerr << "), ";
   }
   
   if (this->hsv)
   {
      std::cerr << "HSV(";
      std::cerr << this->hue << ", ";
      std::cerr << this->saturation << ", ";
      std::cerr << this->value;
      std::cerr << "), ";
   }

   std::cerr << "Alpha(" << this->alpha << ")";

   std::cerr << color << "}";
   std::cerr << black << std::endl;

   return;
}

