#include "scene.hh"


// --------------------------------------------------
S3DScene::S3DScene (void)
{
   this->camera = 0;
   this->screenWidth = this->screenHeight = 800;
   this->iniframe = 0;
   this->endframe = 0;
   this->fps = 25;
   this->nframes = 0;
   this->frameAction = 0;
   this->currentframe = 0;
}


// --------------------------------------------------
S3DScene::S3DScene (S3DScene *scene)
{
   // TODO
}


// --------------------------------------------------
void S3DScene::initAnimation(void)
{
   this->currentframe = this->iniframe;
}


// --------------------------------------------------
void S3DScene::endAnimation(void)
{
   this->currentframe = this->endframe;
}


// --------------------------------------------------
void S3DScene::updateFrame(float t)
{
   float time = (float) this->nframes / (float) this->fps;
   
   while (t >= time)
      t -= time; 

   this->currentframe = (t / time) * this->nframes + this->iniframe;
}


// --------------------------------------------------
void S3DScene::nextFrame(void)
{
   long int index = this->currentframe;
   
   index ++;
   this->currentframe = index;
   if (this->currentframe > this->endframe)
      this->currentframe = this->iniframe;
}


// --------------------------------------------------
void S3DScene::executeActions(void)
{
   long int index, i;
   S3DAnimItem anim;
   S3DVector *v;
   S3DCamera *cam;
   S3DMesh *msh;

   if (this->frameAction == 0)
      return;

   index = (int) (this->currentframe - this->iniframe);
   //std::cerr << " Animation Index = " << index << std::endl;
   for (i = 0; i < this->frameAction[index].size(); i ++)
   {
      anim = this->frameAction[index][i];

      if (!strcmp(anim.typeobj, "camera"))
      {
	 if (!strcmp(anim.action, "position"))
	 {
	    cam = (S3DCamera *) anim.obj;
	    v = (S3DVector *) anim.data;
	    cam->setPosition(v->X(), v->Y(), v->Z());
//	    v->print(" Camera position = ");
	 }
	 else if (!strcmp(anim.action, "rotation"))
	 {
	    cam = (S3DCamera *) anim.obj;
	    v = (S3DVector *) anim.data;
	    cam->setEulerAngles(v->X(), v->Y(), v->Z());
//	    v->print(" Camera angles = ");
	 }
      }
      else if (!strcmp(anim.typeobj, "mesh"))
      {
	 if (!strcmp(anim.action, "position"))
	 {
	    msh = (S3DMesh *) anim.obj;
	    v = (S3DVector *) anim.data;
	    msh->setPosition(v->X(), v->Y(), v->Z());
//	    v->print(" Object position = ");
	 }
	 else if (!strcmp(anim.action, "rotation"))
	 {
	    msh = (S3DMesh *) anim.obj;
	    v = (S3DVector *) anim.data;
	    msh->setEulerAngles(v->X(), v->Y(), v->Z());
//	    v->print(" Object orientation = ");
	 }
	 else if (!strcmp(anim.action, "scale"))
	 {
	    msh = (S3DMesh *) anim.obj;
	    v = (S3DVector *) anim.data;
	    msh->setScale(v->X(), v->Y(), v->Z());
//	    v->print(" Object scale = ");
	 }
      }
   }
   
   return;
}


// --------------------------------------------------
void S3DScene::draw (void)
{
   unsigned int i;

   if (camera != 0)
      camera->draw();

   glColor3f(1, 1, 1);
   for (i = 0; i < this->mesh.size(); i ++)
   {
      mesh[i]->draw(true);
   }

   return;
}


// --------------------------------------------------
unsigned int S3DScene::getWidth (void)
{
   return this->screenWidth;
}


// --------------------------------------------------
unsigned int S3DScene::getHeight (void)
{
   return this->screenHeight;
}


// --------------------------------------------------
int S3DScene::load (const char *filename)
{
   if (this->loadS3DGER(filename) != 0)
      return 1;

   return 0;
}


// --------------------------------------------------
S3DScene::~S3DScene (void)
{
   long int i;

   if (this->mesh.size() > 0)
      for (i = 0; i < this->mesh.size(); i ++)
	 delete this->mesh[i];
}


// --------------------------------------------------
int S3DScene::loadS3DGER (const char *filename)
{
   int animtype = 0;
   long int i, idobj, kk;
   int verror = 0;
   char line[4096];
   char *nospc;
   bool firstline, read;
   S3DMesh *msh;
   S3DVector *v;
   float *arrayf;
   long int *arrayli;
   long int sizev;

   std::ifstream file (filename);
   if (!file.is_open())
   {
      std::cerr << "Warning: File \'" << filename << "\' cannot be openned\n"; 
      return 0;
   }

   if (this->camera != 0)
      delete this->camera;
   
   this->camera = new S3DCamera();

   firstline = true;
   read = true;
   do 
   {
      if (read)
      {
	 line[0] = '\0';
	 file.getline (line, 4096);
      }
      else
      {
	 read = true;
      }

      if (firstline == true)
      {
	 if (strncmp(line, "# S3D_GER FORMAT v", 18) )
	 {
	    return 1; // It is not a S3D file
	 }
	 
	 std::cout << "Loading version [" << line + 18 << "]...\n";

	 firstline = false;
      }

      if (line[0] == '!') // A command
      {
	 if (!strncmp(line, "!START FRAME:", 13))
	 {
	    this->iniframe = atoi(line + 13);
	    this->nframes = this->endframe - this->iniframe + 1;
	    if (this->nframes < 0)
	       this->nframes = 0;
	 }
	 else if (!strncmp(line, "!END FRAME:", 11))
	 {
	    this->endframe = atoi(line + 11);
	    this->nframes = this->endframe - this->iniframe + 1;
	    if (this->nframes < 0)
	       this->nframes = 0;
	 }
	 else if (!strncmp(line, "!RENDER WIDTH:", 14))
	    this->screenWidth = atoi(line + 14);
	 else if (!strncmp(line, "!RENDER HEIGHT:", 15))
	    this->screenHeight = atoi(line + 15);
	 else if (!strncmp(line, "!FPS:", 5))
	    this->fps = atoi(line + 5);
	 else if (!strncmp(line, "!FRAME:", 7))
	 {
	    this->currentframe = atol(line + 7);
	 }
	 else if (!strncmp(line, "!ANIMATION TYPE:", 16))
	 {
	    nospc = removeWhiteSpaces(line + 16);

	    if (!strcmp(nospc, "NONE"))
	       animtype = 0;
	    else if (!strcmp(nospc, "SIMPLE"))
	       animtype = 1;
	    else
	       animtype = 100; // UNKNOWN

	    delete [] nospc;
	 }
	 else if (!strncmp(line, "!NUM OF OBJ:", 12))
	 {
	    for (i = 0; i < atoi(line + 12); i ++)
	       this->mesh.push_back(new S3DMesh());
	 }
	 else if (!strncmp(line, "!CURRENT CAMERA:", 16))
	 {
	    // ------------------------------
	    do 
	    {
	       line[0] = '\0';
	       file.getline (line, 4096);

//	       std::cerr << line << "\n"; // DEBUG

	       if (!strncmp(line, "!+NAME:", 7))
	       {
		  nospc = removeWhiteSpaces(line + 7);
		  this->camera->setName(nospc);
		  delete [] nospc;
	       }
	       else if (!strncmp(line, "!+FOV:", 6))
	       {
		  this->camera->setFOV(atof(line + 6));
	       }
	       else if (!strncmp(line, "!+ASPECT:", 9))
	       {
		  this->camera->setAspect(atof(line + 9));
	       }
	       else if (!strncmp(line, "!+CLIP START:", 13))
	       {
		  this->camera->setNearPlane(atof(line + 13));
	       }
	       else if (!strncmp(line, "!+CLIP END:", 11))
	       {
		  this->camera->setFarPlane(atof(line + 11));		  
	       }
	       else if (!strncmp(line, "!+POSITION:", 11))
	       {
		  if (animtype == 0)
		  {
		     v = parseVector(line + 11);
		     this->camera->setPosition(v->X(), v->Y(), v->Z());
		     delete v;
		  }
		  else if (animtype == 1)
		  {
		     v = parseVector(line + 11);
		     this->addAction("position", "camera", v, this->camera);
		  }
	       }
	       else if (!strncmp(line, "!+ROTATION:", 11))
	       {
		  if (animtype == 0)
		  {
		     v = parseVector(line + 11);
		     this->camera->setEulerAngles(v->X(), v->Y(), v->Z());
		     delete v;
		  }
		  else if (animtype == 1)
		  {
		     v = parseVector(line + 11);
		     this->addAction("rotation", "camera", v, this->camera);
		  }
	       }
       
	    } 
	    while (!strncmp(line, "!+", 2));
	    // ------------------------------

	    read = false;
	 }
	 else if (!strncmp(line, "!MESH OBJ:", 10))
	 {
	    idobj = atol(line + 10);
	    msh = this->mesh[idobj];

	    // ------------------------------
	    do 
	    {
	       line[0] = '\0';
	       file.getline (line, 4096);

	       if (!strncmp(line, "!+VERTICES:", 11))
	       {
		  sizev = atol(line + 11);
		  arrayf = new float[sizev * 3];

		  for (kk = 0; kk < sizev; kk++)
		  {
		     line[0] = '\0';
		     file.getline (line, 4096);
		     v = parseVector(line);
		     arrayf[kk * 3] = v->X();
		     arrayf[kk * 3 + 1] = v->Y();
		     arrayf[kk * 3 + 2] = v->Z();
		     delete v;
		  }		     

		  msh->ovwVertices(arrayf, sizev);
		  msh->computeBoundingBox();
		  arrayf = 0;
		  /* arrayf is not freed*/
		  line[0] = '!'; /* set to 0 if everything is right */
		  line[1] = '+'; /* set to 0 if everything is right */
		  line[2] = '0'; /* set to 0 if everything is right */
	       }
	       else if (!strncmp(line, "!+FACES:", 8))
	       {
		  sizev = atol(line + 8);
		  arrayli = new long int[sizev * 3];

		  for (kk = 0; kk < sizev; kk++)
		  {
		     line[0] = '\0';
		     file.getline (line, 4096);
		     v = parseVector(line);
		     arrayli[kk * 3] = v->X();
		     arrayli[kk * 3 + 1] = v->Y();
		     arrayli[kk * 3 + 2] = v->Z();
		     delete v;
		  }		     

		  msh->ovwFaces(arrayli, sizev);
		  arrayli = 0;
		  /* arrayli is not freed*/
		  line[0] = '!'; /* set to 0 if everything is right */
		  line[1] = '+'; /* set to 0 if everything is right */
		  line[2] = '0'; /* set to 0 if everything is right */
	       }
	       else if (!strncmp(line, "!+NORMALS:", 10))
	       {
		  sizev = atol(line + 10);
		  arrayf = new float[sizev * 3];

		  for (kk = 0; kk < sizev; kk++)
		  {
		     line[0] = '\0';
		     file.getline (line, 4096);
		     v = parseVector(line);
		     arrayf[kk * 3] = v->X();
		     arrayf[kk * 3 + 1] = v->Y();
		     arrayf[kk * 3 + 2] = v->Z();
		     delete v;
		  }		     

		  msh->ovwNormals(arrayf, sizev);
		  arrayf = 0;
		  /* arrayf is not freed*/
		  line[0] = '!'; /* set to 0 if everything is right */
		  line[1] = '+'; /* set to 0 if everything is right */
		  line[2] = '0'; /* set to 0 if everything is right */
	       }
	       else if (!strncmp(line, "!+UV:", 5))
	       {
		  sizev = atol(line + 5);
		  //TODO
		  line[0] = '!'; /* set to 0 if everything is right */
		  line[1] = '+'; /* set to 0 if everything is right */
		  line[2] = '0'; /* set to 0 if everything is right */
	       }
       
	    } 
	    while (!strncmp(line, "!+", 2));
	    // ------------------------------

	    read = false;
	 }
	 else if (!strncmp(line, "!ID OBJ:", 8))
	 {
	    idobj = atol(line + 8);
	    msh = this->mesh[idobj];

	    // ------------------------------
	    do 
	    {
	       line[0] = '\0';
	       file.getline (line, 4096);

	       if (!strncmp(line, "!+NAME:", 7))
	       {
		  nospc = removeWhiteSpaces(line + 7);
		  msh->setName(nospc);
		  delete [] nospc;
	       }
	       else if (!strncmp(line, "!+POSITION:", 11))
	       {
		  if (animtype == 0)
		  {
		     v = parseVector(line + 11);
		     msh->setPosition(v->X(), v->Y(), v->Z());
		     delete v;
		  }
		  else if (animtype == 1)
		  {
		     v = parseVector(line + 11);
		     this->addAction("position", "mesh", v, msh);
		  }
	       }
	       else if (!strncmp(line, "!+ROTATION:", 11))
	       {
		  if (animtype == 0)
		  {
		     v = parseVector(line + 11);
		     msh->setEulerAngles(v->X(), v->Y(), v->Z());
		     delete v;
		  }
		  else if (animtype == 1)
		  {
		     v = parseVector(line + 11);
		     this->addAction("rotation", "mesh", v, msh);
		  }
	       }
	       else if (!strncmp(line, "!+SCALE:", 8))
	       {
		  if (animtype == 0)
		  {
		     v = parseVector(line + 8);
		     msh->setScale(v->X(), v->Y(), v->Z());
		     delete v;
		  }
		  else if (animtype == 1)
		  {
		     v = parseVector(line + 8);
		     this->addAction("scale", "mesh", v, msh);
		  }

	       }
       
	    } 
	    while (!strncmp(line, "!+", 2));
	    // ------------------------------

	    read = false;
	 }

      }
   }
   while (!file.eof());
   

   file.close();
   return verror;
}


// --------------------------------------------------
void S3DScene::addAction(const char *action, const char *typeobj,
			 void *data, void *obj)
{
   long int index;
   S3DAnimItem anim;

   this->nframes = this->endframe - this->iniframe + 1;

   if (this->frameAction == 0)
      this->frameAction = new std::vector <S3DAnimItem>[this->nframes];
   
   anim.action = action;
   anim.typeobj = typeobj;
   anim.data = data;
   anim.obj = obj;

   index = (int)(this->currentframe - this->iniframe);
   this->frameAction[index].push_back(anim);

   //std::cerr << "Animation index = " << index << "\n";

   return;
}


// --------------------------------------------------
char *S3DScene::removeWhiteSpaces(const char *str)
{
   unsigned int i, j;
   char *outstr;

   if (str == 0)
      return 0;
   
   
   outstr = new char[strlen(str) + 1];
   
   j = 0;
   for (i = 0; i < strlen(str); i ++)
   {
      if ( (str[i] != ' ') && (str[i] != '\t') && (str[i] != '\r') &&
	   (str[i] != '\n') && (str[i] != '\0') )
      {
	 outstr[j] = str[i];
	 j ++;
      }

   }
   outstr[j] = '\0';

   return outstr;
}


// --------------------------------------------------
S3DVector *S3DScene::parseVector(const char *str, char sep)
{
   bool end;
   long int i, j, k;
   char outstr[1000];
   S3DVector *v;


   if (str == 0)
      return 0;

   k = 0;


   v = new S3DVector(10);
   for (i = 0; i < 10; i ++)
      v->set(i, 0.0);

   i = 0;
   end = false;


   while (!end)
   {
      while ( (str[i] == sep) ||
	      (str[i] == ' ') ||  (str[i] == '\t') ||
	      (str[i] == '\r') || (str[i] == '\n') )
      {
	 i ++;
      }
      if (str[i] == '\0')
	 end = true;

      j = 0;
      if (!end)
	 while ( (str[i] != sep) &&
		 (str[i] != ' ') &&  (str[i] != '\t') &&
		 (str[i] != '\r') && (str[i] != '\n') &&
		 (str[i] != '\0') )
	 {
	    outstr[j] = str[i];
	    j ++;
	    i ++;
	 }
      if (str[i] == '\0')
	 end = true;

      outstr[j] = '\0';
      
      v->set(k, atof(outstr)); 
      k ++;
   }
   
   return v;
}
