#ifndef __SHADER_OBJ__
#define __SHADER_OBJ__


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glew.h>
#include <cstring>
#include <iostream>
#include <fstream>


/** @class   S3DShaderObj shader.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a shader programs manager. It can read the programs
 *           from files or it can load the text file of the program directly.
 *
 *  @bug     No bugs detected yet
 *  @warning 
 */


class S3DShaderObj {

   public:

      /** 
      * @post Constructor. Inizialite the empty image.
      */
      S3DShaderObj (void);

      /** 
       * @param[in] b The shader
       * @post Constructor copy
      */
      S3DShaderObj (S3DShaderObj *b);

      /**
       * @post Destructor
       */
      ~S3DShaderObj (void);

      /**
       * @param[in] The object (shader or program)
       * @post Prints errors from shaders and programs
       */
      void printObjectInfoLog (GLuint obj);

      /**
       * @post Uses the current program
       */
      void useProgram (void);

      /**
       * @post Uses the default OPENGL pipeline
       */
      void doNotUseProgram (void);

      /**
       * @post Returns the text of the program
       */
      char* getText (void);

      /**
       * @param[in] fileVertex The name of the file for the vertex program
       * @param[in] fileFragment The name of the file for the fragment program
       * @post Loads both programs from files; 
       *       if some one is 0, it is not loaded
       */
      bool loadPrograms (const char *fileVertex, 
			 const char *fileFragment);

      /**
       * @param[in] vertexP The text with the vertex program
       * @param[in] fragmentP The text with the fragment program
       * @post Loads both programs from text; if some one is 0, it is not loaded
       */
      bool loadTextPrograms (const char *vertexP, 
			     const char *fragmentP);
      
      /**
       * @post Returns the current program
       */
      GLuint getProgram (void);

      /**
       * @post Returns the vertex shader
       */
      GLuint getVertexS (void);

      /**
       * @post Returns the fragment shader
       */
      GLuint getFragmentS (void);

      /**
       * @param[in] var The name of the variable
       * @post Locates a variable in the shader
       */
      GLint locate (const char *var);

      /**
       * @post Clears the shaders
       */
      void clearShaders (void);

   protected:

      /**
       * @pre filename must be a valid file
       * @param[in] filename The name of the file
       * @post Read a text file for the present shader
       *
       */
      void readFile (const char *filename);

   private:
      GLuint sh_p, sh_v, sh_f;
      char *sh_text;
      unsigned long int sh_textSize;
};



#endif 
