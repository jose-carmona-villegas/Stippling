#ifndef __IMGCACHE__
#define __IMGCACHE__

#include <iostream>
#include <math.h>
#include <SDL/SDL_image.h>
#include <GL/glew.h>
#include <vector>
#include "image.hh"

/** @class   S3DImagesCache imgcache.hh
 *  @author  Germ�n Arroyo
 *  @date    2007
 *  @brief   This class is an image manager class. It allows scale with 
 *           differents algorithms.
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning Be careful with the performance of some of the methods
 */

class S3DImagesCache {
   public:

      /** 
      * @post Constructor. Inizialite the empty image.
      */
      S3DImagesCache(void);

      /** @post Destructor. Memory is freed here.
       */
      ~S3DImagesCache(void);

      /**
       * @param[in] name A short name for the image in the cache
       * @post The image in the cache
       */
      S3DImage *getImage(const char *name);

      /**
       * @param[in] filename A valid filename for the new image in the cache
       * @param[in] name A valid name for the new image in the cache or 0
       *                 it it is 0, the name will be the filename
       * @post Add a new image to the cache
       * @note name must be unique or the algorithm to search the name will not
       *       work properly
       */
      void addImage(const char *filename, const char *name=0);

      /**
       * @param[in] filename A valid name for the new image in the cache
       * @post Remove a image from the cache
       */
      void removeImage(const char *name);

      /**
       * @param[in] unit The unit of the texture: GL_TEXTURE0, GL_TEXTURE2, etc.
       * @param[in] interp The way of the interpolation: GL_LINEAR, GL_NEAREST
       * @param[in] way One of this values: GL_CLAMP, GL_REPEAT, etc.
       * @param[in] mode The way to put the texture: GL_DECAL, GL_MODULATE,etc.
       * @post Set (or reset) the textures from the images
       */
      void setTexture2D(GLenum unit, GLenum interp, GLenum way,
			GLenum mode);

      /**
       * @param[in] name The name of the image
       * @post The ID of the texture of the image
       */
      GLuint getTexture2D(const char *name);

      /**
       * @param[in] newpath A valid path to search the files
       * @post The ID of the path
       * @warning This method will change the name of the files, so if some of
       *          the images had the same name the algorithm to search will fail
       */
      void setPath (const char *newpath);

      /**
       * @param[in] max The maximum available memory in the graphics card
       *                if max is less than 0, the available memory has no limit
       * @post Change the available memory
       */
      void setMaxMemoryAvailable (long int max = -1);

      /**
       * @param[in] unit The unit of the texture: GL_TEXTURE0, GL_TEXTURE2, etc.
       * @param[in] interp The way of the interpolation: GL_LINEAR, GL_NEAREST
       * @param[in] way One of this values: GL_CLAMP, GL_REPEAT, etc.
       * @param[in] mode The way to put the texture: GL_DECAL, GL_MODULATE,etc.
       * @post Select the texture mode to apply
       */
      void setTextureMode(GLenum unit, GLenum interp, GLenum way, GLenum mode);

      /**
       * @post Set the textures with the default mode
       */
      void setTexture2D(void);

   protected:
      
      /**
       * @param[in] filename A valid filename for the new image in the cache
       * @post The index of the image in the vector or a number less than 0 if
       *       the image does not exist
       */
      long int getIndex (const char *filename);

   private:
      std::vector <S3DImage *> limg; /// List of images
      std::vector <char *> lname; /// List of name of the images
      std::vector <long int> lcnt; /// List of counters
      char *path; /// The path to search images
      long int maxmemory; /// The maximum amount of bytes available
      long int usedmemory; /// The amount of used memory
      GLenum unitP; // Unit parameter of the texture
      GLenum interpP; // Interpolator parameter of the texture
      GLenum wayP; // Way parameter of the texture
      GLenum modeP; // Mode parameter of the texture
};


#endif

