#ifndef __FILEMGR__
#define __FILEMGR__

#include <fstream>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <cstring>

#ifdef WINDOWS
#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#else

#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

#endif


/** @class   S3DFileMgr filemgr.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class manage all kind of files and directories

 *
 *  @bug     No bugs detected yet
 *  @warning It doesn't work for Windows O.S. yet
 */

class S3DFileMgr {
   public:
      /** 
       * @post Constructor, make a black color
       */
      S3DFileMgr ();

      /** 
       * @pre directory must be valid
       * @param[in] dir The directory
       * @post Constructor, make file manager
       */
      S3DFileMgr (const char *dir);
      
      /** 
       * @post Destructor, free the memory
       */
      ~S3DFileMgr ();
      
      /** 
       * @pre dir must be a valid subpath
       * @param[in] dir The path
       * @post Switch to a new directory inside of the present one
       */
      void getInDir (const char *dir);

      /** 
       * @pre dir must be a valid text
       * @param[in] dir The directory
       * @post Switch to a new directory
       */
      void switchDir (const char *dir);

      /** 
       * @param[in] completePath If the returned name is with complete path
       * @post Get the file pointed by the index
       * @warning You can free the pointer safely
       */
      char *getFileName (bool completePath=true);

      /** 
       * @param[in] completePath If the returned name is with complete path
       * @pre i must be a valid number  
       * @post Get the file pointer by i
       * @warning You can free the pointer safely
       */
      char *getFileName (unsigned int i, bool completePath=true);

      /** 
       * @post Get the size of the file pointed by the index
       * @warning You can free the pointer safely
       */
      float getFileSize (void);

      /** 
       * @pre i must be a valid number  
       * @post Get the size of the file pointer by i
       * @warning You can free the pointer safely
       */
      float getFileSize (unsigned int i);

      /** 
       * @post The number of elements in the directory
       */
      unsigned int numOfElements (void);

      /** 
       * @post Remove the directory "." from the list
       */
      void removeDot (void);

      /** 
       * @post True if the present pointed file is a directory, false otherwise
       */
      bool isDirectory (void);

      /** 
       * @param[in] i The index
       * @post True if the present pointed file is a directory, false otherwise
       */
      bool isDirectory (int i);

      /** 
       * @param[in] i The index
       * @post True if the present pointed file is a file, false otherwise
       */
      bool isFile (int i);

      /** 
       * @post True if the present pointed file is a file, false otherwise
       */
      bool isFile (void);

      /** 
       * @post true if the pointer is moved to the next file, 
       *       false if the pointer is already pointing to the last element
       */
      bool nextFile (void);

      /** 
       * @post true if the pointer is moved to the previous file, 
       *       false if the pointer is already pointing to the first element
       */
      bool prevFile (void);

      /**
       * @post  Print this color to cerr (DEBUG)
       */
      void print (void);

      /**
       * @param[in] str String to display, if 0 no text displayed
       * @post  Print this color to cerr (DEBUG)
       */
      void print (const char *str);

      /**
       * @param[in] s True or false
       * @post  Hide warning and error messages
       */
      void hideMsg (bool s);

   private:

      /**
       * @post  clean the memory
       */
      void clean (void);

#ifdef WINDOWS

#else
      DIR *dp; /// Directory descriptor
      struct dirent *dirp; /// Directory structure
#endif
      std::vector <char *> fnames; /// Name of the files
      std::vector <int> typeFile; /** Type of the file (0 = file, 1 = directory
                                   *  2 = unknown) */
      long int index; /// the index
      char *dirname; /// the name of the present directory
      bool showWarnings; /// show the warnings
};

#endif

