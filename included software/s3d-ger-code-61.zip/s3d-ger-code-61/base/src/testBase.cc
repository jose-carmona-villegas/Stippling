#include <iostream>
#include <math.h>

#include "matrix.hh"
#include "vector.hh"
#include "color.hh"
#include "filemgr.hh"

int main (int argc, char *argv[])
{
   S3DVector *v0, *v1, *v;
   S3DMatrix *m0, *m1, *m;
   S3DColor  *c0, *c1; 
   const double pi = 3.141516;

   std::cerr << "-------------------------------------------" << std::endl;
   std::cerr << "-----------   VECTOR TEST   ---------------" << std::endl;
   std::cerr << "-------------------------------------------" << std::endl;
   
   v0 = new S3DVector (1.0, 1.0, 1.0, 1.0);
   v1 = new S3DVector (0.3, 0.2, 0.1, 1.0);

   v0->print("v0");
   v1->print("v1");

   v = v0->plus(v1);
   v->print("v0+v1");
   delete v;
   v = v0->minus(v1);
   v->print("v0-v1");
   delete v;
   v = v1->minus(v0);
   v->print("v1-v0");
   delete v;
   v = v0->minus(v0);
   v->print("v0-v0");
   delete v;
   v = v0->normalize();
   v->print("v0 normalized");
   delete v;
   v = v1->dot(5);
   v->print("v1 · 5");
   delete v;
   v = v1->cross(v0);
   v->print("v1 x v0");
   delete v;
   v = v0->cross(v0);
   v->print("v0 x v0");
   delete v;
   v = v0->copyWithLength(5);
   v->print("v0 with size = 5");
   delete v;
   v = v0->copyWithLength(1);
   v->print("v0 with size = 1");
   delete v;

   std::cerr << "v0 · v0 = " << v0->dot(v0) << std::endl;
   std::cerr << "mag(v0) = " << v0->magnitude() << std::endl;


   std::cerr << "-------------------------------------------" << std::endl;
   std::cerr << "-----------   MATRIX TEST   ---------------" << std::endl;
   std::cerr << "-------------------------------------------" << std::endl;

   
   m0 = new S3DMatrix (S3DMatrix::IDENTITY, 4);
   m1 = new S3DMatrix (S3DMatrix::IDENTITY, 4);
   m0->setTranslateMatrix(3, 5, 2);
   m1->setRotateXMatrix(90.0 * pi / 180.0);

   m0->print("m0");
   m1->print("m1");

   m = m0->plus(m1);
   m->print("m0+m1");
   delete m;

   m = m0->minus(m1);
   m->print("m0-m1");
   delete m;

   m = m0->dot(m1);
   m->print("m0 · m1");
   delete m;

   m = m0->cross(m1);
   m->print("m0 x m1");
   delete m;

   m = m0->dot(4);
   m->print("m0 · 4");
   delete m;

   m = m0->transpose();
   m->print("Transp(m0)");

   std::cerr << "-------------------------------------------" << std::endl;
   std::cerr << "---------   VECTOR & MATRIX TEST ----------" << std::endl;
   std::cerr << "-------------------------------------------" << std::endl;

   v = v0->mult4x4Matrix(m0->get());
   v->print ("v0 translated by m0");
   delete v0;
   v0 = v;
   v = v0->mult4x4Matrix(m1->get());
   v->print("v rotated 90 degrees in x axis by m1");


   std::cerr << "-------------------------------------------" << std::endl;
   std::cerr << "------------   COLOR TEST   ---------------" << std::endl;
   std::cerr << "-------------------------------------------" << std::endl;

   c0 = new S3DColor ();
   c1 = new S3DColor (0.2, 0.5, 0.3);
   c0->print ("c0 -> undefined");
   c1->print ("c1 -> set RGB");

   c0->setHSV(350, 0.5, 1.0);
   c1->RGBtoHSV();
   c0->print ("c0 -> set HSV");
   c1->print ("c1 -> convert RGB to HSV");

   c0->setRGB(0.5, 0.5, 1.0);
   c1->setHSV(10, 0.1, 0.1);
   c0->print ("c0 -> set RGB");
   c1->print ("c1 -> set HSV");

   c0->RGBtoHSV();
   c1->HSVtoRGB();
   c0->print ("c0 -> convert to HSV");
   c1->print ("c1 -> convert to RGB");

   std::cerr << "-------------------------------------------" << std::endl;
   std::cerr << "------------   FILE  TEST   ---------------" << std::endl;
   std::cerr << "-------------------------------------------" << std::endl;

   S3DFileMgr *fm = new S3DFileMgr("./");
   fm->hideMsg(true);
   fm->print("Files in this directory:");
   fm->switchDir("../../");
   fm->print("Files in ../..");
   fm->getInDir("volum");
   fm->print("Files in ../../volum");

   delete fm;


   delete c0;
   delete c1;
   delete m;
   delete v;
   delete v0;
   delete v1;
   delete m0;
   delete m1;
   return 0;
}
