#ifndef __IMAGE__
#define __IMAGE__

#include <iostream>
#include <math.h>
#include <SDL/SDL_image.h>
#include <GL/glew.h>
#include "matrix.hh"
#include "mathematic.hh"

/** @class   S3DImage image.hh
 *  @author  Germ�n Arroyo
 *  @date    2007
 *  @brief   This class is an image manager class. It allows scale with 
 *           differents algorithms.
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning Be careful with the performance of some of the methods
 */

class S3DImage {
   public:

      /// Use the best interpolation method, no matter the performance
      static const unsigned int QUALITY         = 0x01;

      /// Use the best performance algorithm
      static const unsigned int PERFORMANCE     = 0x02;

      /// Use the nearest point algorithm (good performance, bad quality)
      static const unsigned int NEAREST         = 0x03;

      /// Use a bilinear algorithm (good quality when the output is larger)
      static const unsigned int LINEAR          = 0x04;

      /// Use a reduction algorithm (good quality when the output is smaller)
      static const unsigned int TILED           = 0x05;

      /// Use OpenGL to resize the image
      static const unsigned int OPENGL          = 0x06;

      // TODO
      // static const unsigned int BICUBIC         = 0x07;


      /// Operators:
      /// color 0: c0 = (r0, g0, b0, a0)
      /// color 1: c1 = (r1, g1, b1, a1)
      /// value: k
      /// ---------
      /// r0 + r1, g0 + g1, b0 + b1, a0 + a1
      static const unsigned int ADD                  = 0x01;
      /// r0 - r1, g0 - g1, b0 - b1, a0 - a1
      static const unsigned int SUBTRACT             = 0x02;
      /// r0 * r1, g0 * g1, b0 * b1, a0 * a1
      static const unsigned int MULTIPLY             = 0x03;
      /// r0 / r1, g0 / g1, b0 / b1, a0 / a1
      static const unsigned int DIVIDE               = 0x04;
      /// max(r0, r1), max(g0, g1), max(b0, b1), max(a0, a1)
      static const unsigned int MAX                  = 0x05;
      /// min(r0, r1), min(g0, g1), min(b0, b1), min(a0, a1)
      static const unsigned int MIN                  = 0x06;
      /// r0 ^ r1, g0 ^ g1, b0 ^ b1, a0 ^ a1
      static const unsigned int POWERTO              = 0x07;
      /// r1, g0, b0, a0
      static const unsigned int COPYRED              = 0x08;
      /// r0, g1, b0, a0
      static const unsigned int COPYGREEN            = 0x09;
      /// r0, g0, b1, a0
      static const unsigned int COPYBLUE             = 0x10;
      /// r0, g0, b0, a1
      static const unsigned int COPYALPHA            = 0x11;
      /// r1, g1, b1, a0
      static const unsigned int COPYRGB              = 0x12;
      /// r1, g1, b1, a1
      static const unsigned int COPYRGBA             = 0x28;
      /// ||c0 + c1||
      static const unsigned int MAGNITUDE            = 0x13;
      /// atan(c0, c1)
      static const unsigned int ANGLE                = 0x14;
      /// if (c0 = c1) -> c0, otherwise: 0
      static const unsigned int EQUAL                = 0x15;
      /// -c0
      static const unsigned int INVERT               = 0x16;
      /// c0 = vec4((r0 + g0 + b0 + a0) / 3, 1.0)
      static const unsigned int DESATURATE           = 0x17;
      /// c0 ^ k
      static const unsigned int CONTRAST             = 0x18;
      /// c0 + k
      static const unsigned int BRIGHTNESS           = 0x19;
      /// if (c0 > k) -> 1.0, otherwise: 0
      static const unsigned int THRESHOLD            = 0x20;
      /// Rotate the value of the pixel 
      static const unsigned int CWTANGENTx           = 0x21;
      /// Rotate the value of the pixel 
      static const unsigned int CWTANGENTy           = 0x23;
      /// Rotate the value of the pixel 
      static const unsigned int CCWTANGENTx          = 0x24;
      /// Rotate the value of the pixel 
      static const unsigned int CCWTANGENTy          = 0x25;
      /// ||c0||
      static const unsigned int NORMALIZE            = 0x26;
      /// (k, k, k, a0)
      static const unsigned int SETRGB               = 0x27;
      /// (k, g0, b0, a0)
      static const unsigned int SETRED               = 0x29;
      /// (r0, k, b0, a0)
      static const unsigned int SETGREEN             = 0x30;
      /// (r0, g0, k, a0)
      static const unsigned int SETBLUE              = 0x31;
      /// (r0, g0, b0, k)
      static const unsigned int SETALPHA             = 0x32;
      /// vec4(k)
      static const unsigned int SETRGBA              = 0x33;
      /// ||c1||
      static const unsigned int NORMALIZEDEST        = 0x34;
      /// c0 / (c0^2 + c1^1)
      static const unsigned int NORMVECTORS          = 0x35;

      /** 
      * @post Constructor. Inizialite the empty image.
      */
      S3DImage(void);

      /** 
       * @pre s must be a valid surface
       * @post Constructor. Inizialite a non empty image.
       * @warning Do not free s, this object will do it for you
       * @param[in] s The surface
      */
      S3DImage(SDL_Surface *s);

      /**
       * @pre img The image to copy
       * @post Constructor copy
       * @warning The texture in GPU memory is not copied, so the new texture
       *          will be unmapped (id-texture = 0)
       */
      S3DImage(S3DImage *img);

      /**
       * @pre w The width of the image
       * @pre h The height of the image
       * @pre bpp The bytes per pixel of the image
       * @post Make a new empty image with this size and BPP
       */
      S3DImage(unsigned int w, unsigned int h, unsigned int bpp);

      /**
       * @pre buffer must be not empty. It must be a valid buffer of an image
       * @param[in] w The width of the image
       * @param[in] h The height of the image
       * @param[in] bpp The bytes per pixel of the image
       * @param[in] buffer The buffer gotten from OpenGL
       * @post Make a new empty image with this size and BPP
       */
      S3DImage(unsigned int w, unsigned int h, unsigned int bpp, 
	       unsigned char *buffer);

      /** @post Destructor. Memory is freed here.
       */
      ~S3DImage(void);

      /**
       * @pre  filename cannot be 0
       * @post Return false if it fails, in other case load the image, 
       *       if it fails, the image will be empty (0)
       * @param[in] filename The name of the file
       */
      bool load(const char *filename);

      /**
       * @pre  filename cannot be 0
       * @post Return false if it fails, in other case save the image
       * @param[in] filename The name of the file (BMP)
       */
      bool save(const char *filename);

      /**
       * @pre  filename cannot be 0
       * @post Return false if it fails, in other case save the image of doubles
       * @param[in] filename The name of the file (BMP - normalized)
       */
      bool saveDoubles(const char *filename);


      /**
       * @pre img cannot be the same object as the result
       * @param[in] img The image to copy in it
       * @param[in] w The width of the image
       * @param[in] h The height of the image
       * @post Copy the part of the img that fits
       */
      void copy (S3DImage *img, long int x, long int y);
      
      /**
       * @param[in] w The width of the new image (if it is 0, do nothing)
       * @param[in] h The height of the new image (if it is 0, do nothing)
       * @param[in] flag The algorithm to be used, see also 
       *            S3DImage#QUALITY, S3DImage#PERFORMANCE, 
       *            S3DImage#NEAREST, S3DImage#TILED, S3DImage#LINEAR
       * @post Scale the image, the original image is destroyed in the process
       * @warning You shouldn't use it as it was efficient
       */
      void scale(unsigned int w, unsigned int h, int flag);

      /**
       * @param[in] w The width of the new image (if it is 0, do nothing)
       * @param[in] h The height of the new image (if it is 0, do nothing)
       * @param[in] flag The algorithm to be used, see also 
       *            S3DImage#QUALITY, S3DImage#PERFORMANCE, 
       *            S3DImage#NEAREST, S3DImage#TILED, S3DImage#LINEAR
       * @post Scale the image to the nearest pow of two size in width
       *       and height, the original image is destroyed in the process
       * @warning You shouldn't use it as it was efficient
       */
      void scaleNearest2Pow (unsigned int w, unsigned int h, int flag);

      /**
       * @post The width of the image
      */
      unsigned int getWidth(void);

      /**
       * @post The height of the image
       */
      unsigned int getHeight(void);

      /**
       * @post The bytes per pixel in the image
       */
      unsigned int getBPP(void);

      /*
       * @post The image in OpenGL format (as an array of UNSIGNED_BYTE)
       */
      const unsigned char *getRaw(void);

      /*
       * @pre  x and y must be greater or equal than 0 and lesser than the size
       *       of the image
       * @post The pixel of a given position in SDL format (RGBA)
       * @param[in] s The source image (or 0 if the source image is itself)
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
      */
      Uint32 getPixel(SDL_Surface *s, unsigned int x, unsigned int y);

      /*
       * @pre  x and y must be greater or equal than 0 and lesser than the size
       *       of the image
       * @note The pointer may be
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @post The pixel of a given position in a unsigned char array (RGBA)
       *       values are in range [0, 255]
      */
      unsigned char *getPixelRGBA (unsigned int x, unsigned int y);

      /*
       * @pre  x and y must be greater or equal than 0 and lesser than the size
       *       of the image
       * @note The pointer may be
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @post The pixel of a given position in a unsigned char array (RGB)
       *       values are in range [0, 255]

      */
      unsigned char *getPixelRGB (unsigned int x, unsigned int y);

      /*
       * @pre  x and y must be greater or equal than 0 and lesser than the size
       *       of the image
       * @param[in] s The source image (or 0 if the source image is itself)
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @param[in] pixel The color in SDL format (RGBA)
       * @post Set the pixel of a given position
      */
      void setPixel(SDL_Surface *s, unsigned int x, unsigned int y, 
		    Uint32 pixel);

      /*
       * @post Set the pixel of a given position
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @param[in] r The red color in [0,1]
       * @param[in] g The green color in [0,1]
       * @param[in] b The green color in [0,1]
       * @param[in] a The alpha value in [0,1]
      */
      void setPixelRGBA(long int x, long int y, float r, float g,
			float b, float a);
      /*
       * @post Set the pixel of a given position
       * @param[in] x The x coordinate
       * @param[in] y The y coordinate
       * @param[in] r The red color in [0,1]
       * @param[in] g The green color in [0,1]
       * @param[in] b The green color in [0,1]
      */
      void setPixelRGB(long int x, long int y, float r, float g,
		       float b);


      /* 
       * @post Flip horizontally or vertically the image, 
       *       source image is destroyed in the process 
       * @param[in] h If it is true, flip it horizontally
       * @param[in] v If it is true, flip it vertically
       * @note Vertical flip is useful to export it as OpenGL texture
       * @warning If both, h and v are false, it will do nothing
       * @warning This method is not efficient
      */
      void flip(bool h, bool v);

      /**
       * @pre  BPP must be between 1 and 4
       * @param[in]  BPP Bytes per pixel
       * @post Convert to other byte-per-pixel format
       * @note It is useful to export it as OpenGL texture
       * @warning This method need a review (TODO)
       */
      void convert (unsigned int BPP);

      /**
       * @param[in] enable If it will be enabled or not
       * @post Enable the posibility of operating in doubles for some operators
       */
      void enableCopyDoubles (bool enable=true);

      /**
       * @post The value of the 4 components of the double array
       * @note If the operation of doubles is disabled (default) 
       *       it will return the value 0
       * @note Values returned can be out of the range [0, 1] (values are 
       *       normalized)
       *       Values lesser than 0 can be clampped to 0, whereas 
       *       values greater than 1 can be scaled to 255.
       */
      double *getPixelDoubles (int x, int y);

      /**
       * @param[in] r The red channel
       * @param[in] g The green channel
       * @param[in] b The blue channel
       * @param[in] a The alpha channel
       * @post Change the value of a pixel in the real array but not in the 
       *       image
       * @note If the operation of doubles is disabled (default) 
       *       it will do nothing
       * @note Values should get input in the range [0,1] however other values
       *       are allowed (values are normalized)
       */
      void setPixelDoubles (int x, int y, 
			    double r, double g, double b, double a);

      /**
       * @post The source image of doubles of the class
       * @warning The pointer may change as the result of some method, do not
       *          free the memory, this is not a copy
       */
      double *getDoublesBuffer(void);

      /**
       * @param[in] i The position x
       * @param[in] j The position y
       * @post The red component in [0, 1] (fist look at doubles then in chars)
       */
      double getRed(int i, int j);

      /**
       * @param[in] i The position x
       * @param[in] j The position y
       * @post The green component in [0, 1] 
       *       (fist look at doubles then in chars)
       */
      double getGreen(int i, int j);

      /**
       * @param[in] i The position x
       * @param[in] j The position y
       * @post The blue component in [0, 1] (fist look at doubles then in chars)
       */
      double getBlue(int i, int j);

      /**
       * @param[in] i The position x
       * @param[in] j The position y
       * @post The alpha channel in [0, 1] (fist look at doubles then in chars)
       */
      double getAlpha(int i, int j);

      /**
       * @post If the operation with doubles is enabled or not
       */
      bool isEnabledDoubles(void);

      /**
       * @pre img cannot be the same object as the result
       * @pre high_thres should be greater than low_thres
       * @param[in] img A valid image
       * @param[in] sigma The value of sigma for the blurring of the image
       * @param[in] sigma2 The value of sigma for the detection of borders
       * @param[in] low_thres The threshold for the borders in [0, 1]
       * @param[in] high_thres The threshold for the borders in [0, 1]
       * @post The borders of the image with only one pixel of thikness
       *       using a Canny algorithm
       * @note You can learn more about Canny algorithm here:
       *       <http://www.pages.drexel.edu/~weg22/can_tut.html>
       *       <http://robotics.eecs.berkeley.edu/~sastry/ee20/cacode.html>
       *       <http://en.wikipedia.org/wiki/Canny_edge_detector>
       */
      void getCanny (S3DImage *img, float sigma, float sigma2,
		     float low_thres, float high_thres,
		     unsigned int masksize=6);

      /**
       * @pre img must be a valid image
       * @param[in] img The image
       * @param[in] r The radius of the kernel
       * @param[in] n The parameter of sharpness (default = 1)
       * @param[in] tprev The value of the previous ETF if 0 given
       *            the algorithm will return the the counter-clockwise
       *            tangent of the Sobel gradient in the red and green channels
       *            If it is distinct from 0: 
       *             x value will be take from Red component, whereas
       *             y value will be taken from Green component
       * @post Get the Edge Tangent Flow (ETF) of an image according to the 
       *       paper of Kang: Coherent Line Drawing
       *       <http://www.cs.umsl.edu/~kang/Papers/kang_npar07.html>
       *       In the red channel is obtained the x component
       *       In the green channel is obtained the y component
       *       Blue and Alpha components are set to 0
       * @note The values are stored in the buffer of doubles if the flag is 
       *       enabled
       */
      void getETF (S3DImage *img, double r, double n=1, S3DImage *tprev=0);

      
      /**
       * @pre img must be a valid image
       * @param[in] img The image
       * @param[in] r The radius of the kernel
       * @param[in] n The parameter of sharpness (default = 1)
       * @param[in] tprev The value of the previous ETF if 0 given
       *            the algorithm will return the the counter-clockwise
       *            tangent of the Sobel gradient in the red and green channels
       *            If it is distinct from 0: 
       *             x value will be take from Red component, whereas
       *             y value will be taken from Green component
       * @post Get a iteration of the ETF given by iter
       */
      void getIterETF (S3DImage *img, double r, double n=1, 
		       unsigned int iter=0);

      /*
       * @post Compute the silhouettes according to the paper of Kang
       */
      void getSilhouette (S3DImage *img, S3DImage *ti, 
			  double sc, double sm,
			  double tau,
			  double rho=0.99, double dm=1, double dn=1);

      /**
       * @pre  img can be the same object as the result
       * @pre  img must be a valid image
       * @pre  m must be a valid matrix with size greater than 1
       * @param[in] img The source image 
       * @param[in] m The matrix
       * @param[in] xp The position of the zone to make the covolution
       *               if xp is less than 0 it will take the coordinate 0
       * @param[in] yp The position of the zone to make the covolution
       *               if yp is less than 0 it will take the coordinate 0
       * @param[in] wp The width of the zone to make the covolution
       *               if wp is less or equal to 0, wp will be the size
       *               of the image
       * @param[in] hp The height of the zone to make the covolution
       *               if hp is less or equal to 0, hp will be the size
       *               of the image
       * @param[in] normalize If it is true the filter is normalized, if it is
       *                      false, the filter is not normalized
       * @note This function is able to operate in doubles is enabled
       */
      void convolute (S3DImage *img, S3DMatrix *m, bool normalize=false,
		      int xp=-1, int yp=-1, int wp=-1, int hp=-1);


      /**
       * @pre img can be the same object as the result
       * @pre  img must be a valid image
       * @param[in] v The value of the threshold
       * @post The thresholded image
       * @note This function is able to operate in doubles is enabled
       */
      void threshold (S3DImage *img, unsigned char v);

      /**
       * @pre img1 can be the same object as the result
       * @pre img2 can be the same object as the result or 0
       * @pre  img1 must be a valid image
       * @pre  img2 must be a valid image or 0
       * @param[in] operation The operation to apply
       * @post The operated image
       * @note This function will operate the buffers of doubles if enabled
       *       the operation with doubles and the first image has enabled the 
       *       operation with doubles
       */
      void operate (int operation, S3DImage *img1, S3DImage *img2=0,
		    double value=2);

      /**
       * @param[in]  s True or false
       * @post Hide the warning and error messages
       */
      void hideMsg (bool s);

      /**
       * @post The source image of the class
       * @warning The pointer may change as the result of some method
       */
      SDL_Surface *getBuffer(void);

      /**
       * @post The ID of the image, it may be 0
       * @warning The pointer may change as the result of some method
       */
      const char *getID (void);

      /**
       * @pre img cannot be the same object as the result
       * @pre x, y, w and h must be valid or all 0
       * @param[in] img The original image
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] w The width, if it is 0, it takes the width of the image
       * @param[in] h The height, if it is 0, it takes the height of the image
       * @post Crop img and copy it to this
       * @warning Inner buffer must be inicialized before call this method
       */
      void crop (S3DImage *img, unsigned int x, unsigned int y, 
		 unsigned int w, unsigned int h);

      /**
       * @param[in] unit The unit of the texture: GL_TEXTURE0, GL_TEXTURE2, etc.
       * @param[in] interp The way of the interpolation: GL_LINEAR, GL_NEAREST
       * @param[in] way One of this values: GL_CLAMP, GL_REPEAT, etc.
       * @param[in] mode The way to put the texture: GL_DECAL, GL_MODULATE,etc.
       * @post Select the ID of the texture
       */
      GLuint setTexture2D(GLenum unit, GLenum interp, GLenum way,
			  GLenum mode);

      /**
       * @post Remove the texture from the GPU
       */
      void delTexture2D(void);

      /**
       * @post The ID of the texture, 0 if none
       */
      GLuint getTexture2D(void);


   protected:
      /**
       * @pre[in] w The width
       * @pre[in] h The height
       * @pre[in] bpp Bytes per pixel
       * @post Create a surface
       */      
      SDL_Surface *createSurface(unsigned int w, unsigned int h, 
				 unsigned int bpp);

   private:
      SDL_Surface *buffer; /// The raw image
      char *id; /// The name of the file, it is the ID too
      GLuint idtex; /// Id. of the texture
      bool showWarnings; /// Show the warnings or not
      bool maintainDoubles; /// operate in doubles
      double *dbuffer; /// Maintained values of the image
};


#endif
