#ifndef __MATRIX__
#define __MATRIX__

#include <iostream>
#include <iomanip>
#include <math.h>
#include <cstring>
#include "mathematic.hh"

/** @class   S3DMatrix matrix.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class is a matrix with the same number of rows and columns
 *
 *  @bug     No bugs detected yet
 *  @warning 
 */

class S3DMatrix {
   public:

      /// Undefined matrix
      static const unsigned int UNDEFINED        = 0x00;

      /// All the elements of the matrix are 0
      static const unsigned int ALL_ZERO         = 0x01;
      static const unsigned int EMPTY            = 0x01;

      /// All the elements of the matrix are 1
      static const unsigned int ALL_ONE          = 0x02;

      /// The identity matrix
      static const unsigned int IDENTITY         = 0x03;

      /// The kernels:
      /// Gauss kernel (matrix nxn)
      static const int GAUSSnxn           = 0x00;
      /// Gauss first derivative (matrix nxn)
      static const int DoGAUSSnxnH        = 0x01;
      static const int DoGAUSSnxnV        = 0x02;
      /// Gauss second derivative (matrix nxn)
      static const int DHoGAUSSnxnH       = 0x03;
      static const int DVoGAUSSnxnV       = 0x04;
      static const int DHoGAUSSnxnV       = 0x05;
      static const int DVoGAUSSnxnH       = 0x06;
      /// Laplacian (matrix nxn)
      static const int LoGAUSSnxn         = 0x07;
      /// High pass filter
      static const int FPHIGH3x3          = 0x08;
      /// Blur filte
      static const int BLUR3x3            = 0x09;
      static const int FPLOW3x3           = 0x09;
      /// Roberts filter
      static const int ROBERTS3x3H        = 0x10;
      static const int ROBERTS3x3V        = 0x11;
      /// Prewitt filter
      static const int PREWITT3x3H        = 0x12;
      static const int PREWITT3x3V        = 0x13;
      /// Sobel filter
      static const int SOBEL3x3H          = 0x14;
      static const int SOBEL3x3V          = 0x15;

      static const int LAPLACE5x5         = 0x16;

      /** 
       * @param[in] flag It can be one of these:
       *                  UNDEFINED
       *                  ALL_ZERO
       *		  ALL_ONE
       *		  IDENTITY
       * @post Constructor
      */
      S3DMatrix(unsigned int flag, unsigned int size=3);

      /** 
       * @param[in] m A  valid array (not 0) as a vector of 16 elements: 
       *              |  0  1  2  3  | ->
       *              |  4  5  6  7  | ->
       *              |  8  9 10 11  | ->
       *              | 12 13 14 15  | 
       * @post Constructor
      */
      S3DMatrix (double *m, unsigned int size=3);

      /** 
       * @post Destructor, it frees the used memory
      */
      ~S3DMatrix ();

      /**
       * @param[in] m A  valid array (not 0) as a vector of the same size
       *            of the matrix: 
       *              |  0  1  2  3  | ->
       *              |  4  5  6  7  | ->
       *              |  8  9 10 11  | ->
       *              | 12 13 14 15  | 
       * @post Set the matrix
       */
      void set (double *m);

      /**
       * @pre i and j must be lesser than the size of the matrix
       * @param[in] i The column (starting with 0)
       * @param[in] j The row (starting with 0)
       * @param[in] v The value of the cell
       * @post Set a component in the vector
       */
      void set (unsigned int i, unsigned j, double v);

      /**
       * @param[in] flag It can be one of these:
       *                  UNDEFINED
       *                  ALL_ZERO
       *		  ALL_ONE
       *		  IDENTITY
       * @post Set a default matrix
       */
      void setDefaultMatrix (unsigned int flag);

      /**
       * @param[in] type Type of the kernel
       * @param[in] sigma The value of sigma for gaussian kernels
       * @param[in] cte This constant is multiplied to PI for 
       *            mapping the function in a different range
       * @post Set the matrix to the values of the kernel
       */
      void setKernelConvolution (int type, float sigma=1, double cte=1);

      /**
       * @pre The size of the matrix must be greater or equal to 4x4, if the 
              size is greater than 4x4 you sould use a identity matrix as base
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Set the components in the vector as a translation matrix
       */
      void setTranslateMatrix (double x, double y, double z);

      /**
       * @pre The size of the matrix must be greater or equal to 3x3, if the 
              size is greater than 3x3 you sould use a identity matrix as base
       * @param[in] alpha The angle
       * @param[in] x The x coordinate of the axis
       * @param[in] y The y coordinate of the axis
       * @param[in] z The z coordinate of the axis
       * @post Set the components in the vector as a rotation matrix with an 
       *       arbitrary axis
       * @note alpha is in radians
       */
      void setRotateMatrix (double alpha, double x, double y, double z);

      /**
       * @pre The size of the matrix must be greater or equal to 3x3, if the 
              size is greater than 3x3 you sould use a identity matrix as base
       * @param[in] alpha The angle
       * @post Set the components in the vector as a rotation matrix
       * @note alpha is in radians
       */
      void setRotateXMatrix (double alpha);

      /**
       * @pre The size of the matrix must be greater or equal to 3x3, if the 
              size is greater than 3x3 you sould use a identity matrix as base
       * @param[in] alpha The angle
       * @post Set the components in the vector as a rotation matrix
       * @note alpha is in radians
       */
      void setRotateYMatrix (double alpha);

      /**
       * @pre The size of the matrix must be greater or equal to 3x3, if the 
              size is greater than 3x3 you sould use a identity matrix as base
       * @param[in] alpha The angle
       * @post Set the components in the vector as a rotation matrix
       * @note alpha is in radians
       */
      void setRotateZMatrix (double alpha);

      /**
       * @pre The size of the matrix must be greater or equal to 3x3, if the 
              size is greater than 3x3 you sould use a identity matrix as base
       * @param[in] x The x per one
       * @param[in] y The y per one
       * @param[in] z The z per one
       * @post Set the components in the vector as a scale matrix
       */
      void setScaleMatrix (double x, double y, double z);

      /**
       * @post The matrix as an array
       * @warning It is not a copy, do not free the array
       */
      double *get (void);

      /**
       * @pre i and j must be lesser than the size of the matrix
       * @param[in] i The column (starting with 0)
       * @param[in] j The row (starting with 0)
       * @post The value of the cell
       */
      double get (unsigned int i, unsigned int j);

      /**
       * @post The size of the matrix
       */
      unsigned int getSize(void);

      /**
       * @pre m have to have the same size of this matrix and be distinct to 0
       * @post The convolution with matrix m
       */
      double convolute(S3DMatrix *m);

      /**
       * @post Transpose the matrix, useful for OpenGL matrices
       */
      S3DMatrix *transpose (void);

      /**
       * @pre m must be a valid matrix (not 0)
       * @param[in] m The matrix 
       * @post The matrices addition (this + m)
       */
      S3DMatrix *plus (S3DMatrix *m);

      /**
       * @pre m must be a valid matrix (not 0)
       * @param[in] m The matrix
       * @post The matrices substraction (this - m)
       */
      S3DMatrix *minus (S3DMatrix *m);

      /**
       * @pre m must be a valid matrix (not 0)
       * @param[in] cte The constant
       * @post The scalar multiplication of the matrices (this · cte)
       */
      S3DMatrix *dot (double cte);

      /**
       * @pre m must be a valid matrix (not 0)
       * @param[in] m The matrix
       * @post The scalar multiplication of the matrices (this · m)
       */
      S3DMatrix *dot (S3DMatrix *m);

      /**
       * @pre m must be a valid matrix (not 0) and it must have the same size
       * @param[in] m The matrix
       * @post The multiplication of matrices (this x m)
       */
      S3DMatrix *cross (S3DMatrix *m);

      /**
       * @post  A copy of this matrix
       */
      S3DMatrix *copy (void);

      /**
       * @post  Print this matrix to cerr (DEBUG)
       */
      void print (void);

      /**
       * @param[in] str String to display, if 0 no text displayed
       * @post  Print this matrix to cerr (DEBUG)
       */
      void print (const char *str);


   private:
      double *mat;
      unsigned int size;
};

#endif

