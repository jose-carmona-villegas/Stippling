#ifndef __SCENE__
#define __SCENE__

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <string.h>
#include <vector>
#include <SDL/SDL_image.h>
#include <GL/glew.h>
#include "matrix.hh"
#include "vector.hh"
#include "framebuffer.hh"
#include "image.hh"
#include "mesh.hh"
#include "camera.hh"

/** @struct  S3DAnimItem scene.hh
 *  @author  Germán Arroyo
 *  @date    2010
 *  @brief   This structure contain a string representing an operation and a 
 *           pointer to data.
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning 
 */
struct S3DStructAnimItem {
      const char *action;
      const char *typeobj;
      void *data;
      void *obj;
};

typedef struct S3DStructAnimItem S3DAnimItem;


/** @class   S3DScene scene.hh
 *  @author  Germán Arroyo
 *  @date    2010
 *  @brief   This class is a scene manager. It manage meshes, cameras,
 *           animations, and so on.
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning 
 */

class S3DScene {
   public:

      /** 
      * @post Constructor. Inizialite the mesh image.
      */
      S3DScene (void);

      /** 
       * @pre mesh must be a valid Mesh
       * @post Constructor copy.
       * @param[in] mesh The mesh
      */
      S3DScene (S3DScene *scene);

      /** 
       * @post The width of the scene
      */
      unsigned int getWidth (void);

      /** 
       * @post The width of the scene
      */
      unsigned int getHeight (void);

      /**
       * @pre filename must be a valid name of a file
       * @post Returns some number distinct to 0 if it loads the model,
       *       it try to use the protected methods to do it
       *       returns 0 in other case
       * @param[in] filename the name of the file
       */
      int load (const char *filename);

      /**
       * @post Draw the models 
       *       without using any shader, and without enable or disable texturing
       *       it does not change to the smooth or flat mode either
       */
      virtual void draw(void);

      /**
       * @post Execute the actions for the current frame
       */
      void executeActions(void);

      /**
       * @post Change the current frame to the begining of the animation
       */
      void initAnimation(void);

      /**
       * @post Change the current frame to the end of the animation
       */
      void endAnimation(void);

      /**
       * @post Change to the next frame
       */
      void nextFrame(void);

      /**
       * @param[in] t The time in seconds
       * @post Change to the frame according the time and the fps
       */
      void updateFrame(float t);

      /**
       * @post Destructor
       */
      ~S3DScene(void);

   protected:

      /**
       * @pre filename must be a valid name of a S3DGER file
       * @post Returns some number distinct to 0 if it loads the model,
       *       it try to use the protected methods to do it
       *       returns 0 in other case
       * @param[in] filename the name of the file
       */
      int loadS3DGER (const char *filename);

      /**
       * @param[in] str A valid string of characters
       * @post The input string without spaces 
       */
      char *removeWhiteSpaces(const char *str);

      /**
       * @param[in] str A valid string of characters
       * @param[in] sep A valid character as separator
       * @post The vector converted from a string 
       */
      S3DVector *parseVector(const char *str, char sep=' ');

      /**
       * @param[in] action A valid action
       * @param[in] typeobj A valid type of object
       * @param[in] data The valid data
       * @param[in] obj A valid object
       * @post Add a new action to the timeline
       * @note Supported object types:
       *       - camera: A camera
       *       - mesh: A mesh
       * @note Supported actions:
       *       - position: Change the position of the object
       *       - rotation: Change the rotation of the object
       *       - scale: Change the scale of the object (not valid for cameras)
       */
      void addAction(const char *action, const char *typeobj, 
		     void *data, void *obj);

      /* Variables: */
      S3DCamera *camera; // The current camera
      std::vector<S3DMesh *> mesh; // Array of meshes
      long int nframes;
      long int iniframe, endframe;

   private:
      std::vector <S3DAnimItem> *frameAction;
      unsigned int screenWidth, screenHeight;
      double currentframe;
      float fps;
};





#endif

