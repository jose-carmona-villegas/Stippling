#include "image.hh"


// --------------------------------------------------
S3DImage::S3DImage (void)
{
   this->buffer = 0;
   this->id = 0;
   this->idtex = 0;
   this->showWarnings = true;

   this->maintainDoubles = 0;
   this->dbuffer = 0;
}


// --------------------------------------------------
S3DImage::S3DImage (SDL_Surface *s)
{
   this->buffer = s;
   this->id = 0;
   this->idtex = 0;
   this->showWarnings = true;

   this->maintainDoubles = 0;
   this->dbuffer = 0;
}


// --------------------------------------------------
S3DImage::S3DImage (unsigned int w, unsigned int h, unsigned int bpp)
{
   this->id = 0;
   this->idtex = 0;
   this->showWarnings = true;
   
   this->buffer = this->createSurface(w, h, bpp);

   this->maintainDoubles = 0;
   this->dbuffer = 0;
}


// --------------------------------------------------
S3DImage::S3DImage (unsigned int w, unsigned int h, unsigned int bpp,
		    unsigned char *bytes)
{
   unsigned int i, j;
   unsigned long long int p;
   Uint32 c;

   this->maintainDoubles = 0;
   this->dbuffer = 0;

   this->id = 0;
   this->idtex = 0;
   this->showWarnings = true;

   if (bytes == 0)
   {
      this->buffer = 0;
      return;
   }

   this->buffer = this->createSurface(w, h, bpp);

   SDL_LockSurface(this->buffer);   
   for (j = 0; j < h; j ++)  
      for (i = 0; i < w; i ++)
      {
	 p = (i + j * w) * bpp;
	 switch (bpp)
	 {
	    case 1: {
	       c = SDL_MapRGB(this->buffer->format, bytes[p], bytes[p], 
		  	      bytes[p]);
	    } break;

	    case 2: {
	       c = SDL_MapRGB(this->buffer->format, bytes[p], bytes[p + 1], 
			       bytes[p]);
	    } break;

	    case 3: {
	       c = SDL_MapRGB(this->buffer->format, bytes[p], bytes[p + 1],
			      bytes[p + 2]);
	    } break;

	    case 4: {
	       c = SDL_MapRGBA(this->buffer->format, bytes[p], bytes[p + 1],
			       bytes[p + 2], bytes[p + 3]);
	    } break;
	 }

	 this->setPixel(0, i, j, c);
      }
   SDL_UnlockSurface(this->buffer);

}


// --------------------------------------------------
S3DImage::S3DImage (S3DImage *img)
{
   unsigned char *c;
   int i, j;

   this->maintainDoubles = false;
   this->dbuffer = 0;

   this->id = 0;
   this->idtex = 0;
   this->showWarnings = true;

   if (img->getBuffer() != 0)
   {
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 img->getBPP());
      for (j = 0; j < img->getHeight(); j ++)
	 for (i = 0; i < img->getWidth(); i ++)
	 {
	    c = img->getPixelRGBA(i, j);
	    if (c != 0)
	    {
	       this->setPixelRGBA(i, j, c[0] / 255.0, c[1] / 255.0, 
				  c[2] / 255.0, c[3] / 255.0);
	       delete [] c;
	    }
	 }
   }
   
   if (img->getDoublesBuffer() != 0)
   {
      this->maintainDoubles = true;
      this->dbuffer = new double[img->getWidth() * img->getHeight() * 4];
      memcpy (this->dbuffer, img->getDoublesBuffer(), 
	      sizeof(double) * 4 * img->getWidth() * img->getHeight());
   }
}


// --------------------------------------------------
S3DImage::~S3DImage (void)
{
   if (this->buffer != 0)
      SDL_FreeSurface (this->buffer);

   if (this->dbuffer != 0)
      delete [] this->dbuffer;

   if (this->id != 0)
      delete [] this->id;

   if (this->idtex != 0)
      glDeleteTextures(1, &(this->idtex));
}



// --------------------------------------------------
void S3DImage::copy (S3DImage *img, long int x, long int y)
{
   long int i, j, a, b;
   long int w1, h1;

   if ( (this->buffer == 0) || (img == 0) )
      return;

   w1 = x + img->getWidth();
   h1 = y + img->getHeight();

   if ((w1 <= 0) || (h1 <= 0))
      return;

   SDL_LockSurface(this->buffer);
   for (j = y; j < h1; j ++)
      for (i = x; i < w1; i ++)
      {
	 a = i - x;
	 b = j - y;
	 if ( (i >= 0) && (i < this->buffer->w) &&
	      (j >= 0) && (j < this->buffer->h) &&
	      (a >= 0) && (b >= 0) && 
	      (a < img->getWidth()) && (b < img->getHeight()))
	 {
	    this->setPixel(0, i, j, 
			   img->getPixel(0, (unsigned int) a, 
					 (unsigned int) b));
	 }
      }
   SDL_UnlockSurface(this->buffer);
}


// --------------------------------------------------
SDL_Surface *S3DImage::getBuffer(void)
{
   return this->buffer;
}


// --------------------------------------------------
void S3DImage::enableCopyDoubles(bool enable)
{
   this->maintainDoubles = enable;
   if (enable == false)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;
      this->dbuffer = 0;
   }
}


// --------------------------------------------------
bool S3DImage::isEnabledDoubles(void)
{
   return this->maintainDoubles;
}


// --------------------------------------------------
double *S3DImage::getDoublesBuffer(void)
{
   return this->dbuffer;
}


// --------------------------------------------------
double *S3DImage::getPixelDoubles(int i, int j)
{
   double *c;
   long int pos;

   if (this->dbuffer == 0)
      return 0;

   if ( (i < 0) || (j < 0) || 
	(i >= this->getWidth()) || (j >= this->getHeight()))
      return 0;
   
   c = new double[4];
   pos = 4 * (i + j * this->getWidth());
   c[0] = this->dbuffer[pos];
   c[1] = this->dbuffer[pos + 1];
   c[2] = this->dbuffer[pos + 2];
   c[3] = this->dbuffer[pos + 3];

   return c;
}


// --------------------------------------------------
void S3DImage::setPixelDoubles(int i, int j, 
			       double r, double g, double b, double a)
{
   double *c;
   long int pos;

   if (this->dbuffer == 0)
      return;

   if ( (i < 0) || (j < 0) || 
	(i >= this->getWidth()) || (j >= this->getHeight()))
      return;
   
   pos = 4 * (i + j * this->getWidth());
   this->dbuffer[pos] = r;
   this->dbuffer[pos + 1] = g;
   this->dbuffer[pos + 2] = b;
   this->dbuffer[pos + 3] = a;

   return;
}


// --------------------------------------------------
const char *S3DImage::getID(void)
{
   return this->id;
}


// --------------------------------------------------
bool S3DImage::load (const char *filename)
{
   
   if (this->buffer != 0)
      SDL_FreeSurface (this->buffer);
   if (this->id != 0)
   {
      delete [] this->id;
      this->id = 0;
   }
      
   this->buffer = IMG_Load (filename);
   if (this->buffer == 0)
   {
      if (this->showWarnings)
	 std::cerr << "IMG_Load failed in file \"" << filename
		   << "\": " << IMG_GetError () << "\n";
      return false;
   }
   else
   {
      this->id = new char[strlen (filename) + 1];
      memcpy (this->id, filename, strlen (filename));
      this->id[strlen(filename)] = '\0';
   }
   return true;
}


// --------------------------------------------------
void S3DImage::hideMsg (bool s)
{
   this->showWarnings = !s;
}


// --------------------------------------------------
bool S3DImage::saveDoubles (const char *filename)
{
   S3DImage *img;
   bool d = this->maintainDoubles;
   int i, j;
   double minr, ming, minb, mina;
   double maxr, maxg, maxb, maxa;
   double r, g, b, a;
   long int pos;


   if ((this->dbuffer == 0) || (filename == 0))
      return false;

   img = new S3DImage(this->getWidth(), this->getHeight(), this->getBPP());
   for (j = 0; j < this->getHeight(); j ++)
      for (i = 0; i < this->getWidth(); i ++)
      {
	 pos = (i + j * this->getWidth()) * 4;
	 r = this->dbuffer[pos];
	 g = this->dbuffer[pos + 1];
	 b = this->dbuffer[pos + 2];
	 a = this->dbuffer[pos + 3];

	 if (pos == 0)
	 {
	    minr = ming = minb = mina = maxr = maxg = maxb = maxa = 0;
	 }
	 else
	 {
	    if (r < minr)
	       minr = r;
	    else if (r > maxr)
	       maxr = r;

	    if (g < ming)
	       ming = g;
	    else if (g > maxg)
	       maxg = g;

	    if (b < minb)
	       minb = b;
	    else if (b > maxb)
	       maxb = b;

	    if (a < mina)
	       mina = a;
	    else if (a > maxa)
	       maxa = a;
	 }
      }
   
   std::cerr << "MIN = (" << minr << ", " << ming 
	     << ", " << minb << ", " << mina << ")" << std::endl;
   std::cerr << "MAX = (" << maxr << ", " << maxg 
	     << ", " << maxb << ", " << maxa << ")" << std::endl;

   for (j = 0; j < this->getHeight(); j ++)
      for (i = 0; i < this->getWidth(); i ++)
      {
	 pos = (i + j * this->getWidth()) * 4;

	 if (fabs(maxr - minr) < 0.00001)
	    r = 0;
	 else
	    r = (this->dbuffer[pos] - minr) / (maxr - minr);

	 if (fabs(maxg - ming) < 0.00001)
	    g = 0;
	 else
	    g = (this->dbuffer[pos + 1] - ming) / (maxg - ming);

	 if (fabs(maxb - minb) < 0.00001)
	    b = 0;
	 else
	    b = (this->dbuffer[pos + 2] - minb) / (maxb - minb);

	 if (fabs(maxa - mina) < 0.00001)
	    a = 0;
	 else
	    a = (this->dbuffer[pos + 3] - mina) / (maxa - mina);

	 img->setPixelRGBA(i, j, r, g, b, a);
      }
   img->convert(3);
   img->save(filename);
   
   this->maintainDoubles = d;
   delete img;

   return true;
}


// --------------------------------------------------
bool S3DImage::save (const char *filename)
{
   
   if ( (this->buffer == 0) || (filename == 0))
      return false;

   if (SDL_SaveBMP (this->buffer, filename))
   {
      if (this->showWarnings)
	 std::cerr << "IMG_SaveBMP failed in file \"" << filename
		   << "\": " << IMG_GetError () << "\n";
      return false;
   }

   return true;
}


// --------------------------------------------------
unsigned int S3DImage::getWidth (void)
{
   if (this->buffer != 0)
      return this->buffer->w;
   else
      return 0;
}


// --------------------------------------------------
unsigned int S3DImage::getHeight (void)
{
   if (this->buffer != 0)
      return this->buffer->h;
   else
      return 0;
}


// --------------------------------------------------
double S3DImage::getRed(int i, int j)
{
   double *cf;
   unsigned char *c;
   double col;

   col = 0;
   if (this->maintainDoubles)
   {
      cf = this->getPixelDoubles(i, j);
      if (cf != 0)
      {
	 col = cf[0];
	 delete [] cf;
      }
   }
   else
   {
      c = this->getPixelRGBA(i, j);
      if (c != 0)
      {
	 col = c[0] / 255.0;
	 delete [] c;
      }
   }

   return col;
}


// --------------------------------------------------
double S3DImage::getGreen(int i, int j)
{
   double *cf;
   unsigned char *c;
   double col;

   col = 0;
   if (this->maintainDoubles)
   {
      cf = this->getPixelDoubles(i, j);
      if (cf != 0)
      {
	 col = cf[1];
	 delete [] cf;
      }
   }
   else
   {
      c = this->getPixelRGBA(i, j);
      if (c != 0)
      {
	 col = c[1] / 255.0;
	 delete [] c;
      }
   }

   return col;
}


// --------------------------------------------------
double S3DImage::getBlue(int i, int j)
{
   double *cf;
   unsigned char *c;
   double col;

   col = 0;
   if (this->maintainDoubles)
   {
      cf = this->getPixelDoubles(i, j);
      if (cf != 0)
      {
	 col = cf[2];
	 delete [] cf;
      }
   }
   else
   {
      c = this->getPixelRGBA(i, j);
      if (c != 0)
      {
	 col = c[2] / 255.0;
	 delete [] c;
      }
   }

   return col;
}


// --------------------------------------------------
double S3DImage::getAlpha(int i, int j)
{
   double *cf;
   unsigned char *c;
   double col;

   col = 0;
   if (this->maintainDoubles)
   {
      cf = this->getPixelDoubles(i, j);
      if (cf != 0)
      {
	 col = cf[3];
	 delete [] cf;
      }
   }
   else
   {
      c = this->getPixelRGBA(i, j);
      if (c != 0)
      {
	 col = c[3] / 255.0;
	 delete [] c;
      }
   }

   return col;
}


// --------------------------------------------------
const unsigned char *S3DImage::getRaw (void)
{
   if (this->buffer != 0)
      return (unsigned char *) this->buffer->pixels;
   else
      return 0;
}


// --------------------------------------------------
unsigned int S3DImage::getBPP (void)
{
   if (this->buffer != 0)
      return this->buffer->format->BytesPerPixel;
   else
      return 0;
}


// --------------------------------------------------
void S3DImage::convert (unsigned int BPP)
{
   unsigned int x, y, x2, y2;
   unsigned int i;
   SDL_Surface *surface;
   Uint8 color[4];
   unsigned int bpp;

   if (this->buffer == 0)
      return;

   if (BPP == this->buffer->format->BytesPerPixel)
      return;

   surface = this->createSurface(this->buffer->w, this->buffer->h, BPP);
   if(surface == 0) 
   {
      if (this->showWarnings)
	 std::cerr << "CreateRGBSurface failed: " 
		   << SDL_GetError() << std::endl;
      return;
   }


   SDL_LockSurface(surface);
   SDL_LockSurface(this->buffer);

   if (BPP > this->buffer->format->BytesPerPixel)
   {
      for (y = 0; y < this->buffer->h; y ++)
	 for (x = 0; x < this->buffer->w; x ++)
	 { 
	    SDL_GetRGBA(getPixel(0, x, y), this->buffer->format,
			&color[0], &color[1], &color[2], &color[3]);
	    for (i = this->buffer->format->BytesPerPixel - 1; i < BPP; i ++)
	    {
	       if (i < 3)
		  color[i] = color[this->buffer->format->BytesPerPixel - 1];
	       else
		  color[i] = 255;
	    }
	    this->setPixel(surface, x, y, SDL_MapRGBA(surface->format, 
						      color[0], color[1],
						      color[2], color[3]));
	    
	 }
   }
   else
   {
      for (y = 0; y < this->buffer->h; y ++)
	 for (x = 0; x < this->buffer->w; x ++)
	    this->setPixel(surface, x, y, getPixel(0, x, y));
   }
   SDL_UnlockSurface(surface);
   SDL_UnlockSurface(this->buffer);


   SDL_FreeSurface (this->buffer);
   this->buffer = surface;

   return;
}


// --------------------------------------------------
void S3DImage::convolute (S3DImage *img, S3DMatrix *m, bool normalize, 
			  int xp, int yp, int wp, int hp)
{
   S3DMatrix *conv[4];
   int i, j, ii, jj, xnconv, ynconv;
   int lmax, lmin;
   Uint32 pixel;
   unsigned char *c;
   float cf[4];
   bool end;
   double norm;
   bool deleteimg;

   if (img == 0)
      return;


   if (img == this) // copy the image
   {
      img = new S3DImage(this);
      deleteimg = true;
   }
   else
      deleteimg = false;


   if ( (this->buffer != 0) && (this->buffer->w != img->getWidth()) &&
	(this->buffer->h != img->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 img->getBPP());
   this->id = 0;
   this->idtex = 0;

   // doubles operations:
   if (this->maintainDoubles)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;
      this->dbuffer = new double [img->getWidth() * img->getHeight() * 4];
//      std::cerr << "DEBUG: maintaining doubles \n";
   }


   if (xp < 0)
      xp = 0;

   if (yp < 0)
      yp = 0;

   if ( (wp <= 0) || (wp >= this->buffer->w - xp))
      wp = this->buffer->w - xp;

   if ( (hp <= 0) || (hp >= this->buffer->h - yp))
      hp = this->buffer->h - yp;
	
   conv[0] = new S3DMatrix(S3DMatrix::ALL_ZERO, m->getSize());
   conv[1] = new S3DMatrix(S3DMatrix::ALL_ZERO, m->getSize());
   conv[2] = new S3DMatrix(S3DMatrix::ALL_ZERO, m->getSize());
   conv[3] = new S3DMatrix(S3DMatrix::ALL_ZERO, m->getSize());

   // Compute the value of normalization in the mask
   if (normalize == false)
      norm = 1;
   else
   {
      norm = 0;
      for (j = 0; j < m->getSize(); j ++)
	 for (i = 0; i < m->getSize(); i ++)
	    norm += m->get(i, j);

      if (fabs(norm) <= 0.0) 
	 norm = 1;
   }


   lmax = m->getSize() / 2;
   
   if (m->getSize() % 2 == 0)
      lmin = -(lmax - 1);
   else
      lmin = -lmax;
   

   for (j = xp; j < hp; j++)
      for (i = yp; i < wp; i++)
      {
	 end = false;

	 for (jj = lmin; (jj <= lmax) && (!end); jj ++)
	    for (ii = lmin; (ii <= lmax) && (!end); ii ++)
	    {
	       xnconv = (ii + i);
	       ynconv = (jj + j);
		  
	       if (xnconv < 0)
		  xnconv = -xnconv;

	       if (ynconv < 0)
		  ynconv = -ynconv;

	       if (xnconv >= buffer->w)
		  xnconv = buffer->w - xnconv;

	       if (ynconv >= buffer->h)
		  ynconv = buffer->h - ynconv;
	       
	       c = img->getPixelRGBA(xnconv, ynconv);
	       if (c != 0)
	       {
		  // save values and normalize the mask
		  conv[0]->set(ii - lmin, jj - lmin, 
			       c[0] / (norm * 255.0));
		  conv[1]->set(ii - lmin, jj - lmin, 
			       c[1] / (norm * 255.0));
		  conv[2]->set(ii - lmin, jj - lmin, 
			       c[2] / (norm * 255.0));
		  conv[3]->set(ii - lmin, jj - lmin, 
			       c[3] / (norm * 255.0));

		  delete [] c;
	       }
	       else
	       {
		  conv[0]->set(ii - lmin, jj - lmin, 0);
		  conv[1]->set(ii - lmin, jj - lmin, 0);
		  conv[2]->set(ii - lmin, jj - lmin, 0);
		  conv[3]->set(ii - lmin, jj - lmin, 0);
	       }
	    }
	 
	 if (!end)
	 {
	    cf[0] = m->convolute(conv[0]);
	    cf[1] = m->convolute(conv[1]);
	    cf[2] = m->convolute(conv[2]);
	    cf[3] = m->convolute(conv[3]);
	 }
	 else
	    cf[0] = cf[1] = cf[2] = cf[3] = 0.0;

	 if (this->maintainDoubles) // doubles
	 {
	    this->setPixelDoubles(i, j, cf[0], cf[1], cf[2], cf[3]);
//	    std::cerr << "DEBUG: Saving double --> (" 
//		      << cf[0] << ", " << cf[1] << ", " << cf[2] << ", "
//		      << cf[3] << ")\n";
	 }

	 if (cf[0] > 1)
	    cf[0] = 1;
	 else if (cf[0] < 0)
	    cf[0] = -cf[0];
	 if (cf[1] > 1)
	    cf[1] = 1;
	 else if (cf[1] < 0)
	     cf[1] = -cf[1];
	 if (cf[2] > 1)
	    cf[2] = 1;
	 else if (cf[2] < 0)
	    cf[2] = -cf[2];
	 if (cf[3] > 1)
	    cf[3] = 1;
	 else if (cf[3] < 0)
	    cf[3] = -cf[3];

	 this->setPixelRGBA(i, j, cf[0], cf[1], cf[2], cf[3]);
      }

   delete conv[0];
   delete conv[1];
   delete conv[2];
   delete conv[3];

   if (deleteimg)
      delete img;
}


// --------------------------------------------------
void S3DImage::threshold (S3DImage *img, unsigned char v)
{
   int i, j;
   int lmax, lmin;
   Uint32 pixel;
   unsigned char *c;
   float cf[4];
   bool end;
   double norm;
   bool deleteimg; 


   if (img == 0)
      return;

   if (img == this) // copy the image
   {
      img = new S3DImage(this);
      deleteimg = true;
   }
   else
      deleteimg = false;


   if ( (this->buffer != 0) && (this->buffer->w != img->getWidth()) &&
	(this->buffer->h != img->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 img->getBPP());
   // doubles
   if (this->maintainDoubles)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;

      this->dbuffer = new double[img->getWidth() * img->getHeight() * 4];
   }
   
   this->id = 0;
   this->idtex = 0;


   for (j = 0; j < img->getWidth(); j++)
      for (i = 0; i < img->getHeight(); i++)
      {
	 c = img->getPixelRGBA(i, j);
	 if (c != 0)
	 {
	    if (c[0] > v)
	       cf[0] = 255;
	    else
	       cf[0] = 0;

	    if (c[1] > v)
	       cf[1] = 255;
	    else
	       cf[1] = 0;

	    if (c[2] > v)
	       cf[2] = 255;
	    else
	       cf[2] = 0;

	    if (c[3] > v)
	       cf[3] = 255;
	    else
	       cf[3] = 0;

	    if (this->maintainDoubles)
	       this->setPixelDoubles(i, j, cf[0], cf[1], cf[2], cf[3]);

	    this->setPixelRGBA(i, j, cf[0], cf[1], cf[2], cf[3]);

	    delete [] c;
	 }
      }

   if (deleteimg)
      delete img;
}


// --------------------------------------------------
void S3DImage::operate (int operation, S3DImage *img1, S3DImage *img2, 
			double value)
{
   int i, j, k, w, h;
   int lmax, lmin;
   Uint32 pixel;
   unsigned char *c1, *c2;
   float cf[4];
   double x, y;
   bool end;
   double norm;
   double val[4];
   double *cf1 = 0;
   double *cf2 = 0;
   bool deleteimg1, deleteimg2;
   double min[4];
   double max[4];

   if (img1 == 0)
      return;

   if (img1 == this) // copy the image
   {
      img1 = new S3DImage(this);
      deleteimg1 = true;
   }
   else
      deleteimg1 = false;

   if ((img2 != 0) && (img2 == this)) // copy the image
   {
      img2 = new S3DImage(this);
      deleteimg2 = true;
   }
   else
      deleteimg2 = false;


   if ( (this->buffer != 0) && (this->buffer->w != img1->getWidth()) &&
	(this->buffer->h != img1->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img1->getWidth(), 
					 img1->getHeight(), 
					 img1->getBPP());
   this->id = 0;
   this->idtex = 0;

   // doubles
   if (this->maintainDoubles)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;

      this->dbuffer = new double[img1->getWidth() * img1->getHeight() * 4];
   }

   // if normalized computed max and min of the image
   if ( (operation == NORMALIZE) || (operation == NORMALIZEDEST) )
   {
      cf1 = 0;

      if (operation == NORMALIZE)
      {
	 w = img1->getWidth();
	 h = img1->getHeight();
      }
      else if (operation == NORMALIZEDEST)
      {
	 if (img2 == 0)
	    return; // ERROR!!!

	 w = img2->getWidth();
	 h = img2->getHeight();
      }

      for (j = 0; j < h; j++)
	 for (i = 0; i < w; i++)
	 {
	    if ( (this->maintainDoubles) && 
		 (this->dbuffer != 0))
	    {
	       if (operation == NORMALIZE)
		  cf1 = img1->getPixelDoubles(i, j);
	       else if (operation == NORMALIZEDEST)
		  cf1 = img2->getPixelDoubles(i, j);

	       for (k = 0; k < 4; k ++)
		  val[k] = cf1[k];
	       delete [] cf1;
	    }
	    else
	    {
	       if (operation == NORMALIZE)
		  c1 = img1->getPixelRGBA(i, j);
	       else if (operation == NORMALIZEDEST)
		  c1 = img2->getPixelRGBA(i, j);

	       for (k = 0; k < 4; k ++)
		  val[k] = (double) c1[k] / 255.0;
	       delete [] c1;
	    }

	    if ((i == 0) && (j == 0))
	    {
	       for (k = 0; k < 4; k++)
		  min[k] = max[k] = val[k];
	    }
	    else
	    {
	       for (k = 0; k < 4; k++)
		  if (val[k] < min[k])
		     min[k] = val[k];
		  else
		     if (val[k] > max[k])
			max[k] = val[k];
	    }
	 }
   }

   cf1 = cf2 = 0;
   for (j = 0; j < img1->getHeight(); j++)
      for (i = 0; i < img1->getWidth(); i++)
      {
	 if (img1->isEnabledDoubles())
	 {
	    cf1 = img1->getPixelDoubles(i, j);
	 }
	 else
	    cf1 = 0;

	 c1 = img1->getPixelRGBA(i, j);
	 if (c1 == 0)
	 {
	    c1 = new unsigned char[4];
	    for (k = 0; k < 4; k ++)
	       c1[k] = 0;
	 }

	 if ( (img2 == 0) ||
	      (i >= img2->getWidth()) || (j >= img2->getHeight()) )
	 {
	    c2 = new unsigned char[4];
	    for (k = 0; k < 4; k ++)
	       c2[k] = 0;
	 }
	 else
	 {
	    c2 = img2->getPixelRGBA(i, j);

	    if (img2->isEnabledDoubles())
	       cf2 = img2->getPixelDoubles(i, j);
	    else 
	       cf2 = 0;
	 }
	 
	 for (k = 0; k < 4; k ++)
	 {
	    if (cf1 == 0)
	       x = c1[k] / 255.0;
	    else
	       x = cf1[k];

	    if (cf2 == 0)
	       y = c2[k] / 255.0;
	    else
	       y = cf2[k];


	    switch(operation)
	    {
	       case ADD: {
		  cf[k] = x + y;
	       } break;

	       case MULTIPLY: {
		  cf[k] = x * y;
	       } break;
	       case SUBTRACT: {
		  cf[k] = x - y;
	       } break;
	       case DIVIDE: {
		  cf[k] = x / y;	       
	       } break;
	       case POWERTO: {
		  cf[k] = pow(x, y);	       
	       } break;
	       case MAX: {
		  if (x >= y)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case MIN: {
		  if (x <= y)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case COPYRED: {
		  if (k != 0)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case COPYGREEN: {
		  if (k != 1)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case COPYBLUE: {
		  if (k != 2)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case COPYALPHA: {
		  if (k != 3)
		     cf[k] = x;
		  else
		     cf[k] = y;
	       } break;
	       case COPYRGB: {
		  if (k != 3)
		     cf[k] = y;
		  else
		     cf[k] = x;
	       } break;
	       case COPYRGBA: {
		  cf[k] = y;
	       } break;
	       case MAGNITUDE: {
		  cf[k] = (c1[0] + c2[0]) * (c1[0] + c2[0]);
		  cf[k] += (c1[1] + c2[1]) * (c1[1] + c2[1]);
		  cf[k] += (c1[2] + c2[2]) * (c1[2] + c2[2]);
		  cf[k] += (c1[3] + c2[3]) * (c1[3] + c2[3]);
		  cf[k] = sqrt(cf[k]);
	       } break;
	       case ANGLE: {
		  cf[k] = atan2(y, x) / S3DMath::PI;
	       } break;
	       case EQUAL: {
		  if (x != y)
		     cf[k] = 0;
		  else
		     cf[k] = x;
	       } break;
	       case INVERT: {
		  cf[k] = 255 - x;
	       } break;
	       case DESATURATE: {
		  if (k < 3)
		     if (cf1 == 0)
			cf[k] = (c1[0] + c1[1] + c1[2]) / (3.0 * 255.0);
		     else
			cf[k] = (cf1[0] + cf1[1] + cf1[2]) / 3.0;
	       } break;
	       case CONTRAST: {
		  if (k < 3)
		     cf[k] = pow(x, value);
	       } break;
	       case BRIGHTNESS: {
		  if (k < 3)
		     cf[k] = x + value;
	       } break;
	       case THRESHOLD: {
		  if (x >= value)
		     cf[k] = 1;
		  else
		     cf[k] = 0;
	       } break;
	       case CWTANGENTx: { // t(x)
		  cf[k] = y;
	       } break;
	       case CWTANGENTy: {
		  cf[k] = -x;
	       } break;
	       case CCWTANGENTx: {
		  cf[k] = -y;
	       } break;
	       case CCWTANGENTy: {
		  cf[k] = x;
	       } break;
	       case NORMALIZE: {
		  if ((max[k] - min[k]) == 0)
		     cf[k] = 1;
		  else
		     cf[k] = (x - min[k]) / (max[k] - min[k]);
	       } break;
	       case NORMALIZEDEST: {
		  if ((max[k] - min[k]) == 0)
		     cf[k] = 1;
		  else
		     cf[k] = (y  - min[k]) / (max[k] - min[k]);
	       } break;
	       case SETRED: {
		  if (k == 0)
		     cf[k] = value;
		  else
		     cf[k] = x;
	       } break;
	       case SETGREEN: {
		  if (k == 1)
		     cf[k] = value;
		  else
		     cf[k] = x;
	       } break;
	       case SETBLUE: {
		  if (k == 2)
		     cf[k] = value;
		  else
		     cf[k] = x;
	       } break;
	       case SETALPHA: {
		  if (k == 3)
		     cf[k] = value;
		  else
		     cf[k] = x;
	       } break;
	       case SETRGB: {
		  if (k != 3)
		     cf[k] = value;
		  else
		     cf[k] = x;
	       } break;
	       case SETRGBA: {
		  cf[k] = value;
	       } break;
	       case NORMVECTORS: {
		  if ((x * x + y * y) == 0.0)
		     cf[k] = 0;
		  else
		     cf[k] = x / sqrt(x * x + y * y);
	       } break;

	    }
	 }

	 if (cf1 != 0)
	    delete [] cf1;

	 if (cf2 != 0)
	    delete [] cf2;

	 delete [] c1;
	 delete [] c2;

	 if (this->maintainDoubles)
	    this->setPixelDoubles(i, j, cf[0], cf[1], cf[2], cf[3]);

	 if (cf[0] > 1)
	    cf[0] = 1;
	 else if (cf[0] < 0)
	    cf[0] = 0;
	 if (cf[1] > 1)
	    cf[1] = 1;
	 else if (cf[1] < 0)
	     cf[1] = 0;
	 if (cf[2] > 1)
	    cf[2] = 1;
	 else if (cf[2] < 0)
	    cf[2] = 0;
	 if (cf[3] > 1)
	    cf[3] = 1;
	 else if (cf[3] < 0)
	    cf[3] = 0;

	 this->setPixelRGBA(i, j, cf[0], cf[1], cf[2], cf[3]);
      }

   if (deleteimg1)
      delete img1;
   if (deleteimg2)
      delete img2;
}


// --------------------------------------------------
void S3DImage::flip (bool h, bool v)
{
   unsigned int x, y, x2, y2;
   SDL_Surface *surface;
   unsigned int bpp;

   if (this->buffer == 0)
      return;

   surface = this->createSurface(this->buffer->w, this->buffer->h, 
				 this->buffer->format->BytesPerPixel);
   if(surface == 0) 
   {
      if (this->showWarnings)
	 std::cerr << "CreateRGBSurface failed: " 
		   << SDL_GetError() << std::endl;
      return;
   }

   SDL_LockSurface(surface);
   SDL_LockSurface(this->buffer);
   for (y = 0; y < this->buffer->h; y ++)
      for (x = 0; x < this->buffer->w; x ++)
      {
	 if (h)
	    x2 = this->buffer->w - 1 - x;
	 else
	    x2 = x;
	 
	 if (v)
	    y2 = this->buffer->h - 1 - y;
	 else
	    y2 = y;
	 
	 this->setPixel(surface, x2, y2, getPixel(0, x, y));
      }
   SDL_UnlockSurface(surface);
   SDL_UnlockSurface(this->buffer);


   SDL_FreeSurface (this->buffer);
   this->buffer = surface;
}


// --------------------------------------------------
unsigned char *S3DImage::getPixelRGBA (unsigned int x, unsigned int y)
{
   Uint8 r, g, b, a;
   Uint32 pixel;
   unsigned char *p;

   if (this->buffer == 0)
      return 0;

   if (x < 0)
      return 0;
   
   if (y < 0)
      return 0;

   if (x >= this->getWidth())
      return 0;

   if (y >= this->getHeight())
      return 0;

   pixel = this->getPixel(0, x, y);
   
   SDL_GetRGBA(pixel, this->buffer->format, &r, &g, &b, &a);
   p = new unsigned char[4];

   p[0] = r;
   p[1] = g;
   p[2] = b;
   p[3] = a;

   return p;
}


// --------------------------------------------------
unsigned char *S3DImage::getPixelRGB (unsigned int x, unsigned int y)
{
   Uint8 r, g, b, a;
   Uint32 pixel;
   unsigned char *p;

   if (this->buffer == 0)
      return 0;

   if (x < 0)
      return 0;
   
   if (y < 0)
      return 0;

   if (x >= this->getWidth())
      return 0;

   if (y >= this->getHeight())
      return 0;

   pixel = this->getPixel(0, x, y);
   
   SDL_GetRGBA(pixel, this->buffer->format, &r, &g, &b, &a);
   p = new unsigned char[3];

   p[0] = r;
   p[1] = g;
   p[2] = b;

   return p;
}


// --------------------------------------------------
Uint32 S3DImage::getPixel(SDL_Surface *s, unsigned int x, unsigned int y)
{
   int bpp;
   Uint8 *p;

   if (s == 0)
   {
      s = this->buffer;

      if (s == 0)
      {
	 std::cerr << "Error: invalid access to NULL image\n";
	 return 0;
      }
   }

   bpp = s->format->BytesPerPixel;
   // Here p is the address to the pixel we want to retrieve 
   p = (Uint8 *)s->pixels + y * s->pitch + x * bpp;
   
   switch(bpp) 
   {
      case 1:
	 return *p;
	 
      case 2:
	 return *(Uint16 *)p;
	 
      case 3:
	 if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
	    return p[0] << 16 | p[1] << 8 | p[2];
	 else
	    return p[0] | p[1] << 8 | p[2] << 16;
	 
      case 4:
	 return *(Uint32 *)p;
	 
      default:
	 return 0;       /* shouldn't happen, but avoids warnings */
   }
}


// --------------------------------------------------
void S3DImage::setPixelRGBA(long int x, long int y, 
			    float r, float g, float b, float a)
{
   Uint32 pixel;   

   if (this->buffer == 0)
      return;

   if (x < 0)
      return;
   
   if (y < 0)
      return;

   if (x >= this->getWidth())
      return;

   if (y >= this->getHeight())
      return;

   if (r > 1)
      r = 1;
   else 
      if (r < 0)
	 r = 0;
   if (g > 1)
      g = 1;
   else 
      if (g < 0)
	 g = 0;
   if (b > 1)
      b = 1;
   else 
      if (b < 0)
	 b = 0;
   if (a > 1)
      a = 1;
   else 
      if (a < 0)
	 a = 0;

   pixel = SDL_MapRGBA(this->buffer->format, 
		       (int) (r * 255), 
		       (int) (g * 255), 
		       (int) (b * 255), 
		       (int) (a * 255));

   this->setPixel(0, x, y, pixel);
}


// --------------------------------------------------
void S3DImage::setPixelRGB(long int x, long int y, 
			   float r, float g, float b)
{
   Uint32 pixel;   

   if (this->buffer == 0)
      return;

   if (x < 0)
      return;
   
   if (y < 0)
      return;

   if (x >= this->getWidth())
      return;

   if (y >= this->getHeight())
      return;


   if (r > 1)
      r = 1;
   else 
      if (r < 0)
	 r = 0;
   if (g > 1)
      g = 1;
   else 
      if (g < 0)
	 g = 0;
   if (b > 1)
      b = 1;
   else 
      if (b < 0)
	 b = 0;

   pixel = SDL_MapRGB(this->buffer->format, 
		      (int) round(r * 255), 
		      (int) round(g * 255), 
		      (int) round(b * 255));

   this->setPixel(0, x, y, pixel);
}


// --------------------------------------------------
void S3DImage::setPixel(SDL_Surface *s, unsigned int x, unsigned int y, 
			Uint32 pixel)
{
   int bpp;
   Uint8 *p;

   if (s == 0)
   {
      s = this->buffer;
       
      if (s == 0)
	 return;
   }

   bpp = s->format->BytesPerPixel;
   // Here p is the address to the pixel we want to set
   p = (Uint8 *)s->pixels + y * s->pitch + x * bpp;

   SDL_LockSurface(s);
   switch(bpp) 
   {
      case 1:
      {
	 *p = pixel;
      } break;
	  
      case 2: 
      {
	 *(Uint16 *)p = pixel;
      } break;

      case 3:
      {
	 if(SDL_BYTEORDER == SDL_BIG_ENDIAN) 
	 {
	    p[0] = (pixel >> 16) & 0xff;
	    p[1] = (pixel >> 8) & 0xff;
	    p[2] = pixel & 0xff;
	 } 
	 else 
	 {
	    p[0] = pixel & 0xff;
	    p[1] = (pixel >> 8) & 0xff;
	    p[2] = (pixel >> 16) & 0xff;
	 }
      } break;
	  
      case 4:
      {
	 *(Uint32 *)p = pixel;
      } break;
   }
   SDL_UnlockSurface(s);

   return;
}


// --------------------------------------------------
void S3DImage::scaleNearest2Pow (unsigned int w, unsigned int h, int flag)
{
   unsigned int w2, h2;
   float base;
    
   w2 = 2;
   while (w2 < w)
      w2 *= 2;
   
   h2 = 2;
   while (h2 < h)
      h2 *= 2;

   scale (w2, h2, flag);
}


// --------------------------------------------------
void S3DImage::crop (S3DImage *img, unsigned int x, unsigned int y, 
		     unsigned int w, unsigned int h)
{
   unsigned int i, j;


   if (img->getID() == 0)
      this->id = 0;
   else
   {
      this->id = new char[strlen(img->getID())];
      memcpy (this->id, img->getID(), strlen (img->getID()));
   }

   if (w == 0)
   {
      x = 0;
      w = img->getWidth();
   }

   if (h == 0)
   {
      h = img->getHeight();
      y = 0;
   }

   if (this->buffer != 0)
      SDL_FreeSurface(this->buffer);

   this->buffer = this->createSurface(w, h, img->getBPP());


   SDL_LockSurface(this->buffer);
   for (j = y; j < h; j ++)
      for (i = x; i < w; i++)
	 this->setPixel (0, i, j, img->getPixel (0, i, j));
   SDL_UnlockSurface(this->buffer);
}


// --------------------------------------------------
void S3DImage::scale (unsigned int w, unsigned int h, int flag)
{
   unsigned char *dataOut;
   SDL_Surface *surface;
   long int i, j;
   long int incw, inch;
   long int x, y, cx, cy;
   float x2, y2;
   float v0, v1, v2, v3;
   float r, g, b, a, n;
   GLenum flaggl;
   unsigned long int pos;
   Uint8 color0[4];
   Uint8 color1[4];
   Uint8 color2[4];
   Uint8 color3[4];

   if ( (this->buffer == 0) || (w <= 1) || (h <= 1) || 
	( (w == this->buffer->w) && (h == this->buffer->h) ) )
      return;

   if (flag == PERFORMANCE)
      flag = NEAREST;

   if (flag == QUALITY)
   {
      if ((w > this->buffer->w) && (h > this->buffer->h))
	 flag = LINEAR;
      else
	 flag = TILED;
   }


   surface = this->createSurface(w, h, this->buffer->format->BytesPerPixel);
   if(surface == 0) 
   {
      if (this->showWarnings)
	 std::cerr << "CreateRGBSurface failed: " 
		   << SDL_GetError() << std::endl;
      return;
   }

   SDL_LockSurface(surface);
   SDL_LockSurface(this->buffer);
   switch (flag)
   {
      case NEAREST:
      {
	 for (y = 0; y < surface->h; y ++)
	    for (x = 0; x < surface->w; x ++)
	    {
	       x2 = (float) this->buffer->w * (float) x / (float) surface->w;
	       y2 = (float) this->buffer->h * (float) y / (float) surface->h;
	       cx = (unsigned int) roundl(x2);
	       cy = (unsigned int) roundl(y2);
	       if (cx >= this->buffer->w)
		  cx = this->buffer->w - 1;
	       if (cy >= this->buffer->h)
		  cy = this->buffer->h - 1;

	       this->setPixel(surface, x, y, getPixel(0,cx,cy)); 
	    }
      } break;

      case LINEAR:
      {
	 for (y = 0; y < surface->h; y ++)
	    for (x = 0; x < surface->w; x ++)
	    {
	       x2 = (float) this->buffer->w * (float) x / (float) surface->w;
	       y2 = (float) this->buffer->h * (float) y / (float) surface->h;

	       v0 = x2 - floor(x2);
	       v1 = ceilf(x2) - x2;
	       v2 = y2 - floor(y2);
	       v3 = ceilf(y2) - y2;

	       cx = (unsigned int) ceilf (x2);
	       cy = (unsigned int) ceilf (y2);
	       if (cx >= this->buffer->w)
		  cx = this->buffer->w - 1;
	       if (cy >= this->buffer->h)
		  cy = this->buffer->h - 1;
	       

	       SDL_GetRGBA(getPixel(0,
				    (unsigned int) floor(x2), 
				    (unsigned int) floor(y2)), 
			   surface->format, 
			   &color0[0], &color0[1], &color0[2], &color0[3]);
	       
	       SDL_GetRGBA(getPixel(0, cx, (unsigned int) floor(y2)), 
			   surface->format, 
			   &color1[0], &color1[1], &color1[2], &color1[3]);
	       
	       SDL_GetRGBA(getPixel(0,(unsigned int) floor(x2), cy), 
			   surface->format, 
			   &color2[0], &color2[1], &color2[2], &color2[3]);
	       
	       SDL_GetRGBA(getPixel(0, cx, cy), 
			   surface->format, 
			   &color3[0], &color3[1], &color3[2], &color3[3]);




	       if  (fabs(v1 - v0) <= 0.0) 
	       {
		  if (fabs(v3 - v2) <= 0.0)
		  {
		     r = color0[0];
		     g = color0[1];
		     b = color0[2];
		     a = color0[3];
		  }
		  else
		  {
		     r = 0.5 * (color0[0] * v3 + color1[0] * v3 + 
				color2[0] * v2 + color3[0] * v2);
		     
		     g = 0.5 * (color0[1] * v3 + color1[1] * v3 + 
				color2[1] * v2 + color3[1] * v2);
		     
		     b = 0.5 * (color0[2] * v3 + color1[2] * v3 + 
				color2[2] * v2 + color3[2] * v2);
		     
		     a = 0.5 * (color0[3] * v3 + color1[3] * v3 + 
				color2[3] * v2 + color3[3] * v2);
		  }
	       }
	       else
		  if (fabs(v3 - v2) <= 0.0)
		  {
		     r = 0.5 * (color0[0] * v1 + color1[0] * v0 + 
				color2[0] * v1 + color3[0] * v0);
		     
		     g = 0.5 * (color0[1] * v1 + color1[1] * v0 + 
				color2[1] * v1 + color3[1] * v0);
		     
		     b = 0.5 * (color0[2] * v1 + color1[2] * v0 + 
				color2[2] * v1 + color3[2] * v0);
		     
		     a = 0.5 * (color0[3] * v1 + color1[3] * v0 + 
				color2[3] * v1 + color3[3] * v0);
		  }
		  else
		  {
		     r = (color0[0] * v1 * v3 + color1[0] * v0 * v3 + 
			  color2[0] * v1 * v2 + color3[0] * v0 * v2);
		     
		     g = (color0[1] * v1 * v3 + color1[1] * v0 * v3 + 
			  color2[1] * v1 * v2 + color3[1] * v0 * v2);
		     
		     b = (color0[2] * v1 * v3 + color1[2] * v0 * v3 + 
			  color2[2] * v1 * v2 + color3[2] * v0 * v2);
		     
		     a = (color0[3] * v1 * v3 + color1[3] * v0 * v3 + 
			  color2[3] * v1 * v2 + color3[3] * v0 * v2);
		  }

	       this->setPixel(surface, x, y, 
			      SDL_MapRGBA(surface->format, 
					  (int) round(r), 
					  (int) round(g), 
					  (int) round(b), 
					  (int) round(a)));
	    }
      } break;

      case TILED: {
	 incw = (unsigned int) ((float) this->buffer->w / 
				(float) surface->w / 2.0);
	 inch = (unsigned int) ((float) this->buffer->h / 
				(float) surface->h / 2.0);

	 if (incw < 1)
	    incw = 0;
	 
	 if (inch < 1)
	    inch = 0;

	 for (y = 0; y < surface->h; y ++)
	    for (x = 0; x < surface->w; x ++)
	    {
	       x2 = (float) this->buffer->w * (float) x / (float) surface->w;
	       y2 = (float) this->buffer->h * (float) y / (float) surface->h;

	       r = g = b = a = 0.0;
	       n = 0;
	       for (i = -incw; i <= incw; i ++)
		  for (j = -inch; j <= inch; j ++)
		  {
		     cx = i + (long int) x2;
		     cy = j + (long int) y2;

		     if (cx < 0)
			cx = abs(cx);
		     else
			if (cx >= this->buffer->w)
			   cx = 2 * this->buffer->w - cx;

		     if (cy < 0)
			cy = abs(cy);
		     else
			if (cy >= this->buffer->h)
			   cy = 2 * this->buffer->h - cy;

		     SDL_GetRGBA(getPixel(0, cx, cy), 
				 surface->format, 
				 &color0[0], &color0[1], &color0[2], 
				 &color0[3]);

		     r += (float) color0[0];
		     g += (float) color0[1];
		     b += (float) color0[2];
		     a += (float) color0[3];
		     n++;
		  }

	       r /= n;
	       g /= n;
	       b /= n;
	       a /= n;
		     
	       this->setPixel(surface, x, y, 
			      SDL_MapRGBA(surface->format, 
					  (int) round(r), 
					  (int) round(g), 
					  (int) round(b), 
					  (int) round(a)));
	    }

      } break;

/*      
      case BICUBIC: {
	 /// TODO
	 // Do nothing, if flag is not correct:
	 SDL_UnlockSurface(surface);
	 SDL_UnlockSurface(this->buffer);
	 SDL_FreeSurface (surface);	 
      } break;
*/
      case OPENGL: {
	 switch (this->getBPP())
	 {
	    case 1: {
	       flaggl = GL_LUMINANCE;
	    } break;

	    case 2: {
	       flaggl = GL_LUMINANCE_ALPHA;
	    } break;

	    case 3: {
	       flaggl = GL_RGB;
	    } break;

	    case 4: {
	       flaggl = GL_RGBA;
	    } break;
	 };

	 dataOut = new unsigned char[surface->w * surface->h * this->getBPP()];
	 gluScaleImage( flaggl, this->buffer->w, this->buffer->h,
			GL_UNSIGNED_BYTE,
			this->buffer->pixels, w, h, flaggl, dataOut);

	 for (y = 0; y < surface->h; y ++)
	    for (x = 0; x < surface->w; x ++)
	    {
	       pos = (x + y * surface->w) * this->getBPP();
	       this->setPixel(surface, x, y, 
			      SDL_MapRGBA(surface->format, 
					  (int) dataOut[pos], 
					  (int) dataOut[pos + 1], 
					  (int) dataOut[pos + 2], 
					  (int) dataOut[pos + 3]));
	    }
	 delete [] dataOut;
      } break;

      default: {
	 // Do nothing, if flag is not correct:
	 SDL_UnlockSurface(surface);
	 SDL_UnlockSurface(this->buffer);
	 SDL_FreeSurface (surface);	 
      } break;
   }
   SDL_UnlockSurface(surface);
   SDL_UnlockSurface(this->buffer);

   SDL_FreeSurface (this->buffer);
   this->buffer = surface;
}


// --------------------------------------------------
GLuint S3DImage::setTexture2D(GLenum unit, GLenum interp, GLenum way,
			      GLenum mode)
{
   GLuint n;

   if (this->idtex != 0)
      glDeleteTextures(1, &(this->idtex));   

   // GL_TEXTURE1, GL_TEXTURE2, etc.
   glActiveTexture(unit); // Multitexture  
   
  
   glEnable(GL_TEXTURE_2D);
   if (this->idtex == 0)
      glGenTextures(1, &(this->idtex));
   
   glBindTexture(GL_TEXTURE_2D, (this->idtex));
   
   switch (this->getBPP()) 
   {
      case 1: {
	 n = GL_LUMINANCE;
      } break;
	 
      case 2: {
	 n = GL_LUMINANCE_ALPHA;
      } break;
	 
      case 3: {
	 n = GL_RGB;
      } break;
	 
      case 4: {
	 n = GL_RGBA;
      } break;
   };
   
   // GL_LINEAR, GL_NEAREST
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, interp);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, interp);

   // GL_CLAMP, GL_REPEAT, etc.
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, way);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, way);
   
   // GL_DECAL, GL_MODULATE
   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, mode);
  

   glTexImage2D(GL_TEXTURE_2D, 0, n, this->getWidth(), this->getHeight(),
		0, n, GL_UNSIGNED_BYTE, this->getRaw());

   return this->idtex;
}


// --------------------------------------------------
void S3DImage::delTexture2D(void)
{
   if (this->idtex != 0)
      glDeleteTextures(1, &(this->idtex));

   this->idtex = 0;
}


// --------------------------------------------------
GLuint S3DImage::getTexture2D(void)
{
   return this->idtex;
}


// --------------------------------------------------
SDL_Surface *S3DImage::createSurface(unsigned int w, unsigned int h, 
				     unsigned int bpp)
{
   SDL_Surface *bf;

   switch (bpp)
   {
      case 1: {
	 bf = SDL_CreateRGBSurface(SDL_SWSURFACE, 
					     w, h, bpp * 8,
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
				       0xff000000, 0x00000000, 
				       0x00000000, 0x00000000
#else
				       0x000000ff, 0x00000000, 
				       0x00000000, 0x00000000
#endif
	    );
      } break;   

      case 2: {
	 bf = SDL_CreateRGBSurface(SDL_SWSURFACE, 
					     w, h, bpp * 8,
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
				       0xff000000, 0x00ff0000, 
				       0x00000000, 0x00000000
#else
				       0x000000ff, 0x0000ff00, 
				       0x00000000, 0x00000000
#endif
	    );
      } break;   

      case 3: {
	 bf = SDL_CreateRGBSurface(SDL_SWSURFACE, 
					     w, h, bpp * 8,
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
				       0xff000000, 0x00ff0000, 
				       0x0000ff00, 0x00000000
#else
				       0x000000ff, 0x0000ff00, 
				       0x00ff0000, 0x00000000
#endif
	    );
      } break;   

      case 4: {
	 bf = SDL_CreateRGBSurface(SDL_SWSURFACE, 
					     w, h, bpp * 8,
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
				       0xff000000, 0x00ff0000, 
				       0x0000ff00, 0x000000ff
#else
				       0x000000ff, 0x0000ff00, 
				       0x00ff0000, 0xff000000
#endif
	    );
      } break;   

   }
   
   
   return bf;
}


// --------------- COMPLEX ALGORITH FOR ARTIFICIAL VISION -------------------

// --------------------------------------------------
void S3DImage::getCanny (S3DImage *img, float sigma, float sigma2,
			 float low_thres, float high_thres,
			 unsigned int masksize)
{
   S3DImage *gauss;
   S3DImage *Ix, *Iy;
   double orientation, magnitude;
   S3DImage *blur;
   S3DMatrix *kernel;
   unsigned char *cl, *cr;
//   unsigned char *cfx, *cfy;
   double *cfx, *cfy;
   double grad, gx, gy;
   S3DImage *orig;
   int edge_direction;
   double lpixel, rpixel;
   double p[8], pixel;
   int i, j;

   if (img == 0)
      return;

   orig = new S3DImage ();
   orig->operate(DESATURATE, img);

   if ( (this->buffer != 0) && (this->buffer->w != img->getWidth()) &&
	(this->buffer->h != img->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 img->getBPP());
   this->id = 0;
   this->idtex = 0;

   // Create the kernel
   kernel = new S3DMatrix(S3DMatrix::EMPTY, masksize);


   // 1. Remove the noise
   gauss = new S3DImage();
   kernel->setKernelConvolution(S3DMatrix::GAUSSnxn, sigma);
   gauss->convolute(orig, kernel, true);

   // 2. Detect gradients
   Ix = new S3DImage();
   Iy = new S3DImage();
   Ix->enableCopyDoubles(); // work with the doubles 
   Iy->enableCopyDoubles(); // work with the doubles
   kernel->setKernelConvolution(S3DMatrix::DoGAUSSnxnH, sigma2);
   Ix->convolute(gauss, kernel);
   kernel->setKernelConvolution(S3DMatrix::DoGAUSSnxnV, sigma2);
   Iy->convolute(gauss, kernel);

   // 3. Visit all the pixels of the image
   for (j = 0; j < img->getHeight(); j ++)
      for (i = 0; i < img->getWidth(); i ++)
      {
	 // 3. 1. Get the gradient
	 cfx = Ix->getPixelDoubles (i, j);
	 cfy = Iy->getPixelDoubles (i, j);

	 if (cfx != 0)
	 {
	    gx = (cfx[0] + cfx[1] + cfx[2]) / 3.0;
	    delete [] cfx;
	 }
	 else
	    gx = 0;

	 if (cfy != 0)
	 {
	    gx = (cfy[0] + cfy[1] + cfy[2]) / 3.0;
	    delete [] cfy;
	 }
	 else
	    gy = 0;

	 grad = gx + gy;

	 if (grad < 0)
	    grad = 0;
	 else if (grad > 1)
	    grad = 1;

	 // 3. 2. Find edge direction 
	 if (gx == 0)
	 {
	    if (gy == 0)
	       orientation = 0.0;
	    else if (gy < 0)
	    {
	       orientation = 90.0;
	       gy = -gy;
	    }
	    else
	       orientation = 90.0;	    
	 }
	 // Can't take inverse tan of angle in 2nd Quad
	 else if ( (gx<0) && (gy>0) )
	 {
	    gx = -gx;
	    orientation = 180 - ( (atan((float)(gy) / (float)(gx))) * 
				  (180/S3DMath::PI) );
	 }
	 // Can't take inverse tan of angle in 4th Quad
	 else if ((gx > 0) && (gy < 0))
	 {
	    gy = -gy;
	    orientation = 180 - ( (atan((float)(gy) / (float)(gx))) * 
				  (180/S3DMath::PI) );
	 }
	 // else angle is in 1st or 3rd Quad
	 else
	    orientation = ( (atan((float)(gy) / (float)(gx))) * 
			    (180/S3DMath::PI) ) ;


	 // RELATES EDGE DIRECTION TO EDGE THAT CAN BE TRACED IN AN IMAGE
	 // set orientation direction, only four possible directions, 
	 //     vertical, horizontal, diagonals
	 
	 // map/set angles to the following     
	 if (fabs(orientation) < 22.5)
	    edge_direction = 0;
	 else if(fabs(orientation) < 67.5)
	    edge_direction = 45;
	 else if(fabs(orientation) < 112.5)
	    edge_direction = 90;
	 else if(fabs(orientation) < 157.5)
	    edge_direction = 135;
	 else
	    edge_direction = 0;

	 // APPLY NON-MAXIMUM SUPRESSION TO GET THIN LINES AND HYSTERESIS
	 // TO KEEP LINES SOLID WITH NO BREAKS
	 // now get the neighboring two adjacent pixels based on edge direction


	 if (edge_direction == 0)
	 {                  
	    cl = orig->getPixelRGBA (i - 1, j);
	    cr = orig->getPixelRGBA (i + 1, j);
	 }
	 else if (edge_direction == 45)
	 {
	    cl = orig->getPixelRGBA (i - 1, j + 1);
	    cr = orig->getPixelRGBA (i + 1, j - 1);
	 }
	 else if(edge_direction == 90)
	 {
	    cl = orig->getPixelRGBA (i, j - 1);
	    cr = orig->getPixelRGBA (i, j + 1);
	 }
	 else
	 {
	    cl = orig->getPixelRGBA (i - 1, j - 1);
	    cr = orig->getPixelRGBA (i + 1, j + 1);
	 }
	 
	 if (cl == 0)
	    lpixel = 0;
	 else
	 {
	    lpixel = (double) cl[0] / 255.0;
	    delete [] cl;
	 }
	 if (cr == 0)
	    rpixel = 0;
	 else
	 {
	    rpixel = (double) cr[0] / 255.0;
	    delete [] cr;
	 }


	 // now check if gradient magnitude is less than 
	 // either the left or right pixel
	 // from above, if it is set to 0.
	 if ( (grad < lpixel) || (grad < rpixel) )
	    pixel = 0;
	 else // hysteresis
	 {
	    // check if above or equal to high threshold, if so have an edge
	    if (grad >= high_thres)
	    {
	       pixel = 255;
	    }
	    // check if below low threshold, if so not an edge
	    else if (grad < low_thres)
	       pixel = 0;
                              
	    // in between, so compare with adjacent pixels to 
	    // find out if it is an edge or not
	    else
	    {
	       // get the adjacent pixels for comparison to the current pixel
	       cl = orig->getPixelRGBA(i - 1, j - 1);
	       if (cl != 0)
	       {
		  p[0] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[0] = 0;

	       cl = orig->getPixelRGBA(i - 1, j);
	       if (cl != 0)
	       {
		  p[1] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[1] = 0;

	       cl = orig->getPixelRGBA(i - 1, j + 1);
	       if (cl != 0)
	       {
		  p[2] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[2] = 0;

	       cl = orig->getPixelRGBA(i, j + 1);
	       if (cl != 0)
	       {
		  p[3] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[3] = 0;

	       cl = orig->getPixelRGBA(i + 1, j + 1);
	       if (cl != 0)
	       {
		  p[4] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[4] = 0;

	       cl = orig->getPixelRGBA(i + 1, j);
	       if (cl != 0)
	       {
		  p[5] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[5] = 0;

	       cl = orig->getPixelRGBA(i + 1, j - 1);
	       if (cl != 0)
	       {
		  p[6] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[6] = 0;

	       cl = orig->getPixelRGBA(i, j - 1);
	       if (cl != 0)
	       {
		  p[7] = (double) cl[0] / 255.0;
		  delete [] cl;
	       }
	       else
		  p[7] = 0;


	       // check if the current pixel is connected 
	       // to an edge pixel, if it is make it an edge also, 
	       // if no then it is a non-edge
	       if ( (p[0] > high_thres) || 
		    (p[1] > high_thres) ||
		    (p[2] > high_thres) || 
		    (p[3] > high_thres) ||
		    (p[4] > high_thres) || 
		    (p[5] > high_thres) ||
		    (p[6] > high_thres) || 
		    (p[7] > high_thres) )
		  pixel = 255;
	       else
		  pixel = 0;
	    }
	 }

	 // save the pixel
	 this->setPixelRGBA(i, j, pixel, pixel, pixel, 1.0);
      }
   

   // This function is based on the following code:
   // <http://www.experts-exchange.com/Programming/Languages/C/Q_21645971.html>

   delete orig;
   delete gauss;
   delete Ix;
   delete Iy;


   return;
}  


// --------------------------------------------------
void S3DImage::getIterETF (S3DImage *img, double r, double n, unsigned int iter)
{
   unsigned int i = 0;

   this->getETF(img, r, n);
   
   for (i = 1; i < iter; i ++)
   {
      this->getETF(img, r, n, this);
   }

   return;
}


// --------------------------------------------------
void S3DImage::getETF (S3DImage *img, double r, double n, S3DImage *tprev)
{
   int x0, x1, y0, y1;
   double *cf;
   unsigned char *c;
   S3DImage *im0, *im1, *input;
   S3DImage *Inx, *Iny; 
   unsigned int sizekernel = (unsigned int) (r / 2.0);
   double sum0, sum1;
   S3DMatrix *kernel;
   double tx0, tx1;
   double ty0, ty1;
   double gx, gy;
   double ws, wm, wd, phi;
   double angle, dist;
   double ck;
   bool deleteimg;

   if ( (img == 0) || (img == this) )
   {
      return;
   }

   input = new S3DImage();
   input->enableCopyDoubles();
   input->operate(DESATURATE, img);

   if (tprev == 0)
   {
      kernel = new S3DMatrix(S3DMatrix::EMPTY, 3);

      Inx = new S3DImage();
      Inx->enableCopyDoubles();
      Iny = new S3DImage();
      Iny->enableCopyDoubles();

      kernel->setKernelConvolution(S3DMatrix::SOBEL3x3H);
      Inx->convolute(input, kernel);

      kernel->setKernelConvolution(S3DMatrix::SOBEL3x3V);
      Iny->convolute(input, kernel);

      Inx->operate(NORMVECTORS, Inx, Iny);
      Iny->operate(NORMVECTORS, Iny, Inx);

      this->operate(COPYRED, Inx, Iny);
//      this->operate(COPYRED, im0, im1);
      this->operate(SETALPHA, this, 0, 0);
      this->operate(SETBLUE, this, 0, 0);

//      this->saveDoubles("/tmp/t0.bmp"); // DEBUG

      delete input;
      delete Inx;
      delete Iny;

      return;
   }
   else
      if (tprev == this) // copy the image
      {
	 tprev = new S3DImage(this);
	 deleteimg = true;
      }
      else
	 deleteimg = false;


   if ( (this->buffer != 0) && (this->buffer->w != img->getWidth()) &&
	(this->buffer->h != img->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 3);
   this->id = 0;
   this->idtex = 0;

   // doubles operations:
   if (this->maintainDoubles)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;
      this->dbuffer = new double [img->getWidth() * img->getHeight() * 4];
   }


   // compute the normalized gradients
   kernel = new S3DMatrix(S3DMatrix::EMPTY, 3);
   kernel->setKernelConvolution(S3DMatrix::SOBEL3x3V);
   Inx = new S3DImage();
   Inx->enableCopyDoubles();
   Inx->convolute(input, kernel);
   kernel->setKernelConvolution(S3DMatrix::SOBEL3x3H);
   Iny = new S3DImage();
   Iny->enableCopyDoubles();
   Iny->convolute(input, kernel);

   for (x1 = 0; x1 < this->getHeight(); x1 ++)
      for (x0 = 0; x0 < this->getWidth(); x0 ++)
      {
	 // get tprev(x)
	 tx0 = tprev->getRed(x0, x1);
	 tx1 = tprev->getGreen(x0, x1);
	 // Normalize the vector:
	 if ((tx0 * tx0 + tx1 * tx1) <= 0)
	    tx0 = tx1 = 0;
	 else
	 {
	    tx0 = tx0 / sqrt(tx0 * tx0 + tx1 * tx1);
	    tx1 = tx1 / sqrt(tx0 * tx0 + tx1 * tx1);
	 }



	 // get g(x) (magnitude)
	 gx = sqrt(Inx->getRed(x0, x1) * Inx->getRed(x0, x1) + 
		   Iny->getRed(x0, x1) * Iny->getRed(x0, x1) );

	 sizekernel = (int) r * 2;
	 ck = sizekernel / 2;

	 // Compute the sumatory:
	 sum0 = 0;
	 sum1 = 0;
	 for (y1 = x1 - ck; y1 <= x1 + ck; y1 ++)
	    for (y0 = x0 - ck; y0 <= x0 + ck; y0 ++)
	    {
	       // get tprev(y)
	       ty0 = tprev->getRed(y0, y1);
	       ty1 = tprev->getGreen(y0, y1);
	       // Normalize the vector:
	       if ((ty0 * ty0 + ty1 * ty1) <= 0)
		  ty0 = ty1 = 0;
	       else
	       {
		  ty0 = ty0 / sqrt(ty0 * ty0 + ty1 * ty1);
		  ty1 = ty1 / sqrt(ty0 * ty0 + ty1 * ty1);
	       }

	       // get g(y) (magnitude)
	       gy = sqrt(Inx->getRed(y0, y1) * Inx->getRed(y0, y1) + 
			 Iny->getRed(y0, y1) * Iny->getRed(y0, y1) );


//	       std::cerr << "G = " << gx << ", " << gy << std::endl;


	       // compute one of the elements:
/*
	       if ( (tx0 != 0) || (tx1 != 0) || (ty0 != 0) || (ty1 != 0) )
	       {
		  std::cerr << "tx = " << tx0 << ", " << tx1 << std::endl;
		  std::cerr << "ty = " << ty0 << ", " << ty1 << std::endl;
	       }
*/

	       angle = tx0 * ty0 + tx1 * ty1;
	       if (angle > 0)
		  phi = 1;
	       else
		  phi = -1;


	       // The distance of the dot is the distance of the mask 
	       // to the center
	       dist = sqrt( (x0 - y0) * (x0 - y0) +  (x1 - y1) * (x1 - y1) );
	       if (dist < r)
		  ws = 1;
	       else
		  ws = 0;

//	       std::cerr << "dist = " << dist << ", r = " << r << std::endl;

	       wm = 0.5 * (1 + tanh(n * (fabs(gy) - fabs(gx))));

	       wd = sqrt((tx0 * ty0) * (tx0 * ty0) + 
			 (tx1 * ty1) * (tx1 * ty1) );

	       sum0 += phi * ty0 * ws * wm * wd;
	       sum1 += phi * ty1 * ws * wm * wd;
/*
	       if (angle != 0)
	       {
		  std::cerr << "ty = " << ty0 << ", " << ty1 << std::endl;
		  std::cerr << "phi = " << wm << std::endl;
		  std::cerr << "ws = " << ws << std::endl;
		  std::cerr << "wm = " << wm << std::endl;
		  std::cerr << "wd = " << wd << std::endl;
	       }
*/
	    }

//	 std::cerr << "SUM = " << sum0 << ", " << sum1 << std::endl;

	 if ((sum0 * sum0 + sum1 * sum1) > 0)
	 {
	    sum0 = sum0 / sqrt(sum0 * sum0 + sum1 * sum1);
	    sum1 = sum1 / sqrt(sum0 * sum0 + sum1 * sum1);
	 }
	 else
	    sum0 = sum1 = 0;

	 if (this->maintainDoubles)
	    this->setPixelDoubles(x0, x1, sum0, sum1, 0.0, 0.0);

	 this->setPixelRGBA(x0, x1, sum0, sum1, 0.0, 0.0);
      }

   delete kernel;
   delete Inx;
   delete Iny;
   delete input;
   

//   this->operate(NORMALIZE, this);

//   this->saveDoubles("/tmp/t1.bmp"); // DEBUG

   if (deleteimg)
      delete tprev;
}


// --------------------------------------------------
void S3DImage::getSilhouette (S3DImage *img, S3DImage *ti, 
			      double sc, double sm, double tau,
			      double rho, double dm, double dn)
{
   S3DImage *input;
   bool deleteimg;
   double x0, x1, ix0, ix1, z0, z1;
   long int s, t;
   double p, q;
   const double limitG = 0.0001;
   double ss = sc * 1.6;
   double Ft, Fs, Hx, Hxt;
   S3DImage *Inx, *Iny;
   S3DMatrix *kernel;
   double *cf;
   unsigned char *c;
   double gx, gy, ti0, ti1;
   double It;


   if ((img == 0) || (ti == 0) || (ti == this))
   {
      return;
   }

   if (img == this) // copy the image
   {
      img = new S3DImage(this);
      deleteimg = true;
   }
   else
      deleteimg = false;

   input = new S3DImage();
   input->operate(DESATURATE, img);

   

   if ( (this->buffer != 0) && (this->buffer->w != img->getWidth()) &&
	(this->buffer->h != img->getHeight()) )
   {
      delete this->buffer;
      this->buffer = 0;
   }

   if (this->buffer == 0)
      this->buffer = this->createSurface(img->getWidth(), 
					 img->getHeight(), 
					 3);
   this->id = 0;
   this->idtex = 0;

   // doubles operations:
   if (this->maintainDoubles)
   {
      if (this->dbuffer != 0)
	 delete [] this->dbuffer;
      this->dbuffer = new double [img->getWidth() * img->getHeight() * 4];
   }



   kernel = new S3DMatrix(S3DMatrix::EMPTY, 3);

   Inx = new S3DImage();
   Inx->enableCopyDoubles();
   Iny = new S3DImage();
   Iny->enableCopyDoubles();
   
   kernel->setKernelConvolution(S3DMatrix::SOBEL3x3V);
   Inx->convolute(input, kernel);
   
   kernel->setKernelConvolution(S3DMatrix::SOBEL3x3H);
   Iny->convolute(input, kernel);

   // obtain the size of the kernel
   p = sqrt(-log(limitG) * 2 * sm * sm);
   q = sqrt(-log(limitG) * 2 * sc * sc);

   std::cerr << "p = " << p << std::endl;
   std::cerr << "q = " << q << std::endl;

   for (ix1 = 0; ix1 < input->getHeight(); ix1 ++)
      for (ix0 = 0; ix0 < input->getWidth(); ix0 ++)
      {
	 Hx = 0;

	 // ------------------- FIRST STEP ----------------------------
	 s = 0;
	 z0 = ix0;
	 z1 = ix1;
	 while (s <= p)
	 {
	    // get vector of flow in s: ti(z)
	    ti0 = ti->getRed(z0, z1);
	    ti1 = ti->getGreen(z0, z1);
	    if ((ti0 * ti0 + ti1 * ti1) <= 0)
	       ti0 = ti1 = 0;
	    else
	    {
	       ti0 = ti0 / sqrt(ti0 * ti0 + ti1 * ti1);
	       ti1 = ti1 / sqrt(ti0 * ti0 + ti1 * ti1);
	    }

	    // get vector of gradient in li(s): g(x, y) 
	    gx = Inx->getRed(z0, z1);
	    gy = Iny->getRed(z0, z1);

	    if ((gx * gx + gy * gy) <= 0)
	       gx = gy = 0;
	    else
	    {
	       gx = gx / sqrt(gx * gx + gy * gy);
	       gy = gy / sqrt(gx * gx + gy * gy);
	    }

	    // compute Fs
	    Fs = 0;
	    for (t = -q; t <= q; t += dn)
	    {
	       // compute the new position with the vector
	       x0 = z0 + t * gx;
	       x1 = z1 + t * gy;	       

	       // get I(x)
	       It = input->getRed(x0, x1);

	       // Compute Ft
	       Ft = S3DMath::Gauss(t, sc) - rho * S3DMath::Gauss(t, ss);
	       // Compute Fs
	       Fs += (It * Ft);
	    }	       

	    Hx += S3DMath::Gauss(s, sm) * Fs; 	    
	    
	    s += dm;
	    z0 = z0 + dm * ti0;
	    z1 = z1 + dm * ti1;
	 }

	 // ------------------- SECOND STEP ----------------------------
	 s = 0;
	 z0 = ix0;
	 z1 = ix1;
	 while (s >= -p)
	 {
	    // get vector of flow in s: ti(z)
	    ti0 = ti->getRed(z0, z1);
	    ti1 = ti->getGreen(z0, z1);
	    if ((ti0 * ti0 + ti1 * ti1) <= 0)
	       ti0 = ti1 = 0;
	    else
	    {
	       ti0 = ti0 / sqrt(ti0 * ti0 + ti1 * ti1);
	       ti1 = ti1 / sqrt(ti0 * ti0 + ti1 * ti1);
	    }

	    // get vector of gradient in li(s): g(x, y) 
	    gx = Inx->getRed(z0, z1);
	    gy = Iny->getRed(z0, z1);

	    if ((gx * gx + gy * gy) <= 0)
	       gx = gy = 0;
	    else
	    {
	       gx = gx / sqrt(gx * gx + gy * gy);
	       gy = gy / sqrt(gx * gx + gy * gy);
	    }

	    // compute Fs
	    Fs = 0;
	    for (t = -q; t <= q; t += dn)
	    {
	       // compute the new position with the vector
	       x0 = z0 + t * gx;
	       x1 = z1 + t * gy;	       

	       // get I(x)
	       It = input->getRed(x0, x1);
	       // Compute Ft
	       Ft = S3DMath::Gauss(t, sc) - rho * S3DMath::Gauss(t, ss);
	       // Compute Fs
	       Fs += (It * Ft);
	    }	       

	    Hx += S3DMath::Gauss(s, sm) * Fs; 	    

	    s -= dm;
	    z0 = z0 + dm * ti0;
	    z1 = z1 + dm * ti1;
	 }

	 // Threshold
	 if ( (Hx < 0) && ((1 + tanh(Hx)) < tau) ) 
	 {
	    Hxt = 1;
	 }
	 else
	 {
//	    std::cout << "   1 + tanh(Hx) = " << 1 + tanh(Hx) << "\n";
//	    std::cout << "    tau = " << tau << "\n";
//	    std::cout << "    Hx = " << Hx << "\n";
	    Hxt = 0;
	 }

	 if (this->maintainDoubles)
	    this->setPixelDoubles(ix0, ix1, Hxt, Hxt, Hxt, 0.0);
	 
	 this->setPixelRGBA(ix0, ix1, 1 - Hxt, 1 - Hxt, 1 - Hxt, 0.0);	 
      }


//   this->saveDoubles("/tmp/t2.bmp"); // DEBUG

   delete kernel;
   delete input;
   delete Inx;
   delete Iny;


   if (deleteimg)
      delete img;
}
