#include "matrix.hh"


// --------------------------------------------------
S3DMatrix::S3DMatrix(unsigned int flag, unsigned int s)
{
   unsigned int i, j;
   this->mat = new double[s * s];
   this->size = s;

   if (flag != S3DMatrix::UNDEFINED)
      this->setDefaultMatrix(flag);
}


// --------------------------------------------------
S3DMatrix::S3DMatrix (double *m, unsigned int s)
{
   this->mat = new double[s * s];
   this->size = s;
   std::memcpy(this->mat, m, sizeof(double) * s * s);
}


// --------------------------------------------------
S3DMatrix::~S3DMatrix ()
{
   if (this->mat != 0)
      delete [] this->mat;
}


// --------------------------------------------------
void S3DMatrix::set (double *m)
{
   std::memcpy(this->mat, m, sizeof(double) * this->size * this->size);
}


// --------------------------------------------------
void S3DMatrix::set (unsigned int i, unsigned j, double v)
{
   this->mat[i + j * this->size] = v;
}


// --------------------------------------------------
void S3DMatrix::setDefaultMatrix (unsigned int flag)
{
   unsigned int i, j;

   switch (flag) {
      case S3DMatrix::ALL_ZERO : {
	 memset(this->mat, 0, sizeof(double) * this->size * this->size);
      } break;

      case S3DMatrix::ALL_ONE : {
	 for (j = 0; j < this->size; j ++)
	    for (i = 0; i < this->size; i ++)
	    {
	       this->mat[i + j * this->size] = 1.0;
	    }
      } break;

      case S3DMatrix::IDENTITY : {
	 memset(this->mat, 0, sizeof(double) * this->size * this->size);
	 for (j = 0; j < this->size; j ++)
	    this->mat[j + j * this->size] = 1.0;
      } break;
   };

}


// --------------------------------------------------
double S3DMatrix::convolute(S3DMatrix *m)
{
   double af, bf;
   double res;
   int i, j;


   if (m == 0)
      return 0;
   
   res = 0;
//   std::cerr << "res = " << res << ": --------\n";
   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
      {
	 af = this->mat[i + this->size * j];
	 bf = m->get(i, j);
	 res += (af * bf); 
//	 std::cerr << "res += " << af << " * " << bf << "\n";
      }

//   std::cerr << "res = " << res << "______ \n";
   return res;
}


// --------------------------------------------------
unsigned int S3DMatrix::getSize(void)
{
   return this->size;
}


// --------------------------------------------------
void S3DMatrix::setTranslateMatrix (double x, double y, double z)
{
   unsigned int i;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   this->mat[0 + this->size * 3] = x; 
   this->mat[1 + this->size * 3] = y;
   this->mat[2 + this->size * 3] = z;  
}


// --------------------------------------------------
void S3DMatrix::setRotateMatrix (double alpha, double x, double y, double z)
{
   unsigned int i;
   double ca, sa;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   ca = cos(alpha);
   sa = sin(alpha);
   
   this->mat[0] = (1 - x * x) * ca + x * x;
   this->mat[1] = -z * sa - x * y * ca + x * y;
   this->mat[2] = y * sa - x * z * ca + x * z;

   this->mat[0 + this->size] = z * sa - x * y * ca + x * y;
   this->mat[1 + this->size] = (1 - y * y) * ca + y * y;
   this->mat[2 + this->size] = -x * sa - y * z * ca + y * z;

   this->mat[0 + this->size * 2] = -y * sa - x * z * ca + x * z; 
   this->mat[1 + this->size * 2] = x * sa - y * z * ca + y * z;
   this->mat[2 + this->size * 2] = (1 - z) * (1 - z) * ca + z * z;
}


// --------------------------------------------------
void S3DMatrix::setRotateXMatrix (double alpha)
{
   unsigned int i;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   this->mat[0] =  1.0; 
   this->mat[1] =  0.0; 
   this->mat[2] =  0.0; 

   this->mat[0 + this->size] =  0.0;
   this->mat[1 + this->size] =  cos(alpha);
   this->mat[2 + this->size] = -sin(alpha);

   this->mat[0 + 2 * this->size] =  0.0;
   this->mat[1 + 2 * this->size] = sin(alpha);
   this->mat[2 + 2 * this->size] = cos(alpha);
}


// --------------------------------------------------
void S3DMatrix::setRotateYMatrix (double alpha)
{
   unsigned int i;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   this->mat[0] =  cos(alpha);
   this->mat[1] =  0.0; 
   this->mat[2] =  sin(alpha); 
   
   this->mat[0 + this->size] = 0.0;
   this->mat[1 + this->size] = 1.0;
   this->mat[2 + this->size] = 0.0;
   
   this->mat[0 + 2 * this->size] = -sin(alpha);
   this->mat[1 + 2 * this->size] =  0.0;
   this->mat[2 + 2 * this->size] =  cos(alpha);
}


// --------------------------------------------------
void S3DMatrix::setRotateZMatrix (double alpha)
{
   unsigned int i;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   this->mat[0] =  cos(alpha);
   this->mat[1] = -sin(alpha); 
   this->mat[2] =  0.0; 
   
   this->mat[0 + this->size] = sin(alpha);
   this->mat[1 + this->size] = cos(alpha);
   this->mat[2 + this->size] = 0.0;
   
   this->mat[0 + 2 * this->size] = 0.0;
   this->mat[1 + 2 * this->size] = 0.0;
   this->mat[2 + 2 * this->size] = 1.0;
}


// --------------------------------------------------
void S3DMatrix::setKernelConvolution (int type, float sigma, double cte)
{
   float div;
   unsigned int w, h;
   long x, y;
   double xd, yd;
   double inc;
   double k = 1.0; 

   // TODO

   w = h = this->size;

   // If the size of the matrix is even, it is transformed to odd
   if (h % 2 == 0)
   {
      h--;
      this->size = h;
   }

   if (w % 2 == 0)
   {
      w--;
      this->size = w;
   }

   if ((w <= 0) || (h <= 0))
      return;

   // Compute the samples:
   inc = (2.0 * S3DMath::PI) / (double) (w - 1);

   if (this->mat != 0)
      delete [] this->mat;
   
   switch (type)
   {
      case GAUSSnxn: {
	 this->mat = new double[w * w];
	 k = 2 * S3DMath::PI * sigma * sigma;

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, k * S3DMath::Gauss(cte * xd, cte * yd, sigma));
	    }

      } break;
	 
      case DoGAUSSnxnH: {
	 this->mat = new double[w * w];
	 k = 2 * S3DMath::PI * sigma * sigma * sigma * sigma;	       

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, k * S3DMath::IxGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case DoGAUSSnxnV: {
	 this->mat = new double[w * w];
	 k = 2 * S3DMath::PI * sigma * sigma * sigma * sigma;	       

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, k * S3DMath::IyGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case LoGAUSSnxn: {
	 this->mat = new double[w * w];
	 k = sigma * sigma * sigma * sigma;	       


	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, 
			 k * S3DMath::LoGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case DHoGAUSSnxnH: {
	 this->mat = new double[w * w];
	 k = sigma * sigma * sigma * sigma;	       

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, 
			 k * S3DMath::IxxGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case DVoGAUSSnxnV: {
	 this->mat = new double[w * w];
	 k = sigma * sigma * sigma * sigma;	       

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, 
			 k * S3DMath::IyyGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case DHoGAUSSnxnV: {
	 this->mat = new double[w * w];
	 k = sigma * sigma * sigma * sigma;

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, 
			 k * S3DMath::IxyGauss(cte * xd, cte * yd, sigma));
	    }
      } break;

      case DVoGAUSSnxnH: {
	 this->mat = new double[w * w];
	 k = sigma * sigma * sigma * sigma;

	 for (y = 0; y < h; y ++)
	    for (x = 0; x < w; x ++)
	    {
	       xd = x * inc - S3DMath::PI;
	       yd = y * inc - S3DMath::PI;

	       this->set(x, y, 
			 k * S3DMath::IyxGauss(cte * xd, cte * yd, sigma));
	    }
      } break;


      case FPHIGH3x3: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (y = 0; y < 3; y ++)
	    for (x = 0; x < 3; x ++)
	    {
	       this->set(x, y, -1);
	    }
	 this->set(1, 1, 8);
      } break;

      case BLUR3x3: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (y = 0; y < 3; y ++)
	    for (x = 0; x < 3; x ++)
	    {
	       this->set(x, y, 1.0 / 9.0);
	    }
      } break;

      case ROBERTS3x3H: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (y = 0; y < 3; y ++)
	    for (x = 0; x < 3; x ++)
	    {
	       this->set(x, y, 0);
	    }

	 this->set(1, 1, 1);
	 this->set(2, 2, -1);
      } break;

      case ROBERTS3x3V: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (y = 0; y < 3; y ++)
	    for (x = 0; x < 3; x ++)
	    {
	       this->set(x, y, 0);
	    }
	 this->set(2, 1, 1);
	 this->set(1, 2, -1);
      } break;


      case PREWITT3x3H: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (x = 0; x < 3; x ++)
	 {
	    this->set(x, 0, -1);
	 }
	 for (x = 0; x < 3; x ++)
	 {
	    this->set(x, 1, 0);
	 }
	 for (x = 0; x < 3; x ++)
	 {
	    this->set(x, 2, 1);
	 }
      } break;      

      case PREWITT3x3V: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 for (x = 0; x < 3; x ++)
	 {
	    this->set(0, y, -1);
	 }
	 for (x = 0; x < 3; x ++)
	 {
	    this->set(1, y, 0);
	 }
	 for (x = 0; x < 3; x ++)
	 {
	    this->set(2, y, 1);
	 }
      } break;      

      case SOBEL3x3H: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 this->set(0, 0, -1);
	 this->set(1, 0, -2);
	 this->set(2, 0, -1);
	 this->set(0, 1, 0);
	 this->set(1, 1, 0);
	 this->set(2, 1, 0);
	 this->set(0, 2, 1);
	 this->set(1, 2, 2);
	 this->set(2, 2, 1);
      } break;      

      case SOBEL3x3V: {
	 this->mat = new double[3 * 3];
	 this->size = 3;

	 this->set(0, 0, -1);
	 this->set(0, 1, -2);
	 this->set(0, 2, -1);
	 this->set(1, 0, 0);
	 this->set(1, 1, 0);
	 this->set(1, 2, 0);
	 this->set(2, 0, 1);
	 this->set(2, 1, 2);
	 this->set(2, 2, 1);
      } break;      

      case LAPLACE5x5: {
	 this->mat = new double[5 * 5];
	 this->size = 5;

	 this->set(0, 0, 0);
	 this->set(1, 0, 0);
	 this->set(2, 0, -1);
	 this->set(3, 0, 0);
	 this->set(4, 0, 0);

	 this->set(0, 1, 0);
	 this->set(1, 1, -1);
	 this->set(2, 1, -2);
	 this->set(3, 1, -1);
	 this->set(4, 1, 0);

	 this->set(0, 2, -1);
	 this->set(1, 2, -2);
	 this->set(2, 2, 16);
	 this->set(3, 2, -2);
	 this->set(4, 2, -1);

	 this->set(0, 3, 0);
	 this->set(1, 3, -1);
	 this->set(2, 3, -2);
	 this->set(3, 3, -1);
	 this->set(4, 3, 0);

	 this->set(0, 4, 0);
	 this->set(1, 4, 0);
	 this->set(2, 4, -1);
	 this->set(3, 4, 0);
	 this->set(4, 4, 0);

      } break;      

      default: {
	 std::cerr << "* Warning: Invalid type of convolution when creating "
		   << "the kernel in the matrix.\n";
      } break;
   }
   
   return;
}


// --------------------------------------------------
void S3DMatrix::setScaleMatrix (double x, double y, double z)
{
   unsigned int i;

   for (i = 0; i < this->size; i ++)
      this->mat[i + i * this->size] = 1.0;

   this->mat[0] = x;
   this->mat[1 + this->size] = y;
   this->mat[2 + this->size * 2] = z;
}


// --------------------------------------------------
double *S3DMatrix::get(void)
{
   return this->mat;
}


// --------------------------------------------------
double S3DMatrix::get(unsigned int i, unsigned int j)
{
   return this->mat[i + this->size * j];
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::transpose (void)
{
   S3DMatrix *m;
   unsigned int i, j;

   m = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
	 m->set(j, i, this->mat[i + j * this->size]);
   
   return m;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::plus (S3DMatrix *m)
{
   S3DMatrix *mn;
   unsigned int i, j;

   mn = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
	 mn->set(i, j, this->mat[i + j * this->size] + m->get(i, j));
   
   return mn;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::minus (S3DMatrix *m)
{
   S3DMatrix *mn;
   unsigned int i, j;

   mn = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
	 mn->set(i, j, this->mat[i + j * this->size] - m->get(i, j));
   
   return mn;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::dot (S3DMatrix *m)
{
   S3DMatrix *mn;
   unsigned int i, j;

   mn = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
	 mn->set(i, j, this->mat[i + j * this->size] * m->get(i, j));
   
   return mn;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::dot (double cte)
{
   S3DMatrix *mn;
   unsigned int i, j;

   mn = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
	 mn->set(i, j, this->mat[i + j * this->size] * cte);
   
   return mn;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::cross (S3DMatrix *m)
{
   unsigned int i, j, k;
   double c;
   S3DMatrix *mn;

   mn = new S3DMatrix (S3DMatrix::UNDEFINED, this->size);

   for (j = 0; j < this->size; j ++)
      for (i = 0; i < this->size; i ++)
      {
	 c = 0;
         for (k = 0; k < this->size; k ++)
	    c += this->mat[k + j * this->size] * m->get(i, k);

	 mn->set(i, j, c);
      }

   return mn;
}


// --------------------------------------------------
S3DMatrix *S3DMatrix::copy (void)
{
   S3DMatrix *mn = new S3DMatrix(S3DMatrix::UNDEFINED, this->size);
   mn->set(this->mat);
}


// --------------------------------------------------
void S3DMatrix::print (void)
{
   this->print(0);
}


// --------------------------------------------------
void S3DMatrix::print (const char *str)
{
   unsigned int i, j;
   const char *color = "\033[22;31m";
   const char *black = "\033[22;30m";
   
   std::cerr.precision(2);

   if (str == 0)
      std::cerr << color << "Matrix: {" << std::endl;
   else
      std::cerr << color << "Matrix \"" << str << "\": {" << std::endl;

   std::cerr << black;

   for (j = 0; j < this->size; j ++)
   {
      for (i = 0; i < this->size; i ++)
      {
	 std::cerr.setf(std::ios::left, std::ios::adjustfield);
	 std::cerr << " " << std::setw(10) 
		   << this->mat[i + j * this->size] << " ";
      }
      std::cerr << std::endl;
   }

   std::cerr << color << "}";
   std::cerr << black << std::endl; 
   return;
}

