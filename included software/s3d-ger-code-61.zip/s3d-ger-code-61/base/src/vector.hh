#ifndef __VECTOR__
#define __VECTOR__

#include <iostream>
#include <math.h>
#include <cstring>
#include "matrix.hh"


/** @class   S3DVector vector.hh
 *  @author  Germ�n Arroyo
 *  @date    2007
 *  @brief   This class is a vector, it may represent a point.
 *
 *  @bug     No bugs detected yet
 *  @warning The class does not test if the arrays are 0 or not
             The class does not test if the length of the vector 
             are correct or not, so it may return stranges values or even 
	     break your program
 */

class S3DVector {
   public:

      /** 
       * @pre length must be greater than 0
       * @post Constructor
       * @param[in] length The new length of the vector
       * @warning The vector elements are garbage
      */
      S3DVector(unsigned int length);

      /** 
       * @pre length must be greater than 0, v must be valid
       * @post Constructor
       * @param[in] the vector to copy
       * @param[in] length The new length of the vector
       * @warning The vector elements are garbage
      */
      S3DVector(double *v, unsigned int length);

      /** 
       * @post Constructor. 2D vector
       * @param[in] x The x position
       * @param[in] y The y position.
      */
      S3DVector (double x, double y);

      /** 
       * @post Constructor. 3D vector
       * @param[in] x The x position
       * @param[in] y The y position.
       * @param[in] z The z position.
      */
      S3DVector (double x, double y, double z);

      /** 
       * @post Constructor. 4D vector
       * @param[in] x The x position
       * @param[in] y The y position.
       * @param[in] z The z position.
       * @param[in] w The w position.
      */
      S3DVector (double x, double y, double z, double w);

      /** 
       * @post Destructor, it frees the used memory
      */
      ~S3DVector ();

      /**
       * @post It changes the first coordinate (x)
       */
      void X (double x);

      /**
       * @post It changes the second coordinate (y)
       */
      void Y (double y);

      /**
       * @post It changes the third coordinate (z)
       */
      void Z (double z);

      /**
       * @post It changes the fourth coordinate (w)
       */
      void W (double w);

      /**
       * @post The first coordinate (x)
       */
      double X (void);

      /**
       * @post The second coordinate (y)
       */
      double Y (void);

      /**
       * @post The third coordinate (z)
       */
      double Z (void);

      /**
       * @post The fourth coordinate (w)
       */
      double W (void);

#ifdef NOBLOCKED
      // This method has been blocked because conflicts with other method
      /**
       * @param[in] x The x position
       * @param[in] y The y position.
       * @post Set the 2d vector
       */
      void set (double x, double y);
#endif

      /**
       * @param[in] x The x position.
       * @param[in] y The y position.
       * @param[in] z The z position.
       * @post Set the 3d vector
       */
      void set (double x, double y, double z);

      /**
       * @param[in] x The x position.
       * @param[in] y The y position.
       * @param[in] z The z position.
       * @param[in] w The w position.
       * @post Set the 4d vector
       */
      void set (double x, double y, double z, double w);

      /**
       * @pre v must be valid (not 0) and have the same length that this
       * @param[in] v The vector to copy
       * @post Set a vector
       */
      void set (double *v);

      /**
       * @pre i must be lesser than the length of the vector
       * @param[in] i The index of the coordinate (starting with 0)
       * @param[in] v The value of the coordinate
       * @post Set a component in the vector
       */
      void set (unsigned int i, double v);

      /**
       * @post The vector as an array
       * @warning It is not a copy, do not free the array
       */
      double *get (void);

      /**
       * @pre i must be lesser than the length of the vector
       * @param[in] i The index of the coordinate from 0
       * @post The value of a coordinate in the vector
       */
      double get (unsigned int i);

      /**
       * @post The magnitude of the vector
       */
      double magnitude (void);

      /**
       * @pre v must be a valid vector (not 0) and have the same size
       * @param[in] v The vector
       * @post The scalar dot operation: (this � v)
       */
      double dot (S3DVector *v);

      /**
       * @param[in] cte The constant
       * @post The scalar dot operation with a costant: (this � cte)
       */
      S3DVector *dot (double cte);

      /**
       * @pre v must be a valid vector (not 0) and have the same size
       * @param[in] v The vector
       * @post The vectorial cross operation: (this x v)
       * @warning This method only works for 3d vectors,
                  with 4d vectors, the w coordinate does not change
       */
      S3DVector *cross (S3DVector *v);

      /**
       * @pre v0, v1, uv0, uv1 must be valid vectors (not 0) and 
       *      have the same size
       * @param[in] v0 The first vertex
       * @param[in] v1 The second vertex
       * @param[in] uv0 The first texel
       * @param[in] uv1 The second texel
       * @post The binormal of a face
       * @warning This method only works for 2d texels
       */
      S3DVector *binormal (S3DVector *v0, S3DVector *v1,
			   S3DVector *uv0, S3DVector *uv1);

      /**
       * @pre v0, v1, uv0, uv1 must be valid vectors (not 0) and 
       *      have the same size
       * @param[in] v0 The first vertex
       * @param[in] v1 The second vertex
       * @param[in] uv0 The first texel
       * @param[in] uv1 The second texel
       * @post The tangent of a face
       * @warning This method only works for 2d texels
       */
      S3DVector *tangent (S3DVector *v0, S3DVector *v1,
			  S3DVector *uv0, S3DVector *uv1);

      /**
       * @pre v must be a valid vector (not 0) and have the same size
       * @param[in] v The vector
       * @post The plus operation: (this + v)
       */
      S3DVector *plus (S3DVector *v);

      /**
       * @pre v must be a valid vector (not 0) and have the same size
       * @param[in] v The vector
       * @post The minus operation: (this - v)
       */
      S3DVector *minus (S3DVector *v);

      /**
       * @post The normalized vector
       */
      S3DVector *normalize (void);

      /**
       * @param[in] prec The precision of the comparation
       * @post If all the components of the vector are zero or not:
               Example:
                 (x, y, z) =?= 0
                 --> if (abs(x) > abs(prec)) -> false
       */
      bool isZero (double prec);

      /**
       * @pre v must be valid (not 0)
       * @param[in] v The vector to compare
       * @param[in] prec The precision of the comparation
       * @post If it is equal to v or not
               Example:
                 (x, y, z) =?= (a, b, c)
                 --> if (abs(x - a) > abs(prec)) -> false
       */
      bool isEqual (S3DVector *v, double prec);


      /**
       * @pre v must be valid (not 0)
       * @param[in] v The vector to compute the distance
       * @post The distance to v
       */
      double distance (S3DVector *v);

      /**
       * @pre The length of the vector must be less or equal to 4
       * @param[in] m The matrix as OpenGL format
       * @post  v x m
       */
      S3DVector *mult4x4Matrix (double m[16]);

      /**
       * @pre The length of the vector must be less or equal to 4
       * @param[in] m The matrix 
       * @post  v x m
       */
      S3DVector *mult4x4Matrix (S3DMatrix *m);

      /**
       * @pre The length of the vector must be less or equal to 3
       * @param[in] m The matrix as OpenGL format
       * @post  v x m
       */
      S3DVector *mult3x3Matrix (double m[9]);

      /**
       * @pre The length of the vector must be less or equal to 3
       * @param[in] m The matrix 
       * @post  v x m
       */
      S3DVector *mult3x3Matrix (S3DMatrix *m);

      /**
       * @post  A exact copy of this vector
       */
      S3DVector *copy (void);

      /**
       * @param[in] newLength The length of the new vector 
       * @post  A partial copy of this vector
       */
      S3DVector *copyWithLength (unsigned int newLength);

      /**
       * @post Reset every coordinate of this vector to 0
       */
      void setZero (void);

      /**
       * @post The length of the vector
       */
      unsigned int getLength (void);


      /**
       * @warning It is the original point, so do NOT free it
       * @post A raw vector of double
       */ 
      double *getRaw(void);
      

      /**
       * @post  Print this vector to cerr (DEBUG)
       */
      void print (void);

      /**
       * @param[in] str String to display, if 0 no text displayed
       * @post  Print this vector to cerr (DEBUG)
       */
      void print (const char *str);


   private:
      double *vect;
      unsigned int length;
};

#endif

