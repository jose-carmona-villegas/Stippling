#include "camera.hh"


// --------------------------------------------------
S3DCamera::S3DCamera (void)
{
   this->name = 0;
   this->fov = 45;
   this->znear = 0.1;
   this->zfar  = 100;
}


// --------------------------------------------------
S3DCamera::S3DCamera (S3DCamera *camera)
{
   if (camera == 0)
   {
      this->fov = 45;
      this->znear = 0.1;
      this->zfar = 100;

      return;
   }
   
   this->setPosition(camera->X(), camera->Y(), camera->Z());
   this->setEulerAngles(camera->AX(), camera->AY(), camera->AZ());
   this->fov = camera->getFOV();
   this->aspect = camera->getAspect();
   this->znear = camera->getNearPlane();
   this->zfar = camera->getFarPlane();
}


// --------------------------------------------------
void S3DCamera::setName (const char *n)
{
   if (this->name != 0)
      delete [] this->name;

   if (n == 0)
   {
      this->name = 0;
      return;
   }

   this->name = new char[strlen(n)];
   this->name[0] = '\0';
   strcpy(this->name, n);

   return;
}


// --------------------------------------------------
char *S3DCamera::getName (void)
{
   return this->name;
}


// --------------------------------------------------
void S3DCamera::setPosition (float x, float y, float z)
{
   this->px = x;
   this->py = y;
   this->pz = z;
}


// --------------------------------------------------
void S3DCamera::setEulerAngles (float x, float y, float z, bool dgr)
{
   if (dgr == false)
   {
      this->ax = x * 3.14159 / 180.0;
      this->ay = y * 3.14159 / 180.0;
      this->az = z * 3.14159 / 180.0;

      return;
   }

   this->ax = x;
   this->ay = y;
   this->az = z;
}


// --------------------------------------------------
void S3DCamera::draw (bool fr)
{
   float top, bottom, left, right;

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
/*
   if (fr == true)
   {
      top = tan (this->fov * 3.14159 / 360.0) * this->znear;
      bottom = -top;
      left = this->aspect * bottom;
      right = this->aspect * top;
      glFrustum (left, right, bottom, top, this->znear, this->zfar);
   }
   else
*/
   {
      gluPerspective (this->fov, this->aspect, this->znear, this->zfar); 
   }

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   glRotatef(-this->ax, 1, 0, 0);
   glRotatef(-this->ay, 0, 1, 0);
   glRotatef(-this->az, 0, 0, 1);

   glTranslatef(-this->px, -this->py, -this->pz);
}


// --------------------------------------------------
void S3DCamera::print (void)
{
   std::cout << "Camera name: " << this->name << "\n";
   std::cout << " Angle FOV: " << this->fov << "\n";
   std::cout << " Angle Aspect: " << this->aspect << "\n";
   std::cout << " Position: " 
	     << this->px << ", "
	     << this->py << ", "	
	     << this->pz << "\n";
   std::cout << " Euler Angles (DEGREES): " 
	     << this->ax << ", "
	     << this->ay << ", "	
	     << this->az << "\n";
   std::cout << " Clip Near: " << this->znear << "\n";
   std::cout << " Clip Far: " << this->zfar << "\n";
}


// --------------------------------------------------
void S3DCamera::setResolution (float w, float h)
{
   this->aspect = w / h;
}


// --------------------------------------------------
void S3DCamera::setFOV (float f, bool dgr)
{
   if (dgr == false)
      this->fov = 3.14159 / 180.0;
   else
      this->fov = f;
}


// --------------------------------------------------
void S3DCamera::setAspect (float a)
{
   this->aspect = a;
}


// --------------------------------------------------
void S3DCamera::setNearPlane (float n)
{
   this->znear = n;
}


// --------------------------------------------------
void S3DCamera::setFarPlane (float f)
{
   this->zfar = f;
}


// --------------------------------------------------
float S3DCamera::X (void)
{
   return this->px;
}

// --------------------------------------------------
float S3DCamera::Y (void)
{
   return this->py;
}

// --------------------------------------------------
float S3DCamera::Z (void)
{
   return this->pz;
}


// --------------------------------------------------
void S3DCamera::X (float x)
{
   this->px = x;
}


// --------------------------------------------------
void S3DCamera::Y (float y)
{
   this->py = y;
}


// --------------------------------------------------
void S3DCamera::Z (float z)
{
   this->pz = z;
}


// --------------------------------------------------
float S3DCamera::AX (void)
{
   return this->ax;
}

// --------------------------------------------------
float S3DCamera::AY (void)
{
   return this->ay;
}

// --------------------------------------------------
float S3DCamera::AZ (void)
{
   return this->az;
}


// --------------------------------------------------
void S3DCamera::AX (float x)
{
   this->ax = x;
}


// --------------------------------------------------
void S3DCamera::AY (float y)
{
   this->ay = y;
}


// --------------------------------------------------
void S3DCamera::AZ (float z)
{
   this->az = z;
}


// --------------------------------------------------
float S3DCamera::getFOV (void)
{
   return this->fov;
}


// --------------------------------------------------
float S3DCamera::getAspect (void)
{
   return this->aspect;
}


// --------------------------------------------------
float S3DCamera::getNearPlane (void)
{
   return this->znear;
}


// --------------------------------------------------
float S3DCamera::getFarPlane (void)
{
   return this->zfar;
}


// --------------------------------------------------
S3DCamera::~S3DCamera (void)
{
}
