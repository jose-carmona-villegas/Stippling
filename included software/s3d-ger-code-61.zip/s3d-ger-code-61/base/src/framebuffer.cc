#include "framebuffer.hh"
//#define FORCE_NO_FBO


// --------------------------------------------------
S3DFBO::S3DFBO(unsigned int width, unsigned int height, 
	       GLenum format, GLenum flag, GLenum type, GLenum interp, 
	       bool withdepthbuffer, bool withstencilbuffer)
{
   int maxtexsize;

   this->img = 0;

   this->backup = 0;
   this->old_viewport = new GLint[4];
   glGetIntegerv( GL_VIEWPORT, old_viewport);

   this->fbo = 0;
   this->depthbuffer = 0;

   this->w = width;
   this->h = height;

   this->fmt = format;
   this->flg = flag;
   this->tp = type;
   this->intr = interp;

#ifndef FORCE_NO_FBO

   glGenFramebuffersEXT(1, &(this->fbo));
   if (withdepthbuffer == true)
      glGenRenderbuffersEXT(1, &(this->depthbuffer));

   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, this->fbo);

//   glGetIntegerv(GL_MAX_TEXTURE_SIZE,&maxtexsize);
//   std::cerr << "GL_MAX_TEXTURE_SIZE = " << maxtexsize << "\n";

   if (this->img == 0)
      glGenTextures(1, &(this->img));

   glBindTexture(GL_TEXTURE_2D, this->img);

   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, interp);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, interp);

   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

   glTexImage2D(GL_TEXTURE_2D, 0, format,  this->w, this->h, 
		0, flag, type, 0);

   glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT, 
			     GL_TEXTURE_2D, this->img, 0);


   if (withdepthbuffer == true)
   {
      glBindTexture(GL_TEXTURE_2D, this->depthbuffer);
      //    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, 
      //           width, height, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, 0);

//      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
//      glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_LUMINANCE);
//      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, 
//                      GL_COMPARE_R_TO_TEXTURE);

      glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
      glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

      glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, this->depthbuffer);
      if (withstencilbuffer == false)
	 glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, 
				  width, height);
      else
      {
	 glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, 
				  GL_DEPTH_STENCIL_EXT, 
				  width, height);
	 glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, 
				      GL_DEPTH_ATTACHMENT_EXT, 
				      GL_RENDERBUFFER_EXT, this->depthbuffer);

	 glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT, 
				      GL_STENCIL_ATTACHMENT_EXT, 
				      GL_RENDERBUFFER_EXT, this->depthbuffer);
      }
   }

   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);

   glDrawBuffer(GL_BACK);
   glReadBuffer(GL_BACK);


   this->status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);

#else

   this->status = GL_FRAMEBUFFER_UNSUPPORTED_EXT;

#endif
}


// --------------------------------------------------
S3DFBO::~S3DFBO()
{
   if (this->old_viewport != 0)
      delete [] this->old_viewport;

   if (this->backup != 0)
      delete [] this->backup;

   if (this->img != 0)
   {
      glDeleteTextures(1, &(this->img));
      this->img = 0;
   }


   if (this->depthbuffer != 0)
      glDeleteRenderbuffersEXT(1, &(this->depthbuffer));

   if (this->fbo != 0)
      glDeleteFramebuffersEXT(1, &(this->fbo));
}


// --------------------------------------------------
void S3DFBO::renderFBO(void)
{
   GLint new_viewport[4];


#ifndef FORCE_NO_FBO

//   glPushAttrib(GL_ALL_ATTRIB_BITS);

   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, this->fbo);

   glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
   glReadBuffer(GL_COLOR_ATTACHMENT0_EXT);

   glPushAttrib(GL_VIEWPORT_BIT);

#else

   glGetIntegerv (GL_VIEWPORT, new_viewport);
   if ( (new_viewport[2] != this->old_viewport[2]) || 
	(new_viewport[3] != this->old_viewport[3]) || 
	(this->backup == 0))
   {
      memcpy(this->old_viewport, new_viewport, sizeof(GLint) * 4);
      if (this->backup != 0)
	 delete [] this->backup;

      this->backup = new unsigned char[this->old_viewport[2] * 
				       this->old_viewport[3] * 3];
   }

   glReadPixels(this->old_viewport[0], this->old_viewport[1], 
		this->old_viewport[2], this->old_viewport[3], 
		GL_RGB, GL_UNSIGNED_BYTE, this->backup);   
   
   
//   glPushAttrib(GL_ALL_ATTRIB_BITS);
   glPushAttrib(GL_VIEWPORT_BIT);

#endif

   glViewport(0, 0, this->w, this->h);
}


// --------------------------------------------------
void S3DFBO::renderFramebuffer(void)
{
   unsigned char *bk;

#ifndef FORCE_NO_FBO

   glPopAttrib();

   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
   glDrawBuffer(GL_BACK);
   glReadBuffer(GL_BACK);

#else

   bk = new unsigned char[this->w * this->h * this->fmt];
   glReadPixels(0, 0, this->w, this->h, 
		this->flg, this->tp, bk);   
   
   // We can use the depthbuffer texture as background in this case
   if (this->img == 0)
      glGenTextures( 1, &(this->img));

   glBindTexture (GL_TEXTURE_2D, this->img);

   glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
   
   // the texture wraps over at the edges (repeat)
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
   glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

   glTexImage2D(GL_TEXTURE_2D, 0, this->fmt, this->w, this->h,
		0, this->flg, this->tp, bk);
   
   delete [] bk;


   glPopAttrib();

   
//   glViewport(this->old_viewport[0], this->old_viewport[1], 
//	      this->old_viewport[2], this->old_viewport[3]);
   if (this->backup != 0)
   {
//      glRasterPos2i(this->old_viewport[0], this->old_viewport[1]);
      glDrawPixels(this->old_viewport[2], this->old_viewport[3], 
		   GL_RGB, GL_UNSIGNED_BYTE, this->backup);
   }


#endif

}


// --------------------------------------------------
bool S3DFBO::isValid (void)
{
   bool isOK = false;

   this->status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);

   switch(this->status) {                                          
      case GL_FRAMEBUFFER_COMPLETE_EXT: { // Everything's OK
	 isOK = true;
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_FORMATS_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER_EXT\n";
      } break;
	 
      case GL_FRAMEBUFFER_UNSUPPORTED_EXT: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "GL_FRAMEBUFFER_UNSUPPORTED_EXT\n";
      } break;
	 
      default: {
	 std::cerr << "glift::CheckFramebufferStatus() ERROR:\n\t"
		   << "Unknown ERROR\n";
      }
   }

   return isOK;
}


// --------------------------------------------------
GLuint S3DFBO::getTexture (void)
{
   return this->img;
}
