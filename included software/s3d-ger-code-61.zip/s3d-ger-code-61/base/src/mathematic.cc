#include "mathematic.hh"


// --------------------------------------------------
S3DMath::S3DMath(void)
{
   return;
}


// --------------------------------------------------
double S3DMath::Gauss (double x, double sigma)
{
   double k = 1.0 / (sqrt(2 * PI) * sigma);
   double exp = - (x * x) / (2 * sigma * sigma);

   return k * pow(E, exp);
}


// --------------------------------------------------
double S3DMath::Gauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return k * pow(E, exp);
}


// --------------------------------------------------
 double S3DMath::IxGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return k * -x / (sigma * sigma) * pow(E, exp);
}


// --------------------------------------------------
 double S3DMath::IyGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return k * -y / (sigma * sigma) * pow(E, exp);
}


// --------------------------------------------------
 double S3DMath::IxxGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return ((x * x) / pow(sigma, 4) - 1.0 / (sigma * sigma)) * pow(E, exp) * k;
}


// --------------------------------------------------
 double S3DMath::IyyGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return ((y * y) / pow(sigma, 4) - 1.0 / (sigma * sigma)) * pow(E, exp) * k;
}


// --------------------------------------------------
 double S3DMath::IxyGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return ((x * y) / (sigma * sigma)) * pow(E, exp) * k;
}


// --------------------------------------------------
 double S3DMath::IyxGauss (double x, double y, double sigma)
{
   double k = 1.0 /  (2 * PI * sigma * sigma);
   double exp = - (x * x + y * y) / (2 * sigma * sigma);

   return ((x * y) / (sigma * sigma)) * pow(E, exp) * k;
}


// --------------------------------------------------
 double S3DMath::LoGauss (double x, double y, double sigma)
{
   return IxxGauss(x, y, sigma) + IyyGauss(x, y, sigma);
}
