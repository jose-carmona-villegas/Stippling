#ifndef __CAMERA__
#define __CAMERA__

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <string.h>
#include <vector>
#include <SDL/SDL_image.h>
#include <GL/glew.h>
#include "matrix.hh"
#include "vector.hh"
#include "framebuffer.hh"
#include "image.hh"
#include "mesh.hh"


/** @class   S3DCamera camera.hh
 *  @author  Germán Arroyo
 *  @date    2010
 *  @brief   This class deal with the camera of a scene
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning 
 */

class S3DCamera {
   public:

      /** 
      * @post Constructor. Inizialite the camera.
      */
      S3DCamera (void);

      /** 
       * @pre mesh must be a valid Camera
       * @post Constructor copy.
       * @param[in] mesh The mesh
      */
      S3DCamera (S3DCamera *camera);

      /**
       * @param[in] fr If fr is true the method uses glFrustrum to draw, 
       *               in other case, it uses gluPerspective
       * @post Draw the model using the textures in order (max. 8 texture units)
       *       without using any shader, and without enable or disable texturing
       *       it does not change the smooth of flat mode either
       */
      virtual void draw(bool fr = false);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Set the position of the camera
       */
      void setPosition (float x, float y, float z);

      /**
       * @param[in] x The x angle
       * @param[in] y The y angle
       * @param[in] z The z angle
       * @param[in] dgr If it is true the angles are in degrees, in other case
       *                the angles are in radians
       * @post Set the euler angles of the camera orientation
       */
      void setEulerAngles (float x, float y, float z, bool dgr=true);

      /**
       * @param[in] w The width resolution
       * @param[in] h The height resolution
       * @post Change the aspect of the camera acording to the resolution
       */
      void setResolution (float w, float h);

      /**
       * @param[in] f The angle in degrees if dgr=true, in other case it is in
       *              radians
       * @param[in] dgr The angle is in degrees or in radians
       * @post Set the fov angle
       
       */
      void setFOV (float f, bool dgr=true);

      /**
       * @ 
       * @post Set The aspect ratio of the camera
       */
      void setAspect (float a);

      /**
       * @post The position of the near plane
       */
      void setNearPlane (float n);

      /**
       * @post The position of the far plane
       */
      void setFarPlane (float f);

      /**
       * @post The fov of the camera
       */
      float getFOV (void);

      /**
       * @post The aspect of the camera
       */
      float getAspect (void);

      /**
       * @post The position of the near plane
       */
      float getNearPlane (void);

      /**
       * @post The position of the far plane
       */
      float getFarPlane (void);

      /**
       * @param[in] name A valid name for the camera or 0
       * @post Set the name of the camera
       */
      void setName (const char *name);

      /**
       * @post The name of the camera
       */
      char *getName (void);

      /**
       * @post The x position of the camera
       */
      float X (void);

      /**
       * @post The y position of the camera
       */
      float Y (void);

      /**
       * @post The z position of the camera
       */
      float Z (void);

      /**
       * @post Set the x position of the camera
       */
      void X (float x);

      /**
       * @post Set the y position of the camera
       */
      void Y (float y);

      /**
       * @post Set the z position of the camera
       */
      void Z (float z);

      /**
       * @post The x angle of the camera
       */
      float AX (void);

      /**
       * @post The y angle of the camera
       */
      float AY (void);

      /**
       * @post The z angle of the camera
       */
      float AZ (void);

      /**
       * @post Set the x angle of the camera
       */
      void AX (float x);

      /**
       * @post Set the y angle of the camera
       */
      void AY (float y);

      /**
       * @post Set the z angle of the camera
       */
      void AZ (float z);

      /**
       * @post Destructor
       */
      ~S3DCamera(void);

      /**
       * @post Print the camera data
       */
      void print (void);

   protected:

   private:
      float ax, ay, az; /// Angles of the camera
      float px, py, pz; /// Position of the camera
      float fov;
      float aspect;
      float znear, zfar;
      float left, right, top, bottom;
      char *name; /// The name of the camera
};


#endif

