#include "imgcache.hh"


// --------------------------------------------------
S3DImagesCache::S3DImagesCache (void)
{
   this->path = new char[1];
   this->path[0] = '\0';
   this->maxmemory = -1;

   this->unitP = GL_TEXTURE0;
   this->interpP = GL_NEAREST;
   this->wayP = GL_CLAMP;
   this->modeP = GL_REPLACE;
}


// --------------------------------------------------
S3DImagesCache::~S3DImagesCache (void)
{
   int i;
   
   for (i = 0; i < this->lname.size(); i ++)
      if (this->lname[i] != 0)
	 delete [] this->lname[i];
}

// --------------------------------------------------
void S3DImagesCache::setPath (const char *newpath)
{
   int i;
   
   if (newpath == 0)
      newpath = "";
   
   if (this->path != 0)
      delete [] this->path;

   this->path = new char[strlen(newpath) + 2];
   for (i = 0; i < strlen(newpath); i ++)
      if (newpath[i] == '\\')
      {
	 this->path[i] = '/';
      }
      else
      {
	 this->path[i] = newpath[i];
      }

   if (this->path[strlen(newpath) - 1] != '/')
   {
      this->path[strlen(newpath)] = '/';
      this->path[strlen(newpath) + 1] = '\0';
   }
   else
      this->path[strlen(newpath)] = '\0';
}


// --------------------------------------------------
void S3DImagesCache::addImage (const char *filename, const char *name)
{
   S3DImage *img;
   long int i;
   char *str;
   char *str2;

   i = this->getIndex(name); 
   if (i < 0)
   {
      img = new S3DImage();

      str = new char[strlen(this->path) + strlen(filename) + 2];
      str[0] = '\0';
      sprintf(str, "%s%s", this->path, filename);

      if (name == 0)
      {
	 str2 = new char[strlen(filename) + 2];
	 str2[0] = '\0';
	 strcpy(str2, filename);
      }
      else
      {
	 str2 = new char[strlen(name) + 2];
	 str2[0] = '\0';
	 strcpy(str2, name);
      }

//      std::cerr << "Loading image in the cache: \"" << str << "\"\n"; 
//      std::cerr << "  path: \"" << this->path << "\"\n"; 
//      if (name == 0)
//	 std::cerr << "  filename: \"" << filename << "\"\n"; 
//      else
//	 std::cerr << "  name: \"" << name << "\"\n"; 

      
      if (img->load(str) != 0)
      {

	 this->limg.push_back(img);
	 this->lname.push_back(str2);
	 this->lcnt.push_back(1);
      }
      else
	 delete [] str2;

      delete [] str;
   }
   else
   {
      this->lcnt[i] = this->lcnt[i] + 1;
   }

   return;
}


// --------------------------------------------------
void S3DImagesCache::removeImage (const char *name)
{
   S3DImage *img;
   long int i;

   i = this->getIndex(name); 
   if (i < 0)
      return;

   this->lcnt[i] = this->lcnt[i] - 1;
   if (this->lcnt[i] < 0)
   {
      this->lcnt.erase(this->lcnt.begin() + i);
      this->limg.erase(this->limg.begin() + i);
      if (this->lname[i] != 0)
	 delete [] this->lname[i];
      this->lname.erase(this->lname.begin() + i);
   }

   return;
}


// --------------------------------------------------
S3DImage *S3DImagesCache::getImage (const char *name)
{
   unsigned long int i;

   for (i = 0; i < this->lname.size(); i ++)
      if ( (this->lname[i] != 0 ) && (!strcmp(this->lname[i], name)) )
      {
//	 std::cerr << "Compare : \"" << this->lname[i]
//		   << "\" with \"" << name << "\"\n";
	 this->lcnt[i] ++;
	 return this->limg[i];
      }

   return 0;
}


// --------------------------------------------------
long int S3DImagesCache::getIndex (const char *name)
{
   long int i;

   if (name == 0)
      return -1;

   for (i = 0; i < this->lname.size(); i ++)
      if ( (this->lname[i] != 0 ) && (!strcmp(this->lname[i], name)) )
      {
	 return i;
      }

   return -1;
}


// --------------------------------------------------
void S3DImagesCache::setTextureMode(GLenum unit, GLenum interp, GLenum way,
				    GLenum mode)
{
   this->unitP = unit;
   this->interpP = interp;
   this->wayP = way;
   this->modeP = mode;
}


// --------------------------------------------------
void S3DImagesCache::setTexture2D(void)
{
   this->setTexture2D(this->unitP, this->interpP, this->wayP, this->modeP);
}


// --------------------------------------------------
void S3DImagesCache::setTexture2D(GLenum unit, GLenum interp, GLenum way,
				  GLenum mode)
{
   long int i;

   this->usedmemory = 0;
   for (i = 0; i < this->limg.size(); i++)
   {
      if (this->usedmemory < this->maxmemory)
      {
	 this->usedmemory += (this->limg[i]->getWidth() * 
			      this->limg[i]->getHeight() * 
			      this->limg[i]->getBPP());
      }
      this->limg[i]->setTexture2D(unit, interp, way, mode);
   }
}


// --------------------------------------------------
GLuint S3DImagesCache::getTexture2D(const char *name)
{
   S3DImage *img;
   GLuint t;
   long int min = -1000;
   long int i, index;

   img = this->getImage(name);

   if (img == 0)
      return 0;

   t = img->getTexture2D();
   if (t == 0)
   {
      for (i = 0; i < this->lcnt.size(); i ++)
      {
	 if (min < this->lcnt[i])
	 {
	    min = this->lcnt[i];
	    index = i;
	 }
	 this->lcnt[i] --;
	 if (this->lcnt[i] < 0)
	    this->lcnt[i] = 0;
      }
      if (index >= 0)
      {
	 this->limg[index]->delTexture2D();
	 this->usedmemory -= (this->limg[index]->getWidth() * 
			      this->limg[index]->getHeight() * 
			      this->limg[index]->getBPP());

	 t = img->setTexture2D(this->unitP, this->interpP, this->wayP,
			       this->modeP);
	 this->usedmemory -= (img->getWidth() * img->getHeight() * 
			      img->getBPP());
      }
   }

   return t;
}
