#include "filemgr.hh"

// --------------------------------------------------
S3DFileMgr::S3DFileMgr (void)
{
   this->index = 0;
   this->dirname = 0;
   this->showWarnings = true;
}


// --------------------------------------------------
S3DFileMgr::S3DFileMgr (const char *dir)
{
   this->index = 0;
   this->dirname = 0;
   this->switchDir(dir);
   this->showWarnings = true;
}


// --------------------------------------------------
S3DFileMgr::~S3DFileMgr ()
{
   this->clean();
}


// --------------------------------------------------
void S3DFileMgr::clean (void)
{
   long long int i;

   for (i = 0; i < fnames.size(); i++)
   {
      delete [] fnames[i];
   }
   this->fnames.clear();
   this->typeFile.clear();
   if (this->dirname != 0)
      delete [] dirname;

   this->index = 0;
}
      

// --------------------------------------------------
void S3DFileMgr::getInDir (const char *dir)
{
   char *cpy;


   if (dir == 0)
      return;

   if (dir[0] == '/')
      dir ++;

#ifdef WINDOWS
   if (dir[0] == '\\')
      dir ++;
#endif


   if (this->dirname == 0)
      this->switchDir(this->dirname);

   cpy = new char[std::strlen(dir) + std::strlen(this->dirname) + 4];
   cpy[0] = '\0';
   
#ifdef WINDOWS
   if ( (this->dirname[std::strlen(this->dirname - 1)] == '\\') ||
        (this->dirname[std::strlen(this->dirname - 1)] == '/') )
      sprintf(cpy, "%s%s", this->dirname, dir);
   else
      sprintf(cpy, "%s\\%s", this->dirname, dir);
#else
   if (this->dirname[std::strlen(this->dirname) - 1] == '/')
      sprintf(cpy, "%s%s", this->dirname, dir);
   else
      sprintf(cpy, "%s/%s", this->dirname, dir);
#endif

   this->switchDir(cpy);
   delete [] cpy;

   return;
}


// --------------------------------------------------
void S3DFileMgr::switchDir (const char *dir)
{
   char *cpy;
   int status;

   if (dir == 0)
      return;

   if (this->fnames.size() > 0)
      this->clean();

   this->dirname = new char[std::strlen(dir) + 1];
   this->dirname[0] = '\0';
   std::strcpy(this->dirname, dir);

#ifdef WINDOWS

   WIN32_FIND_DATA *fd;
   HANDLE fh;

   fd = new WIN32_FIND_DATA();
   
   cpy = new char[std::strlen(dir) + 4];
   cpy[0] = '\0';

   if ( (dir[std::strlen(dir) - 1] != '/') &&
	(dir[std::strlen(dir) - 1] != '\\') )
     sprintf(cpy, "%s/*", dir);
   else
     sprintf(cpy, "%s*", dir);
 
   fh = FindFirstFile((LPCSTR) cpy, fd);

   delete [] cpy;

   if (fh != INVALID_HANDLE_VALUE)
   {
     do
     {
       cpy = new char[std::strlen(fd->cFileName) + 1];
       std::strcpy (cpy, fd->cFileName);
       this->fnames.push_back(cpy);

       if (fd->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) // Is directory
       {
          this->typeFile.push_back(1);
       }
       else if (fd->dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE) // Is file
	  this->typeFile.push_back(0);
       else // Other case
	  this->typeFile.push_back(2);

     } while (FindNextFile(fh, fd));
   }
   
   FindClose(fh);   

   return;

#else

   struct stat st;

   if((this->dp  = opendir(dir)) == 0) 
   {
      if (this->showWarnings)
	 std::cout << "Error(" << errno << ") opening " << dir << std::endl;
      return;
   }

   while ((this->dirp = readdir(dp)) != 0) 
   {
      cpy = new char[std::strlen(this->dirp->d_name) + 4];
      cpy[0] = '\0';
      std::strcpy(cpy, this->dirp->d_name);

      this->fnames.push_back(cpy);

      status = stat(this->dirp->d_name, &st);


      if ( (status) && (this->showWarnings) )
      {
         std::cerr << "Warning in status = ";
         switch (status)
         {
            case EACCES: {
               std::cerr << "The process does not have "
                         << "search permission for a directory"
                         << " component of the file name.";
            } break;

            case ENAMETOOLONG: {
               std::cerr << "This error is used when either"
                         << " the total length of a file name is"
                         << " greater than PATH_MAX, or when an"
                         << " individual file name component has"
                         << " a length greater than NAME_MAX.";
            } break;

            case ENOENT: {
               std::cerr << "This error is reported when a"
                         << " file referenced as a directory"
                         << " component in the file name doesn't"
                         << " exist, or when a component is a symbolic"
                         << " link whose target file does not exist.";
            } break;

            case ENOTDIR: {
               std::cerr << "A file that is referenced as a "
                         << "directory component in the file name"
                         << " exists, but it isn't a directory. ";
            } break;

            case ELOOP: {
               std::cerr << "Too many symbolic links were resolved"
                         << " while trying to look up the file name."
                         << " The system has an arbitrary limit on the"
                         << " number of symbolic links that may be"
                         << " resolved in looking up a single file name,"
                         << " as a primitive way to detect loops.";
            } break;
             
            default : {
               std::cerr << "Unknown error: " << status;
            } break;
         }
         std::cerr << "\n";
      }

      if ( (st.st_mode & S_IFDIR) && (!status))
         this->typeFile.push_back(1);
      else
         if (!status)
            this->typeFile.push_back(0);
         else   
         {
            this->typeFile.push_back(2);
         }
   }
   closedir(dp);

   return;
#endif
}


// --------------------------------------------------
char *S3DFileMgr::getFileName (unsigned int i, bool completePath)
{
   long int indx;
   char *name;

   indx = this->index;
   this->index = i;
   name = this->getFileName(completePath);
   this->index = indx;

   return name;
}


// --------------------------------------------------
void S3DFileMgr::removeDot (void)
{
   int i, j;

   for (i = 0; i < this->fnames.size(); i ++)
      if ( (this->fnames[i] != 0) &&
           ( (!strcmp(".", this->fnames[i])) || 
             (!strcmp("./", this->fnames[i])) ||
             (!strcmp(".\\", this->fnames[i])) ) )
      {
         this->fnames.erase(this->fnames.begin() + i);
         this->typeFile.erase(this->typeFile.begin() + i);

         this->index = 0;
         return;
      }

   return;
}


// --------------------------------------------------
char *S3DFileMgr::getFileName (bool completePath)
{
   char *cpy;
   unsigned long int size;

   if (this->fnames.size() == 0)
      return 0;

   size = (std::strlen(this->fnames[this->index]) + 
	   std::strlen(this->dirname) + 4);

   cpy = new char[size];
   cpy[0] = '\0';

   if (completePath)
   {
#ifdef WINDOWS
      if ( (this->dirname[std::strlen(this->dirname) - 1] == '\\') ||
           (this->dirname[std::strlen(this->dirname) - 1] == '/') )
         sprintf(cpy, "%s%s", this->dirname, this->fnames[this->index]);
      else
         sprintf(cpy, "%s\\%s", this->dirname, this->fnames[this->index]);
#else
      if (this->dirname[std::strlen(this->dirname) - 1] == '/')
         sprintf(cpy, "%s%s", this->dirname, this->fnames[this->index]);
      else
         sprintf(cpy, "%s/%s", this->dirname, this->fnames[this->index]);
#endif
   }
   else
   {
      std::strcpy(cpy, this->fnames[this->index]);
   }

   return cpy;
}


// --------------------------------------------------
unsigned int S3DFileMgr::numOfElements (void)
{
   return this->fnames.size();
}


// --------------------------------------------------
bool S3DFileMgr::isFile (int i)
{
   long int indx;
   bool d;

   indx = this->index;
   this->index = i;
   d = this->isFile();
   this->index = indx;

   return d;
}


// --------------------------------------------------
bool S3DFileMgr::isDirectory(int i)
{
   long int indx;
   bool d;

   indx = this->index;
   this->index = i;
   d = this->isDirectory();
   this->index = indx;

   return d;
}


// --------------------------------------------------
bool S3DFileMgr::isDirectory (void)
{
   if (this->typeFile.size() == 0)
      return false;

#ifdef WINDOWS
#else
   if (this->typeFile[this->index] == 2)
   {
      if((opendir(this->getFileName())) != 0)
      { 
         // fix the previous error:
         this->typeFile[this->index] = 1;
         return true;
      }
   }   
#endif

   if (this->typeFile[this->index] != 1)
      return false;

   return true;
}


// --------------------------------------------------
float S3DFileMgr::getFileSize(unsigned int i)
{
   long int indx;
   float f;

   indx = this->index;
   this->index = i;
   f = this->getFileSize();
   this->index = indx;

   return f;
}


// --------------------------------------------------
float S3DFileMgr::getFileSize(void)
{
   std::ifstream f;
   std::ifstream::pos_type begin_pos;

   if (this->fnames.size() == 0)
      return -1;

   f.open(this->getFileName(), 
          std::ios_base::binary | std::ios_base::in);

  if (!f.good() || f.eof() || !f.is_open())
  { 
     return -1;
  }

  f.seekg(0, std::ios_base::beg);

  begin_pos = f.tellg();

  f.seekg(0, std::ios_base::end);

  return (float) (f.tellg() - begin_pos);
}


// --------------------------------------------------
bool S3DFileMgr::isFile (void)
{
   if (this->typeFile.size() == 0)
      return false;

   // Let test it
   if (this->typeFile[this->index] == 2)
   {
      if (this->getFileSize() >= 0)
         return true;
      else 
         return false;
   }
   
   if (this->typeFile[this->index] != 0)
      return false;

   return true;
}


// --------------------------------------------------
bool S3DFileMgr::nextFile (void)
{
   this->index ++;
   if (this->index >= this->fnames.size())
      this->index = this->fnames.size() - 1;
}


// --------------------------------------------------
bool S3DFileMgr::prevFile (void)
{
   this->index --;
   if (this->index < 0)
      this->index = 0;
}


// --------------------------------------------------
void S3DFileMgr::print (void)
{
   int i;
   char *cr;

   for (i = 0; i < this->numOfElements(); i ++)
   {
      if (this->isDirectory())
         std::cout << " [D] ";
      else
         if (this->isFile())
            std::cout << "  *  ";
         else   
            std::cout << " [?] ";

      cr = this->getFileName();
      std::cout << cr;
      std::cout << " / [" << this->getFileName(false) << "]";
      if (this->isFile())
         std::cout << " (" <<  (int) this->getFileSize() << " bytes)";

      std::cout << std::endl;

      delete cr;

      this->nextFile();
   }
   std::cout << std::endl;
}


// --------------------------------------------------
void S3DFileMgr::print (const char *str)
{
   std::cout << str << std::endl;
   this->print();
}


// --------------------------------------------------
void S3DFileMgr::hideMsg (bool s)
{
   this->showWarnings = !s;
}
