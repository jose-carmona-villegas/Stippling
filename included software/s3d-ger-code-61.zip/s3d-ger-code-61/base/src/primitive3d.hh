#ifndef __PRIMITIVE3D__
#define __PRIMITIVE3D__

#include <iostream>
#include <math.h>
#include <GL/glew.h>
#include <math.h>
#include "image.hh"

/** @class   S3DPrimitive3D primitive3d.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class has a set of 3D primitives 
 *
 *  @bug     No bugs detected yet
 *  @warning 
 */

class S3DPrimitive3D {
   public:

      /// This is used to compute the circles
      static const double DEGREES_TO_RADIANS = M_PI / 180.0;
      

      /**
       * @post Draw a box
       * @param[in] way The OpenGL parameter to draw between vertices
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] w The width
       * @param[in] h The height
       * @param[in] d The depth
       */
      static void drawBox(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			  GLfloat w, GLfloat h, GLfloat d);

      /**
       * @post Draw a plane
       * @param[in] way The OpenGL parameter to draw between vertices
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] w The width
       * @param[in] h The height
       * @note The texels are inverted to render images in a proper way
       */
      static void drawPlane(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			    GLfloat w, GLfloat h);

      /**
       * @post Draw a plane
       * @param[in] way The OpenGL parameter to draw between vertices
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] w The width
       * @param[in] h The height
       * @param[in] inverted If it is true, it works as the other drawPlane
       *                     in other case, the texels are not inverted 
       */
      static void drawPlane(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			    GLfloat w, GLfloat h, bool inverted);

      /**
       * @post Draw the axis
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] length The length of the line
       */
      static void drawAxis(GLfloat x, GLfloat y, GLfloat z, GLfloat length);

      /**
       * @post The ID of the texture
       * @pre img must be different to 0 and a valid image
       * @param[in] unit The unit of the texture: GL_TEXTURE1, GL_TEXTURE2, etc.
       * @param[in] interp The way of the interpolation: GL_LINEAR, GL_NEAREST
       * @param[in] way One of this values: GL_CLAMP, GL_REPEAT, etc.
       * @param[in] mode The way to put the texture GL_DECAL, GL_MODULATE
       * @param[in] img A valid image
       */
      static GLuint setTexture2D(GLenum unit, GLenum interp, GLenum way,
				 GLenum mode, S3DImage *img);


      /**
       * @post The ID of the texture
       * @pre img must be different to 0 and a valid image
       * @param[in] unit The unit of the texture: GL_TEXTURE1, GL_TEXTURE2, etc.
       * @param[in] interp The way of the interpolation: GL_LINEAR, GL_NEAREST
       * @param[in] way One of this values: GL_CLAMP, GL_REPEAT, etc.
       * @param[in] mode The way to put the texture GL_DECAL, GL_MODULATE
       * @param[in] buffer A valid buffer (OpenGL format)
       * @param[in] bpp The number of bytes per sample in the image
       * @param[in] w The with of the image
       * @param[in] h The height of the image
       */
      static GLuint setTexture2D(GLenum unit, GLenum interp, 
				 GLenum way, GLenum mode, 
				 void *buffer, unsigned int bpp, 
				 unsigned int w, unsigned int h);

      /**
       * @param[in] way The OpenGL parameter to draw between vertices
       *                in special GL_TRIANGLE_FAN or GL_LINE_STRIP
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] a The horizontal radius
       * @param[in] b The vertical radius
       * @param[in] r The exponent, r = 1 is a rectangle, r may be greater 
       *              than 1 
       */
      static void drawSuperellipse (GLenum way, 
				    GLfloat x, GLfloat y, GLfloat z, 
				    GLfloat a, GLfloat b, GLfloat r);

      /**
       * @param[in] way The OpenGL parameter to draw between vertices
       *                in special GL_TRIANGLE_FAN or GL_LINE_STRIP
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] r The horizontal radius
       */
      static void drawCircle (GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			      GLfloat r);

      /**
       * @param[in] way The OpenGL parameter to draw between vertices
       *                in special GL_TRIANGLE_FAN or GL_LINE_STRIP
       * @param[in] angle The angle of the circle
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @param[in] r The horizontal radius
       */
      static void drawCircle (GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			      GLfloat r, unsigned int angle);

      /**
       * @param[in] x0 The start x position
       * @param[in] y0 The start y position
       * @param[in] z0 The start z position
       * @param[in] x1 The end x position
       * @param[in] y1 The end y position
       * @param[in] z1 The end z position
       * @param[in] w  The size of the arrow or the final dot
       * @param[in] startarrow If it is true, an arrow is drawn at the beginning
       * @param[in] endarrow If it is true, an arrow is drawn at the end
       */
      static void drawConnector(GLfloat x0, GLfloat y0, GLfloat z0, 
				GLfloat x1, GLfloat y1, GLfloat z1, 
				GLfloat w, bool startarrow, bool endarrow);

};


#endif

