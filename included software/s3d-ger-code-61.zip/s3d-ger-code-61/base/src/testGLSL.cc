#include <iostream>
#include <math.h>

#include <iostream>
#include <SDL/SDL.h>
#include <GL/glew.h>
#include "shader.hh"
#include "primitive3d.hh"
#include "framebuffer.hh"
#include "mesh.hh"


int main (int argc, char *argv[])
{
   SDL_Surface *screen;
   SDL_Event event;
   const SDL_VideoInfo* info = NULL;
   int width = 800;
   int height = 800;
   int bpp = 0;
   int flags = 0;
   int quit = 0;
   const GLubyte* strm;
   GLint value;
   GLenum err;
   float f = 0; // Test variable
   char text[1000];
   unsigned int i;
   S3DShaderObj *sd;
   GLuint tex, tex2, tex3, imgtex;
   S3DImage *img, *imgnuev;
   float arrowpos = -1;
   S3DFBO *fbo;
   float version;
   S3DMatrix *m;
   S3DImage *img2;
   S3DMesh *model;


   /* ----- SDL init --------------- */
   if(SDL_Init(SDL_INIT_VIDEO) < 0) 
   {
      std::cerr << "Video initialization failed: " << SDL_GetError() << "\n";
      exit(-1);
   }
   
   atexit(SDL_Quit);
	
   info = SDL_GetVideoInfo();
   bpp = info->vfmt->BitsPerPixel;
   
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

/*	flags = SDL_OPENGL | SDL_FULLSCREEN; */
   flags = SDL_OPENGL | SDL_RESIZABLE;

/* ----- Setting up the screen surface --------------- */

//   SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE, 2);
   screen = SDL_SetVideoMode(width, height, bpp, flags);
   if(screen == 0) 
   {
      std::cerr << "Video mode set failed: " << SDL_GetError() << "\n";
      exit(-1);
   }

   SDL_WM_SetCaption("UI test", 0);


/* ----- Checking for OpenGL 2 --------------- */
   strm = glGetString(GL_VENDOR);
   std::cerr << "Vendor: " << strm << "\n";
   strm = glGetString(GL_RENDERER);
   std::cerr << "Renderer: " << strm << "\n";
   strm = glGetString(GL_VERSION);
   std::cerr << "OpenGL Version: " << strm << "\n";

   version = atof((const char *) strm);

   if (version < 2) 
   {
      std::cerr << "Warning: OpenGL 2 not supported!\n";
   }
   strm = glGetString(GL_VERSION);
   std::cerr << "Detected OpenGL Version >= " << version << "\n";

   strm = glGetString(GL_SHADING_LANGUAGE_VERSION);
   std::cerr << "GLSL Version: " << strm << "\n";


   // Glew init:
   err = glewInit();
   if (GLEW_OK != err)
   {
      /* Problem: glewInit failed, something is seriously wrong. */
      std::cerr << "Error: " << glewGetErrorString(err) << "\n";
      exit (-1);
   }

   std::cerr << "Status: Using GLEW " << glewGetString(GLEW_VERSION) << "\n";

   if (!glewGetExtension("ARB_texture_non_power_of_two"))
   {
      std::cerr << "Warning: ARB_texture_non_power_of_two may not be supported"
		<< "\n";
   }

   // GLSL Test:
   // ---------------------------------------------------------- 
   sd = new S3DShaderObj();

//   sd->loadPrograms("../shaders/pointLight.vert", 
//                    "../shaders/pointLight.frag");

   sd->loadPrograms("../shaders/toon.vert", 
		    "../shaders/toon.frag");

   glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
   fbo = new S3DFBO(2048, 2048,
		    GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, GL_LINEAR, true);

/* ----- Load Image --------------- */
   m = new S3DMatrix(S3DMatrix::UNDEFINED, 3);
   m->set(0, 0, 1);
   m->set(1, 0, 2);
   m->set(2, 0, 1);
   m->set(0, 1, 0);
   m->set(1, 1, 0);
   m->set(2, 1, 0);
   m->set(0, 2, -1);
   m->set(1, 2, -2);
   m->set(2, 2, -1);
   
   img = new S3DImage();
   img2 = new S3DImage();
   glEnable(GL_TEXTURE_2D);
   img->load ("../media/lamp.png");
   img2->convert(3);
   img2->convolute(img, m);
   delete m;

   imgnuev = new S3DImage();
   imgnuev->load ("../media/marble.png");
   model = new S3DMesh();
   model->load("../media/pot.ply");
//   model->load("/home/german/happy_low.ply");
//   model->load("/home/german/happy_high.ply");

//   model->setPivot(-1, 0, -1);
//   model->applyPivot();
   model->computeBinormals();
//   model->voxelize(128, 128, 128, "/tmp/happy");


/* ----- Event cycle --------------- */
   quit = 0;
   while (!quit) 
   {
      glClearColor(0.6, 0.6, 0.7, 0.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      glDisable(GL_CULL_FACE);
      glEnable(GL_DEPTH_TEST);

      // Draw something in the FBO:
      fbo->renderFBO();

      tex3 = imgnuev->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_CLAMP, 
				   GL_MODULATE);

      tex = img->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_CLAMP, 
			      GL_DECAL);
      tex2 = img2->setTexture2D(GL_TEXTURE0, GL_NEAREST, GL_CLAMP, 
				GL_DECAL);

      glClearColor(0.6, 0.6, 0.7, 1.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluPerspective(45, 1.33, 1.0, 60.0);

      glEnable(GL_BLEND);
      glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      f += 0.05;
      if (f > 360)
	 f = 0;

      glDisable(GL_TEXTURE_2D);
      glTranslatef (0, 0, -4);
      glLineWidth(8);

      glColor4f(0.0, 0.0, 1.0, 0.2);
      S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 0, 0, 0, 0.5, 0.5, 4.5);
      glColor3f(0, 0, 0);
      S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP, 0, 0, 0, 0.5, 0.5, 4.5);

      glColor3f (0.8, 0.9, 0.0);
      S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 0, 0, 0.1, 
				       0.5, 0.5, 0.5);
      glColor3f(0, 0, 0);
      S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP, 0, 0, 0.1, 0.5, 0.5, 0.5);

      glColor3f (0.0, 0.9, 0.8);
      S3DPrimitive3D::drawSuperellipse(GL_TRIANGLE_FAN, 0, 0, 0.2, 
				       0.5, 0.5, 0.25);
      glColor3f(0, 0, 0);
      S3DPrimitive3D::drawSuperellipse(GL_LINE_STRIP, 0, 0, 0.2, 
				       0.5, 0.5, 0.25);

      S3DPrimitive3D::drawConnector(-1.0, 0.5, 0.3, 1.0, 0.5, 0.3, 0.3,
				    false, true);

      S3DPrimitive3D::drawConnector(0.0, 0.0, 0.3, 0.0, 1.0, 0.3, 0.3,
				    false, false);
      glColor4f (0.0, 0.9, 0.6, 0.6);
      S3DPrimitive3D::drawConnector(0.0, 0.0, 0.4, arrowpos, 0.5, 0.3, 0.4,
				    false, true);
      arrowpos += 0.005;
      if (arrowpos > 1)
	 arrowpos = -1;

      glRotatef (f, 1.0, 1.0, 1.0);


      sd->useProgram();
//      glDisable(GL_BLEND);
      glDisable(GL_TEXTURE_2D);
      glColor4f(0.0, 0.0, 1.0, 0.2);
      S3DPrimitive3D::drawCircle(GL_TRIANGLE_FAN, 0, 0, 0, 1);

     
      sd->doNotUseProgram();
      glColor4f(0.0, 0.0, 0.0, 1.0);
      S3DPrimitive3D::drawCircle(GL_LINE_STRIP, 0, 0, 0, 1);



      glEnable(GL_BLEND);
      glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
      glLoadIdentity();
      glTranslatef (0, 0, -4);
      glRotatef (f, -1.0, 1.0, 1.0);

      glActiveTexture(GL_TEXTURE0);
      glEnable(GL_TEXTURE_2D);
//      glDisable(GL_BLEND);
      glBindTexture(GL_TEXTURE_2D, tex);
      glColor4f(1.0, 1.0, 1.0, 1.0);
      S3DPrimitive3D::drawPlane(GL_POLYGON, -1, -0.5, -1, 2, 2);


      glActiveTexture(GL_TEXTURE0);
      glEnable(GL_TEXTURE_2D);
//      glDisable(GL_BLEND);
      glBindTexture(GL_TEXTURE_2D, tex2);
      glColor4f(1.0, 1.0, 1.0, 1.0);
      S3DPrimitive3D::drawPlane(GL_POLYGON, -1.5, -0.5, -1.5, 2, 2);

      fbo->renderFramebuffer();
      imgtex = fbo->getTexture();

      // ---------------------------------------------------------

      glClearColor(0.0, 0.0, 0.0, 1.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

      sd->doNotUseProgram();
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      gluPerspective(45, 1.33, 1.0, 60.0);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      f += 0.65;
      if (f > 360)
	 f = 0;

      glDisable(GL_TEXTURE_2D);
      glTranslatef (0, 0, -4);
      glRotatef (f, 1.0, 1.0, 1.0);

      sd->doNotUseProgram();
      glEnable(GL_TEXTURE_2D);
      glEnable(GL_BLEND);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      glBindTexture(GL_TEXTURE_2D, imgtex);
      glColor4f(1.0, 1.0, 1.0, 1.0);
      S3DPrimitive3D::drawPlane(GL_POLYGON, -1, -0.5, -1, 2, 2);
//      glDisable(GL_BLEND);

      glShadeModel(GL_SMOOTH);	
                
      glDisable(GL_BLEND);
      glDisable(GL_TEXTURE_2D);
      glEnable(GL_TEXTURE_2D);
      // select modulate to mix texture with color for shading
      glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D, tex3);
      glEnable(GL_LIGHTING);
      glEnable(GL_LIGHT0);

//      glDisable(GL_TEXTURE_1D);
//      glDisable(GL_TEXTURE_2D);
//      glDisable(GL_TEXTURE_3D);
//      glBindTexture(GL_TEXTURE_2D, 0);

      glPushMatrix();
      {
	 glColor3f(0.8, 0.7, 1.0);
//	 glScalef(8, 8, 8);
	 glScalef(0.4, 0.4, 0.4);
	 model->draw();

	 glDisable(GL_TEXTURE_2D);
	 glDisable(GL_LIGHTING);
	 glDisable(GL_LIGHT0);
	 glLineWidth(1);
	 glColor3f(1, 1, 0);
	 model->drawBoundingBox();
	 glColor3f(0, 1, 0);
	 model->drawNormals(0.1);
	 glColor3f(1, 0, 0);
	 model->drawBinormals(0.1);
	 glColor3f(0, 0, 1);
	 model->drawTangents(0.1);
      }
      glPopMatrix();
      glEnable(GL_TEXTURE_2D);
      glDisable(GL_LIGHTING);
      glDisable(GL_LIGHT0);


      // ----------------------

      while (SDL_PollEvent(&event)) 
      {
	 switch (event.type) 
	 {
	    // If you touch the close button:
	    case SDL_QUIT: {
	       quit = 1;
	    } break;
	    
	    // If the screen is resized:
	    case SDL_VIDEORESIZE: {
	       screen = SDL_SetVideoMode(event.resize.w, 
					 event.resize.h, 
					 bpp, flags); 
	       if(screen == 0)
	       {
		  std::cerr << "Video resize failed: " << SDL_GetError() 
			    << "\n";
		  exit (-1);
	       }
	       else
	       {
		  // Resize
		  width = event.resize.w;
		  height = event.resize.h;

		  // When resize, the viewport must be updated:

	       }

	    } break;

	    default : {
	       // Read events
	    } break;
	 
	 }
      }


      SDL_GL_SwapBuffers();
      SDL_Delay(1);
   }
   
   // Delete program
   delete sd;
   delete fbo;
   delete img;
   delete img2;

   SDL_Quit();

   return 0;
}
