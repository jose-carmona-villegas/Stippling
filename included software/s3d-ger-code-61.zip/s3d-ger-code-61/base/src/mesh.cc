#include "mesh.hh"


// --------------------------------------------------
S3DMesh::S3DMesh (void)
{
   this->name = 0;
   this->nvert = 0;
   this->nfac = 0;

   this->vertex = 0;
   this->face = 0;
   this->normal = 0;
   this->texel = 0;
   this->texID = 0;

   this->tangent = 0;
   this->binormal = 0;

   this->minBounding = new S3DVector(0, 0, 0);
   this->maxBounding = new S3DVector(0, 0, 0);

   this->pivot = new S3DVector(0, 0, 0);
   this->px = this->py = this->pz = 0;
   this->ax = this->ay = this->az = 0;
   this->sx = this->sy = this->sz = 0;
}


// --------------------------------------------------
void S3DMesh::setName (const char *n)
{
   if (this->name != 0)
      delete [] this->name;

   if (n == 0)
   {
      this->name = 0;
      return;
   }

   this->name = new char[strlen(n) + 1];
   this->name[0] = '\0';
   strcpy(this->name, n);

   return;
}


// --------------------------------------------------
void S3DMesh::ovwNormals(float *normalArray, long int size)
{
   if (this->normal != 0)
      delete [] this->normal;
   
   this->nvert = size;
   this->normal = normalArray;
}


// --------------------------------------------------
void S3DMesh::ovwVertices(float *vertexArray, long int size)
{
   if (this->vertex != 0)
      delete [] this->vertex;
   
   this->nvert = size;
   this->vertex = vertexArray;
}


// --------------------------------------------------
void S3DMesh::ovwFaces(long int *faceArray, long int size)
{
   if (this->face != 0)
      delete [] this->face;
   
   this->nfac = size;
   this->face = faceArray;
}


// --------------------------------------------------
char *S3DMesh::getName (void)
{
   return this->name;
}


// --------------------------------------------------
void S3DMesh::setPivot (float x, float y, float z)
{
   this->pivot->X(x);
   this->pivot->Y(y);
   this->pivot->Z(z);
}


// --------------------------------------------------
void S3DMesh::applyPivot (void)
{
   long int i;
   float x = this->pivot->X();
   float y = this->pivot->Y();
   float z = this->pivot->Z();

   for (i = 0; i < this->nvert; i++)
   {
      this->vertex[i * 3] = this->vertex[i * 3] + this->pivot->X();
      this->vertex[i * 3 + 1] = this->vertex[i * 3 + 1] + this->pivot->Y();
      this->vertex[i * 3 + 2] = this->vertex[i * 3 + 2] + this->pivot->Z();
   }

   this->minBounding->X(this->pivot->X() + this->minBounding->X());
   this->minBounding->Y(this->pivot->Y() + this->minBounding->Y());
   this->minBounding->Z(this->pivot->Z() + this->minBounding->Z());

   this->maxBounding->X(this->pivot->X() + this->maxBounding->X());
   this->maxBounding->Y(this->pivot->Y() + this->maxBounding->Y());
   this->maxBounding->Z(this->pivot->Z() + this->maxBounding->Z());

   this->pivot->X(0);
   this->pivot->Y(0);
   this->pivot->Z(0);
}


// --------------------------------------------------
void S3DMesh::computeBoundingBox (void)
{
   long int i;
   float vx, vy, vz, minx, miny, minz, maxx, maxy, maxz;
   bool first;

   if (this->vertex == 0)
      return ;

   minx = miny = minz = 0;
   maxx = maxy = maxz = 0;

   first = true;

   for (i = 0; i < this->nvert; i ++)
   {
      vx = this->vertex[i * 3];
      vy = this->vertex[i * 3 + 1];
      vz = this->vertex[i * 3 + 2];

      if (first == true)
      {
	 minx = maxx = vx;
	 miny = maxy = vy;
	 minz = maxz = vz;
	 
	 first = false;
      }
      else
      {
	 if (vx < minx)
	    minx = vx;
	 else
	    if (vx > maxx)
	       maxx = vx; 

	 if (vy < miny)
	    miny = vy;
	 else
	    if (vy > maxy)
	       maxy = vy;

	 if (vz < minz)
	    minz = vz;
	 else
	    if (vz > maxz)
	       maxz = vz;
     }
   }

   if (this->minBounding == 0)
      this->minBounding = new S3DVector(minx, miny, minz);
   else
      this->minBounding->set(minx, miny, minz); 

   if (this->maxBounding == 0)
      this->maxBounding = new S3DVector(maxx, maxy, maxz);
   else
      this->maxBounding->set(maxx, maxy, maxz); 

   return;
}


// --------------------------------------------------
void S3DMesh::drawNormals (float d)
{
   long int i;

   if (this->normal == 0)
      return;

   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);


   glBegin(GL_LINES);
   for (i = 0; i < this->nvert; i ++)   
   {
      glVertex3f(this->vertex[i * 3], 
		 this->vertex[i * 3 + 1],
		 this->vertex[i * 3 + 2]);

      glVertex3f(this->vertex[i * 3] + 
		 this->normal[i * 3] * d, 
		 this->vertex[i * 3 + 1] +
		 this->normal[i * 3 + 1] * d,
		 this->vertex[i * 3 + 2] + 
		 this->normal[i * 3 + 2] * d);
   }
   glEnd();

   glPopMatrix();
}


// --------------------------------------------------
void S3DMesh::drawBinormals (float d)
{
   long int i;

   if (this->binormal == 0)
      return;

   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);


   glBegin(GL_LINES);
   for (i = 0; i < this->nvert; i ++)   
   {
      glVertex3f(this->vertex[i * 3], 
		 this->vertex[i * 3 + 1],
		 this->vertex[i * 3 + 2]);

      glVertex3f(this->vertex[i * 3] + 
		 this->binormal[i * 3] * d, 
		 this->vertex[i * 3 + 1] +
		 this->binormal[i * 3 + 1] * d,
		 this->vertex[i * 3 + 2] + 
		 this->binormal[i * 3 + 2] * d);
   }
   glEnd();

   glPopMatrix();
}


// --------------------------------------------------
void S3DMesh::drawTangents (float d)
{
   long int i;

   if (this->tangent == 0)
      return;

   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);


   glBegin(GL_LINES);
   for (i = 0; i < this->nvert; i ++)   
   {
      glVertex3f(this->vertex[i * 3], 
		 this->vertex[i * 3 + 1],
		 this->vertex[i * 3 + 2]);

      glVertex3f(this->vertex[i * 3] + 
		 this->tangent[i * 3] * d, 
		 this->vertex[i * 3 + 1] +
		 this->tangent[i * 3 + 1] * d,
		 this->vertex[i * 3 + 2] + 
		 this->tangent[i * 3 + 2] * d);
   }
   glEnd();

   glPopMatrix();
}



// --------------------------------------------------
void S3DMesh::drawBoundingBox (void)
{
   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);


   glBegin(GL_LINE_STRIP);
   // BOTTOM:
   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());

   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());

   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());

   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());

   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());

   // TOP:
   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glEnd();

   // EDGES:
   glBegin(GL_LINES);
   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());
   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->minBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());
   glVertex3f(this->maxBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());

   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->minBounding->Z() + this->pivot->Z());
   glVertex3f(this->minBounding->X() + this->pivot->X(), 
	      this->maxBounding->Y() + this->pivot->Y(), 
	      this->maxBounding->Z() + this->pivot->Z());
   glEnd();

   glPopMatrix();
}


// --------------------------------------------------
void S3DMesh::placeMesh(bool ignorepivot)
{
   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);

   if ( (this->pivot->X() != 0) ||
	(this->pivot->Y() != 0) || 
	(this->pivot->Z() != 0) )
   {
      if (ignorepivot == false)
	 glTranslatef(this->pivot->X(), this->pivot->Y(), this->pivot->Z());
   }
   
   return;
}


// --------------------------------------------------
void S3DMesh::draw (bool ignorepivot)
{
   float *v;
   float *n;
   float *t;
   long int i, j;

   glPushMatrix();
   glTranslatef(this->px, this->py, this->pz);
   glRotatef(this->ax, 1, 0, 0);
   glRotatef(this->ay, 0, 1, 0);
   glRotatef(this->az, 0, 0, 1);
   glScalef(this->sx, this->sy, this->sz);

   if ( (this->pivot->X() != 0) ||
	(this->pivot->Y() != 0) || 
	(this->pivot->Z() != 0) )
   {
      if (ignorepivot == false)
      {
	 glPushMatrix();
	 glTranslatef(this->pivot->X(), this->pivot->Y(), this->pivot->Z());
      }
   }

   glBegin(GL_TRIANGLES);
   for (i = 0; i < this->nfac; i ++)
   {
      j = this->face[i * 3];
      v = this->vertex + j * 3;
      if (this->normal != 0)
      {
	 n = this->normal + j * 3;
	 glNormal3fv(n);
      }

      if (this->texel != 0)
      {
	 t = this->texel + j * 3;
	 glTexCoord3fv(t);
      }
      glVertex3fv(v);

      j = this->face[i * 3 + 1];
      v = this->vertex + j * 3;
      if (this->normal != 0)
      {
	 n = this->normal + j * 3;
	 glNormal3fv(n);
      }

      if (this->texel != 0)
      {
	 t = this->texel + j * 3;
	 glTexCoord3fv(t);
      }
      glVertex3fv(v);

      j = this->face[i * 3 + 2];
      v = this->vertex + j * 3;
      if (this->normal != 0)
      {
	 n = this->normal + j * 3;
	 glNormal3fv(n);
      }

      if (this->texel != 0)
      {
	 t = this->texel + j * 3;
	 glTexCoord3fv(t);
      }
      glVertex3fv(v);
   }
   glEnd();

   if ( (this->pivot->X() != 0) ||
	(this->pivot->Y() != 0) || 
	(this->pivot->Z() != 0) )
   {
      if (ignorepivot == false)
	 glPopMatrix();
   }

   glPopMatrix();
}


// --------------------------------------------------
void S3DMesh::setPosition(float x, float y, float z)
{
   this->px = x;
   this->py = y;
   this->pz = z;
}


// --------------------------------------------------
void S3DMesh::setEulerAngles(float x, float y, float z, bool dgr)
{
   if (dgr == false)
   {
      this->ax = x * 3.14159 / 180.0;
      this->ay = y * 3.14159 / 180.0;
      this->az = z * 3.14159 / 180.0;

      return;
   }

   this->ax = x;
   this->ay = y;
   this->az = z;
}


// --------------------------------------------------
void S3DMesh::setScale(float x, float y, float z)
{
   this->sx = x;
   this->sy = y;
   this->sz = z;
}


// --------------------------------------------------
int S3DMesh::load (const char *filename)
{
   if (this->loadPLY(filename) != 0)
      return 1;

   return 0;
}

// --------------------------------------------------
int S3DMesh::loadPLY (const char *filename)
{
   float minx, miny, minz;
   float maxx, maxy, maxz;
   char line[2048];
   int len, len2;
   bool readingHeader;
   int verror = 1;
   long int i, j, k;
   int xyzOrder[3] = {2047, 2047, 2047};
   int normalOrder[3] = {2047, 2047, 2047};
   int strOrder[3] = {2047, 2047, 2047};
   char *pch;
   float value[2048];
   float x, y, z, nx, ny, nz, s, t, r;
   std::vector<float> tmpface;
   S3DVector *v0, *v1, *t0, *t1, *tg, *bn;


   i = j = -1;
   minx = miny = minz = maxx = maxy = maxz = 0.0;
   
   std::ifstream file (filename);
   if (!file.is_open())
   {
      std::cerr << "Warning: File \'" << filename << "\' cannot be openned\n"; 
      return 0;
   }

   // Load the header
   line[0] = '\0';
   file.getline (line, 2048);
   if (strncmp(line, "ply", 3))
   {
      std::cerr << "Warning: File \'" << filename << "\' is not a PLY\n"; 
      return 0;
   }

   readingHeader = true;
   while (readingHeader)
   {
      line[0] = '\0';
      file.getline (line, 2048);

//      std::cerr << "\'" << line << "\'\n"; // DEBUG

      len = strlen("format");
      if (!strncmp(line, "format", len))
      {
	 len2 = strlen ("ascii 1.0");
	 if (strncmp(line + len + 1, "ascii 1.0", len2))
	    std::cerr << "Warning: unknown format for PLY file\n";

	 verror = 0;
      }

      if (!strncmp(line, "end_header", 10))
	 readingHeader = false;

      len = strlen("comment");
      if (!strncmp(line, "comment", len))
      {
	 std::cerr << "  * PLY Comment: " << line + len << "\n";
      }

      len = strlen("element vertex");
      if (!strncmp(line, "element vertex", len))
      {
	 this->nvert = atol(line + len);
	 i = 0;
      }

      len = strlen("element face");
      if (!strncmp(line, "element face", len))
      {
	 this->nfac = atol(line + len);
	 j = 0;
      }

      len = strlen("property float x");
      if (!strncmp(line, "property float x", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    xyzOrder[0] = i;
	    i ++;
	 }
      }

      len = strlen("property float y");
      if (!strncmp(line, "property float y", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    xyzOrder[1] = i;
	    i ++;
	 }
      }

      len = strlen("property float z");
      if (!strncmp(line, "property float z", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    xyzOrder[2] = i;
	    i ++;
	 }
      }


      len = strlen("property float nx");
      if (!strncmp(line, "property float nx", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    normalOrder[0] = i;
	    i ++;
	 }
      }

      len = strlen("property float ny");
      if (!strncmp(line, "property float ny", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    normalOrder[1] = i;
	    i ++;
	 }
      }

      len = strlen("property float nz");
      if (!strncmp(line, "property float nz", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    normalOrder[2] = i;
	    i ++;
	 }
      }

      len = strlen("property float s");
      if (!strncmp(line, "property float s", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    strOrder[0] = i;
	    i ++;
	 }
      }

      len = strlen("property float t");
      if (!strncmp(line, "property float t", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    strOrder[1] = i;
	    i ++;
	 }
      }

      len = strlen("property float r");
      if (!strncmp(line, "property float r", len))
      {
	 if (i < 0)
	    std::cerr << "Warning: Defining properties without element\n";
	 else
	 {
	    strOrder[2] = i;
	    i ++;
	 }
      }


//      readingHeader = false; // DEBUG
   }

   std::cerr << "Number of vertices: " << this->nvert << "\n";
   std::cerr << "Number of faces: " << this->nfac << "\n";

   if (this->vertex != 0)
      delete [] this->vertex;
   this->vertex = new float[3 * this->nvert];
   memset(this->vertex, 0, 3 * this->nvert * sizeof(float));

   if (this->normal != 0)
      delete [] this->normal;
   this->normal = new float[3 * this->nvert];
   memset(this->normal, 0, 3 * this->nvert * sizeof(float));

   if (this->texel != 0)
      delete [] this->texel;
   this->texel = new float[3 * this->nvert];
   memset(this->texel, 0, 3 * this->nvert * sizeof(float));


   for (i = 0; i < this->nvert; i ++)
   {
      line[0] = '\0';
      file.getline (line, 2048);

//      std::cerr << "\'" << line << "\'\n"; // DEBUG

      memset(value, 0, 2048 * sizeof(float));
      pch = strtok(line, " \t");
      if (pch != 0)
      {
	 j = 0;
	 value[j] = atof(pch);
	 j ++;
//	 std::cerr << "[" << 0 << "] - \'" << pch << "\'\n"; // DEBUG
	 while (pch != 0)
	 {
	    pch = strtok(0, " \t");
	    if (pch != 0)
	    {
//	       std::cerr << "[" << j << "] - \'" << pch << "\'\n"; // DEBUG
	       value[j] = atof(pch);
	       j ++;
	    }
	 }
      }

      x = value[xyzOrder[0]];
      y = value[xyzOrder[1]];
      z = value[xyzOrder[2]];
      nx = value[normalOrder[0]];
      ny = value[normalOrder[1]];
      nz = value[normalOrder[2]];
      s = value[strOrder[0]];
      t = value[strOrder[1]];
      r = value[strOrder[2]];

/*
      std::cerr << "  * (x, y, z)[" << i << "] = " 
		<< x << ", " << y << ", " << z << "\n";
      std::cerr << "  * (nx, ny, nz)[" << i << "] = " 
		<< nx << ", " << ny << ", " << nz << "\n";
      std::cerr << "  * (s, t, r)["
		<< s << ", " << t << ", " << r << "\n";
*/
      this->vertex[i * 3 + 0] = x;
      this->vertex[i * 3 + 1] = y;
      this->vertex[i * 3 + 2] = z;


      // Bounding:
      if (i == 0)
      {
	 minx = x;
	 miny = y;
	 minz = z;

	 maxx = x;
	 maxy = y;
	 maxz = z;
      }
      else
      {
	 if (x < minx)
	    minx = x;
	 if (y < miny)
	    miny = y;
	 if (z < minz)
	    minz = z;	 

	 if (x > maxx)
	    maxx = x;
	 if (y > maxy)
	    maxy = y;
	 if (z > maxz)
	    maxz = z;
      }

      this->normal[i * 3 + 0] = nx;
      this->normal[i * 3 + 1] = ny;
      this->normal[i * 3 + 2] = nz;

      this->texel[i * 3 + 0] = s;
      this->texel[i * 3 + 1] = t;
      this->texel[i * 3 + 2] = r;
   }

   // The bounding box:
   this->minBounding->X(minx);
   this->minBounding->Y(miny);
   this->minBounding->Z(minz);
   this->maxBounding->X(maxx);
   this->maxBounding->Y(maxy);
   this->maxBounding->Z(maxz);   

/*
   std::cerr << "Loaded - Bounding: MIN = " << this->minBounding->X() << ", "
	     << this->minBounding->Y() << ", " 
	     << this->minBounding->Z() << "\n";
   
   std::cerr << "Loaded - Bounding: MAX = " << this->maxBounding->X() << ", "
	     << this->maxBounding->Y() << ", " 
	     << this->maxBounding->Z() << "\n";
*/

   for (i = 0; i < this->nfac; i ++)
   {
      line[0] = '\0';
      file.getline (line, 2048);

//      std::cerr << "\'" << line << "\'\n"; // DEBUG

      memset(value, 0, 2048 * sizeof(float));
      pch = strtok(line, " \t");
      if (pch != 0)
      {
	 j = 0;
	 value[j] = atof(pch);
	 j ++;
//	 std::cerr << "[" << 0 << "] - \'" << pch << "\'\n"; // DEBUG
	 while (pch != 0)
	 {
	    pch = strtok(0, " \t");
	    if (pch != 0)
	    {
//	       std::cerr << "[" << j << "] - \'" << pch << "\'\n"; // DEBUG
	       value[j] = atof(pch);
	       j ++;
	    }
	 }
      }

      if (j < 4)
      {
	 if (j >= 1)
	    tmpface.push_back(value[1]);
	 if (j >= 2)
	    tmpface.push_back(value[2]);
	 if (j >= 3)
	    tmpface.push_back(value[3]);
	 std::cerr << "Warning: This file seems corrupted.\n";
      }
      else
/*
	 if (j <= 5)
	 {
	    tmpface.push_back(value[3]);
	    tmpface.push_back(value[2]);
	    tmpface.push_back(value[1]);
	 
	    if (j == 5)
	    {
	       tmpface.push_back(value[4]);
	       tmpface.push_back(value[3]);
	       tmpface.push_back(value[1]);
	    }
	 }
	 else
*/
	 {
	    tmpface.push_back(value[3]);
	    tmpface.push_back(value[2]);
	    tmpface.push_back(value[1]);
	 
	    for (k = 4; k < j; k ++)
	    {
	       tmpface.push_back(value[k]);
	       tmpface.push_back(value[k - 1]);
	       tmpface.push_back(value[k - 3]);
	    }
	 }

   }

   this->nfac = tmpface.size() / 3;
   std::cerr << "Number of triangles: " << this->nfac << "\n";

   if (this->face != 0)
      delete [] this->face;
   this->face = new long int[3 * this->nfac * sizeof(float)];

   for (i = 0; i < tmpface.size(); i ++)
      this->face[i] = tmpface[i];

   file.close();
   return verror;
}

// --------------------------------------------------
float *S3DMesh::getVertices (void)
{
   return this->vertex;
}

// --------------------------------------------------
long int *S3DMesh::getFaces (void)
{
   return this->face;
}


// --------------------------------------------------
float *S3DMesh::getNormals (void)
{
   return this->normal;
}


// --------------------------------------------------
float *S3DMesh::getBinormals (void)
{
   return this->binormal;
}


// --------------------------------------------------
float *S3DMesh::getTangents (void)
{
   return this->tangent;
}


// --------------------------------------------------
float *S3DMesh::getTexels (void)
{
   return this->texel;
}


// --------------------------------------------------
void S3DMesh::computeBinormals(void)
{
   long int i, j;
   S3DVector *v0, *v1, *t0, *t1, *tg, *bn;

   if (this->tangent != 0)
      delete [] this->tangent;
   this->tangent = new float[3 * this->nvert];
   memset(this->tangent, 0, 3 * this->nvert * sizeof(float));

   if (this->binormal != 0)
      delete [] this->binormal;
   this->binormal = new float[3 * this->nvert];
   memset(this->binormal, 0, 3 * this->nvert * sizeof(float));

   // Compute tangents and binormals
   for (i = 0; i < this->nvert; i ++)
   {
      v0 = new S3DVector (this->vertex[i * 3], 
			  this->vertex[i * 3 + 1],
			  this->vertex[i * 3 + 2]);
      t0 = new S3DVector (this->texel[i * 3], 
			  this->texel[i * 3 + 1],
			  this->texel[i * 3 + 2]);
      v1 = 0;
      t1 = 0;
      for (j = 0; (j < this->nfac) && (v1 == 0) && (t1 == 0); j ++)
	 if (this->face[j * 3] == i)
	 {
	    j = this->face[j * 3] + 1;
	    v1 = new S3DVector (this->vertex[j * 3], 
				this->vertex[j * 3 + 1],
				this->vertex[j * 3 + 2]);
	    t1 = new S3DVector (this->texel[j * 3], 
				this->texel[j * 3 + 1],
				this->texel[j * 3 + 2]);
	 }
	 else
	    if  (this->face[j * 3 + 1] == i)
	    {
	       j = this->face[j * 3 + 0];
	       v1 = new S3DVector (this->vertex[j * 3], 
				   this->vertex[j * 3 + 1],
				   this->vertex[j * 3 + 2]);
	       t1 = new S3DVector (this->texel[j * 3], 
				   this->texel[j * 3 + 1],
				   this->texel[j * 3 + 2]);
	    }
	    else
	       if  (this->face[j * 3 + 2] == i)
	       {
		  j = this->face[j * 3 + 1];
		  v1 = new S3DVector (this->vertex[j * 3], 
				      this->vertex[j * 3 + 1],
				      this->vertex[j * 3 + 2]);
		  t1 = new S3DVector (this->texel[j * 3], 
				      this->texel[j * 3 + 1],
				      this->texel[j * 3 + 2]);
	       }

//      std::cerr << "V0 = " << v0->X() << ", " << v0->Y()
//		<< ", " << v0->Z() << "\n";

//      std::cerr << "V1 = " << v1->X() << ", " << v1->Y()
//		<< ", " << v1->Z() << "\n";


      tg = v0->tangent(v0, v1, t0, t1);
      bn = v0->binormal(v0, v1, t0, t1);

      this->tangent[i * 3 + 0] = tg->X();
      this->tangent[i * 3 + 1] = tg->Y();
      this->tangent[i * 3 + 2] = tg->Z();


//      std::cerr << "TANGENT = " << tg->X() << ", " << tg->Y()
//		<< ", " << tg->Z() << "\n";

      this->binormal[i * 3 + 0] = bn->X();
      this->binormal[i * 3 + 1] = bn->Y();
      this->binormal[i * 3 + 2] = bn->Z();

//      std::cerr << "BINORMAL = " << bn->X() << ", " << bn->Y()
//		<< ", " << bn->Z() << "\n";

      delete v0;
      if (v1 != 0)
	 delete v1;
      delete t0;
      if (t1 != 0)
	 delete t1;
   }

}

// --------------------------------------------------
long int S3DMesh::getNFaces (void)
{
   return this->nfac;
}

// --------------------------------------------------
long int S3DMesh::getNVertices (void)
{
   return this->nvert;
}

// --------------------------------------------------
unsigned char *S3DMesh::voxelize (int w, int h, int d, const char *file)
{
   S3DFBO *fbo;
   long int k;
   float d1;
   float top;
   float inc;
   unsigned char *data;
   S3DImage *slide;
   char name[2048];
   
   name[0] = '\0';

   if ( (w <= 0) || (h <= 0) || (d <= 0) )
      return 0;

   data = new unsigned char[w * h * d];
   if (data == 0)
   {
      std::cerr << "Warning: Not enough memory to voxelize the model\n";
      return 0;
   }
   
   fbo = new S3DFBO(w, h, GL_RGB, GL_RGB, GL_UNSIGNED_BYTE, GL_NEAREST, 
		    true, true);
   fbo->renderFBO();

   glMatrixMode(GL_PROJECTION);
   glPushMatrix();

   glMatrixMode(GL_MODELVIEW);
   glPushMatrix();


   // TODO
   d1 = (float) d - 1;
   if (d1 < 1)
      d1 = 1;

   inc = fabs(this->maxBounding->Z() - this->minBounding->Z()) / (float) d1;
   top = -this->maxBounding->Z();
   for (k = 0; k < d; k ++)
   {
      glViewport(0, 0, w, h);
      glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
      glOrtho(this->minBounding->X(), this->maxBounding->X(),
	      this->minBounding->Y(), this->maxBounding->Y(),
//	      top + (this->minBounding->Z() - this->maxBounding->Z()),
	      top, 
//	      this->maxBounding->Z());
	      this->maxBounding->Z() + 100000);

//      glOrtho(-50, 50, -50, 50, -1, 1);
//      top = inc * ((float) k / (float) d1);
/*
      std::cerr << "TOP =  " << top << "\n";
      std::cerr << "Bounding: MIN = " << this->minBounding->X() << ", "
		<< this->minBounding->Y() << ", " 
		<< this->minBounding->Z() << "\n";

      std::cerr << "Bounding: MAX = " << this->maxBounding->X() << ", "
		<< this->maxBounding->Y() << ", " 
		<< this->maxBounding->Z() << "\n";
*/
      top += inc;

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      glEnable(GL_STENCIL_TEST);

      glStencilMask(0xFFFFFFFF);
      glClearStencil(0);

      glClearColor(0, 0, 0, 0);
      glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
      glClear(GL_COLOR_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);


      glDisable(GL_LIGHTING);
      glDisable(GL_LIGHT0);
      glDisable(GL_TEXTURE_1D);
      glDisable(GL_TEXTURE_2D);
      glDisable(GL_TEXTURE_3D);

      glColor3f(1, 1, 1);

      glEnable(GL_CULL_FACE);

      // Draw back increasing 1
      glStencilFunc(GL_ALWAYS, 1, 1);
      glStencilOp(GL_INCR, GL_INCR, GL_INCR);
      glCullFace(GL_BACK);
      this->draw(true);

      // Draw front subtracting 1
      glStencilFunc(GL_ALWAYS, 1, 1);
      glStencilOp(GL_DECR, GL_DECR, GL_DECR);
      glCullFace(GL_FRONT);
      this->draw(true);

      // Draw disabling cull-facing
//      glCullFace(GL_BACK);
      glDisable(GL_CULL_FACE);
      glStencilFunc(GL_NOTEQUAL, 0, 0xFF);
      glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

      glClear(GL_COLOR_BUFFER_BIT);
      this->draw(true);

      glDisable(GL_STENCIL_TEST);

      glReadPixels(0, 0, w, h, GL_LUMINANCE, GL_UNSIGNED_BYTE, 
		   data + w * h * k);

      if (file != 0)
      {
	 slide = new S3DImage(w, h, 1, data + w * h * k);
	 slide->convert(3);
	 name[0] = '\0';
	 sprintf(name, "%s%4u.bmp", file, (unsigned int) k);
	 slide->save(name);
	 delete slide;
      }
   }

   glMatrixMode(GL_MODELVIEW);
   glPopMatrix();

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();

   glMatrixMode(GL_MODELVIEW);
   fbo->renderFramebuffer();
   delete fbo;

   return data;
}

// --------------------------------------------------
S3DMesh::~S3DMesh (void)
{
   if (this->vertex != 0)
      delete [] this->vertex;

   if (this->normal != 0)
      delete [] this->normal;
   
   if (this->face != 0)
      delete [] this->face;

   if (this->texel != 0)
      delete [] this->texel;

   if (this->texID != 0)
      delete [] this->texID;
}


// --------------------------------------------------
void S3DMesh::print (void)
{
   std::cout << "Object name: " << this->name << "\n";
   std::cout << " Position: " 
	     << this->px << ", "
	     << this->py << ", "	
	     << this->pz << "\n";
   std::cout << " Euler Angles (DEGREES): " 
	     << this->ax << ", "
	     << this->ay << ", "	
	     << this->az << "\n";
   std::cout << " Scale: " 
	     << this->sx << ", "
	     << this->sy << ", "	
	     << this->sz << "\n";
   std::cout << " Number of vertices: " << this->nvert << "\n";
   std::cout << " Number of faces: " << this->nfac << "\n";
}

