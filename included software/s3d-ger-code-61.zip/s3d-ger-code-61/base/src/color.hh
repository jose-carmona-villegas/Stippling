#ifndef __COLOR__
#define __COLOR__

#include <stdlib.h>
#include <iostream>


#ifndef byte
#define byte unsigned char
#endif


/** @class   S3DColor color.hh
 *  @author  Germán Arroyo
 *  @date    2007
 *  @brief   This class represents a color. It has got a few methods to 
 *           change the space of the color.
 *           This class uses a cache system which compute the space 
 *           color when it is asked or defined, then the returned color is 
 *           the color of the cache, not a real color. \\
             @see <a href="../table_of_colors.txt">Table of colors</a>

 *
 *  @bug     No bugs detected yet
 *  @warning The class does not test if the arrays are 0 or not
             The class does not test if the length of the vector 
             are correct or not, so it may return stranges values or even 
	     break your program
 */

class S3DColor {
   public:

      /** 
       * @post Constructor, make a black color
       */
      S3DColor ();

      /** 
       * @pre R, G, and B must be values between 0.0 and 1.0
       * @param[in] R The red component
       * @param[in] G The green component
       * @param[in] B The blue component
       * @post Constructor, make a RGB color
       */
      S3DColor (float R, float G, float B);
      
      /** 
       * @pre R, G, B, and A must be values between 0.0 and 1.0
       * @param[in] R The red component
       * @param[in] G The green component
       * @param[in] B The blue component
       * @param[in] A The alpha component
       * @post Constructor, make a RGBA color
       */
      S3DColor (float R, float G, float B, float A); 
      
      /** 
       * @post Destructor, free the memory
       */
      ~S3DColor ();
      
      /** 
       * @post Compute the HSV components from RGB components and update the
       *       cache of the HSV elements
       */
      void RGBtoHSV (void);
      
      /** 
       * @post Compute the RGB components from HSV components and update the
       *       cache of the RGB elements
       */
      void HSVtoRGB (void);
      
      /** 
       * @pre r must be a value between 0.0 and 1.0
       * @param[in] r The red component
       * @post Set the red component and update the cache of the RGB elements
       */
      void R(float r);
      
      /** 
       * @pre g must be a value between 0.0 and 1.0
       * @param[in] g The green component
       * @post Set the green component and update the cache of the RGB elements
       */
      void G(float g);
      
      /** 
       * @pre b must be a value between 0.0 and 1.0
       * @param[in] b The red component
       * @post Set the blue component and update the cache of the RGB elements
       */
      void B(float b);
      
      /** 
       * @pre a must be a value between 0.0 and 1.0
       * @param[in] a The alpha component
       * @post Set the alpha component
       */
      void A (float a);
      
      /** 
       * @post The red component
       */
      float R (void);
      
      /** 
       * @post The green component
       */
      float G (void);
      
      /** 
       * @post The blue component
       */
      float B (void);
      
      /** 
       * @post The alpha component
       */
      float A (void);
      
      /** 
       * @pre h must be a value between 0.0 and 360.0
       * @param[in] h The hue component
       * @post Set the hue component and update the cache of the HSV elements
       */
      void H (float h);
      
      /** 
       * @pre s must be a value between 0.0 and 1.0
       * @param[in] s The saturation component
       * @post Set the saturation component and update the cache 
       *       of the HSV elements
       */
      void S (float s);
      
      /** 
       * @pre v must be a value between 0.0 and 1.0
       * @param[in] v The value (brightness) component
       * @post Set the value component and update the cache 
       *       of the HSV elements
       */
      void V (float v);
      
      /** 
       * @post The hue
       */
      float H (void);
      
      /** 
       * @post The saturation
       */
      float S (void);
      
      /** 
       * @post The value (brightness)
       */
      float V (void);
      
      /** 
       * @pre h must be a value between 0.0 and 360.0
       *      v and s must be a value between 0.0 and 1.0
       * @param[in] h The hue
       * @param[in] s The saturation
       * @param[in] v The value (brightness) component
       * @post Change the cache of HSV values
       */
      void setHSV (float h, float s, float v);
      
      /** 
       * @pre h must be a value between 0.0 and 360.0
       *      a, v and s must be a value between 0.0 and 1.0
       * @param[in] h The hue
       * @param[in] s The saturation
       * @param[in] v The value (brightness) component
       * @param[in] a The alpha value
       * @post Change the cache of HSV values and set the alpha value
       */
      void setHSV (float h, float s, float v, float a);
      
      /** 
       * @pre r, g, and b must be a value between 0.0 and 1.0
       * @param[in] r The red component
       * @param[in] g The green component
       * @param[in] b The blue component
       * @post Change the cache of RGB values
       */
      void setRGB (float r, float g, float b);
      
      /** 
       * @pre a, r, g, and b must be a value between 0.0 and 1.0
       * @param[in] r The red component
       * @param[in] g The green component
       * @param[in] b The blue component
       * @param[in] a The alpha value
       * @post Change the cache of RGB values and set the alpha value
       */
      void setRGB (float r, float g, float b, float a);

      /** 
       * @post Make a copy of this color, you can safely free the copy
       */
      S3DColor *copy (void);
      

      /**
       * @post  Print this color to cerr (DEBUG)
       */
      void print (void);

      /**
       * @param[in] str String to display, if 0 no text displayed
       * @post  Print this color to cerr (DEBUG)
       */
      void print (const char *str);

   private:
      float red, green, blue;
      float hue, saturation, value;
      bool rgb;
      bool hsv;
      float alpha;
};

#endif

