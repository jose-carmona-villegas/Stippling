#ifndef __MATHEMATIC__
#define __MATHEMATIC__

#include <iostream>
#include <iomanip>
#include <math.h>
#include <cstring>

/** @class   S3DMath mathematic.hh
 *  @author  Germán Arroyo
 *  @date    2010
 *  @brief   This class is a compendium of mathematical functions and operators
 *
 *  @bug     No bugs detected yet
 *  @warning 
 */

class S3DMath {
   public:

      /// PI
      static const double PI       = 3.1415926535897932385;
      static const double E        = 2.7182818284590452354;

      /** 
       * @post Constructor
       */
      S3DMath(void);

      /**
       * @param[in] x The x position
       * @param[in] sigma The Standard deviation
       * @post Compute the 1D gaussian function in (x)
       */
      static double Gauss (double x, double sigma);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] sigma The Standard deviation
       * @post Compute the 2D gaussian function in (x, y)
       */
      static double Gauss (double x, double y, double sigma);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @post Compute the 2D first partial derivative gaussian
       *       function in (x, y)
       */
      static double IxGauss (double x, double y, double sigma);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] sigma The Standard deviation
       * @post Compute the 2D first partial derivative gaussian
       *       function in (x, y)
       */
      static double IyGauss (double x, double y, double sigma);


      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] sigma The Standard deviation
       * @post Compute the 2D second partial derivative gaussian
       *       function in (x, y)
       */
      static double IxxGauss (double x, double y, double sigma);


      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] sigma The Standard deviation
       * @post Compute the 2D second partial derivative gaussian
       *       function in (x, y)
       */
      static double IxyGauss (double x, double y, double sigma);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @post Compute the 2D second partial derivative gaussian
       *       function in (x, y)
       */
      static double IyxGauss (double x, double y, double sigma);


      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @post Compute the 2D second partial derivative gaussian
       *       function in (x, y)
       */
      static double IyyGauss (double x, double y, double sigma);


      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] sigma The Standard deviation
       * @post Compute the Laplacian function in (x, y), 
       *       it is equal to Ixx + Iyy
       */
      static double LoGauss (double x, double y, double sigma);



   private:

};

#endif

