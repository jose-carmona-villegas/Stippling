#include "primitive3d.hh"


// --------------------------------------------------
void S3DPrimitive3D::drawBox(GLenum way, 
			     GLfloat x, GLfloat y, GLfloat z, 
			     GLfloat w, GLfloat h, GLfloat d)
{
   GLfloat x1, y1, z1;
   
   x1 = x + w;
   y1 = y + h;
   z1 = z + d;

   // Front face
   glBegin(way);
   glVertex3f (x,  y,  z1);
   glVertex3f (x1, y,  z1);
   glVertex3f (x1, y1, z1);
   glVertex3f (x,  y1, z1);
   glVertex3f (x,  y,  z1);
   glEnd();

   // Back face
   glBegin(way);
   glVertex3f (x,   y,  z);
   glVertex3f (x,   y1, z);
   glVertex3f (x1,  y1, z);
   glVertex3f (x1,  y,  z);
   glVertex3f (x,   y,  z);
   glEnd();

   // Left face
   glBegin(way);
   glVertex3f (x,  y,  z);
   glVertex3f (x,  y,  z1);
   glVertex3f (x,  y1, z1);
   glVertex3f (x,  y1, z);
   glVertex3f (x,  y,  z);
   glEnd();

   // Right face
   glBegin(way);
   glVertex3f (x1,  y,  z);
   glVertex3f (x1,  y1, z);
   glVertex3f (x1,  y1, z1);
   glVertex3f (x1,  y,  z1);
   glVertex3f (x1,  y,  z);
   glEnd();

   // Bottom face
   glBegin(way);
   glVertex3f (x,  y, z);
   glVertex3f (x1, y, z);
   glVertex3f (x1, y, z1);
   glVertex3f (x,  y, z1);
   glVertex3f (x,  y, z);
   glEnd();

   // Top face
   glBegin(way);
   glVertex3f (x,  y1, z);
   glVertex3f (x,  y1, z1);
   glVertex3f (x1, y1, z1);
   glVertex3f (x1, y1, z);
   glVertex3f (x,  y1, z);
   glEnd();
}


// --------------------------------------------------
GLuint S3DPrimitive3D::setTexture2D(GLenum unit, GLenum interp, 
				    GLenum way, GLenum mode, 
				    void *buffer, unsigned int bpp, 
				    unsigned int w, unsigned int h)
{
   GLuint n;
   GLuint idtex = 0;
   

   // GL_TEXTURE0, GL_TEXTURE1, GL_TEXTURE2, etc.
   glActiveTexture(unit); // Multitexture  
   
  
   glEnable(GL_TEXTURE_2D);
   glGenTextures(1, &idtex);
   
   glBindTexture(GL_TEXTURE_2D, idtex);
   
   switch (bpp) 
   {
      case 1: {
	 n = GL_LUMINANCE;
      } break;
	 
      case 2: {
	 n = GL_LUMINANCE_ALPHA;
      } break;
	 
      case 3: {
	 n = GL_RGB;
      } break;
	 
      case 4: {
	 n = GL_RGBA;
      } break;
   };
   
   // GL_LINEAR, GL_NEAREST
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, interp);
   glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, interp);

   // GL_CLAMP, GL_REPEAT, etc.
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, way);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, way);
   
   // GL_DECAL, GL_MODULATE
   glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, mode);
  

   glTexImage2D(GL_TEXTURE_2D, 0, n, w, h,
		0, n, GL_UNSIGNED_BYTE, buffer);

   return idtex;
}


// --------------------------------------------------
GLuint S3DPrimitive3D::setTexture2D(GLenum unit, GLenum interp, GLenum way,
				    GLenum mode, S3DImage *img)
{
   GLuint id;
   
   if (img == 0)
      return 0;

   id = img->setTexture2D(unit, interp, way, mode);

   return id;
}


// --------------------------------------------------
void S3DPrimitive3D::drawPlane(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			       GLfloat w, GLfloat h)
{
   GLfloat x1, y1, z1;
   
   x1 = x + w;
   y1 = y + h;

   // Front face
   glBegin(way);
   glTexCoord2f (0.0, 1.0);
   glVertex3f (x,  y,  z);
   glTexCoord2f (1.0, 1.0);
   glVertex3f (x1, y,  z);
   glTexCoord2f (1.0, 0.0);
   glVertex3f (x1, y1, z);
   glTexCoord2f (0.0, 0.0);
   glVertex3f (x,  y1, z);
   glTexCoord2f (0.0, 1.0);
   glVertex3f (x,  y,  z);

   glEnd();
}


// --------------------------------------------------
void S3DPrimitive3D::drawPlane(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
			       GLfloat w, GLfloat h, bool inverted)
{
   GLfloat x1, y1, z1;

   if (inverted == true) 
      drawPlane(way, x, y, z, w, h);
   else
   {
   
      x1 = x + w;
      y1 = y + h;

      // Front face
      glBegin(way);
      glTexCoord2f (0.0, 0.0);
      glVertex3f (x,  y,  z);
      glTexCoord2f (1.0, 0.0);
      glVertex3f (x1, y,  z);
      glTexCoord2f (1.0, 1.0);
      glVertex3f (x1, y1, z);
      glTexCoord2f (0.0, 1.0);
      glVertex3f (x,  y1, z);
      glTexCoord2f (0.0, 0.0);
      glVertex3f (x,  y,  z);
      
      glEnd();
   }
}

// --------------------------------------------------
void S3DPrimitive3D::drawConnector(GLfloat x0, GLfloat y0, GLfloat z0, 
				   GLfloat x1, GLfloat y1, GLfloat z1, 
				   GLfloat w, bool startarrow, bool endarrow)
{
   GLfloat t = w;
   GLfloat t2 = t * 0.5;
   GLfloat alpha, x, y;

   glBegin(GL_LINE_STRIP);
   {
      glVertex3f (x0, y0, z0);
      glVertex3f (x1, y1, z1);
   }
   glEnd();

   if (!startarrow)
   {
      glBegin(GL_QUADS);
      {
	 glVertex3f (x0 - t2, y0 - t2, z0);
	 glVertex3f (x0 + t2, y0 - t2, z0);
	 glVertex3f (x0 + t2, y0 + t2, z0);
	 glVertex3f (x0 - t2, y0 + t2, z0);
      }
      glEnd();
   }
   else
   {
      glBegin(GL_TRIANGLES);
      {
	 alpha = atan2(y0 - y1, x0 - x1) - 90;
	 x = x0 + cos(alpha) * t * 2.0;
	 y = y0 + sin(alpha) * t * 2.0;
	 glVertex3f (x, y, z0);

	 alpha = atan2(y0 - y1, x0 - x1) + 90;
	 x = x0 + cos(alpha) * t * 2.0;
	 y = y0 + sin(alpha) * t * 2.0;
	 glVertex3f (x, y, z0);

	 glVertex3f (x0, y0, z0);
      }
      glEnd();
   }

   if (!endarrow)
   {
      glBegin(GL_QUADS);
      {
	 glVertex3f (x1 - t2, y1 - t2, z0);
	 glVertex3f (x1 + t2, y1 - t2, z0);
	 glVertex3f (x1 + t2, y1 + t2, z0);
	 glVertex3f (x1 - t2, y1 + t2, z0);
      }
      glEnd();
   }
   else
   {
      glBegin(GL_TRIANGLES);
      {
	 alpha = atan2(y1 - y0, x1 - x0) - 90;
	 x = x1 + cos(alpha) * t * 2.0;
	 y = y1 + sin(alpha) * t * 2.0;
	 glVertex3f (x, y, z1);

	 alpha = atan2(y1 - y0, x1 - x0) + 90;
	 x = x1 + cos(alpha) * t * 2.0;
	 y = y1 + sin(alpha) * t * 2.0;
	 glVertex3f (x, y, z1);

	 glVertex3f (x1, y1, z1);
      }
      glEnd();
   }
}


// --------------------------------------------------
void S3DPrimitive3D::drawCircle(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
				GLfloat r, unsigned int angle)
{
   GLfloat xf, yf;
   int t;

   if (r <= 0)
      return;

   while (angle >= 360)
      angle -= 360;
   while (angle < 0)
      angle += 360;

   if (angle == 0)
      return;


   // Right face
   glBegin(way);
   {
      if (way == GL_TRIANGLE_FAN)
      {
	 glVertex3f (x,  y,  z);
      }
      
      for (t = 0; t <= angle; t ++)
      {
	 xf = r * cos(t * M_PI / 180.0);
	 yf = r * sin(t * M_PI / 180.0);
	 glVertex3f (x + xf,  y + yf,  z);
      }
   }
   glEnd();
}


// --------------------------------------------------
void S3DPrimitive3D::drawCircle(GLenum way, GLfloat x, GLfloat y, GLfloat z, 
				GLfloat r)
{
   GLfloat xf, yf;
   int t;

   if (r <= 0)
      return;

   // Right face
   glBegin(way);
   {
      if (way == GL_TRIANGLE_FAN)
      {
	 glVertex3f (x,  y,  z);
      }
      
      for (t = 0; t <= 360; t ++)
      {
	 xf = r * cos(t * DEGREES_TO_RADIANS);
	 yf = r * sin(t * DEGREES_TO_RADIANS);
	 glVertex3f (x + xf,  y + yf,  z);
      }
   }
   glEnd();
}


// --------------------------------------------------
void S3DPrimitive3D::drawSuperellipse (GLenum way, 
				       GLfloat x, GLfloat y, GLfloat z, 
				       GLfloat a, GLfloat b, GLfloat r)
{
   long int t;
   float xf, yf;
   float rad = 2.0 / r;


   glBegin(way);
   {
      if (way == GL_TRIANGLE_FAN)
      {    
         glVertex3f (x,  y,  z);
      }

      // CCW
      for (t = 89; t >= 0; t --)
      {
         xf = a * pow(cos((float) t * DEGREES_TO_RADIANS), rad);
         yf = b * pow(sin((float) t * DEGREES_TO_RADIANS), rad);
         glVertex3f (x + xf,  y + yf,  z);
      }

      for (t = 0; t <= 90; t ++)
      {
         xf = a * pow(cos((float) t * DEGREES_TO_RADIANS), rad);
         yf = -b * pow(sin((float) t * DEGREES_TO_RADIANS), rad);
         glVertex3f (x + xf,  y + yf,  z);
      }


      for (t = 90; t >= 0; t --)
      {
         xf = -a * pow(cos((float) t * DEGREES_TO_RADIANS), rad);
         yf = -b * pow(sin((float) t * DEGREES_TO_RADIANS), rad);
         glVertex3f (x + xf,  y + yf,  z);
      }

      for (t = 0; t <= 89; t ++)
      {
         xf = -a * pow(cos((float) t * DEGREES_TO_RADIANS), rad);
         yf = b * pow(sin((float) t * DEGREES_TO_RADIANS), rad);
         glVertex3f (x + xf,  y + yf,  z);
      }

      t = 89;
      xf = a * pow(cos((float) t * DEGREES_TO_RADIANS), rad);
      yf = b * pow(sin((float) t * DEGREES_TO_RADIANS), rad);
      glVertex3f (x + xf,  y + yf,  z);

   }
   glEnd();

   return;
}



// --------------------------------------------------

void S3DPrimitive3D::drawAxis(GLfloat x, GLfloat y, GLfloat z, GLfloat length)
{
   GLfloat x1, y1, z1;
   GLfloat fsize;

   fsize = length * 0.25;
   
   x1 = x + length;
   y1 = y + length;
   z1 = z + length;


   // X-axis
   glColor4f (0.6, 0.0, 0.0, 0.4);
   glBegin(GL_LINES);
   glVertex3f (x,  y,  z);
   glVertex3f (x1, y,  z);
   glEnd();


   // X name
   glBegin(GL_LINE_STRIP);
   glVertex3f (x1 + fsize,  y,  z);
   glVertex3f (x1 + fsize * 2.0, y + fsize,  z);
   glEnd();
   glBegin(GL_LINE_STRIP);
   glVertex3f (x1 + fsize * 2.0,  y,  z);
   glVertex3f (x1 + fsize, y + fsize,  z);
   glEnd();


   // Y-axis
   glColor4f (0.0, 0.6, 0.0, 0.4);
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y,  z);
   glVertex3f (x,  y1,  z);
   glEnd();

   // Y name
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y1 + fsize,  z);
   glVertex3f (x + fsize * 0.5, y1 + fsize * 2,  z);
   glEnd();
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y1 + fsize * 2,  z);
   glVertex3f (x + fsize * 0.25, y1 + fsize * 1.5,  z);
   glEnd();

   // Z-axis
   glColor4f (0.0, 0.0, 0.6, 0.4);
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y,  z);
   glVertex3f (x,  y,  z1);
   glEnd();

   // Z name
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y,  z1 + fsize);
   glVertex3f (x + fsize,  y, z1 + fsize);
   glEnd();
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y + fsize,  z1 + fsize);
   glVertex3f (x + fsize,  y + fsize, z1 + fsize);
   glEnd();
   glBegin(GL_LINE_STRIP);
   glVertex3f (x,  y,  z1 + fsize);
   glVertex3f (x + fsize, y + fsize,  z1 + fsize);
   glEnd();
}


// --------------------------------------------------

