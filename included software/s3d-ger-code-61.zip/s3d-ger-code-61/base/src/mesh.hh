#ifndef __MESH__
#define __MESH__

#include <iostream>
#include <fstream>
#include <string>
#include <math.h>
#include <string.h>
#include <vector>
#include <SDL/SDL_image.h>
#include <GL/glew.h>
#include "matrix.hh"
#include "vector.hh"
#include "framebuffer.hh"
#include "image.hh"


/** @class   S3DMesh mesh.hh
 *  @author  Germ�n Arroyo
 *  @date    2009
 *  @brief   This class is an mesh manager. It manage vertices, edges and faces
 *           and it can load mesh files.
 *
 *  @bug     No bugs detected yet, some things to do only
 *  @warning 
 */

class S3DMesh {
   public:

      /** 
      * @post Constructor. Inizialite the mesh image.
      */
      S3DMesh(void);

      /** 
       * @pre mesh must be a valid Mesh
       * @post Constructor copy.
       * @param[in] mesh The mesh
      */
      S3DMesh(S3DMesh *mesh);

      /**
       * @pre filename must be a valid name of a file
       * @post Returns some number distinct to 0 if it loads the model,
       *       it try to use the protected methods to do it
       *       returns 0 in other case
       * @param[in] filename the name of the file
       */
      int load (const char *filename);

      /**
       * @post Draw the bounding box
       */
      void drawBoundingBox(void);

      /**
       * @param[in] name A valid name for the mesh or 0
       * @post Set the name of the camera
       */
      void setName (const char *name);

      /**
       * @post The name of the mesh
       */
      char *getName (void);

      /**
       * @param[in] x The x coordinate of the pivot
       * @param[in] y The y coordinate of the pivot
       * @param[in] z The z coordinate of the pivot
       * @post Change the pivot of the model
       */
      void setPivot (float x, float y, float z);

      /**
       * @post Apply the transformation given by the pivot to the vertices 
       *       of the mesh. The new pivot will be the position (0, 0, 0).
       * @warning This method is very slow because uses the CPU. It changes
       *          the position of the vertices in the model.
       */
      void applyPivot (void);

      /**
       * @post Compute the bounding box from the present vertices if any
       */
      void computeBoundingBox (void);

      /**
       * @post The vertices of the model with the format: X0 Y0 Z0 X1 Y1 Z1 ...
       */
      float *getVertices(void);

      /**
       * @post The faces of the model with the format: V0_0 V1_0 V2_0 ...
       */
      long int *getFaces(void);

      /**
       * @post The texels of the model with the format: S0 T0 R0 S1 T1 R1 ...
       */
      float *getTexels(void);

      /**
       * @post The normals of the model with the format: 
       *       Xn0 Yn0 Zn0 Xn1 Yn1 Zn1 ...
       */
      float *getNormals(void);

      /**
       * @post The binormals of the model with the format: 
       *       BXn0 BYn0 BZn0 BXn1 BYn1 BZn1 ...
       */
      float *getBinormals(void);

      /**
       * @post The tangents of the model with the format: 
       *       TXn0 TYn0 TZn0 TXn1 TYn1 TZn1 ...
       */
      float *getTangents(void);

      /**
       * @post The number of faces of the mesh
       */
      long int getNFaces(void);

      /**
       * @post The number of vertices of the mesh
       */
      long int getNVertices(void);

      /**
       * @param[in] w The width of the volume
       * @param[in] h The height of the volume
       * @param[in] d The depth of the volume
       * @param[in] file A valid filename without extension
       *            if file is 0, the slides will not be saved
       * @post If everything is OK, it returns the array of voxels, 
       *       in other case it returns 0
       */
      unsigned char *voxelize(int w, int h, int d, const char *file = 0);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Set the position of the mesh
       */
      void setPosition (float x, float y, float z);

      /**
       * @param[in] x The x angle
       * @param[in] y The y angle
       * @param[in] z The z angle
       * @param[in] dgr If it is true the angles are in degrees, in other case
       *                the angles are in radians
       * @post Set the euler angles of the mesh orientation
       */
      void setEulerAngles (float x, float y, float z, bool dgr=true);

      /**
       * @param[in] x The x position
       * @param[in] y The y position
       * @param[in] z The z position
       * @post Set the scale of the mesh
       */
      void setScale (float x, float y, float z);

      /**
       * @param[in] d The size of the normals, by default is 1.0
       * @post Draw the normals of the mesh
       */
      void drawNormals(float d = 1.0);

      /**
       * @param[in] d The size of the binormals, by default is 1.0
       * @post Draw the binormals of the mesh
       */
      void drawBinormals(float d = 1.0);

      /**
       * @param[in] vertexArray The array of vertices
       * @param[in] size The size of the vector
       * @post Overwrite the vector of vertices
       * @warning Do not free or change the vector, it is not a copy
       */
      void ovwVertices (float *vertexArray, long int size);

      /**
       * @param[in] faceArray The array of faces (V0, V1, V2)
       * @param[in] size The size of the vector
       * @post Overwrite the vector of faces
       * @warning Do not free or change the vector, it is not a copy
       */
      void ovwFaces (long int *faceArray, long int size);


      /**
       * @param[in] normalArray The array of normal (X, Y, Z)
       * @param[in] size The size of the vector
       * @post Overwrite the vector of normals
       * @warning Do not free or change the vector, it is not a copy
       */
      void ovwNormals (float *vertexArray, long int size);


      /**
       * @param[in] ignorepivot If the pivot is ignored or not
       * @post Place a mesh using pushmatrix
       * @warning After calling this method you should call glPopMatrix()
       *          for the modelview matrix
       */
      void placeMesh(bool ignorepivot=false);


      /**
       * @post Recompute the tangents and binormals of the mesh
       * @warning This method is very slow because uses the CPU
       */
      void computeBinormals(void);

      /**
       * @param[in] d The size of the tangent, by default is 1.0
       * @post Draw the tangents of the mesh
       */
      void drawTangents(float d = 1.0);

      /**
       * @param[in] ignorepivot If it is true, the pivot is ignored, and the 
       *                        model is not translated
       * @post Draw the model using the textures in order (max. 8 texture units)
       *       without using any shader, and without enable or disable texturing
       *       it does not change the smooth of flat mode either
       */
      virtual void draw(bool ignorepivot = false);

      /**
       * @post Destructor
       */
      ~S3DMesh(void);

      /**
       * @post Print the camera data
       */
      void print (void);

   protected:

      /**
       * @pre filename must be a valid name of a PLY file
       * @post Returns some number distinct to 0 if it loads the model,
       *       it try to use the protected methods to do it
       *       returns 0 in other case
       * @param[in] filename the name of the file
       */
      int loadPLY (const char *filename);

   private:
      long int nvert; // Number of vertices
      long int nfac; // Number of faces
      float *vertex; /// Array of vertices: X0 Y0 Z0 X1 Y1 Z1 ... Xn Yn Zn
      float *normal; /// Array of normals: Nx0 Ny0 Nz0 ... Nxn Nyn Nzn
      float *tangent; /// Array of tangents: Tx0 Ty0 Tz0 ... Txn Tyn Tzn
      float *binormal; /// Array of binormals: Bx0 By0 Bz0 ... Bxn Byn Bzn
      long int *face; /** Array of triangles: 
			  V0(0) V1(0) V2(0) ... V0(n) V1(n) V2(n)  **/
      float *texel; /// Array of texels: S0 T0 R0 S1 T1 R0 ... Sn Tn Rn
      int *texID; /// Array of textures: T0 T1 ... Tn
      S3DVector *minBounding, *maxBounding; /// The bounding box of the model
      S3DVector *pivot; /// The pivot of the model
      float px, py, pz; /// Position of the object
      float ax, ay, az; /// Angles of the object
      float sx, sy, sz; /// Scale of the object
      char *name; /// The name of the mesh
};


#endif

