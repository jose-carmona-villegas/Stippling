#include "vector.hh"


// --------------------------------------------------
S3DVector::S3DVector (unsigned int le)
{
   unsigned int i; 

   this->vect = new double[le];
   this->length = le;
}


// --------------------------------------------------
S3DVector::S3DVector (double x, double y)
{
   this->vect = new double[2];
   this->length = 2;

   this->vect[0] = x;
   this->vect[1] = y;
}


// --------------------------------------------------
S3DVector::S3DVector (double x, double y, double z)
{
   this->vect = new double[3];
   this->length = 3;

   this->vect[0] = x;
   this->vect[1] = y;
   this->vect[2] = z;
}


// --------------------------------------------------
S3DVector::S3DVector (double x, double y, double z, double w)
{
   this->vect = new double[4];
   this->length = 4;

   this->vect[0] = x;
   this->vect[1] = y;
   this->vect[2] = z;
   this->vect[3] = w;
}


// --------------------------------------------------
S3DVector::S3DVector (double *v, unsigned int i)
{
   unsigned int j;

   this->vect = new double[i];
   this->length = i;

   if (v != 0)
   {
      for (j = 0; j < i; j ++)
	 this->vect[j] = v[j];
   }
}


// --------------------------------------------------
S3DVector::~S3DVector ()
{
   if (this->vect != 0)
      delete [] this->vect;
}


// --------------------------------------------------
void S3DVector::X (double x)
{
   this->vect[0] = x;
}


// --------------------------------------------------
void S3DVector::Y (double y)
{
   this->vect[1] = y;
}


// --------------------------------------------------
void S3DVector::Z (double z)
{
   this->vect[2] = z;
}


// --------------------------------------------------
void S3DVector::W (double w)
{
   this->vect[3] = w;
}


// --------------------------------------------------
double S3DVector::X (void)
{
   return this->vect[0];
}


// --------------------------------------------------
double S3DVector::Y (void)
{
   return this->vect[1];
}


// --------------------------------------------------
double S3DVector::Z (void)
{
   return this->vect[2];
}


// --------------------------------------------------
double S3DVector::W (void)
{
   return this->vect[3];
}


#ifdef NOBLOCKED
// This method has been blocked because conflicts with other method
// --------------------------------------------------
void S3DVector::set (double x, double y)
{
   this->vect[0] = x;
   this->vect[1] = y;
}
#endif


// --------------------------------------------------
void S3DVector::set (double x, double y, double z)
{
   this->vect[0] = x;
   this->vect[1] = y;
   this->vect[2] = z;
}


// --------------------------------------------------
void S3DVector::set (double x, double y, double z, double w)
{
   this->vect[0] = x;
   this->vect[1] = y;
   this->vect[2] = z;
   this->vect[3] = w;
}


// --------------------------------------------------
void S3DVector::set (double *v)
{
   std::memcpy(this->vect, v, sizeof(double) * this->length);
   return;
}


// --------------------------------------------------
void S3DVector::set (unsigned int i, double v)
{
   this->vect[i] = v;
}


// --------------------------------------------------
double *S3DVector::get (void)
{
   return this->vect;
}


// --------------------------------------------------
double S3DVector::get (unsigned int i)
{
   return this->vect[i];
}


// --------------------------------------------------
double S3DVector::magnitude (void)
{
   unsigned int i;
   double p;

   p = 0;
   for (i = 0; i < this->length; i++)
      p += (this->vect[i] * this->vect[i]);

   return sqrt(p);
}


// --------------------------------------------------
double S3DVector::dot (S3DVector *v)
{
   unsigned int i;
   double p;

   p = 0;
   for (i = 0; i < this->length; i++)
      p += (this->vect[i] * v->get(i));

   return p;
}


// --------------------------------------------------
S3DVector *S3DVector::dot (double cte)
{
   unsigned int i;
   S3DVector *vn;

   vn = new S3DVector(this->length);

   for (i = 0; i < this->length; i++)
      vn->set(i, this->vect[i] * cte);

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::cross (S3DVector *v)
{
   unsigned int i;
   S3DVector *vn;

   vn = new S3DVector(3);

   vn->X(-this->Z() * v->Y() + this->Y() * v->Z());
   vn->Y(-this->X() * v->Z() + this->Z() * v->X());
   vn->Z(-this->Y() * v->X() + this->X() * v->Y());

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::plus (S3DVector *v)
{
   unsigned int i;
   S3DVector *vn;

   vn = new S3DVector(this->length);

   for (i = 0; i < this->length; i++)
      vn->set(i, this->vect[i] + v->get(i));

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::minus (S3DVector *v)
{
   unsigned int i;
   S3DVector *vn;

   vn = new S3DVector(this->length);

   for (i = 0; i < this->length; i++)
      vn->set(i, this->vect[i] - v->get(i));

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::normalize (void)
{
   unsigned int i;
   S3DVector *vn;
   double m;

   vn = new S3DVector(this->length);
   
   m = this->magnitude();
   
   if ( (m > -0.00001) && (m < 0.00001) )
      for (i = 0; i < this->length; i++)
	 vn->set(i, 0);
   else
   {
      for (i = 0; i < this->length; i++)
	 vn->set(i, this->vect[i] / m);
   }
   
   return vn;
}


// --------------------------------------------------
bool S3DVector::isZero (double prec)
{
   unsigned int i;

   for (i = 0; i < this->length; i++)
      if (fabs(this->vect[i]) > fabs(prec))
	 return false;

   return true;
}


// --------------------------------------------------
bool S3DVector::isEqual (S3DVector *v, double prec)
{
   unsigned int i;

   for (i = 0; i < this->length; i++)
      if (fabs(this->vect[i] - v->get(i)) > fabs(prec))
	 return false;

   return true;
}


// --------------------------------------------------
double S3DVector::distance (S3DVector *v)
{
   unsigned int i;
   double p, m;

   p = 0;
   for (i = 0; i < this->length; i++)
   {
      m = this->vect[i] - v->get(i);
      p += (m * m);
   }

   return sqrt(p);
}


// --------------------------------------------------
S3DVector *S3DVector::mult4x4Matrix (S3DMatrix *m)
{
   double p;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(this->length);

   for (j = 0; j < this->length; j ++)
   {
      p = 0;

      for (i = 0; i < this->length; i ++)
	 p += this->vect[j] * m->get(j, i);

      vn->set(j, p);
   }

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::mult4x4Matrix (double m[16])
{
   double p;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(this->length);

   for (j = 0; j < this->length; j ++)
   {
      p = 0;

      for (i = 0; i < this->length; i ++)
	 p += this->vect[j] * m[j + i * 4];

      vn->set(j, p);
   }

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::mult3x3Matrix (double m[9])
{
   double p;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(this->length);

   for (j = 0; j < this->length; j ++)
   {
      p = 0;

      for (i = 0; i < this->length; i ++)
	 p += this->vect[j] * m[j + i * 3];

      vn->set(j, p);
   }

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::mult3x3Matrix (S3DMatrix *m)
{
   double p;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(this->length);

   for (j = 0; j < this->length; j ++)
   {
      p = 0;

      for (i = 0; i < this->length; i ++)
	 p += this->vect[j] * m->get(j, i);

      vn->set(j, p);
   }

   return vn;
}


// --------------------------------------------------
S3DVector *S3DVector::copy (void)
{
   double m;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(this->length);
   vn->set(this->vect);
}


// --------------------------------------------------
S3DVector *S3DVector::copyWithLength (unsigned int newLength)
{
   int n;
   S3DVector *vn;
   unsigned int i, j;

   vn = new S3DVector(newLength);
   vn->setZero();

   if (this->length < newLength)
      n = this->length;
   else
      n = newLength;

   for (i = 0; i < n; i ++)
      vn->set(i, this->vect[i]);

   return vn;
}


// --------------------------------------------------
void S3DVector::setZero (void)
{
   memset(this->vect, 0, sizeof(double) * this->length);
}


// --------------------------------------------------
unsigned int S3DVector::getLength (void)
{
   return this->length;
}


// --------------------------------------------------
double *S3DVector::getRaw (void)
{
   return this->vect;
}


// --------------------------------------------------
S3DVector *S3DVector::tangent (S3DVector *v0, S3DVector *v1,
			       S3DVector *uv0, S3DVector *uv1)
{
   long int i;
   S3DVector *tangent, *tangent0, *n0, *n;
   float x, y, z;
   float coef;

   if ( (v0 == 0) || (v1 == 0) || (uv0 == 0) || (uv1 == 0) )
      return 0;

   coef = 1.0 / (float) (uv0->X() * uv1->Y() - uv1->X() * uv0->Y());
   n0 = v0->cross(v1);
   n = n0->normalize();

   x = coef * ((v0->X() * uv1->Y())  + (v1->X() * -uv0->Y()));
   y = coef * ((v0->Y() * uv1->Y())  + (v1->Y() * -uv0->Y()));
   z = coef * ((v0->Z() * uv1->Y())  + (v1->Z() * -uv0->Y()));

   tangent0 = new S3DVector(x, y, z);
   tangent = tangent0->normalize();
   
   delete n;

   return tangent;
}


// --------------------------------------------------
S3DVector *S3DVector::binormal (S3DVector *v0, S3DVector *v1,
				S3DVector *uv0, S3DVector *uv1)
{
   long int i;
   S3DVector *tangent, *binormal, *binormal0, *n, *n0;
   float x, y, z;
   float coef;

   if ( (v0 == 0) || (v1 == 0) || (uv0 == 0) || (uv1 == 0) )
      return 0;

   coef = 1.0 / (float) (uv0->X() * uv1->Y() - uv1->X() * uv0->Y());
   n0 = v0->cross(v1);
   n = n0->normalize();

   x = coef * ((v0->X() * uv1->Y())  + (v1->X() * -uv0->Y()));
   y = coef * ((v0->Y() * uv1->Y())  + (v1->Y() * -uv0->Y()));
   z = coef * ((v0->Z() * uv1->Y())  + (v1->Z() * -uv0->Y()));

   tangent = new S3DVector(x, y, z);
   binormal0 = n->cross(tangent);
   binormal = binormal0->normalize();

   delete n0;
   delete binormal0;
   delete tangent;
   delete n;

   return binormal;
}

// --------------------------------------------------
void S3DVector::print (void)
{
   this->print(0);
}


// --------------------------------------------------
void S3DVector::print (const char *str)
{
   unsigned int i, le;
   const char *color = "\033[22;34m";
   const char *black = "\033[22;30m";

   le = this->length - 1;
   if (str == 0)
      std::cerr << color << "Vector: {";
   else
      std::cerr << color << "Vector \"" << str << "\": {";

   std::cerr << black;

   for (i = 0; i < le; i ++)
      std::cerr << this->vect[i] << ", ";

   std::cerr << this->vect[le] << color << "}";
   std::cerr << black << std::endl;

   return;
}

